#!/usr/bin/env python3
"""Evaluate explicit Proposed-GAT checkpoints with the recovered Fig. 5 rule."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from models.model import calculate_achievable_rate  # noqa: E402
from utils.artifacts import (  # noqa: E402
    expected_dataset_metadata,
    load_validated_dataset,
    paper_dataset_paths,
)
from utils.feasibility import (  # noqa: E402
    decode_endpoint_mutual_matching,
    shared_uav_action_audit,
)
from utils.project_setup import (  # noqa: E402
    build_gat_scheduler,
    load_config,
)


def paper_config(num_uav: int) -> dict:
    config = load_config(ROOT / "configs/paper.yaml")
    config.update({
        "NUM_UAV": int(num_uav),
        "TX_POWER": 10.0,
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": 5.0,
        "CSI_MODE": "perfect",
    })
    return config


def canonical_test(num_uav: int):
    config = paper_config(num_uav)
    seeds = {"train": 10086, "val": 10087, "test": 10088}
    sizes = {"train": 500, "val": 128, "test": 128}
    metadata = expected_dataset_metadata(config, num_uav, seeds, sizes)
    _, path = paper_dataset_paths(ROOT / "datasets/paper", num_uav, seeds, sizes)
    payload = load_validated_dataset(path, metadata, ("test",))
    return payload["test_set"], metadata["fingerprint"], path


def load_explicit_checkpoint(path: Path, train_num_uav: int, device: torch.device):
    payload = torch.load(path, map_location=device, weights_only=False)
    if int(payload["num_uav"]) != int(train_num_uav):
        raise ValueError(
            f"{path}: checkpoint N={payload['num_uav']} != label N={train_num_uav}"
        )
    expected = {
        "tx_power_dbm": 10.0,
        "channel_model": "rician",
        "rician_k_db": 5.0,
        "csi_mode": "perfect",
    }
    for key, value in expected.items():
        if payload.get(key) != value:
            raise ValueError(f"{path}: {key}={payload.get(key)!r}, expected {value!r}")
    model = build_gat_scheduler(paper_config(train_num_uav), raw_node_dim=1)
    model.load_state_dict(payload["model_state_dict"])
    model.to(device).eval()
    return model, payload


def priority_values(pi: torch.Tensor, state, rule: str) -> torch.Tensor:
    values = pi.reshape(-1).float().cpu()
    if rule == "pi":
        return values
    tx, rx = state.links[:, 0], state.links[:, 1]
    snr = state.signal_power[tx, rx].cpu() / state.noise_power
    solo_rate = torch.log2(1.0 + snr / state.snr_gap).float()
    return values * solo_rate


def evaluate(model, test_set, priority_rule: str) -> dict:
    rates, active_fractions, active_sets = [], [], []
    probability_means, probability_maxima, candidate_counts = [], [], []
    device = next(model.parameters()).device
    with torch.no_grad():
        for sample_index, state in enumerate(test_set):
            pi, _ = model(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
            )
            probability = pi.reshape(-1).float().cpu()
            candidate = (probability >= 0.5).float()
            probability_means.append(float(probability.mean()))
            probability_maxima.append(float(probability.max()))
            candidate_counts.append(int(candidate.sum()))
            action, decoder_audit = decode_endpoint_mutual_matching(
                candidate,
                state.links,
                priorities=priority_values(pi, state, priority_rule),
                max_rounds=1,
            )
            final_audit = shared_uav_action_audit(action, state.links)
            if not final_audit["binary"] or not final_audit["feasible"]:
                raise RuntimeError(
                    f"sample {sample_index}: recovered decoder returned "
                    "a non-binary or shared-UAV-infeasible action"
                )
            rate = calculate_achievable_rate(
                action.reshape(-1, 1),
                state,
                binary=True,
                detach_hard=True,
            ).sum()
            rates.append(float(rate))
            active_fractions.append(float(action.float().mean()))
            active_sets.append(torch.nonzero(
                action.reshape(-1) > 0.5, as_tuple=True
            )[0].tolist())
    values = np.asarray(rates, dtype=float)
    return {
        "mean_aggregate_phy_rate_mbps": float(5.0 * values.mean()),
        "sem_aggregate_phy_rate_mbps": float(
            5.0 * values.std(ddof=1) / np.sqrt(len(values))
        ),
        "mean_active_fraction": float(np.mean(active_fractions)),
        "mean_probability": float(np.mean(probability_means)),
        "mean_snapshot_max_probability": float(np.mean(probability_maxima)),
        "mean_candidate_active_links": float(np.mean(candidate_counts)),
        "zero_candidate_snapshot_fraction": float(np.mean(
            np.asarray(candidate_counts) == 0
        )),
        "per_sample_probability_mean": probability_means,
        "per_sample_probability_max": probability_maxima,
        "per_sample_candidate_active_links": candidate_counts,
        "per_sample_rate_mbps": (5.0 * values).tolist(),
        "per_sample_active_project_link_indices": active_sets,
    }


def parse_checkpoint(value: str) -> tuple[int, Path]:
    label, separator, path = value.partition("=")
    if not separator:
        raise argparse.ArgumentTypeError("checkpoint must be TRAIN_N=/path/model.pth")
    try:
        train_num_uav = int(label)
    except ValueError as error:
        raise argparse.ArgumentTypeError("TRAIN_N must be an integer") from error
    checkpoint = Path(path).expanduser().resolve()
    if not checkpoint.is_file():
        raise argparse.ArgumentTypeError(f"checkpoint not found: {checkpoint}")
    return train_num_uav, checkpoint


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tensor_signature(value: torch.Tensor) -> dict:
    tensor = value.detach().cpu().contiguous()
    array = tensor.numpy()
    return {
        "shape": list(array.shape),
        "dtype": str(array.dtype),
        "sha256": hashlib.sha256(array.tobytes()).hexdigest(),
        "min": float(array.min()) if array.size else None,
        "max": float(array.max()) if array.size else None,
        "mean": float(array.mean()) if array.size else None,
        "std": float(array.std()) if array.size else None,
    }


def state_signature(state) -> dict:
    """Compact input signature for diagnosing server/local preprocessing drift."""
    return {
        "links": tensor_signature(state.links),
        "raw_node_feature_snr_db": tensor_signature(
            state.vertex_features[:, :1]
        ),
        "edge_index": tensor_signature(state.edge_index),
        "edge_weights": tensor_signature(state.edge_weights),
        "signal_power": tensor_signature(state.signal_power),
        "noise_power": float(state.noise_power),
        "snr_gap": float(state.snr_gap),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint",
        action="append",
        required=True,
        type=parse_checkpoint,
        help="Repeatable TRAIN_N=/absolute/or/relative/checkpoint.pth",
    )
    parser.add_argument("--test-nodes", default="20,50")
    parser.add_argument("--priority", choices=("pi", "direct_rate"), default="pi")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("--device cuda requested but CUDA is unavailable")
    device = torch.device(
        "cuda" if args.device == "auto" and torch.cuda.is_available()
        else args.device if args.device != "auto" else "cpu"
    )
    test_nodes = [int(value) for value in args.test_nodes.split(",") if value]
    results, checkpoints, models = {}, {}, {}
    for train_num_uav, checkpoint_path in args.checkpoint:
        model, checkpoint_payload = load_explicit_checkpoint(
            checkpoint_path, train_num_uav, device
        )
        models[train_num_uav] = model
        checkpoints[str(train_num_uav)] = {
            "path": str(checkpoint_path),
            "sha256": sha256(checkpoint_path),
            "train_size": checkpoint_payload.get("config", {}).get("TRAIN_SIZE"),
            "dataset_fingerprint": checkpoint_payload.get("dataset_fingerprint"),
            "best_epoch": checkpoint_payload.get("best_epoch"),
            "checkpoint_selection": checkpoint_payload.get(
                "checkpoint_selection", "historical_best_validation"
            ),
        }
        results[str(train_num_uav)] = {}

    test_metadata = {}
    # A large-N test split contains dense graph tensors.  Load one test scale at
    # a time so the recovery audit does not retain N=20/30/40/50 simultaneously.
    for test_num_uav in test_nodes:
        test_set, fingerprint, test_path = canonical_test(test_num_uav)
        test_metadata[str(test_num_uav)] = {
            "path": str(test_path),
            "file_sha256": sha256(test_path),
            "fingerprint_500_128_128": fingerprint,
            "samples": len(test_set),
            "first_three_state_signatures": [
                state_signature(state) for state in test_set[:3]
            ],
        }
        for train_num_uav, _ in args.checkpoint:
            result = evaluate(
                models[train_num_uav], test_set, args.priority
            )
            results[str(train_num_uav)][str(test_num_uav)] = result
            print(
                f"train N={train_num_uav} -> test N={test_num_uav}: "
                f"{result['mean_aggregate_phy_rate_mbps']:.6f} Mbit/s",
                flush=True,
            )
        del test_set

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({
        "schema": "cross_n_history_recovery_v1",
        "created_at": datetime.now().astimezone().isoformat(),
        "device": str(device),
        "recovered_evaluation": {
            "candidate": "pi >= 0.5",
            "decoder": "one_round_endpoint_mutual_matching",
            "priority": args.priority,
            "settlement": "current true instantaneous Rician channel",
        },
        "checkpoints": checkpoints,
        "test_sets": test_metadata,
        "results": results,
    }, indent=2) + "\n", encoding="utf-8")
    print(f"saved {output}", flush=True)


if __name__ == "__main__":
    main()
