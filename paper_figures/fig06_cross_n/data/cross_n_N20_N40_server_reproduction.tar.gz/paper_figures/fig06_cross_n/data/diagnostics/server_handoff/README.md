# N=20 与 N=40 模型在同一个 N=20 测试集上的最小复现

整个最小复现包（包含 N=20 test set、两个 checkpoint、必要源码、参考结果和
环境清单）：

```text
paper_figures/fig06_cross_n/data/diagnostics/server_handoff/cross_n_N20_N40_server_reproduction.tar.gz
```

## 这次比较到底是什么

不是把两个模型都在 N=20 上训练。

- **N=20 模型**：在 N=20、500 个训练快照上训练。
- **N=40 模型**：在 N=40、500 个训练快照上训练。
- **测试时**：两个模型都直接作用于完全相同的 N=20 test set，不微调、不重新训练。

因此，这个实验测的是 N=40 模型向 N=20 网络的零样本跨规模迁移。

## 对应代码

- 模型训练入口：`train/train_channel_gat_rician.py`
- 训练循环与 best-validation checkpoint 选择：`train/trainer.py`
- GAT 模型：`models/model.py`
- 模型统一构造：`utils/project_setup.py`
- 数据与图状态生成：`utils/network_generate.py`
- 数据集元数据和 fingerprint 检查：`utils/artifacts.py`
- 本次显式 checkpoint 对比入口：
  `paper_figures/fig06_cross_n/diagnostics/evaluate_recovered_checkpoints.py`
- 历史恢复说明：
  `paper_figures/fig06_cross_n/data/diagnostics/HISTORY_RECOVERY.md`

## 两个 checkpoint

### N=20、500 个训练样本

路径：

```text
paper_figures/fig06_cross_n/data/diagnostics/retrained/N20_train500_best.pth
```

SHA256：

```text
7c8b292ce01735b6a2132de27042e13d21e9aa90aa5fcca3822a1840a8292935
```

关键信息：训练 N=20，train/val/test=500/128/128，model seed=10086，
best epoch=19，数据 fingerprint=
`cfc25c9dfdeb0ea7c5547399bfcb889f7e5d037e1bf8a23e08053941d7caf43d`。

### N=40、500 个训练样本

路径：

```text
paper_figures/fig06_cross_n/data/diagnostics/retrained/N40_train500_best.pth
```

SHA256：

```text
b55b926061a9fb1b880140dde3aef52b2e04fdd4eb81e6f4ff7651c916d247a4
```

关键信息：训练 N=40，train/val/test=500/128/128，model seed=10086，
best epoch=27，数据 fingerprint=
`a358f9d9ee1137c473a05500c4ab6684f72d981da8554ec2ff40043bb0ef8c18`。

## 两个模型共用的 N=20 测试集

```text
datasets/paper/rician_K5_tx10/perfect/N20/test_seed10088_n128.pkl
```

- 文件 SHA256：
  `c0f038dd0cbe7de5898d440277f4510c3dc698dea6f08dbc87656232e726f97b`
- 数据 fingerprint：
  `cfc25c9dfdeb0ea7c5547399bfcb889f7e5d037e1bf8a23e08053941d7caf43d`
- 128 个测试快照。

## 一条命令复现

在仓库根目录执行：

```bash
conda run --no-capture-output -n pytorch python -u \
  paper_figures/fig06_cross_n/diagnostics/evaluate_recovered_checkpoints.py \
  --checkpoint 20=paper_figures/fig06_cross_n/data/diagnostics/retrained/N20_train500_best.pth \
  --checkpoint 40=paper_figures/fig06_cross_n/data/diagnostics/retrained/N40_train500_best.pth \
  --test-nodes 20 --priority pi --device cpu \
  --output paper_figures/fig06_cross_n/data/diagnostics/server_handoff/server_result.json
```

本机的完整参考输出在：

```text
paper_figures/fig06_cross_n/data/diagnostics/server_handoff/N20_N40_train500_on_testN20.json
```

## 本机应复现的数值

| 训练规模 | 测试规模 | 平均总速率 (Mbit/s) | 平均 pi | 平均 pi>=0.5 候选数 | 解码后激活比例 |
|---:|---:|---:|---:|---:|---:|
| 20 | 20 | 101.332997 | 0.05041856 | 7.6328125 | 0.03097119 |
| 40 | 20 | 88.352453 | 0.04038817 | 6.1796875 | 0.02555517 |

共同规则为：输入 `state.vertex_features[:, :1]`，模型处于 `eval()`；
以 `pi >= 0.5` 形成候选集合；按 pi 进行一轮端点互选；最后使用当前真实
Rician 信道结算速率。

服务器得到 N=40→20 的平均 pi=0.0045、速率约11 Mbit/s，并不是本机结果的
小幅波动：平均 pi 约小9倍、速率约小8倍，而且差异已经在解码前出现。

## 服务器排查顺序

1. 先运行 `sha256sum -c
   paper_figures/fig06_cross_n/data/diagnostics/server_handoff/CHECKSUMS.sha256`。
   checkpoint 或 test-set 任一哈希不同，都不要继续比较数值。
2. 比较参考 JSON 中
   `test_sets.20.first_three_state_signatures`。前三个快照的 raw SNR、
   `edge_index` 和 `edge_weights` 哈希必须逐项一致。
3. 确认推理输入是 dB 形式的第一列
   `state.vertex_features[:, :1]`，没有额外转成线性值，也没有再次标准化。
4. 必须通过 `build_gat_scheduler(config, raw_node_dim=1)` 构造模型，再加载
   `model_state_dict`，然后调用 `model.eval()`。
5. 特别检查 `input_feature_mean` 和 `input_feature_std`：它们在当前模型中是
   `persistent=False` buffer，不进入 checkpoint 的 `state_dict`。本次复现使用
   构造器默认值 mean=0、std=1。服务器如果从数据重新计算并传入归一化统计，
   即使 checkpoint 完全相同，前向结果也会改变。
6. 平均 pi 一致后，再比较阈值和互选解码。平均 pi 尚不一致时，不要用后处理规则
   解释吞吐量差异。

## 环境

完整环境导出：

```text
paper_figures/fig06_cross_n/data/diagnostics/server_handoff/pytorch_environment_no_builds.yml
```

本机核心版本：Python 3.12.11、PyTorch 2.8.0.dev20250622、
PyG 2.6.1、NumPy 2.3.0、NetworkX 3.5。这个最小评估不依赖 SciPy。

建议先在服务器现有环境中核对 checkpoint、数据和输入签名，不要立即重建环境。
若签名一致而 pi 不一致，再使用该 YAML 创建隔离环境做第二次核验。
