# 跨规模泛化历史恢复记录

## 已恢复的旧实验事实

- 旧 `fig05_cross_n` 运行于 2026-07-21，测试数据元数据为
  `train/val/test = 500/128/128`。
- 旧四个正式 Proposed-GAT checkpoint 均由 2026-07-20 的正式 Fig. 1
  pipeline 触发，训练命令等价于
  `train/train_channel_gat_rician.py --num_uav N --epochs 30`；当时该脚本默认
  `train_size=500`。
- 旧评估规则是 `pi >= 0.5` 后进行一轮端点互选，互选优先级为 `pi`，最终在
  当前真实 Rician 信道上结算。
- 代码整理后的正式 checkpoint 改为 `train_size=300`；当前本机复现表明它们在
  不同测试规模上的动作和速率几乎相同。

## 旧实验原始速率（从运行记录恢复）

单位为 Mbit/s；行是训练规模，列是测试规模。

| train \ test | 20 | 30 | 40 | 50 |
|---:|---:|---:|---:|---:|
| 20 | 101.333 | 136.110 | 166.527 | 192.821 |
| 30 | 101.110 | 136.092 | 166.712 | 193.397 |
| 40 | 73.291 | 136.319 | 166.712 | 193.858 |
| 50 | 0.000 | 59.324 | 160.506 | 193.771 |

## 单变量恢复实验

所有恢复模型写到 `data/diagnostics/retrained/`，不会覆盖
`results/models/paper/`。

```bash
# 复训旧设置 N=20（500样本、30 epoch、旧随机种子）
conda run --no-capture-output -n pytorch python -u \
  train/train_channel_gat_rician.py \
  --num_uav 20 --train_size 500 --epochs 30 --device cpu \
  --checkpoint_out paper_figures/fig06_cross_n/data/diagnostics/retrained/N20_train500_best.pth \
  --report_out paper_figures/fig06_cross_n/data/diagnostics/retrained/N20_train500_report.json

# 复训旧设置 N=50
conda run --no-capture-output -n pytorch python -u \
  train/train_channel_gat_rician.py \
  --num_uav 50 --train_size 500 --epochs 30 --device cpu \
  --checkpoint_out paper_figures/fig06_cross_n/data/diagnostics/retrained/N50_train500_best.pth \
  --report_out paper_figures/fig06_cross_n/data/diagnostics/retrained/N50_train500_report.json

# 用恢复的旧 Fig. 5 解码规则，在相同 N=20/50 test set 上比较
conda run --no-capture-output -n pytorch python -u \
  paper_figures/fig06_cross_n/diagnostics/evaluate_recovered_checkpoints.py \
  --checkpoint 20=paper_figures/fig06_cross_n/data/diagnostics/retrained/N20_train500_best.pth \
  --checkpoint 50=paper_figures/fig06_cross_n/data/diagnostics/retrained/N50_train500_best.pth \
  --test-nodes 20,50 --priority pi \
  --output paper_figures/fig06_cross_n/data/diagnostics/retrained/cross_n_train500_N20_N50.json
```

判定标准：若恢复的 N=50 模型在 test N=20 上重新出现接近零激活/零速率，而
当前300样本 N=50 模型在同一测试集上保持正常，则训练样本数及其导致的checkpoint
优化轨迹就是泛化差异消失的直接原因；否则继续回退 checkpoint 选择和训练器版本。

## 2026-07-29 实际恢复结果

为避免 N=50 的约5小时本地训练，完成了 N=20 与 N=40 的500样本完整复训。

- N=20 恢复模型精确复现旧记录：best epoch=19、test utility=
  25.7454429、旧规则 test N=20 速率=101.332997 Mbit/s。
- N=40 恢复模型精确复现旧训练统计：best epoch=27、best validation
  utility=42.9163、test utility=41.5369864、专用test集平均二元激活链路数
  13.4921875。
- 在同一个 test N=20 和旧 `priority=pi` 解码器上：
  - 当前300样本 N=40：101.457119 Mbit/s；
  - 恢复500样本 N=40：88.352453 Mbit/s；
  - 500样本模型相对300样本模型下降12.916%，相对专用N=20模型为0.8719。
- 旧2026-07-21单次运行的 N=40→20 为73.291 Mbit/s（相对值约0.72）。
  因此500样本复训恢复了“大规模训练、小规模测试受损”的方向，但没有稳定复现旧退化
  幅度。

输出审计说明了直接机制：在 test N=20 上，300样本 N=40 模型平均有7.664条
`pi>=0.5`候选，500样本 N=40 模型只有6.180条；解码后的激活比例由0.03111降至
0.02556。两者解码动作完全相同的快照只有38.28%，活动集合平均Jaccard相似度为
0.7552。两者均没有全零候选快照。因此本次N=40退化不是N=50旧结果那种“全零崩溃”，
而是大规模训练模型在小图上的输出尺度更保守，固定0.5阈值减少并改变了候选链路。

### 当前结论

代码整理时把正式训练量从500改为300并重训checkpoint，是泛化差异消失的主要直接
原因；模型前向结构和基础训练损失在相关提交之间没有实质变化。与此同时，旧热图中
N=50→20为0及N=40→20下降到0.72的幅度对单次训练轨迹和固定0.5阈值敏感，不能作为
稳定泛化规律直接写入论文。正式实验应固定训练量后至少使用多个model seeds，报告均值/
方差，并额外报告阈值前的概率或候选激活审计。
