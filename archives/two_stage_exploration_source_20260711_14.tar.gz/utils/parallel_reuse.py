"""Physical utilities for one-round conditional spatial reuse.

The exact margin functions are useful as centralized diagnostic oracles.  The
conflict-graph margin keeps only interference terms already represented by a
link's conflict neighbors and is therefore the local quantity used by the
deployable LocalPhysicalReuse scheduler.
"""

import torch


# Retain the state object so a recycled Python id cannot return stale tensors.
_PHYSICAL_GAIN_CACHE = {}
_LOCAL_EDGE_GAIN_CACHE = {}


def _signal_power_matrix(state):
    """Return the received-power matrix consistent with the selected CSI."""
    mode = getattr(state, "csi_mode", "perfect")
    if mode == "large_scale":
        signal_power = getattr(state, "signal_power_large_scale", None)
    elif mode == "quantized":
        signal_power = getattr(state, "signal_power_quant", None)
    else:
        signal_power = state.signal_power
    if signal_power is None:
        signal_power = state.signal_power
    return signal_power.detach().cpu()


def local_edge_gains(state):
    """Return direct and conflict-edge gains without forming an L-by-L matrix."""
    cache_key = id(state)
    cached = _LOCAL_EDGE_GAIN_CACHE.get(cache_key)
    if cached is not None and cached[0] is state:
        return cached[1], cached[2], cached[3], cached[4]

    signal_power = _signal_power_matrix(state)
    links = state.links.detach().cpu()
    link_tx = links[:, 0]
    link_rx = links[:, 1]
    direct = signal_power[link_tx, link_rx]
    edge_index = state.edge_index.detach().cpu()
    source, target = edge_index
    if source.numel() > 0:
        edge_gain = signal_power[link_tx[source], link_rx[target]]
    else:
        edge_gain = torch.empty(0, dtype=direct.dtype)
    _LOCAL_EDGE_GAIN_CACHE[cache_key] = (
        state, direct, source, target, edge_gain
    )
    return direct, source, target, edge_gain


def physical_gain_matrix(state):
    """Return direct gains and directed link-to-link interference gains."""
    cache_key = id(state)
    cached = _PHYSICAL_GAIN_CACHE.get(cache_key)
    if cached is not None and cached[0] is state:
        return cached[1], cached[2]

    signal_power = _signal_power_matrix(state)
    links = state.links.detach().cpu()
    link_tx = links[:, 0]
    link_rx = links[:, 1]
    direct = signal_power[link_tx, link_rx]
    gains = signal_power[link_tx[None, :], link_rx[:, None]].clone()
    gains.fill_diagonal_(0.0)
    _PHYSICAL_GAIN_CACHE[cache_key] = (state, direct, gains)
    return direct, gains


def join_margins_from_gains(state, queues, base_action, direct, gains):
    """Compute single-join MWS margins for a supplied interference matrix."""
    queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).cpu()
    base = torch.as_tensor(base_action, dtype=torch.float32).reshape(-1).cpu()
    base = torch.round(base)
    noise = torch.as_tensor(state.noise_power, dtype=torch.float32).cpu()
    snr_gap = float(getattr(state, "snr_gap", 1.0))

    interference = gains @ base
    base_spectral_efficiency = torch.log2(
        1.0 + direct / (interference + noise) / snr_gap
    )

    # Column j is every existing link's rate if inactive candidate j joins.
    joined_efficiency = torch.log2(
        1.0
        + direct[:, None]
        / (interference[:, None] + gains + noise)
        / snr_gap
    )
    existing_change = (
        queues[:, None]
        * base[:, None]
        * (joined_efficiency - base_spectral_efficiency[:, None])
    ).sum(dim=0)
    candidate_gain = queues * base_spectral_efficiency
    margins = candidate_gain + existing_change
    valid = (queues > 0) & (base <= 0)
    return torch.where(
        valid, margins, torch.full_like(margins, float("-inf"))
    )


def exact_join_margins(state, queues, base_action):
    """Compute all inactive links' centralized single-join MWS margins."""
    direct, gains = physical_gain_matrix(state)
    return join_margins_from_gains(state, queues, base_action, direct, gains)


def conflict_graph_local_join_margins(state, queues, base_action):
    """Compute local join margins in O(L+E), using conflict edges only."""
    queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).cpu()
    base = torch.as_tensor(
        base_action, dtype=torch.float32
    ).reshape(-1).round().cpu()
    direct, source, target, edge_gain = local_edge_gains(state)
    noise = torch.as_tensor(state.noise_power, dtype=torch.float32).cpu()
    snr_gap = float(getattr(state, "snr_gap", 1.0))

    interference = torch.zeros_like(direct)
    if source.numel() > 0:
        interference.index_add_(0, target, edge_gain * base[source])
    base_efficiency = torch.log2(
        1.0 + direct / (interference + noise) / snr_gap
    )

    existing_change = torch.zeros_like(direct)
    if source.numel() > 0:
        joined_efficiency = torch.log2(
            1.0
            + direct[target]
            / (interference[target] + edge_gain + noise)
            / snr_gap
        )
        edge_change = (
            queues[target]
            * base[target]
            * (joined_efficiency - base_efficiency[target])
        )
        existing_change.index_add_(0, source, edge_change)

    margins = queues * base_efficiency + existing_change
    valid = (queues > 0) & (base <= 0)
    return torch.where(
        valid, margins, torch.full_like(margins, float("-inf"))
    )


def topk_safety_join_margins(state, queues, base_action, topk):
    """Add each victim's strongest omitted interferers to the safety view.

    The original conflict graph still determines which candidates compete.
    These extra directed pairs are used only to estimate cumulative physical
    harm.  ``topk=0`` is exactly the conflict-graph local margin.
    """
    topk = int(topk)
    if topk < 0:
        raise ValueError("topk must be nonnegative")
    direct, gains = physical_gain_matrix(state)
    local_gains = torch.zeros_like(gains)
    represented = torch.eye(gains.size(0), dtype=torch.bool)
    if state.edge_index.numel() > 0:
        source, target = state.edge_index.detach().cpu()
        local_gains[target, source] = gains[target, source]
        represented[target, source] = True

    if topk > 0 and gains.numel() > 0:
        omitted = gains.masked_fill(represented, float("-inf"))
        k = min(topk, max(gains.size(1) - 1, 0))
        if k > 0:
            values, aggressors = torch.topk(omitted, k=k, dim=1)
            victims = torch.arange(gains.size(0))[:, None].expand_as(aggressors)
            valid = torch.isfinite(values) & (values > 0)
            local_gains[victims[valid], aggressors[valid]] = values[valid]

    return join_margins_from_gains(
        state, queues, base_action, direct, local_gains
    )


def select_local_positive_maxima(scores, valid, edge_index):
    """Keep positive valid candidates that beat every conflict neighbor."""
    scores = torch.as_tensor(scores, dtype=torch.float32).reshape(-1).cpu()
    valid = torch.as_tensor(valid, dtype=torch.bool).reshape(-1).cpu()
    candidates = valid & torch.isfinite(scores) & (scores > 0.0)
    if not candidates.any() or edge_index.numel() == 0:
        return candidates

    source, target = edge_index.detach().cpu()
    both = candidates[source] & candidates[target]
    source_loses = both & (
        (scores[source] < scores[target])
        | ((scores[source] == scores[target]) & (source > target))
    )
    target_loses = both & (
        (scores[target] < scores[source])
        | ((scores[target] == scores[source]) & (target > source))
    )
    losers = torch.zeros_like(candidates)
    losers[source[source_loses]] = True
    losers[target[target_loses]] = True
    return candidates & ~losers


def local_margin_winners(margins, edge_index):
    """Select strict local maxima among finite positive-margin candidates."""
    return select_local_positive_maxima(
        margins, torch.isfinite(margins), edge_index
    )
