import torch

from models.model import calculate_achievable_rate


def mws_objective(schedule, queues, state):
    """Return sum_i Q_i R_i for one binary schedule."""
    rates = calculate_achievable_rate(
        schedule.reshape(-1, 1), state, binary=True
    )
    return torch.sum(queues.reshape(-1) * rates.reshape(-1)).item()


def centralized_mws_greedy(state, queues):
    """Greedy global-CSI approximation to binary max-weight scheduling."""
    device = state.vertex_features.device
    queues = torch.as_tensor(queues, dtype=torch.float32, device=device).reshape(-1)
    schedule = torch.zeros(state.num_vertices, device=device)
    nonempty = (queues > 0).nonzero(as_tuple=True)[0]
    if nonempty.numel() == 0:
        return schedule.unsqueeze(1)

    isolated = []
    for idx in nonempty.tolist():
        candidate = torch.zeros_like(schedule)
        candidate[idx] = 1.0
        isolated.append((mws_objective(candidate, queues, state), idx))

    current = 0.0
    for _, idx in sorted(isolated, reverse=True):
        candidate = schedule.clone()
        candidate[idx] = 1.0
        utility = mws_objective(candidate, queues, state)
        if utility > current + 1e-10:
            schedule, current = candidate, utility

    improved = True
    while improved:
        improved = False
        for idx in (schedule > 0).nonzero(as_tuple=True)[0].tolist():
            candidate = schedule.clone()
            candidate[idx] = 0.0
            utility = mws_objective(candidate, queues, state)
            if utility > current + 1e-10:
                schedule, current, improved = candidate, utility, True
    return schedule.unsqueeze(1)
