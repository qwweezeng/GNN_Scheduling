import torch

from models.two_stage_v2 import (
    bidirectional_conflict_edges,
    structured_competition_logits,
)


def _edge(source, target, weight):
    return (
        torch.tensor([source, target], dtype=torch.long),
        torch.tensor(weight, dtype=torch.float32).unsqueeze(1),
    )


def test_bidirectional_edges_preserve_stronger_direction():
    edge_index, edge_attr = _edge([0, 1], [1, 0], [0.2, 0.8])
    result_index, result_strength = bidirectional_conflict_edges(
        edge_index, edge_attr, 2
    )
    pairs = {
        tuple(pair): float(weight)
        for pair, weight in zip(result_index.t().tolist(), result_strength.tolist())
    }
    assert set(pairs) == {(0, 1), (1, 0)}
    assert all(abs(weight - 0.8) < 1e-6 for weight in pairs.values())


def test_strong_conflict_selects_higher_priority():
    edge_index, edge_attr = _edge([0], [1], [1.0])
    logits = structured_competition_logits(
        torch.tensor([2.0, 1.0]), torch.ones(2), edge_index, edge_attr
    ).squeeze(1)
    assert logits[0] > 0
    assert logits[1] < 0


def test_weak_conflict_allows_spatial_reuse():
    edge_index, edge_attr = _edge([0], [1], [0.1])
    logits = structured_competition_logits(
        torch.tensor([1.0, 1.0]), torch.ones(2), edge_index, edge_attr
    ).squeeze(1)
    assert torch.all(logits > 0)


def test_empty_link_does_not_inhibit_nonempty_neighbor():
    edge_index, edge_attr = _edge([0], [1], [1.0])
    logits = structured_competition_logits(
        torch.tensor([10.0, 1.0]), torch.tensor([0.0, 1.0]),
        edge_index, edge_attr,
    ).squeeze(1)
    assert logits[1] > 0
