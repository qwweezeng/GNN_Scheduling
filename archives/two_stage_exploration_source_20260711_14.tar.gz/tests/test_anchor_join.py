import unittest

import torch

from models.anchor_join import AnchorJoinDecoder


class AnchorJoinDecoderTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(17)
        self.model = AnchorJoinDecoder(hidden_dim=8, num_rounds=2).eval()
        self.solo = torch.tensor([1.0, 2.0, 3.0])
        self.harm = torch.tensor([0.3, 0.6, 0.2])
        self.edges = torch.tensor([[0, 2, 1], [1, 1, 0]])

    def test_nonempty_input_always_has_one_anchor_probability(self):
        probability, diagnostics = self.model(
            self.solo, self.harm, torch.tensor([1.0, 2.0, 0.0]), self.edges
        )
        anchor = diagnostics["anchor_index"]
        self.assertIsNotNone(anchor)
        self.assertEqual(probability[anchor].item(), 1.0)

    def test_all_empty_returns_all_zero(self):
        probability, diagnostics = self.model(
            self.solo, self.harm, torch.zeros(3), self.edges
        )
        self.assertIsNone(diagnostics["anchor_index"])
        self.assertEqual(probability.sum().item(), 0.0)

    def test_common_queue_scaling_is_invariant(self):
        queues = torch.tensor([1.0, 4.0, 2.0])
        first, first_diagnostics = self.model(
            self.solo, self.harm, queues, self.edges
        )
        second, second_diagnostics = self.model(
            self.solo, self.harm, 100.0 * queues, self.edges
        )
        self.assertEqual(
            int(first_diagnostics["anchor_index"]),
            int(second_diagnostics["anchor_index"]),
        )
        self.assertTrue(torch.allclose(first, second, atol=1e-7))

    def test_join_decisions_change_when_anchor_changes(self):
        queues = torch.tensor([1.0, 4.0, 2.0])
        first, _ = self.model(
            self.solo, self.harm, queues, self.edges,
            anchor_index=torch.tensor(0),
        )
        second, _ = self.model(
            self.solo, self.harm, queues, self.edges,
            anchor_index=torch.tensor(1),
        )
        self.assertFalse(torch.allclose(first, second))


if __name__ == "__main__":
    unittest.main()
