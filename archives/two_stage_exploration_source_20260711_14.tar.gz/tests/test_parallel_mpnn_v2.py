import unittest

import torch

from models.parallel_mpnn_v2 import ParallelMPNNv2


class ParallelMPNNv2StructureTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = ParallelMPNNv2(hidden_dim=8, num_rounds=2)
        self.solo = torch.tensor([4.0, 3.0, 2.0])
        self.harm = torch.tensor([0.8, 0.7, 0.2, 0.3])
        self.edge = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        self.queues = torch.tensor([10.0, 2.0, 5.0])

    def test_common_queue_scaling_is_invariant(self):
        first, _ = self.model(self.solo, self.harm, self.queues, self.edge)
        second, _ = self.model(self.solo, self.harm, 100 * self.queues, self.edge)
        torch.testing.assert_close(first, second, atol=1e-6, rtol=1e-6)

    def test_empty_queue_is_exactly_zero(self):
        queues = self.queues.clone()
        queues[1] = 0.0
        probability, _ = self.model(self.solo, self.harm, queues, self.edge)
        self.assertEqual(float(probability[1]), 0.0)

    def test_edge_log_ratio_is_pairwise_and_antisymmetric(self):
        _, diagnostics = self.model(
            self.solo, self.harm, self.queues, self.edge,
            return_history=True,
        )
        ratio = diagnostics["edge_log_value_ratio"]
        self.assertAlmostEqual(float(ratio[0]), -float(ratio[1]), places=6)
        self.assertAlmostEqual(float(ratio[2]), -float(ratio[3]), places=6)

    def test_disconnected_remote_queue_cannot_change_component(self):
        solo = torch.tensor([4.0, 3.0, 8.0])
        harm = torch.tensor([0.8, 0.7])
        edge = torch.tensor([[0, 1], [1, 0]])
        q1 = torch.tensor([10.0, 2.0, 1.0])
        q2 = torch.tensor([10.0, 2.0, 1e6])
        first, _ = self.model(solo, harm, q1, edge)
        second, _ = self.model(solo, harm, q2, edge)
        torch.testing.assert_close(first[:2], second[:2], atol=1e-6, rtol=1e-6)

    def test_permutation_equivariance(self):
        permutation = torch.tensor([2, 0, 1])
        inverse = torch.empty_like(permutation)
        inverse[permutation] = torch.arange(3)
        first, _ = self.model(self.solo, self.harm, self.queues, self.edge)
        permuted_edge = inverse[self.edge]
        second, _ = self.model(
            self.solo[permutation], self.harm,
            self.queues[permutation], permuted_edge,
        )
        torch.testing.assert_close(
            first[permutation], second, atol=1e-6, rtol=1e-6
        )


if __name__ == "__main__":
    unittest.main()
