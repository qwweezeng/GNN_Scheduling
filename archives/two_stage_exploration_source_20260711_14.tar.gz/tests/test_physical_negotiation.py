import unittest

import torch

from models.physical_negotiation import PhysicalNegotiationDecoder


class PhysicalNegotiationDecoderTest(unittest.TestCase):
    def test_empty_queue_is_exactly_zero(self):
        model = PhysicalNegotiationDecoder(hidden_dim=8, num_rounds=2)
        probabilities, _ = model(
            torch.tensor([2.0, 3.0]),
            torch.tensor([0.5]),
            torch.tensor([0.0, 2.0]),
            torch.tensor([[0], [1]]),
        )
        self.assertEqual(probabilities[0].item(), 0.0)

    def test_node_permutation_equivariance(self):
        torch.manual_seed(7)
        model = PhysicalNegotiationDecoder(hidden_dim=8, num_rounds=2).eval()
        solo = torch.tensor([1.0, 2.0, 3.0])
        queues = torch.tensor([2.0, 4.0, 1.0])
        edges = torch.tensor([[0, 2, 1], [1, 1, 0]])
        harm = torch.tensor([0.2, 0.7, 0.4])
        original, _ = model(solo, harm, queues, edges)

        permutation = torch.tensor([2, 0, 1])
        inverse = torch.empty_like(permutation)
        inverse[permutation] = torch.arange(3)
        permuted_edges = inverse[edges]
        permuted, _ = model(
            solo[permutation], harm, queues[permutation], permuted_edges
        )
        self.assertTrue(torch.allclose(
            permuted, original[permutation], atol=1e-6
        ))

    def test_gradients_reach_all_learning_modules(self):
        model = PhysicalNegotiationDecoder(hidden_dim=8, num_rounds=2)
        probabilities, _ = model(
            torch.tensor([1.0, 2.0]),
            torch.tensor([0.5, 0.3]),
            torch.tensor([3.0, 1.0]),
            torch.tensor([[0, 1], [1, 0]]),
        )
        probabilities.sum().backward()
        for name, parameter in model.named_parameters():
            self.assertIsNotNone(parameter.grad, name)


if __name__ == "__main__":
    unittest.main()
