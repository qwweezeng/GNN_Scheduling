import unittest

import torch

from experiments.diagnose_candidate_portfolio import (
    coverage_ratio,
    extend_portfolio,
    greedy_set_cover,
    greedy_utility_portfolio,
)


class CandidatePortfolioTest(unittest.TestCase):
    def test_utility_portfolio_selects_complementary_candidates(self):
        utility = torch.tensor([
            [10.0, 0.0, 4.0],
            [0.0, 10.0, 4.0],
        ])
        selected, best = greedy_utility_portfolio(utility, budget=2)
        self.assertEqual(set(selected), {0, 1})
        self.assertTrue(torch.equal(best, torch.tensor([10.0, 10.0])))

    def test_coverage_core_covers_every_link(self):
        candidates = torch.tensor([
            [1.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 1.0],
            [1.0, 0.0, 1.0, 0.0],
        ])
        utility = torch.tensor([
            [3.0, 2.0, 1.0],
            [1.0, 3.0, 2.0],
        ])
        selected = greedy_set_cover(candidates, utility)
        self.assertEqual(len(selected), 2)
        self.assertEqual(coverage_ratio(candidates, selected), 1.0)

    def test_coverage_core_can_be_extended_by_utility(self):
        utility = torch.tensor([
            [5.0, 0.0, 4.0],
            [0.0, 5.0, 4.0],
        ])
        selected, best = extend_portfolio([2], utility, budget=2)
        self.assertEqual(selected[0], 2)
        self.assertEqual(len(selected), 2)
        self.assertTrue(torch.all(best >= torch.tensor([4.0, 4.0])))


if __name__ == "__main__":
    unittest.main()
