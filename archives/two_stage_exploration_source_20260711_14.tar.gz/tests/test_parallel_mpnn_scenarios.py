import unittest

import torch

from experiments.parallel_mpnn_scenarios import (
    asymmetric_three_link, best_action, strong_two_link,
    two_weakly_coupled_regions, weak_two_link,
)


class ParallelMPNNScenarioTruthTest(unittest.TestCase):
    def test_strong_conflict_winner_follows_queue(self):
        queues, snr, inr = strong_two_link(torch.tensor([10.0, 1.0]))
        action, _ = best_action(queues, snr, inr)
        self.assertEqual(action.int().tolist(), [1, 0])
        queues, snr, inr = strong_two_link(torch.tensor([1.0, 10.0]))
        action, _ = best_action(queues, snr, inr)
        self.assertEqual(action.int().tolist(), [0, 1])

    def test_weak_conflict_prefers_concurrency(self):
        queues, snr, inr = weak_two_link()
        action, _ = best_action(queues, snr, inr)
        self.assertEqual(action.int().tolist(), [1, 1])

    def test_asymmetric_case_prefers_compatible_pair(self):
        queues, snr, inr = asymmetric_three_link()
        action, _ = best_action(queues, snr, inr)
        self.assertEqual(action.int().tolist(), [1, 0, 1])

    def test_disconnected_regions_compose_local_winners(self):
        queues, snr, inr = two_weakly_coupled_regions()
        action, utility = best_action(queues, snr, inr)
        self.assertEqual(action.int().tolist(), [1, 0, 0, 1])
        first_action, first_utility = best_action(
            queues[:2], snr[:2], inr[:2, :2]
        )
        second_action, second_utility = best_action(
            queues[2:], snr[2:], inr[2:, 2:]
        )
        self.assertEqual(
            action.int().tolist(),
            first_action.int().tolist() + second_action.int().tolist(),
        )
        self.assertAlmostEqual(utility, first_utility + second_utility, places=5)


if __name__ == "__main__":
    unittest.main()

