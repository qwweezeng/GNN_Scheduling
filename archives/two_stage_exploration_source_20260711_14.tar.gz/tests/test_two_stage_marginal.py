import unittest

import torch

from models.two_stage_marginal import marginal_utility_probabilities


class MarginalUtilityRuleTest(unittest.TestCase):
    @staticmethod
    def probabilities(benefit, queues, edges, harm):
        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
        if not edges:
            edge_index = torch.empty(2, 0, dtype=torch.long)
        probabilities, external_harm = marginal_utility_probabilities(
            torch.tensor(benefit, dtype=torch.float32),
            torch.tensor(queues, dtype=torch.float32),
            edge_index,
            torch.tensor(harm, dtype=torch.float32),
        )
        return probabilities, external_harm

    def test_empty_queue_never_sends(self):
        probabilities, _ = self.probabilities([2.0], [0.0], [], [])
        self.assertEqual(probabilities.item(), 0.0)

    def test_directed_harm_is_not_symmetrized(self):
        probabilities, external_harm = self.probabilities(
            [1.0, 1.0], [1.0, 1.0], [(0, 1)], [1.0]
        )
        self.assertAlmostEqual(probabilities[0].item(), 0.5)
        self.assertAlmostEqual(probabilities[1].item(), 1.0)
        self.assertAlmostEqual(external_harm[0].item(), 1.0)
        self.assertAlmostEqual(external_harm[1].item(), 0.0)

    def test_weak_mutual_harm_allows_concurrency(self):
        probabilities, _ = self.probabilities(
            [1.0, 1.0], [1.0, 1.0], [(0, 1), (1, 0)], [0.1, 0.1]
        )
        self.assertTrue(torch.all(probabilities > 0.5))

    def test_strong_mutual_harm_selects_larger_weighted_benefit(self):
        probabilities, _ = self.probabilities(
            [1.0, 1.0], [10.0, 2.0], [(0, 1), (1, 0)], [1.0, 1.0]
        )
        self.assertGreater(probabilities[0].item(), 0.5)
        self.assertLess(probabilities[1].item(), 0.5)

    def test_urgent_victim_makes_interferer_retreat(self):
        low_urgency, _ = self.probabilities(
            [1.0, 1.0], [2.0, 1.0], [(0, 1)], [0.5]
        )
        high_urgency, _ = self.probabilities(
            [1.0, 1.0], [2.0, 10.0], [(0, 1)], [0.5]
        )
        self.assertGreater(low_urgency[0].item(), 0.5)
        self.assertLess(high_urgency[0].item(), 0.5)

    def test_multiple_weak_harms_accumulate(self):
        probabilities, external_harm = self.probabilities(
            [1.0, 1.0, 1.0], [1.0, 1.0, 1.0],
            [(0, 1), (0, 2)], [0.4, 0.4]
        )
        self.assertAlmostEqual(external_harm[0].item(), 0.8, places=6)
        self.assertAlmostEqual(probabilities[0].item(), 1.0 / 1.8, places=6)


if __name__ == "__main__":
    unittest.main()
