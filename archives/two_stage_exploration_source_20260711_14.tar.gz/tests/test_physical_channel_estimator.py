import unittest

import torch

from models.physical_channel_estimator import solo_rate_from_snr_db


class SoloRateFormulaTest(unittest.TestCase):
    def test_zero_db_snr_has_one_bit_per_hz(self):
        rate = solo_rate_from_snr_db(torch.tensor([0.0]), snr_gap=1.0)
        self.assertAlmostEqual(rate.item(), 1.0, places=6)

    def test_rate_is_monotonic_in_snr(self):
        rate = solo_rate_from_snr_db(torch.tensor([-5.0, 0.0, 10.0]))
        self.assertTrue(torch.all(rate[1:] > rate[:-1]))


if __name__ == "__main__":
    unittest.main()
