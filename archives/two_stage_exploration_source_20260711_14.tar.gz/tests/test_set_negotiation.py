import unittest

import torch

from models.set_negotiation import SetNegotiation


def permute_graph(edge_index, permutation):
    inverse = torch.empty_like(permutation)
    inverse[permutation] = torch.arange(permutation.numel())
    return inverse[edge_index]


class SetNegotiationStructureTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = SetNegotiation(hidden_dim=8, num_revisions=2)
        self.solo = torch.tensor([1.0, 2.0, 1.5])
        self.queues = torch.tensor([3.0, 1.0, 2.0])
        self.edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        self.harm = torch.tensor([0.8, 0.2, 0.6, 0.3])
        self.randoms = [
            torch.tensor([0.1, 0.8, 0.4]),
            torch.tensor([0.7, 0.2, 0.9]),
            torch.tensor([0.3, 0.6, 0.1]),
        ]

    def test_fixed_randomness_is_reproducible(self):
        first, first_info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_uniforms=self.randoms, return_history=True,
        )
        second, second_info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_uniforms=self.randoms, return_history=True,
        )
        torch.testing.assert_close(first, second)
        torch.testing.assert_close(
            first_info["trajectory_log_probability"],
            second_info["trajectory_log_probability"],
        )

    def test_permutation_equivariance_with_matched_randomness(self):
        original, _ = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_uniforms=self.randoms,
        )
        permutation = torch.tensor([2, 0, 1])
        permuted, _ = self.model(
            self.solo[permutation], self.harm, self.queues[permutation],
            permute_graph(self.edges, permutation),
            random_uniforms=[item[permutation] for item in self.randoms],
        )
        torch.testing.assert_close(original[permutation], permuted)

    def test_empty_queue_never_transmits(self):
        queues = self.queues.clone()
        queues[1] = 0.0
        action, info = self.model(
            self.solo, self.harm, queues, self.edges,
            random_uniforms=self.randoms, return_history=True,
        )
        self.assertEqual(float(action[1]), 0.0)
        for intermediate in info["action_history"]:
            self.assertEqual(float(intermediate[1]), 0.0)

    def test_history_contains_proposal_and_revisions(self):
        _, info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_uniforms=self.randoms, return_history=True,
        )
        self.assertEqual(len(info["action_history"]), 3)
        self.assertEqual(len(info["probability_history"]), 3)

    def test_log_probability_backpropagates(self):
        _, info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_uniforms=self.randoms, return_history=True,
        )
        (-info["trajectory_log_probability"]).backward()
        modules = (
            self.model.channel_encoder,
            self.model.queue_encoder,
            self.model.revision_block,
            self.model.action_head,
        )
        for module in modules:
            self.assertTrue(any(
                parameter.grad is not None
                and torch.isfinite(parameter.grad).all()
                for parameter in module.parameters()
            ))

    def test_external_initial_set_is_the_first_condition(self):
        initial = torch.tensor([1.0, 0.0, 1.0])
        _, info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_uniforms=self.randoms[:2],
            initial_action=initial, return_history=True,
        )
        torch.testing.assert_close(info["action_history"][0], initial)
        self.assertEqual(len(info["action_history"]), 3)
        self.assertEqual(len(info["probability_history"]), 2)


if __name__ == "__main__":
    unittest.main()
