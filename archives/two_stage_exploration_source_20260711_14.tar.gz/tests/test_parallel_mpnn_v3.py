import unittest

import torch

from models.parallel_mpnn_v3 import ParallelMPNNv3


def permute_graph(edge_index, permutation):
    inverse = torch.empty_like(permutation)
    inverse[permutation] = torch.arange(permutation.numel())
    return inverse[edge_index]


class ParallelMPNNv3StructureTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = ParallelMPNNv3(hidden_dim=8, num_rounds=2)
        self.solo = torch.tensor([1.0, 2.0, 1.5])
        self.queues = torch.tensor([3.0, 1.0, 2.0])
        self.edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        self.harm = torch.tensor([0.8, 0.2, 0.6, 0.3])
        self.marks = torch.tensor([0.1, 0.8, 0.4])

    def test_permutation_equivariance_with_marks(self):
        original, _ = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_mark=self.marks,
        )
        permutation = torch.tensor([2, 0, 1])
        permuted, _ = self.model(
            self.solo[permutation], self.harm, self.queues[permutation],
            permute_graph(self.edges, permutation),
            random_mark=self.marks[permutation],
        )
        torch.testing.assert_close(
            permuted, original[permutation], atol=1e-6, rtol=1e-6
        )

    def test_fixed_mark_makes_forward_reproducible(self):
        first, _ = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_mark=self.marks,
        )
        second, _ = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_mark=self.marks,
        )
        torch.testing.assert_close(first, second)

    def test_empty_queue_is_exactly_zero(self):
        queues = self.queues.clone()
        queues[1] = 0.0
        probability, diagnostics = self.model(
            self.solo, self.harm, queues, self.edges,
            random_mark=self.marks,
        )
        self.assertEqual(float(probability[1]), 0.0)
        self.assertEqual(float(diagnostics["random_mark"][1]), 0.0)

    def test_common_queue_scaling_is_invariant_for_fixed_marks(self):
        first, _ = self.model(
            self.solo, self.harm, self.queues, self.edges,
            random_mark=self.marks,
        )
        second, _ = self.model(
            self.solo, self.harm, 100 * self.queues, self.edges,
            random_mark=self.marks,
        )
        torch.testing.assert_close(first, second, atol=1e-6, rtol=1e-6)


if __name__ == "__main__":
    unittest.main()
