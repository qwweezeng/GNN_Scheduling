import unittest
from types import SimpleNamespace

import torch
import torch.nn as nn

from models.two_stage_physical import TwoStagePhysicalScheduler


class DummyEstimator(nn.Module):
    def forward(self, x, edge_index, edge_attr, snr_gap=1.0):
        return torch.ones(x.size(0)), torch.zeros(edge_index.size(1))


class DummyDecoder(nn.Module):
    def forward(self, solo, harm, queues, edge_index):
        return (queues > 0).float().unsqueeze(1), solo.unsqueeze(1)


class TwoStagePhysicalSchedulerTest(unittest.TestCase):
    def test_forward_requires_queue_and_masks_empty(self):
        model = TwoStagePhysicalScheduler(DummyEstimator(), DummyDecoder())
        probability, _ = model(
            torch.ones(2, 1), torch.empty(2, 0, dtype=torch.long),
            torch.empty(0, 1), queues=torch.tensor([0.0, 2.0])
        )
        self.assertEqual(probability[0].item(), 0.0)
        self.assertEqual(probability[1].item(), 1.0)

    def test_work_conserving_fallback_activates_one_nonempty_link(self):
        class LowDecoder(nn.Module):
            def forward(self, solo, harm, queues, edge_index):
                probability = torch.tensor([[0.2], [0.4], [0.1]])
                return probability, probability

        model = TwoStagePhysicalScheduler(
            DummyEstimator(), LowDecoder(), work_conserving=True
        )
        state = SimpleNamespace(
            vertex_features=torch.ones(3, 1),
            edge_index=torch.empty(2, 0, dtype=torch.long),
            edge_weights=torch.empty(0, 1),
            snr_gap=1.0,
        )
        hard = model.schedule_with_state(state, torch.tensor([1.0, 2.0, 0.0]))
        self.assertEqual(hard.sum().item(), 1.0)


if __name__ == "__main__":
    unittest.main()
