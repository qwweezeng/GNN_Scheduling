import unittest

import torch

from models.physical_negotiation_v2 import PhysicalNegotiationDecoderV2


class PhysicalNegotiationDecoderV2Test(unittest.TestCase):
    def test_empty_queue_is_exactly_zero(self):
        model = PhysicalNegotiationDecoderV2(hidden_dim=8, num_rounds=2)
        probabilities, _ = model(
            torch.tensor([2.0, 3.0]), torch.tensor([0.5]),
            torch.tensor([0.0, 2.0]), torch.tensor([[0], [1]])
        )
        self.assertEqual(probabilities[0].item(), 0.0)

    def test_zero_harm_edges_do_not_change_output(self):
        torch.manual_seed(3)
        model = PhysicalNegotiationDecoderV2(hidden_dim=8, num_rounds=2).eval()
        solo = torch.tensor([1.0, 2.0])
        queues = torch.tensor([3.0, 4.0])
        no_edges, _ = model(
            solo, torch.empty(0), queues, torch.empty(2, 0, dtype=torch.long)
        )
        zero_harm, _ = model(
            solo, torch.tensor([0.0]), queues, torch.tensor([[0], [1]])
        )
        self.assertTrue(torch.allclose(no_edges, zero_harm, atol=1e-6))

    def test_duplicate_equal_edges_preserve_mean_but_increase_mass(self):
        # The full output may change because mass deliberately records the
        # accumulated conflict, while the normalized interaction stays bounded.
        model = PhysicalNegotiationDecoderV2(hidden_dim=8, num_rounds=1)
        hidden = torch.ones(2, 8)
        mass = torch.tensor([2.0, 0.0])
        normalized = model._normalize(2.0 * hidden, mass)
        self.assertTrue(torch.allclose(normalized[0], hidden[0]))


if __name__ == "__main__":
    unittest.main()
