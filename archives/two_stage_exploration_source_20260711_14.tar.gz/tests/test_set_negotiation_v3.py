import unittest

import torch

from models.set_negotiation import SetNegotiationV3


class SetNegotiationV3StructureTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = SetNegotiationV3(hidden_dim=8, num_revisions=2)
        self.solo = torch.tensor([1.0, 2.0, 1.5])
        self.queues = torch.tensor([3.0, 1.0, 2.0])
        self.edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        self.harm = torch.tensor([0.8, 0.2, 0.6, 0.3])
        self.initial = torch.tensor([1.0, 0.0, 1.0])
        self.randoms = [
            torch.tensor([0.1, 0.8, 0.4]),
            torch.tensor([0.7, 0.2, 0.9]),
        ]

    def test_common_positive_queue_scaling_is_exactly_invariant(self):
        first, first_info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            initial_action=self.initial, random_uniforms=self.randoms,
            return_history=True,
        )
        second, second_info = self.model(
            self.solo, self.harm, 100 * self.queues, self.edges,
            initial_action=self.initial, random_uniforms=self.randoms,
            return_history=True,
        )
        torch.testing.assert_close(first, second, atol=1e-6, rtol=1e-6)
        for first_probability, second_probability in zip(
            first_info["probability_history"],
            second_info["probability_history"],
        ):
            torch.testing.assert_close(
                first_probability, second_probability,
                atol=1e-6, rtol=1e-6,
            )

    def test_edge_log_queue_difference_is_antisymmetric(self):
        _, info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            initial_action=self.initial, random_uniforms=self.randoms,
            return_history=True,
        )
        difference = info["edge_log_queue_difference"]
        self.assertAlmostEqual(float(difference[0]), -float(difference[1]))
        self.assertAlmostEqual(float(difference[2]), -float(difference[3]))

    def test_empty_queue_never_transmits(self):
        queues = self.queues.clone()
        queues[1] = 0.0
        _, info = self.model(
            self.solo, self.harm, queues, self.edges,
            initial_action=torch.ones(3), random_uniforms=self.randoms,
            return_history=True,
        )
        for action in info["action_history"]:
            self.assertEqual(float(action[1]), 0.0)


if __name__ == "__main__":
    unittest.main()
