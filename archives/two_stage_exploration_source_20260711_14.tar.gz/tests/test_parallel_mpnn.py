import unittest

import torch

from models.parallel_mpnn import ParallelMPNN


def permute_graph(edge_index, permutation):
    inverse = torch.empty_like(permutation)
    inverse[permutation] = torch.arange(permutation.numel())
    return inverse[edge_index]


class ParallelMPNNStructureTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)

    def test_permutation_equivariance(self):
        model = ParallelMPNN(hidden_dim=8, num_rounds=2)
        solo = torch.tensor([1.0, 2.0, 1.5])
        queues = torch.tensor([3.0, 1.0, 2.0])
        edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        harm = torch.tensor([0.8, 0.2, 0.6, 0.3])
        original, _ = model(solo, harm, queues, edges)
        permutation = torch.tensor([2, 0, 1])
        permuted_edges = permute_graph(edges, permutation)
        permuted, _ = model(
            solo[permutation], harm, queues[permutation], permuted_edges
        )
        self.assertTrue(torch.allclose(
            permuted, original[permutation], atol=1e-6
        ))

    def test_disconnected_components_compose(self):
        model = ParallelMPNN(hidden_dim=8, num_rounds=2)
        solo = torch.tensor([1.0, 2.0])
        queues = torch.tensor([3.0, 1.0])
        edges = torch.tensor([[0, 1], [1, 0]])
        harm = torch.tensor([0.8, 0.2])
        local, _ = model(solo, harm, queues, edges)
        combined_edges = torch.cat([edges, edges + 2], dim=1)
        combined_harm = torch.cat([harm, harm])
        combined, _ = model(
            torch.cat([solo, solo]), combined_harm,
            torch.cat([queues, queues]), combined_edges,
        )
        self.assertTrue(torch.allclose(combined[:2], local, atol=1e-6))
        self.assertTrue(torch.allclose(combined[2:], local, atol=1e-6))

    def test_empty_queue_is_exactly_zero(self):
        model = ParallelMPNN(hidden_dim=8, num_rounds=2)
        probabilities, _ = model(
            torch.ones(2), torch.tensor([0.5, 0.5]),
            torch.tensor([0.0, 2.0]),
            torch.tensor([[0, 1], [1, 0]]),
        )
        self.assertEqual(probabilities[0].item(), 0.0)

    def test_common_queue_scaling_is_invariant(self):
        model = ParallelMPNN(hidden_dim=8, num_rounds=2)
        solo = torch.tensor([1.0, 2.0])
        harm = torch.tensor([0.5, 0.5])
        edges = torch.tensor([[0, 1], [1, 0]])
        first, _ = model(solo, harm, torch.tensor([2.0, 5.0]), edges)
        second, _ = model(solo, harm, torch.tensor([200.0, 500.0]), edges)
        self.assertTrue(torch.allclose(first, second, atol=1e-6))

    def test_intent_can_decrease_after_a_round(self):
        model = ParallelMPNN(hidden_dim=4, num_rounds=1)
        for parameter in model.parameters():
            parameter.data.zero_()
        model.intent_head.bias.data.fill_(1.0)
        # Make the shared update produce hidden[0]=-2.  The same intent head
        # then changes logit from +1 initially to -1 after negotiation.
        model.negotiation_block.update_mlp[-1].bias.data[0] = -2.0
        model.intent_head.weight.data[0, 0] = 1.0
        _, diagnostics = model(
            torch.ones(2), torch.tensor([0.9, 0.9]), torch.ones(2),
            torch.tensor([[0, 1], [1, 0]]), return_history=True,
        )
        initial, revised = diagnostics["intent_history"]
        self.assertTrue(torch.all(revised < initial))

    def test_history_has_fixed_number_of_rounds(self):
        model = ParallelMPNN(hidden_dim=8, num_rounds=3)
        _, diagnostics = model(
            torch.ones(1), torch.empty(0), torch.ones(1),
            torch.empty(2, 0, dtype=torch.long), return_history=True,
        )
        self.assertEqual(len(diagnostics["intent_history"]), 4)


if __name__ == "__main__":
    unittest.main()

