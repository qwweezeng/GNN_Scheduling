import unittest

import torch

from models.model import calculate_achievable_rate
from models.sequential_set_policy import (
    complete_physical_graph, exact_addition_deltas, physical_set_utility,
)
from utils.network_generate import NetworkState


class SequentialSetPolicyTest(unittest.TestCase):
    def make_state(self):
        power = torch.tensor([
            [0.0, 10.0, 0.0, 2.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 3.0, 0.0, 8.0],
            [0.0, 0.0, 0.0, 0.0],
        ])
        return NetworkState(
            links=torch.tensor([[0, 1], [2, 3]]),
            vertex_features=torch.tensor([[10.0], [9.0]]),
            edge_index=torch.empty(2, 0, dtype=torch.long),
            edge_weights=torch.empty(0, 1), large_scale=None,
            signal_power=power, signal_power_large_scale=power,
            signal_power_quant=None, noise_power=1.0, bandwidth=1.0,
            snr_gap=1.0, neighbor_map={}, positions=None,
        )

    def test_complete_graph_preserves_both_directions(self):
        edge_index, _, inr, edge_attr = complete_physical_graph(self.make_state())
        self.assertEqual(edge_index.shape, (2, 2))
        self.assertAlmostEqual(inr[1, 0].item(), 2.0)
        self.assertAlmostEqual(inr[0, 1].item(), 3.0)
        self.assertEqual(edge_attr.shape, (2, 1))

    def test_addition_delta_matches_full_rate_calculation(self):
        state = self.make_state()
        _, snr, inr, _ = complete_physical_graph(state)
        queues = torch.tensor([2.0, 3.0])
        selected = torch.tensor([1.0, 0.0])
        deltas = exact_addition_deltas(selected, queues, snr, inr)
        joined = torch.tensor([1.0, 1.0])
        expected = (
            torch.sum(queues * calculate_achievable_rate(
                joined.unsqueeze(1), state, binary=True
            ))
            - torch.sum(queues * calculate_achievable_rate(
                selected.unsqueeze(1), state, binary=True
            ))
        )
        self.assertAlmostEqual(deltas[1].item(), expected.item(), places=5)
        self.assertAlmostEqual(
            physical_set_utility(joined, queues, snr, inr).item(),
            torch.sum(queues * calculate_achievable_rate(
                joined.unsqueeze(1), state, binary=True
            )).item(),
            places=5,
        )


if __name__ == "__main__":
    unittest.main()
