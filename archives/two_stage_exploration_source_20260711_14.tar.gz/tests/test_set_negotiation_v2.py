import unittest

import torch

from models.set_negotiation import SetNegotiationV2


class SetNegotiationV2StructureTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = SetNegotiationV2(hidden_dim=8, num_revisions=2)
        self.solo = torch.tensor([1.0, 2.0, 1.5])
        self.queues = torch.tensor([3.0, 1.0, 2.0])
        self.edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        self.harm = torch.tensor([0.8, 0.2, 0.6, 0.3])
        self.initial = torch.tensor([1.0, 0.0, 1.0])
        self.randoms = [
            torch.tensor([0.1, 0.8, 0.4]),
            torch.tensor([0.7, 0.2, 0.9]),
        ]

    def test_initial_set_is_required(self):
        with self.assertRaises(ValueError):
            self.model(self.solo, self.harm, self.queues, self.edges)

    def test_join_and_keep_heads_are_explicit(self):
        _, info = self.model(
            self.solo, self.harm, self.queues, self.edges,
            initial_action=self.initial,
            random_uniforms=self.randoms,
            return_history=True,
        )
        self.assertEqual(len(info["join_probability_history"]), 2)
        self.assertEqual(len(info["keep_probability_history"]), 2)
        first_probability = info["probability_history"][0]
        first_join = info["join_probability_history"][0]
        first_keep = info["keep_probability_history"][0]
        torch.testing.assert_close(first_probability[0], first_keep[0])
        torch.testing.assert_close(first_probability[1], first_join[1])

    def test_fixed_randomness_is_reproducible(self):
        first, _ = self.model(
            self.solo, self.harm, self.queues, self.edges,
            initial_action=self.initial, random_uniforms=self.randoms,
        )
        second, _ = self.model(
            self.solo, self.harm, self.queues, self.edges,
            initial_action=self.initial, random_uniforms=self.randoms,
        )
        torch.testing.assert_close(first, second)

    def test_empty_queue_is_zero_in_every_round(self):
        queues = self.queues.clone()
        queues[1] = 0.0
        _, info = self.model(
            self.solo, self.harm, queues, self.edges,
            initial_action=torch.ones(3), random_uniforms=self.randoms,
            return_history=True,
        )
        for action in info["action_history"]:
            self.assertEqual(float(action[1]), 0.0)


if __name__ == "__main__":
    unittest.main()
