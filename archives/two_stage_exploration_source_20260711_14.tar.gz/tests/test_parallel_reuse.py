import unittest
from types import SimpleNamespace

import torch
import torch.nn as nn

from models.parallel_reuse import (
    GATExpectedRateLocalPhysicalReuseScheduler,
    LocalPhysicalReuseScheduler,
)
from utils.mws import mws_objective
from utils.parallel_reuse import (
    conflict_graph_local_join_margins,
    exact_join_margins,
    join_margins_from_gains,
    physical_gain_matrix,
    select_local_positive_maxima,
)


class FixedSkeleton:
    def __init__(self, action):
        self.action = torch.as_tensor(action, dtype=torch.float32).reshape(-1, 1)

    def eval(self):
        return self

    def schedule_with_state(self, state, queues):
        del state, queues
        return self.action.clone()


def two_link_state(edge_index=None):
    # Links are 0->1 and 2->3.  signal_power[tx, rx] contains received power.
    power = torch.zeros(4, 4)
    power[0, 1] = 8.0
    power[2, 3] = 6.0
    power[0, 3] = 0.6
    power[2, 1] = 0.8
    if edge_index is None:
        edge_index = torch.tensor([[0, 1], [1, 0]], dtype=torch.long)
    return SimpleNamespace(
        num_vertices=2,
        signal_power=power,
        signal_power_large_scale=None,
        signal_power_quant=None,
        csi_mode="perfect",
        links=torch.tensor([[0, 1], [2, 3]], dtype=torch.long),
        noise_power=1.0,
        snr_gap=1.0,
        edge_index=edge_index,
        edge_weights=torch.ones(edge_index.size(1), 1),
    )


class FixedChannelGAT(nn.Module):
    def schedule_logits(self, x, edge_index, edge_attr):
        del edge_index, edge_attr
        logits = torch.linspace(-0.5, 0.5, x.size(0)).unsqueeze(1)
        return logits, torch.zeros(x.size(0), 2)


class ParallelReusePhysicsTest(unittest.TestCase):
    def test_exact_margin_matches_brute_force_objective_change(self):
        state = two_link_state()
        queues = torch.tensor([3.0, 2.0])
        base = torch.tensor([1.0, 0.0])
        margin = exact_join_margins(state, queues, base)[1]
        brute_force = (
            mws_objective(torch.tensor([1.0, 1.0]), queues, state)
            - mws_objective(base, queues, state)
        )
        self.assertAlmostEqual(float(margin), brute_force, places=5)

    def test_full_conflict_graph_local_margin_equals_exact_margin(self):
        state = two_link_state()
        queues = torch.tensor([3.0, 2.0])
        base = torch.tensor([1.0, 0.0])
        exact = exact_join_margins(state, queues, base)
        local = conflict_graph_local_join_margins(state, queues, base)
        self.assertTrue(torch.equal(torch.isfinite(exact), torch.isfinite(local)))
        self.assertTrue(torch.allclose(exact[torch.isfinite(exact)], local[torch.isfinite(local)]))

    def test_sparse_local_margin_matches_dense_reference(self):
        edges = torch.tensor([[0], [1]], dtype=torch.long)
        state = two_link_state(edges)
        queues = torch.tensor([2.0, 3.0])
        base = torch.tensor([0.0, 1.0])
        direct, gains = physical_gain_matrix(state)
        local_gains = torch.zeros_like(gains)
        local_gains[1, 0] = gains[1, 0]
        dense_reference = join_margins_from_gains(
            state, queues, base, direct, local_gains
        )
        sparse = conflict_graph_local_join_margins(state, queues, base)
        valid = torch.isfinite(dense_reference)
        self.assertTrue(torch.equal(valid, torch.isfinite(sparse)))
        self.assertTrue(torch.allclose(dense_reference[valid], sparse[valid]))

    def test_local_competition_keeps_only_higher_neighbor(self):
        scores = torch.tensor([2.0, 1.0, 0.5])
        valid = torch.ones(3, dtype=torch.bool)
        edges = torch.tensor([[0, 1], [1, 0]], dtype=torch.long)
        selected = select_local_positive_maxima(scores, valid, edges)
        self.assertTrue(torch.equal(selected, torch.tensor([True, False, True])))

    def test_scheduler_never_activates_empty_queue(self):
        state = two_link_state(torch.empty(2, 0, dtype=torch.long))
        scheduler = LocalPhysicalReuseScheduler(FixedSkeleton([1.0, 0.0]))
        action = scheduler.schedule_with_state(
            state, torch.tensor([1.0, 0.0])
        ).reshape(-1)
        self.assertTrue(torch.equal(action, torch.tensor([1.0, 0.0])))

    def test_gat_expected_rate_v2_is_queue_scale_invariant(self):
        state = two_link_state()
        state.vertex_features = torch.tensor([[9.0], [7.0]])
        scheduler = GATExpectedRateLocalPhysicalReuseScheduler(
            FixedChannelGAT()
        )
        queues = torch.tensor([3.0, 2.0])
        original = scheduler.schedule_with_state(state, queues)
        scaled = scheduler.schedule_with_state(state, 11.0 * queues)
        self.assertTrue(torch.equal(original, scaled))


if __name__ == "__main__":
    unittest.main()
