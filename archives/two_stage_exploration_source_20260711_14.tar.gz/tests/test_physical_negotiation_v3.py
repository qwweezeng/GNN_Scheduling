import unittest

import torch

from models.physical_negotiation_v3 import (
    PhysicalNegotiationDecoderV3,
    local_relative_weighted_value,
)


class PhysicalNegotiationDecoderV3Test(unittest.TestCase):
    def test_local_relative_value(self):
        value = torch.tensor([2.0, 8.0, 4.0])
        edges = torch.tensor([[0, 1], [1, 2]])
        relative = local_relative_weighted_value(value, edges)
        self.assertTrue(torch.allclose(
            relative, torch.tensor([0.25, 1.0, 0.5])
        ))

    def test_common_queue_scaling_does_not_change_output(self):
        torch.manual_seed(11)
        model = PhysicalNegotiationDecoderV3(hidden_dim=8, num_rounds=3).eval()
        solo = torch.tensor([1.0, 2.0, 3.0])
        harm = torch.tensor([0.2, 0.7, 0.4])
        edges = torch.tensor([[0, 2, 1], [1, 1, 0]])
        queues = torch.tensor([1.0, 4.0, 2.0])
        original, _ = model(solo, harm, queues, edges)
        scaled, _ = model(solo, harm, 100.0 * queues, edges)
        self.assertTrue(torch.allclose(original, scaled, atol=1e-7))

    def test_empty_queue_is_zero(self):
        model = PhysicalNegotiationDecoderV3(hidden_dim=8, num_rounds=1)
        probability, _ = model(
            torch.tensor([1.0]), torch.empty(0), torch.tensor([0.0]),
            torch.empty(2, 0, dtype=torch.long)
        )
        self.assertEqual(probability.item(), 0.0)


if __name__ == "__main__":
    unittest.main()
