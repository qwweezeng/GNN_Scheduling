import unittest

import torch

from models.parallel_mpnn_v4 import ParallelMPNNv4, directed_local_urgency


class DirectedLocalUrgencyTest(unittest.TestCase):
    def test_direction_is_preserved(self):
        values = torch.tensor([2.0, 10.0])
        edges = torch.tensor([[0, 1], [1, 0]])
        # 0 strongly harms 1, whereas 1 barely harms 0.
        harm = torch.tensor([1.0, 0.1])
        incoming, outgoing = directed_local_urgency(values, harm, edges)
        self.assertAlmostEqual(float(incoming[0]), 1.0)
        self.assertAlmostEqual(float(outgoing[0]), 0.2)
        self.assertAlmostEqual(float(incoming[1]), 1.0)
        self.assertAlmostEqual(float(outgoing[1]), 1.0)

    def test_weak_remote_hotspot_is_discounted(self):
        values = torch.tensor([10.0, 1000.0])
        edges = torch.tensor([[0, 1], [1, 0]])
        harm = torch.tensor([0.001, 0.001])
        incoming, outgoing = directed_local_urgency(values, harm, edges)
        self.assertAlmostEqual(float(incoming[0]), 1.0)
        self.assertAlmostEqual(float(outgoing[0]), 1.0)

    def test_common_queue_scaling_is_invariant(self):
        values = torch.tensor([2.0, 10.0, 4.0])
        edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        harm = torch.tensor([0.8, 0.2, 0.6, 0.3])
        first = directed_local_urgency(values, harm, edges)
        second = directed_local_urgency(100 * values, harm, edges)
        torch.testing.assert_close(first[0], second[0])
        torch.testing.assert_close(first[1], second[1])

    def test_model_is_equivariant_for_fixed_marks(self):
        torch.manual_seed(7)
        model = ParallelMPNNv4(hidden_dim=8, num_rounds=2)
        solo = torch.tensor([1.0, 2.0, 1.5])
        queues = torch.tensor([3.0, 1.0, 2.0])
        edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
        harm = torch.tensor([0.8, 0.2, 0.6, 0.3])
        marks = torch.tensor([0.1, 0.8, 0.4])
        original, _ = model(
            solo, harm, queues, edges, random_mark=marks
        )
        permutation = torch.tensor([2, 0, 1])
        inverse = torch.empty_like(permutation)
        inverse[permutation] = torch.arange(3)
        permuted, _ = model(
            solo[permutation], harm, queues[permutation], inverse[edges],
            random_mark=marks[permutation],
        )
        torch.testing.assert_close(original[permutation], permuted)


if __name__ == "__main__":
    unittest.main()
