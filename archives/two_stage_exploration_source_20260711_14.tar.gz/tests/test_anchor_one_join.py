import unittest

import torch

from models.anchor_one_join import (
    AnchorExactGreedyJoinDecoder, AnchorExactOneJoinDecoder,
    AnchorOneJoinDecoder, anchor_pair_harms, approximate_set_utility,
    exact_one_join_deltas, pairwise_inr_from_fractional_loss,
)


class AnchorOneJoinTest(unittest.TestCase):
    def test_directed_anchor_harms_are_not_symmetrized(self):
        edges = torch.tensor([[0, 1], [1, 0]])
        outgoing, incoming = anchor_pair_harms(
            torch.tensor(0), 2, edges, torch.tensor([0.8, 0.2])
        )
        self.assertAlmostEqual(outgoing[1].item(), 0.8)
        self.assertAlmostEqual(incoming[1].item(), 0.2)

    def test_action_has_one_or_two_links_when_nonempty(self):
        torch.manual_seed(1)
        model = AnchorOneJoinDecoder(hidden_dim=8, num_rounds=1)
        action, _ = model(
            torch.tensor([1.0, 2.0, 3.0]),
            torch.tensor([0.2, 0.3]),
            torch.tensor([1.0, 2.0, 0.0]),
            torch.tensor([[0, 1], [1, 0]]),
        )
        self.assertIn(action.sum().item(), (1.0, 2.0))

    def test_all_empty_is_all_zero(self):
        model = AnchorOneJoinDecoder(hidden_dim=8, num_rounds=1)
        action, diagnostics = model(
            torch.ones(2), torch.empty(0), torch.zeros(2),
            torch.empty(2, 0, dtype=torch.long),
        )
        self.assertEqual(action.sum().item(), 0.0)
        self.assertIsNone(diagnostics["anchor"])

    def test_exact_delta_matches_two_link_utility_formula(self):
        # Anchor value=10, candidate value=8. Anchor harms candidate by 25%,
        # candidate harms anchor by 10%: delta=8*(.75)-10*(.10)=5.
        delta = exact_one_join_deltas(
            torch.tensor(0), torch.tensor([10.0, 8.0]),
            torch.tensor([1.0, 1.0]),
            torch.tensor([[0, 1], [1, 0]]),
            torch.tensor([0.25, 0.10]),
        )
        self.assertAlmostEqual(delta[1].item(), 5.0, places=6)

    def test_exact_decoder_selects_positive_join_only(self):
        model = AnchorExactOneJoinDecoder(hidden_dim=8, num_rounds=1)
        model.anchor_head.weight.data.zero_()
        model.anchor_head.bias.data.zero_()
        action, _ = model(
            torch.tensor([10.0, 8.0]), torch.tensor([0.25, 0.10]),
            torch.tensor([1.0, 1.0]),
            torch.tensor([[0, 1], [1, 0]]),
        )
        self.assertEqual(action.sum().item(), 2.0)

    def test_pairwise_loss_recovers_interference_to_noise(self):
        # Effective SNR=15 gives solo rate 4.  INR=2 gives pair rate log2(6),
        # which defines rho; inversion must recover INR=2.
        solo = torch.tensor([4.0, 4.0])
        pair = torch.log2(torch.tensor(6.0))
        rho = torch.tensor([(4.0 - pair) / 4.0])
        inr = pairwise_inr_from_fractional_loss(
            solo, torch.tensor([[0], [1]]), rho
        )
        self.assertAlmostEqual(inr.item(), 2.0, places=5)

    def test_greedy_join_can_select_more_than_two_links(self):
        model = AnchorExactGreedyJoinDecoder(hidden_dim=8, num_rounds=1)
        model.anchor_head.weight.data.zero_()
        model.anchor_head.bias.data.zero_()
        solo = torch.ones(3)
        queues = torch.ones(3)
        edges = torch.empty(2, 0, dtype=torch.long)
        action, diagnostics = model(solo, torch.empty(0), queues, edges)
        self.assertEqual(action.sum().item(), 3.0)
        self.assertEqual(len(diagnostics["joins"]), 2)
        self.assertAlmostEqual(
            approximate_set_utility(action, solo, queues, edges, torch.empty(0)).item(),
            3.0,
        )


if __name__ == "__main__":
    unittest.main()
