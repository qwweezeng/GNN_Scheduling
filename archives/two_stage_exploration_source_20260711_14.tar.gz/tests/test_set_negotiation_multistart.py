import unittest

import torch

from experiments.diagnose_set_negotiation_multistart import (
    pairwise_hamming,
    summarize_rollouts,
)


class SetNegotiationMultistartTest(unittest.TestCase):
    def test_pairwise_hamming_uses_unique_pairs(self):
        schedules = torch.tensor([
            [0.0, 0.0],
            [1.0, 0.0],
            [1.0, 1.0],
        ])
        self.assertAlmostEqual(pairwise_hamming(schedules), 2.0 / 3.0)

    def test_best_of_budget_is_prefix_based(self):
        summary = summarize_rollouts(
            utilities=[2.0, 5.0, 4.0],
            active_counts=[1.0, 2.0, 3.0],
            budgets=(1, 2, 3),
            teacher_utility=5.0,
        )
        self.assertAlmostEqual(summary["mean_mws_greedy_ratio"], 11.0 / 15.0)
        self.assertEqual(summary["best_of"]["1"]["utility"], 2.0)
        self.assertEqual(summary["best_of"]["2"]["utility"], 5.0)
        self.assertEqual(summary["best_of"]["3"]["active_links"], 2.0)


if __name__ == "__main__":
    unittest.main()
