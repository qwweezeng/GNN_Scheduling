"""Minimal learned conditional reuse on top of a LocalMax schedule skeleton."""

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.model import GATLayer
from models.two_stage import QueueChannelLocalMaxScheduler, local_relative_queue
from utils.parallel_reuse import (
    conflict_graph_local_join_margins,
    select_local_positive_maxima,
)


class ConditionalReuseMarginPredictor(nn.Module):
    """Predict a candidate's signed marginal utility conditioned on A0.

    The frozen channel GAT supplies h_ch.  Fast queue state contributes only a
    one-hop relative queue and the real binary LocalMax skeleton.  One message
    block reads the directed graph in both directions because joining utility
    depends on interference received by the candidate and harm caused to the
    currently active neighbors.
    """

    def __init__(self, channel_model, channel_dim=48, hidden_dim=48, edge_dim=1,
                 use_pairwise_queue_edge=False):
        super().__init__()
        if hidden_dim % 2 != 0:
            raise ValueError("hidden_dim must be even for two attention heads")
        self.channel_model = channel_model
        for parameter in self.channel_model.parameters():
            parameter.requires_grad_(False)
        self.channel_model.eval()
        self.use_pairwise_queue_edge = bool(use_pairwise_queue_edge)

        input_dim = channel_dim + 2
        message_edge_dim = edge_dim + int(self.use_pairwise_queue_edge)
        self.input_projection = nn.Linear(input_dim, hidden_dim)
        self.incoming_gat = GATLayer(
            hidden_dim, message_edge_dim, hidden_dim // 2, num_heads=2
        )
        self.outgoing_gat = GATLayer(
            hidden_dim, message_edge_dim, hidden_dim // 2, num_heads=2
        )
        self.fusion = nn.Linear(3 * hidden_dim, hidden_dim)
        self.margin_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ELU(),
            nn.Linear(hidden_dim // 2, 1),
        )
        self._channel_context_cache = {}

    def train(self, mode=True):
        super().train(mode)
        self.channel_model.eval()
        return self

    def clear_cache(self):
        self._channel_context_cache.clear()

    def _channel_embedding(self, state, device):
        key = (id(state), str(device))
        cached = self._channel_context_cache.get(key)
        if cached is not None and cached[0] is state:
            return cached[1]
        with torch.no_grad():
            _, channel_embedding = self.channel_model.schedule_logits(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
            )
        channel_embedding = channel_embedding.detach()
        self._channel_context_cache[key] = (state, channel_embedding)
        return channel_embedding

    def forward(self, state, queues, base_action):
        device = next(self.margin_head.parameters()).device
        queues = torch.as_tensor(
            queues, dtype=torch.float32, device=device
        ).reshape(-1)
        base_action = torch.as_tensor(
            base_action, dtype=torch.float32, device=device
        ).reshape(-1)
        edge_index = state.edge_index.to(device)
        edge_weights = state.edge_weights.to(device)
        channel_embedding = self._channel_embedding(state, device)
        queue_relative = local_relative_queue(queues, edge_index)
        node_input = torch.cat([
            channel_embedding,
            queue_relative.unsqueeze(1),
            base_action.unsqueeze(1),
        ], dim=1)
        hidden = F.elu(self.input_projection(node_input))
        message_edge_features = edge_weights
        if self.use_pairwise_queue_edge and edge_index.numel() > 0:
            source, target = edge_index
            pair_sum = queues[source] + queues[target]
            aggressor_queue_share = torch.where(
                pair_sum > 0,
                queues[source] / pair_sum.clamp_min(1e-12),
                torch.zeros_like(pair_sum),
            ).unsqueeze(1)
            message_edge_features = torch.cat([
                edge_weights, aggressor_queue_share
            ], dim=1)
        incoming = self.incoming_gat(
            hidden, edge_index, message_edge_features
        )
        outgoing = self.outgoing_gat(
            hidden, edge_index.flip(0), message_edge_features
        )
        negotiated = F.elu(self.fusion(torch.cat([
            hidden, incoming, outgoing
        ], dim=1)))
        return self.margin_head(negotiated).squeeze(1)


class LearnedParallelReuseScheduler:
    """LocalMax skeleton followed by one learned parallel reuse round."""

    def __init__(self, predictor, localmax=None):
        self.predictor = predictor
        self.localmax = localmax or QueueChannelLocalMaxScheduler(
            predictor.channel_model
        )
        self.last_diagnostics = {}

    def eval(self):
        self.predictor.eval()
        self.localmax.eval()
        return self

    def schedule_with_state(self, state, queues):
        device = next(self.predictor.parameters()).device
        queues_device = torch.as_tensor(
            queues, dtype=torch.float32, device=device
        ).reshape(-1)
        base = self.localmax.schedule_with_state(
            state, queues_device
        ).reshape(-1).cpu()
        with torch.no_grad():
            scores = self.predictor(
                state, queues_device, base.to(device)
            ).detach().cpu()
        valid = (queues_device.cpu() > 0) & (base <= 0)
        joiners = select_local_positive_maxima(
            scores, valid, state.edge_index
        )
        action = torch.maximum(base, joiners.float())
        self.last_diagnostics = {
            "positive_candidates": int((valid & (scores > 0)).sum()),
            "selected_joiners": int(joiners.sum()),
        }
        return action.unsqueeze(1)


class LocalPhysicalReuseScheduler:
    """LocalMax followed by one conflict-edge physical reuse round.

    Every inactive nonempty link evaluates its queue-weighted rate gain and the
    rate loss caused to currently active conflict neighbors.  Positive local
    maxima join simultaneously.  There is no sequential global search.
    """

    def __init__(self, localmax):
        self.localmax = localmax
        self.last_diagnostics = {}

    def eval(self):
        self.localmax.eval()
        return self

    def schedule_with_state(self, state, queues):
        base = self.localmax.schedule_with_state(
            state, queues
        ).reshape(-1).cpu()
        margins = conflict_graph_local_join_margins(state, queues, base)
        valid = torch.isfinite(margins)
        joiners = select_local_positive_maxima(
            margins, valid, state.edge_index
        )
        self.last_diagnostics = {
            "positive_candidates": int((valid & (margins > 0)).sum()),
            "selected_joiners": int(joiners.sum()),
        }
        return torch.maximum(base, joiners.float()).unsqueeze(1)


class GATExpectedRateLocalPhysicalReuseScheduler(LocalPhysicalReuseScheduler):
    """Recommended v2: GAT expected-rate skeleton plus local physical reuse."""

    model_version = "local_physical_reuse_v2_gat_expected_rate"

    def __init__(self, channel_model):
        super().__init__(QueueChannelLocalMaxScheduler(
            channel_model, priority_mode="raw_queue_gat_rate"
        ))
