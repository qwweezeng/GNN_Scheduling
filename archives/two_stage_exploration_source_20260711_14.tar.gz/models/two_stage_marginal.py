"""Queue-aware scheduling from learned channel marginal benefit and harm."""

import torch
import torch.nn as nn
import torch.nn.functional as F


def marginal_utility_probabilities(benefit, queues, edge_index, harm_fraction,
                                   eps=1e-8):
    """Combine channel-only quantities with queues using a fixed MWS rule.

    An edge ``source -> target`` means that activating ``source`` harms
    ``target``.  The external harm is therefore accumulated at ``source``.
    """
    benefit = benefit.reshape(-1)
    queues = queues.reshape(-1).to(device=benefit.device, dtype=benefit.dtype)
    harm_fraction = harm_fraction.reshape(-1).to(
        device=benefit.device, dtype=benefit.dtype
    )
    weighted_benefit = queues * benefit
    external_harm = torch.zeros_like(weighted_benefit)
    if edge_index.numel() > 0:
        source, target = edge_index[0], edge_index[1]
        contribution = harm_fraction * weighted_benefit[target]
        external_harm.index_add_(0, source, contribution)
    probabilities = weighted_benefit / (
        weighted_benefit + external_harm + eps
    )
    return probabilities * (queues > 0).to(probabilities.dtype), external_harm


class TwoStageMarginalScheduler(nn.Module):
    """Frozen channel GAT followed by a parameter-free queue combiner."""

    def __init__(self, channel_model, channel_dim=48, edge_hidden_dim=32):
        super().__init__()
        self.channel_model = channel_model
        for parameter in self.channel_model.parameters():
            parameter.requires_grad_(False)
        self.channel_model.eval()

        # b_i: non-negative channel service benefit.
        self.benefit_head = nn.Linear(channel_dim, 1)
        # rho_(i->j): directed fractional harm.  No queue enters this function.
        self.harm_head = nn.Sequential(
            nn.Linear(2 * channel_dim + 1, edge_hidden_dim),
            nn.ReLU(),
            nn.Linear(edge_hidden_dim, 1),
        )
        self.decision_threshold = 0.5
        self.latest_scores = None
        self.latest_channel_quantities = None

    def train(self, mode=True):
        super().train(mode)
        self.channel_model.eval()
        return self

    def channel_quantities(self, x, edge_index, edge_attr):
        """Estimate b_i and directed rho_(i->j) from channel information only."""
        with torch.no_grad():
            _, embedding = self.channel_model.encode(x[:, :1], edge_index, edge_attr)
        benefit = F.softplus(self.benefit_head(embedding)).reshape(-1)
        if edge_index.numel() == 0:
            harm_fraction = edge_attr.new_empty((0,))
        else:
            source, target = edge_index[0], edge_index[1]
            edge_features = torch.cat(
                [embedding[source], embedding[target], edge_attr.reshape(-1, 1)],
                dim=1,
            )
            harm_fraction = torch.sigmoid(self.harm_head(edge_features)).reshape(-1)
        return benefit, harm_fraction

    def forward(self, x, edge_index, edge_attr, queues=None, use_ste=False):
        del use_ste
        if queues is None:
            raise ValueError("TwoStageMarginalScheduler requires explicit queues.")
        queues = torch.as_tensor(
            queues, device=x.device, dtype=x.dtype
        ).reshape(-1)
        benefit, harm_fraction = self.channel_quantities(x, edge_index, edge_attr)
        probabilities, external_harm = marginal_utility_probabilities(
            benefit, queues, edge_index, harm_fraction
        )
        weighted_benefit = queues * benefit
        self.latest_scores = (weighted_benefit - external_harm).detach().unsqueeze(1)
        self.latest_channel_quantities = {
            "benefit": benefit.detach(),
            "harm_fraction": harm_fraction.detach(),
            "external_harm": external_harm.detach(),
        }
        diagnostics = torch.stack([weighted_benefit, external_harm], dim=1)
        return probabilities.unsqueeze(1), diagnostics

    def schedule_with_state(self, state, queues):
        probabilities, _ = self.forward(
            state.vertex_features[:, :1].to(queues.device),
            state.edge_index.to(queues.device),
            state.edge_weights.to(queues.device),
            queues=queues,
        )
        return (probabilities > self.decision_threshold).to(probabilities.dtype)
