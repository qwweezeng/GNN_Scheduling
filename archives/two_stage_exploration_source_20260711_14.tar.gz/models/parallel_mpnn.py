"""Fixed-round parallel conditional negotiation for queue-aware scheduling."""

import torch
import torch.nn as nn

from models.physical_negotiation_v3 import local_relative_weighted_value


class DirectedPhysicalBlock(nn.Module):
    """Aggregate bounded directed harm without losing direction or degree mass."""

    def __init__(self, hidden_dim, message_extra_dim=0, update_extra_dim=0):
        super().__init__()
        self.message_mlp = nn.Sequential(
            nn.Linear(2 * hidden_dim + message_extra_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.update_mlp = nn.Sequential(
            nn.Linear(3 * hidden_dim + 2 + update_extra_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    @staticmethod
    def _mean(weighted_sum, mass):
        return weighted_sum / mass.clamp_min(1e-8).unsqueeze(1)

    def summaries(self, hidden, harm_fraction, edge_index,
                  nonempty=None, message_extra=None,
                  ablate_neighbor_state=False):
        num_nodes = hidden.size(0)
        outgoing_sum = torch.zeros_like(hidden)
        incoming_sum = torch.zeros_like(hidden)
        outgoing_mass = hidden.new_zeros(num_nodes)
        incoming_mass = hidden.new_zeros(num_nodes)
        if edge_index.numel() > 0:
            source, target = edge_index[0], edge_index[1]
            gate = harm_fraction.reshape(-1).to(hidden)
            if nonempty is not None:
                gate = gate * nonempty[source] * nonempty[target]
            if ablate_neighbor_state:
                features = [
                    torch.zeros_like(hidden[source]),
                    torch.zeros_like(hidden[target]),
                ]
            else:
                features = [hidden[source], hidden[target]]
            if message_extra is not None:
                features.append(message_extra)
            interaction = self.message_mlp(torch.cat(features, dim=1))
            weighted = gate.unsqueeze(1) * interaction
            outgoing_sum.index_add_(0, source, weighted)
            incoming_sum.index_add_(0, target, weighted)
            outgoing_mass.index_add_(0, source, gate)
            incoming_mass.index_add_(0, target, gate)
        return (
            self._mean(outgoing_sum, outgoing_mass),
            self._mean(incoming_sum, incoming_mass),
            torch.log1p(outgoing_mass),
            torch.log1p(incoming_mass),
        )


class ChannelEncoder(nn.Module):
    """Stage 1: queue-free channel representation from b and directed rho."""

    def __init__(self, hidden_dim=32, num_rounds=1):
        super().__init__()
        self.num_rounds = int(num_rounds)
        self.node_encoder = nn.Sequential(
            nn.Linear(1, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.block = DirectedPhysicalBlock(hidden_dim)

    def forward(self, solo_rate, harm_fraction, edge_index):
        hidden = self.node_encoder(
            torch.log1p(solo_rate.reshape(-1)).unsqueeze(1)
        )
        for _ in range(self.num_rounds):
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.block.summaries(
                    hidden, harm_fraction, edge_index
                )
            )
            hidden = self.block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
            ], dim=1))
        return hidden


class ParallelMPNN(nn.Module):
    """ParallelMPNN-v1: all links revise intent together for fixed rounds.

    No global anchor or pooling is used.  Every negotiation round shares the
    same message/update parameters, and the intent is recomputed rather than
    monotonically accumulated, so early choices can be withdrawn.
    """

    model_version = "parallel_mpnn_v1"

    def __init__(self, hidden_dim=32, num_rounds=2, channel_rounds=1):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.channel_rounds = int(channel_rounds)
        self.channel_encoder = ChannelEncoder(hidden_dim, channel_rounds)
        self.queue_encoder = nn.Sequential(
            nn.Linear(hidden_dim + 2, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        # Edge extras are [source intent, target intent].  Update extras are
        # [base queue-conditioned state, current intent].
        self.negotiation_block = DirectedPhysicalBlock(
            hidden_dim,
            message_extra_dim=2,
            update_extra_dim=hidden_dim + 1,
        )
        self.intent_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                return_history=False, ablate_intent_messages=False,
                ablate_dynamic_neighbor_state=False):
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        channel = self.channel_encoder(
            solo_rate, harm_fraction, edge_index
        )
        relative_value = local_relative_weighted_value(
            queues * solo_rate, edge_index
        )
        base = self.queue_encoder(torch.cat([
            channel, relative_value.unsqueeze(1), nonempty.unsqueeze(1)
        ], dim=1))
        hidden = base
        intent = torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
        history = [intent]

        for _ in range(self.num_rounds):
            message_extra = None
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                message_extra = torch.stack([
                    intent[source], intent[target]
                ], dim=1)
                if ablate_intent_messages:
                    message_extra = torch.zeros_like(message_extra)
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.negotiation_block.summaries(
                    hidden, harm_fraction, edge_index,
                    nonempty=nonempty,
                    message_extra=message_extra,
                    ablate_neighbor_state=ablate_dynamic_neighbor_state,
                )
            )
            hidden = self.negotiation_block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
                base, intent.unsqueeze(1),
            ], dim=1))
            intent = (
                torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
            )
            history.append(intent)

        probabilities = intent.unsqueeze(1)
        diagnostics = {
            "channel_context": channel,
            "relative_value": relative_value,
            "hidden": hidden,
            "intent_history": history,
            "nonempty": nonempty,
        }
        if return_history:
            return probabilities, diagnostics
        return probabilities, diagnostics
