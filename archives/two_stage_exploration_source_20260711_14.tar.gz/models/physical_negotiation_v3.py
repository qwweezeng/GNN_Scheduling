"""Scale-invariant physical negotiation for dynamic queue scheduling."""

import torch
import torch.nn as nn


def local_relative_weighted_value(weighted_value, edge_index, eps=1e-12):
    """Normalize Q*b by the maximum in the undirected one-hop neighborhood."""
    weighted_value = weighted_value.reshape(-1)
    reference = weighted_value.clone()
    if edge_index.numel() > 0:
        source, target = edge_index[0], edge_index[1]
        reference.scatter_reduce_(
            0, source, weighted_value[target], reduce="amax"
        )
        reference.scatter_reduce_(
            0, target, weighted_value[source], reduce="amax"
        )
    relative = torch.where(
        reference > 0,
        weighted_value / reference.clamp_min(eps),
        torch.zeros_like(weighted_value),
    )
    return relative


class PhysicalNegotiationDecoderV3(nn.Module):
    """V2 harm-mass negotiation with a scale-invariant MWS value coordinate."""

    def __init__(self, hidden_dim=32, num_rounds=3):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.node_encoder = nn.Sequential(
            nn.Linear(2, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.message_mlp = nn.Sequential(
            nn.Linear(2 * hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.update_mlp = nn.Sequential(
            nn.Linear(3 * hidden_dim + 2, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.decision_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5
        self.latest_scores = None

    @staticmethod
    def _normalize(weighted_sum, mass):
        return weighted_sum / mass.clamp_min(1e-8).unsqueeze(1)

    def forward(self, solo_rate, harm_fraction, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        weighted_value = queues * solo_rate
        relative_value = local_relative_weighted_value(
            weighted_value, edge_index
        )
        hidden = self.node_encoder(torch.stack([
            relative_value, nonempty
        ], dim=1))

        for _ in range(self.num_rounds):
            outgoing_sum = torch.zeros_like(hidden)
            incoming_sum = torch.zeros_like(hidden)
            outgoing_mass = torch.zeros_like(nonempty)
            incoming_mass = torch.zeros_like(nonempty)
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                gate = harm_fraction * nonempty[source] * nonempty[target]
                interaction = self.message_mlp(torch.cat([
                    hidden[source], hidden[target]
                ], dim=1))
                weighted_message = gate.unsqueeze(1) * interaction
                outgoing_sum.index_add_(0, source, weighted_message)
                incoming_sum.index_add_(0, target, weighted_message)
                outgoing_mass.index_add_(0, source, gate)
                incoming_mass.index_add_(0, target, gate)
            outgoing_mean = self._normalize(outgoing_sum, outgoing_mass)
            incoming_mean = self._normalize(incoming_sum, incoming_mass)
            mass_features = torch.stack([
                torch.log1p(outgoing_mass), torch.log1p(incoming_mass)
            ], dim=1)
            hidden = self.update_mlp(torch.cat([
                hidden, outgoing_mean, incoming_mean, mass_features
            ], dim=1))

        logits = self.decision_head(hidden)
        self.latest_scores = logits.detach()
        return torch.sigmoid(logits) * nonempty.unsqueeze(1), hidden
