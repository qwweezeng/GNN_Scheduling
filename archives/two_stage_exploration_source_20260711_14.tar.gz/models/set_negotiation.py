"""Minimal within-slot conditional set negotiation for link scheduling."""

import torch
import torch.nn as nn

from models.parallel_mpnn import ChannelEncoder, DirectedPhysicalBlock


class SetNegotiation(nn.Module):
    """Form a joint binary schedule through proposal and shared revisions.

    The model has no cross-slot memory and no handcrafted priority.  A channel
    encoder is queue-free.  Within one slot, every revision conditions on the
    actual sampled binary set from the preceding negotiation round.
    """

    model_version = "set_negotiation_v1"

    def __init__(self, hidden_dim=32, num_revisions=2, channel_rounds=1):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_revisions = int(num_revisions)
        self.channel_rounds = int(channel_rounds)
        self.channel_encoder = ChannelEncoder(hidden_dim, channel_rounds)
        self.queue_encoder = nn.Sequential(
            nn.Linear(hidden_dim + 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        # Each edge sees the two endpoints' current hard actions.  Each node
        # update also sees its immutable within-slot base state and own action.
        self.revision_block = DirectedPhysicalBlock(
            hidden_dim,
            message_extra_dim=2,
            update_extra_dim=hidden_dim + 1,
        )
        self.action_head = nn.Linear(hidden_dim, 1)

    @staticmethod
    def _sample(probability, nonempty, random_uniform=None, generator=None):
        if random_uniform is None:
            random_uniform = torch.rand(
                probability.shape,
                dtype=probability.dtype,
                device=probability.device,
                generator=generator,
            )
        else:
            random_uniform = random_uniform.reshape_as(probability).to(
                probability
            )
        return (random_uniform < probability).to(probability) * nonempty

    @staticmethod
    def _log_probability(probability, action, nonempty):
        probability = probability.clamp(1e-6, 1.0 - 1e-6)
        terms = (
            action * torch.log(probability)
            + (1.0 - action) * torch.log1p(-probability)
        )
        return terms[nonempty > 0].sum()

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                random_uniforms=None, generator=None, return_history=False,
                ablate_set_condition=False, initial_action=None):
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate)
        channel = self.channel_encoder(solo_rate, harm_fraction, edge_index)
        base = self.queue_encoder(torch.cat([
            channel,
            torch.log1p(queues).unsqueeze(1),
            nonempty.unsqueeze(1),
        ], dim=1))

        if random_uniforms is not None:
            expected = self.num_revisions + int(initial_action is None)
            if len(random_uniforms) != expected:
                raise ValueError(
                    f"expected {expected} random tensors, got "
                    f"{len(random_uniforms)}"
                )

        hidden = base
        if initial_action is None:
            probability = (
                torch.sigmoid(self.action_head(hidden)).reshape(-1) * nonempty
            )
            action = self._sample(
                probability, nonempty,
                None if random_uniforms is None else random_uniforms[0],
                generator,
            )
            probabilities = [probability]
            actions = [action]
            log_probabilities = [self._log_probability(
                probability, action, nonempty
            )]
            random_offset = 1
        else:
            action = initial_action.reshape(-1).to(solo_rate) * nonempty
            action = (action > 0.5).to(solo_rate)
            probabilities = []
            actions = [action]
            log_probabilities = []
            random_offset = 0

        for revision in range(self.num_revisions):
            message_extra = None
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                conditioned_action = (
                    torch.zeros_like(action)
                    if ablate_set_condition else action
                )
                message_extra = torch.stack([
                    conditioned_action[source], conditioned_action[target]
                ], dim=1)
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.revision_block.summaries(
                    hidden, harm_fraction, edge_index,
                    nonempty=nonempty,
                    message_extra=message_extra,
                )
            )
            own_condition = (
                torch.zeros_like(action)
                if ablate_set_condition else action
            )
            hidden = self.revision_block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
                base, own_condition.unsqueeze(1),
            ], dim=1))
            probability = (
                torch.sigmoid(self.action_head(hidden)).reshape(-1) * nonempty
            )
            action = self._sample(
                probability, nonempty,
                None if random_uniforms is None
                else random_uniforms[revision + random_offset],
                generator,
            )
            probabilities.append(probability)
            actions.append(action)
            log_probabilities.append(self._log_probability(
                probability, action, nonempty
            ))

        diagnostics = {
            "channel_context": channel,
            "base_state": base,
            "probability_history": probabilities,
            "action_history": actions,
            "trajectory_log_probability": torch.stack(log_probabilities).sum(),
            "nonempty": nonempty,
        }
        if return_history:
            return action.unsqueeze(1), diagnostics
        return action.unsqueeze(1), diagnostics


class SetNegotiationV2(SetNegotiation):
    """Use explicit join/keep transitions instead of redrawing actions."""

    model_version = "set_negotiation_v2"

    def __init__(self, hidden_dim=32, num_revisions=2, channel_rounds=1):
        super().__init__(hidden_dim, num_revisions, channel_rounds)
        del self.action_head
        self.transition_head = nn.Linear(hidden_dim, 2)

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                random_uniforms=None, generator=None, return_history=False,
                ablate_set_condition=False, initial_action=None,
                ablate_neighbor_set=False):
        if initial_action is None:
            raise ValueError("SetNegotiationV2 requires an explicit initial set")
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate)
        channel = self.channel_encoder(solo_rate, harm_fraction, edge_index)
        base = self.queue_encoder(torch.cat([
            channel,
            torch.log1p(queues).unsqueeze(1),
            nonempty.unsqueeze(1),
        ], dim=1))
        action = (
            (initial_action.reshape(-1).to(solo_rate) > 0.5).to(solo_rate)
            * nonempty
        )
        if random_uniforms is not None and (
            len(random_uniforms) != self.num_revisions
        ):
            raise ValueError(
                f"expected {self.num_revisions} random tensors, got "
                f"{len(random_uniforms)}"
            )

        hidden = base
        actions = [action]
        probabilities = []
        join_probabilities = []
        keep_probabilities = []
        log_probabilities = []
        for revision in range(self.num_revisions):
            message_extra = None
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                neighbor_action = (
                    torch.zeros_like(action)
                    if (ablate_set_condition or ablate_neighbor_set)
                    else action
                )
                message_extra = torch.stack([
                    neighbor_action[source], neighbor_action[target]
                ], dim=1)
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.revision_block.summaries(
                    hidden, harm_fraction, edge_index,
                    nonempty=nonempty,
                    message_extra=message_extra,
                )
            )
            own_action = (
                torch.zeros_like(action)
                if ablate_set_condition else action
            )
            hidden = self.revision_block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
                base, own_action.unsqueeze(1),
            ], dim=1))
            transition = torch.sigmoid(self.transition_head(hidden))
            join_probability = transition[:, 0] * nonempty
            keep_probability = transition[:, 1] * nonempty
            probability = torch.where(
                own_action > 0.5, keep_probability, join_probability
            ) * nonempty
            action = self._sample(
                probability, nonempty,
                None if random_uniforms is None
                else random_uniforms[revision],
                generator,
            )
            probabilities.append(probability)
            join_probabilities.append(join_probability)
            keep_probabilities.append(keep_probability)
            actions.append(action)
            log_probabilities.append(self._log_probability(
                probability, action, nonempty
            ))

        diagnostics = {
            "channel_context": channel,
            "base_state": base,
            "probability_history": probabilities,
            "join_probability_history": join_probabilities,
            "keep_probability_history": keep_probabilities,
            "action_history": actions,
            "trajectory_log_probability": torch.stack(log_probabilities).sum(),
            "nonempty": nonempty,
        }
        return action.unsqueeze(1), diagnostics


class SetNegotiationV3(SetNegotiationV2):
    """Scale-invariant queue comparison on edges with explicit transitions."""

    model_version = "set_negotiation_v3"

    def __init__(self, hidden_dim=32, num_revisions=2, channel_rounds=1):
        super().__init__(hidden_dim, num_revisions, channel_rounds)
        self.queue_encoder = nn.Sequential(
            nn.Linear(hidden_dim + 1, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.revision_block = DirectedPhysicalBlock(
            hidden_dim,
            message_extra_dim=3,
            update_extra_dim=hidden_dim + 1,
        )

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                random_uniforms=None, generator=None, return_history=False,
                ablate_set_condition=False, initial_action=None,
                ablate_neighbor_set=False):
        if initial_action is None:
            raise ValueError("SetNegotiationV3 requires an explicit initial set")
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate)
        channel = self.channel_encoder(solo_rate, harm_fraction, edge_index)
        base = self.queue_encoder(torch.cat([
            channel, nonempty.unsqueeze(1),
        ], dim=1))
        log_queue = torch.zeros_like(queues)
        log_queue[nonempty > 0] = torch.log(queues[nonempty > 0])
        action = (
            (initial_action.reshape(-1).to(solo_rate) > 0.5).to(solo_rate)
            * nonempty
        )
        if random_uniforms is not None and (
            len(random_uniforms) != self.num_revisions
        ):
            raise ValueError(
                f"expected {self.num_revisions} random tensors, got "
                f"{len(random_uniforms)}"
            )

        hidden = base
        actions = [action]
        probabilities = []
        join_probabilities = []
        keep_probabilities = []
        log_probabilities = []
        edge_queue_difference = harm_fraction.new_empty(0)
        for revision in range(self.num_revisions):
            message_extra = None
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                neighbor_action = (
                    torch.zeros_like(action)
                    if (ablate_set_condition or ablate_neighbor_set)
                    else action
                )
                edge_queue_difference = (
                    log_queue[source] - log_queue[target]
                )
                message_extra = torch.stack([
                    neighbor_action[source], neighbor_action[target],
                    edge_queue_difference,
                ], dim=1)
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.revision_block.summaries(
                    hidden, harm_fraction, edge_index,
                    nonempty=nonempty,
                    message_extra=message_extra,
                )
            )
            own_action = (
                torch.zeros_like(action)
                if ablate_set_condition else action
            )
            hidden = self.revision_block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
                base, own_action.unsqueeze(1),
            ], dim=1))
            transition = torch.sigmoid(self.transition_head(hidden))
            join_probability = transition[:, 0] * nonempty
            keep_probability = transition[:, 1] * nonempty
            probability = torch.where(
                own_action > 0.5, keep_probability, join_probability
            ) * nonempty
            action = self._sample(
                probability, nonempty,
                None if random_uniforms is None
                else random_uniforms[revision],
                generator,
            )
            probabilities.append(probability)
            join_probabilities.append(join_probability)
            keep_probabilities.append(keep_probability)
            actions.append(action)
            log_probabilities.append(self._log_probability(
                probability, action, nonempty
            ))

        diagnostics = {
            "channel_context": channel,
            "base_state": base,
            "edge_log_queue_difference": edge_queue_difference,
            "probability_history": probabilities,
            "join_probability_history": join_probabilities,
            "keep_probability_history": keep_probabilities,
            "action_history": actions,
            "trajectory_log_probability": torch.stack(log_probabilities).sum(),
            "nonempty": nonempty,
        }
        return action.unsqueeze(1), diagnostics
