"""Anchor election followed by one exact categorical join choice."""

import torch
import torch.nn as nn

from models.anchor_join import HarmGatedMessageBlock
from models.physical_negotiation_v3 import local_relative_weighted_value


def anchor_pair_harms(anchor, num_nodes, edge_index, harm_fraction):
    """Return rho_(anchor->i) and rho_(i->anchor) for every candidate i."""
    anchor_to_candidate = harm_fraction.new_zeros(num_nodes)
    candidate_to_anchor = harm_fraction.new_zeros(num_nodes)
    if edge_index.numel() == 0:
        return anchor_to_candidate, candidate_to_anchor
    source, target = edge_index[0], edge_index[1]
    outgoing = source == anchor
    incoming = target == anchor
    anchor_to_candidate[target[outgoing]] = harm_fraction[outgoing]
    candidate_to_anchor[source[incoming]] = harm_fraction[incoming]
    return anchor_to_candidate, candidate_to_anchor


class AnchorOneJoinDecoder(nn.Module):
    """Always select an anchor, then choose STOP or exactly one join candidate."""

    def __init__(self, hidden_dim=32, num_rounds=3):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.anchor_encoder = nn.Sequential(
            nn.Linear(2, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.anchor_block = HarmGatedMessageBlock(hidden_dim)
        self.anchor_head = nn.Linear(hidden_dim, 1)
        # Candidate value, anchor value, and the two directed pair harms.
        self.join_mlp = nn.Sequential(
            nn.Linear(4, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self.stop_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5
        self.latest_anchor = None
        self.latest_join = None

    def anchor_context(self, solo_rate, harm_fraction, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        relative = local_relative_weighted_value(
            queues * solo_rate, edge_index
        )
        hidden = self.anchor_encoder(torch.stack([relative, nonempty], dim=1))
        for _ in range(self.num_rounds):
            hidden = self.anchor_block(
                hidden, harm_fraction, nonempty, edge_index
            )
        logits = self.anchor_head(hidden).reshape(-1)
        logits = logits.masked_fill(nonempty <= 0, -torch.inf)
        return logits, hidden, relative, nonempty

    def join_distribution(self, anchor, anchor_hidden, relative, nonempty,
                          edge_index, harm_fraction):
        candidates = (nonempty > 0).nonzero(as_tuple=True)[0]
        candidates = candidates[candidates != anchor]
        anchor_to, to_anchor = anchor_pair_harms(
            anchor, relative.numel(), edge_index, harm_fraction
        )
        if candidates.numel() > 0:
            features = torch.stack([
                relative[candidates],
                relative[anchor].expand(candidates.numel()),
                anchor_to[candidates],
                to_anchor[candidates],
            ], dim=1)
            candidate_logits = self.join_mlp(features).reshape(-1)
        else:
            candidate_logits = relative.new_empty((0,))
        # Detach the anchor representation: join-only utility training must not
        # silently rewrite the already calibrated anchor election network.
        stop_logit = self.stop_head(
            anchor_hidden[anchor].detach()
        ).reshape(1)
        choice_logits = torch.cat([stop_logit, candidate_logits], dim=0)
        return torch.softmax(choice_logits, dim=0), candidates, choice_logits

    def forward(self, solo_rate, harm_fraction, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        logits, hidden, relative, nonempty = self.anchor_context(
            solo_rate, harm_fraction, queues, edge_index
        )
        action = solo_rate.new_zeros((solo_rate.numel(), 1))
        if not (nonempty > 0).any():
            return action, {
                "anchor": None, "join": None,
                "anchor_logits": logits,
                "choice_probabilities": solo_rate.new_tensor([1.0]),
                "candidates": torch.empty(0, dtype=torch.long, device=solo_rate.device),
            }
        anchor = torch.argmax(logits)
        probabilities, candidates, choice_logits = self.join_distribution(
            anchor, hidden, relative, nonempty, edge_index, harm_fraction
        )
        choice = torch.argmax(probabilities)
        action[anchor] = 1.0
        join = None
        if int(choice) > 0:
            join = candidates[choice - 1]
            action[join] = 1.0
        self.latest_anchor = int(anchor.detach().cpu())
        self.latest_join = None if join is None else int(join.detach().cpu())
        return action, {
            "anchor": anchor, "join": join,
            "anchor_logits": logits, "anchor_hidden": hidden,
            "relative_value": relative, "nonempty": nonempty,
            "choice_probabilities": probabilities,
            "choice_logits": choice_logits, "candidates": candidates,
        }

    def load_anchor_from_anchor_join(self, state_dict):
        own = self.state_dict()
        anchor_keys = (
            "anchor_encoder", "anchor_block", "anchor_head"
        )
        copied = {
            key: value for key, value in state_dict.items()
            if key.startswith(anchor_keys) and key in own
        }
        own.update(copied)
        self.load_state_dict(own)
        return len(copied)

    def freeze_anchor(self):
        for module in (self.anchor_encoder, self.anchor_block, self.anchor_head):
            for parameter in module.parameters():
                parameter.requires_grad_(False)


def exact_one_join_deltas(anchor, solo_rate, queues, edge_index, harm_fraction):
    """Exact Q-weighted utility change from adding each candidate to anchor."""
    weighted_value = queues.reshape(-1).to(solo_rate) * solo_rate.reshape(-1)
    anchor_to, to_anchor = anchor_pair_harms(
        anchor, weighted_value.numel(), edge_index, harm_fraction
    )
    return (
        weighted_value * (1.0 - anchor_to)
        - weighted_value[anchor] * to_anchor
    )


class AnchorExactOneJoinDecoder(AnchorOneJoinDecoder):
    """Learn the anchor; solve the fixed-anchor one-join subproblem exactly."""

    def forward(self, solo_rate, harm_fraction, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        logits, hidden, relative, nonempty = self.anchor_context(
            solo_rate, harm_fraction, queues, edge_index
        )
        action = solo_rate.new_zeros((solo_rate.numel(), 1))
        if not (nonempty > 0).any():
            return action, {"anchor": None, "join": None}
        anchor = torch.argmax(logits)
        action[anchor] = 1.0
        deltas = exact_one_join_deltas(
            anchor, solo_rate, queues, edge_index, harm_fraction
        )
        eligible = nonempty > 0
        eligible = eligible.clone()
        eligible[anchor] = False
        deltas = deltas.masked_fill(~eligible, -torch.inf)
        join = None
        if eligible.any():
            best_candidate = torch.argmax(deltas)
            if deltas[best_candidate] > 0:
                join = best_candidate
                action[join] = 1.0
        self.latest_anchor = int(anchor.detach().cpu())
        self.latest_join = None if join is None else int(join.detach().cpu())
        return action, {
            "anchor": anchor, "join": join,
            "anchor_logits": logits, "anchor_hidden": hidden,
            "relative_value": relative, "nonempty": nonempty,
            "join_deltas": deltas,
        }


def pairwise_inr_from_fractional_loss(solo_rate, edge_index, harm_fraction):
    """Recover I/N on each directed edge from solo rate and pairwise rho.

    If b_j is the solo rate of target j and rho_(i->j) is its fractional
    pair-rate loss, then the pair rate is (1-rho)b_j.  Inverting Shannon's
    rate expression gives the corresponding receiver-local I/N.
    """
    solo_rate = solo_rate.reshape(-1)
    harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
    if edge_index.numel() == 0:
        return harm_fraction.new_empty((0,))
    target = edge_index[1]
    effective_snr = torch.exp2(solo_rate[target]).sub(1.0)
    pair_rate = solo_rate[target] * (1.0 - harm_fraction)
    pair_sinr = torch.exp2(pair_rate).sub(1.0)
    return (effective_snr / pair_sinr.clamp_min(1e-12) - 1.0).clamp_min(0.0)


def approximate_set_utility(action, solo_rate, queues, edge_index,
                            harm_fraction):
    """Q-weighted set utility reconstructed from directed pair measurements."""
    solo_rate = solo_rate.reshape(-1)
    queues = queues.reshape(-1).to(solo_rate)
    active = action.reshape(-1).to(solo_rate)
    effective_snr = torch.exp2(solo_rate).sub(1.0)
    total_inr = solo_rate.new_zeros(solo_rate.numel())
    if edge_index.numel() > 0:
        source, target = edge_index
        edge_inr = pairwise_inr_from_fractional_loss(
            solo_rate, edge_index, harm_fraction
        )
        total_inr.scatter_add_(0, target, edge_inr * active[source])
    rates = active * torch.log2(1.0 + effective_snr / (1.0 + total_inr))
    return torch.sum(queues * rates)


class AnchorExactGreedyJoinDecoder(AnchorOneJoinDecoder):
    """Learn the anchor, then greedily add every positive-utility candidate.

    This is a structural diagnostic.  The sequential global argmax is not yet
    claimed as the final distributed implementation; it tests whether the
    one-join concurrency cap is the remaining bottleneck.
    """

    def __init__(self, hidden_dim=32, num_rounds=3, max_joins=None):
        super().__init__(hidden_dim=hidden_dim, num_rounds=num_rounds)
        self.max_joins = max_joins

    def forward(self, solo_rate, harm_fraction, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        logits, hidden, relative, nonempty = self.anchor_context(
            solo_rate, harm_fraction, queues, edge_index
        )
        action = solo_rate.new_zeros((solo_rate.numel(), 1))
        if not (nonempty > 0).any():
            return action, {"anchor": None, "joins": []}
        anchor = torch.argmax(logits)
        action[anchor] = 1.0
        joins = []
        utility = approximate_set_utility(
            action, solo_rate, queues, edge_index, harm_fraction
        )
        while True:
            eligible = ((nonempty > 0) & (action.reshape(-1) <= 0))
            if not eligible.any():
                break
            candidates = eligible.nonzero(as_tuple=True)[0]
            deltas = []
            for candidate in candidates:
                proposed = action.clone()
                proposed[candidate] = 1.0
                deltas.append(approximate_set_utility(
                    proposed, solo_rate, queues, edge_index, harm_fraction
                ) - utility)
            deltas = torch.stack(deltas)
            best = torch.argmax(deltas)
            if deltas[best] <= 0:
                break
            selected = candidates[best]
            action[selected] = 1.0
            utility = utility + deltas[best]
            joins.append(selected)
            if self.max_joins is not None and len(joins) >= self.max_joins:
                break
        self.latest_anchor = int(anchor.detach().cpu())
        self.latest_join = [int(item.detach().cpu()) for item in joins]
        return action, {
            "anchor": anchor, "joins": joins,
            "anchor_logits": logits, "anchor_hidden": hidden,
            "relative_value": relative, "nonempty": nonempty,
            "reconstructed_utility": utility,
        }
