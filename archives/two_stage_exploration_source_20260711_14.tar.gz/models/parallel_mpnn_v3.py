"""Stochastic symmetry-breaking parallel negotiation for link scheduling."""

import torch
import torch.nn as nn

from models.parallel_mpnn import ChannelEncoder, DirectedPhysicalBlock
from models.physical_negotiation_v3 import local_relative_weighted_value


class ParallelMPNNv3(nn.Module):
    """ParallelMPNN-v3: v1 plus a fresh local random contention mark.

    The mark does not prescribe an ordering.  It only makes it possible for a
    permutation-equivariant distributed policy to distinguish otherwise
    identical contenders.  Queue/channel context still determines whether a
    marked link should transmit.
    """

    model_version = "parallel_mpnn_v3"

    def __init__(self, hidden_dim=32, num_rounds=2, channel_rounds=1):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.channel_rounds = int(channel_rounds)
        self.channel_encoder = ChannelEncoder(hidden_dim, channel_rounds)
        self.queue_encoder = nn.Sequential(
            nn.Linear(hidden_dim + 3, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.negotiation_block = DirectedPhysicalBlock(
            hidden_dim,
            message_extra_dim=2,
            update_extra_dim=hidden_dim + 1,
        )
        self.intent_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                return_history=False, ablate_intent_messages=False,
                ablate_dynamic_neighbor_state=False, random_mark=None):
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        if random_mark is None:
            random_mark = torch.rand_like(queues)
        else:
            random_mark = random_mark.reshape(-1).to(solo_rate)
        random_mark = random_mark * nonempty

        channel = self.channel_encoder(solo_rate, harm_fraction, edge_index)
        relative_value = local_relative_weighted_value(
            queues * solo_rate, edge_index
        )
        base = self.queue_encoder(torch.cat([
            channel,
            relative_value.unsqueeze(1),
            nonempty.unsqueeze(1),
            random_mark.unsqueeze(1),
        ], dim=1))
        hidden = base
        intent = torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
        history = [intent]

        for _ in range(self.num_rounds):
            message_extra = None
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                message_extra = torch.stack([
                    intent[source], intent[target]
                ], dim=1)
                if ablate_intent_messages:
                    message_extra = torch.zeros_like(message_extra)
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.negotiation_block.summaries(
                    hidden, harm_fraction, edge_index,
                    nonempty=nonempty,
                    message_extra=message_extra,
                    ablate_neighbor_state=ablate_dynamic_neighbor_state,
                )
            )
            hidden = self.negotiation_block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
                base, intent.unsqueeze(1),
            ], dim=1))
            intent = torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
            history.append(intent)

        probabilities = intent.unsqueeze(1)
        diagnostics = {
            "channel_context": channel,
            "relative_value": relative_value,
            "random_mark": random_mark,
            "hidden": hidden,
            "intent_history": history,
            "nonempty": nonempty,
        }
        return probabilities, diagnostics
