"""Channel-only estimator for directed pairwise rate-loss fractions."""

import torch
import torch.nn as nn


def solo_rate_from_snr_db(snr_db, snr_gap=1.0):
    snr_linear = torch.pow(10.0, snr_db.reshape(-1) / 10.0)
    return torch.log2(1.0 + snr_linear / float(snr_gap))


class PhysicalChannelEstimator(nn.Module):
    """Frozen conference GAT plus a supervised directed edge-loss head."""

    def __init__(self, channel_model, channel_dim=48, hidden_dim=32):
        super().__init__()
        self.channel_model = channel_model
        for parameter in self.channel_model.parameters():
            parameter.requires_grad_(False)
        self.channel_model.eval()
        self.harm_head = nn.Sequential(
            nn.Linear(2 * channel_dim + 1, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def train(self, mode=True):
        super().train(mode)
        self.channel_model.eval()
        return self

    def forward(self, x, edge_index, edge_attr, snr_gap=1.0):
        with torch.no_grad():
            _, embedding = self.channel_model.encode(
                x[:, :1], edge_index, edge_attr
            )
        solo_rate = solo_rate_from_snr_db(x[:, 0], snr_gap=snr_gap)
        if edge_index.numel() == 0:
            harm_fraction = edge_attr.new_empty((0,))
        else:
            source, target = edge_index[0], edge_index[1]
            edge_features = torch.cat([
                embedding[source], embedding[target], edge_attr.reshape(-1, 1)
            ], dim=1)
            harm_fraction = torch.sigmoid(
                self.harm_head(edge_features)
            ).reshape(-1)
        return solo_rate, harm_fraction
