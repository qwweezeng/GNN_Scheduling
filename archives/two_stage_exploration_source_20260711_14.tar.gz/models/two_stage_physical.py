"""Complete two-stage scheduler: channel estimation then queue negotiation."""

import torch
import torch.nn as nn

from models.model import calculate_achievable_rate


def exact_state_greedy_from_anchor(anchor, state, queues):
    """Greedily add links by exact full-state Q-weighted utility."""
    device = queues.device
    action = torch.zeros(state.num_vertices, device=device)
    action[anchor] = 1.0

    def utility(candidate_action):
        rates = calculate_achievable_rate(
            candidate_action.reshape(-1, 1), state, binary=True
        )
        return torch.sum(queues.to(rates) * rates)

    current = utility(action)
    while True:
        candidates = (
            (queues.reshape(-1) > 0) & (action <= 0)
        ).nonzero(as_tuple=True)[0]
        if candidates.numel() == 0:
            break
        candidate_utilities = []
        for candidate in candidates:
            proposed = action.clone()
            proposed[candidate] = 1.0
            candidate_utilities.append(utility(proposed))
        candidate_utilities = torch.stack(candidate_utilities)
        best = torch.argmax(candidate_utilities)
        if candidate_utilities[best] <= current + 1e-9:
            break
        action[candidates[best]] = 1.0
        current = candidate_utilities[best]
    return action, current


class OracleStateChannelEstimator(nn.Module):
    """Diagnostic estimator using exact state rates, cached per channel object."""

    def __init__(self):
        super().__init__()
        self._cache = {}

    def estimate_state(self, state, device):
        key = id(state)
        if key not in self._cache:
            num_links = state.num_vertices
            solo = torch.zeros(num_links)
            for link in range(num_links):
                action = torch.zeros(num_links, 1)
                action[link] = 1.0
                solo[link] = calculate_achievable_rate(
                    action, state, binary=True
                )[link]
            harm = torch.zeros(state.edge_index.size(1))
            for edge, (source, target) in enumerate(state.edge_index.t().tolist()):
                action = torch.zeros(num_links, 1)
                action[source] = 1.0
                action[target] = 1.0
                pair_rate = calculate_achievable_rate(
                    action, state, binary=True
                )[target]
                harm[edge] = (
                    (solo[target] - pair_rate) / solo[target].clamp_min(1e-8)
                ).clamp(0.0, 1.0)
            self._cache[key] = (solo, harm)
        return tuple(value.to(device) for value in self._cache[key])


class TwoStagePhysicalScheduler(nn.Module):
    def __init__(self, channel_estimator, negotiation_decoder,
                 work_conserving=False):
        super().__init__()
        self.channel_estimator = channel_estimator
        self.negotiation_decoder = negotiation_decoder
        for parameter in self.parameters():
            parameter.requires_grad_(False)
        self.decision_threshold = 0.5
        self.work_conserving = bool(work_conserving)

    def forward(self, x, edge_index, edge_attr, queues=None, use_ste=False,
                snr_gap=1.0):
        del use_ste
        if queues is None:
            raise ValueError("TwoStagePhysicalScheduler requires explicit queues.")
        solo_rate, harm_fraction = self.channel_estimator(
            x[:, :1], edge_index, edge_attr, snr_gap=snr_gap
        )
        return self.negotiation_decoder(
            solo_rate, harm_fraction, queues, edge_index
        )

    def schedule_with_state(self, state, queues):
        device = queues.device
        if hasattr(self.channel_estimator, "estimate_state"):
            solo_rate, harm_fraction = self.channel_estimator.estimate_state(
                state, device
            )
            probabilities, _ = self.negotiation_decoder(
                solo_rate, harm_fraction, queues,
                state.edge_index.to(device),
            )
        else:
            probabilities, _ = self.forward(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
                queues=queues,
                snr_gap=getattr(state, "snr_gap", 1.0),
            )
        hard = (probabilities > self.decision_threshold).to(probabilities.dtype)
        if self.work_conserving and hard.sum() == 0 and (queues > 0).any():
            active = queues > 0
            active_indices = active.nonzero(as_tuple=True)[0]
            winner = active_indices[
                probabilities.squeeze(1)[active].argmax()
            ]
            hard[winner] = 1.0
        return hard


class OracleExactSetGreedyScheduler(nn.Module):
    """Diagnostic learned-anchor scheduler with exact full-state greedy joins.

    It deliberately uses the simulator state when evaluating a candidate set.
    Therefore it is an upper diagnostic for the information representation,
    not a deployable distributed scheduler.
    """

    def __init__(self, channel_estimator, anchor_decoder):
        super().__init__()
        self.channel_estimator = channel_estimator
        self.anchor_decoder = anchor_decoder
        for parameter in self.parameters():
            parameter.requires_grad_(False)

    @staticmethod
    def _utility(action, queues, state):
        rates = calculate_achievable_rate(
            action.reshape(-1, 1), state, binary=True
        )
        return torch.sum(queues.to(rates) * rates)

    def schedule_with_state(self, state, queues):
        device = queues.device
        solo, harm = self.channel_estimator.estimate_state(state, device)
        logits, _, _, nonempty = self.anchor_decoder.anchor_context(
            solo, harm, queues, state.edge_index.to(device)
        )
        action = solo.new_zeros(solo.numel())
        if not (nonempty > 0).any():
            return action.reshape(-1, 1)
        action[torch.argmax(logits)] = 1.0
        action, _ = exact_state_greedy_from_anchor(
            torch.argmax(logits), state, queues
        )
        return action.reshape(-1, 1)
