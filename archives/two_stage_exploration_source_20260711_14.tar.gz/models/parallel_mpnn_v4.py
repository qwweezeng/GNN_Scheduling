"""Directed local-urgency stochastic negotiation for link scheduling."""

import torch
import torch.nn as nn

from models.parallel_mpnn import ChannelEncoder, DirectedPhysicalBlock


def directed_local_urgency(weighted_value, harm_fraction, edge_index):
    """Return scale-invariant incoming/outgoing harm-discounted urgency."""
    weighted_value = weighted_value.reshape(-1)
    incoming_reference = weighted_value.clone()
    outgoing_reference = weighted_value.clone()
    if edge_index.numel() > 0:
        source, target = edge_index[0], edge_index[1]
        harm = harm_fraction.reshape(-1).to(weighted_value)
        incoming_reference.scatter_reduce_(
            0, target, harm * weighted_value[source], reduce="amax"
        )
        outgoing_reference.scatter_reduce_(
            0, source, harm * weighted_value[target], reduce="amax"
        )
    incoming = torch.where(
        incoming_reference > 0,
        weighted_value / incoming_reference.clamp_min(1e-12),
        torch.zeros_like(weighted_value),
    )
    outgoing = torch.where(
        outgoing_reference > 0,
        weighted_value / outgoing_reference.clamp_min(1e-12),
        torch.zeros_like(weighted_value),
    )
    return incoming, outgoing


class ParallelMPNNv4(nn.Module):
    """ParallelMPNN-v4: directed local urgency plus random symmetry breaking."""

    model_version = "parallel_mpnn_v4"

    def __init__(self, hidden_dim=32, num_rounds=2, channel_rounds=1):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.channel_rounds = int(channel_rounds)
        self.channel_encoder = ChannelEncoder(hidden_dim, channel_rounds)
        self.queue_encoder = nn.Sequential(
            nn.Linear(hidden_dim + 4, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.negotiation_block = DirectedPhysicalBlock(
            hidden_dim,
            message_extra_dim=2,
            update_extra_dim=hidden_dim + 1,
        )
        self.intent_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                return_history=False, ablate_intent_messages=False,
                ablate_dynamic_neighbor_state=False, random_mark=None):
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        if random_mark is None:
            random_mark = torch.rand_like(queues)
        else:
            random_mark = random_mark.reshape(-1).to(solo_rate)
        random_mark = random_mark * nonempty

        channel = self.channel_encoder(solo_rate, harm_fraction, edge_index)
        urgency_in, urgency_out = directed_local_urgency(
            queues * solo_rate, harm_fraction, edge_index
        )
        base = self.queue_encoder(torch.cat([
            channel,
            urgency_in.unsqueeze(1), urgency_out.unsqueeze(1),
            nonempty.unsqueeze(1), random_mark.unsqueeze(1),
        ], dim=1))
        hidden = base
        intent = torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
        history = [intent]

        for _ in range(self.num_rounds):
            message_extra = None
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                message_extra = torch.stack([
                    intent[source], intent[target]
                ], dim=1)
                if ablate_intent_messages:
                    message_extra = torch.zeros_like(message_extra)
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.negotiation_block.summaries(
                    hidden, harm_fraction, edge_index,
                    nonempty=nonempty,
                    message_extra=message_extra,
                    ablate_neighbor_state=ablate_dynamic_neighbor_state,
                )
            )
            hidden = self.negotiation_block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
                base, intent.unsqueeze(1),
            ], dim=1))
            intent = torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
            history.append(intent)

        diagnostics = {
            "channel_context": channel,
            "urgency_in": urgency_in,
            "urgency_out": urgency_out,
            "random_mark": random_mark,
            "hidden": hidden,
            "intent_history": history,
            "nonempty": nonempty,
        }
        return intent.unsqueeze(1), diagnostics
