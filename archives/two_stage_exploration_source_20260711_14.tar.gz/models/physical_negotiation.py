"""Learned distributed set negotiation over physical channel marginals."""

import torch
import torch.nn as nn


class PhysicalNegotiationDecoder(nn.Module):
    """Combine Q*solo-rate values and directed pairwise harms by message passing."""

    def __init__(self, hidden_dim=32, num_rounds=3):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.node_encoder = nn.Sequential(
            nn.Linear(2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.message_mlp = nn.Sequential(
            nn.Linear(2 * hidden_dim + 1, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.update_mlp = nn.Sequential(
            nn.Linear(3 * hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.decision_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5
        self.latest_scores = None

    def forward(self, solo_rate, harm_fraction, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        weighted_value = queues * solo_rate
        node_features = torch.stack(
            [torch.log1p(weighted_value), nonempty], dim=1
        )
        hidden = self.node_encoder(node_features)

        for _ in range(self.num_rounds):
            outgoing = torch.zeros_like(hidden)
            incoming = torch.zeros_like(hidden)
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                edge_input = torch.cat([
                    hidden[source], hidden[target], harm_fraction.unsqueeze(1)
                ], dim=1)
                message = self.message_mlp(edge_input)
                outgoing.index_add_(0, source, message)
                incoming.index_add_(0, target, message)
            hidden = self.update_mlp(torch.cat(
                [hidden, outgoing, incoming], dim=1
            ))

        logits = self.decision_head(hidden)
        self.latest_scores = logits.detach()
        probabilities = torch.sigmoid(logits) * nonempty.unsqueeze(1)
        return probabilities, hidden
