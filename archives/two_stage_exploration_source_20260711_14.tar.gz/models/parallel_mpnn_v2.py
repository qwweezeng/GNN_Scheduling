"""Pairwise queue-ratio conditional negotiation for wireless scheduling."""

import torch
import torch.nn as nn

from models.parallel_mpnn import ChannelEncoder, DirectedPhysicalBlock


class ParallelMPNNv2(nn.Module):
    """ParallelMPNN-v2: queue urgency appears only in pairwise edge messages."""

    model_version = "parallel_mpnn_v2"

    def __init__(self, hidden_dim=32, num_rounds=2, channel_rounds=1):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.channel_rounds = int(channel_rounds)
        self.channel_encoder = ChannelEncoder(hidden_dim, channel_rounds)
        self.base_encoder = nn.Sequential(
            nn.Linear(hidden_dim + 1, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        # Edge extras: source intent, target intent, and log(v_s/v_t).
        self.negotiation_block = DirectedPhysicalBlock(
            hidden_dim,
            message_extra_dim=3,
            update_extra_dim=hidden_dim + 1,
        )
        self.intent_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                return_history=False, ablate_intent_messages=False,
                ablate_dynamic_neighbor_state=False):
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        channel = self.channel_encoder(solo_rate, harm_fraction, edge_index)
        base = self.base_encoder(torch.cat([
            channel, nonempty.unsqueeze(1),
        ], dim=1))

        weighted_value = queues * solo_rate
        log_value = torch.zeros_like(weighted_value)
        positive = weighted_value > 0
        log_value[positive] = torch.log(weighted_value[positive])

        hidden = base
        intent = torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
        history = [intent]
        edge_log_ratio = harm_fraction.new_empty(0)

        for _ in range(self.num_rounds):
            message_extra = None
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                edge_log_ratio = log_value[source] - log_value[target]
                message_extra = torch.stack([
                    intent[source], intent[target], edge_log_ratio,
                ], dim=1)
                if ablate_intent_messages:
                    message_extra = message_extra.clone()
                    message_extra[:, :2] = 0.0
            outgoing, incoming, outgoing_mass, incoming_mass = (
                self.negotiation_block.summaries(
                    hidden, harm_fraction, edge_index,
                    nonempty=nonempty,
                    message_extra=message_extra,
                    ablate_neighbor_state=ablate_dynamic_neighbor_state,
                )
            )
            hidden = self.negotiation_block.update_mlp(torch.cat([
                hidden, outgoing, incoming,
                outgoing_mass.unsqueeze(1), incoming_mass.unsqueeze(1),
                base, intent.unsqueeze(1),
            ], dim=1))
            intent = torch.sigmoid(self.intent_head(hidden)).reshape(-1) * nonempty
            history.append(intent)

        probabilities = intent.unsqueeze(1)
        diagnostics = {
            "channel_context": channel,
            "weighted_value": weighted_value,
            "log_weighted_value": log_value,
            "edge_log_value_ratio": edge_log_ratio,
            "hidden": hidden,
            "intent_history": history,
            "nonempty": nonempty,
        }
        if return_history:
            return probabilities, diagnostics
        return probabilities, diagnostics
