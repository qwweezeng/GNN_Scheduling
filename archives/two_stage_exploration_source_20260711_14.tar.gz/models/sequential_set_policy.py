"""Unified sequential set policy with physically sufficient SNR/INR input."""

import torch
import torch.nn as nn

from models.model import GATLayer


def complete_physical_graph(state, device=None):
    """Return complete directed link graph, effective SNR, and I/N matrix."""
    device = device or state.signal_power.device
    links = state.links.to(device)
    power = state.signal_power.to(device)
    noise = torch.as_tensor(state.noise_power, dtype=power.dtype, device=device)
    gap = float(getattr(state, "snr_gap", 1.0))
    num_links = links.size(0)
    tx, rx = links[:, 0], links[:, 1]
    signal = power[tx, rx]
    effective_snr = signal / (noise * gap)
    # Row=receiver/target link, column=interfering/source link.
    inr_matrix = power[tx[None, :], rx[:, None]] / noise
    inr_matrix.fill_diagonal_(0.0)
    if num_links <= 1:
        edge_index = torch.empty(2, 0, dtype=torch.long, device=device)
        edge_log_inr = torch.empty(0, 1, dtype=power.dtype, device=device)
    else:
        source = torch.arange(num_links, device=device).repeat(num_links)
        target = torch.arange(num_links, device=device).repeat_interleave(num_links)
        keep = source != target
        source, target = source[keep], target[keep]
        edge_index = torch.stack([source, target], dim=0)
        edge_log_inr = torch.log10(
            1.0 + inr_matrix[target, source]
        ).unsqueeze(1)
    return edge_index, effective_snr, inr_matrix, edge_log_inr


def exact_addition_deltas(selected, queues, effective_snr, inr_matrix):
    """Exact utility change for adding each link to the current set."""
    selected = selected.reshape(-1).to(effective_snr)
    queues = queues.reshape(-1).to(effective_snr)
    aggregate_inr = inr_matrix @ selected
    current_rates = selected * torch.log2(
        1.0 + effective_snr / (1.0 + aggregate_inr)
    )
    # Candidate i adds column i to every existing receiver j.
    rates_after_each_candidate = torch.log2(
        1.0 + effective_snr[:, None]
        / (1.0 + aggregate_inr[:, None] + inr_matrix)
    )
    harm_to_selected = (
        queues[:, None] * selected[:, None]
        * (current_rates[:, None] - rates_after_each_candidate)
    ).sum(dim=0)
    own_rate = torch.log2(1.0 + effective_snr / (1.0 + aggregate_inr))
    return queues * own_rate - harm_to_selected


def physical_set_utility(selected, queues, effective_snr, inr_matrix):
    selected = selected.reshape(-1).to(effective_snr)
    aggregate_inr = inr_matrix @ selected
    rates = selected * torch.log2(
        1.0 + effective_snr / (1.0 + aggregate_inr)
    )
    return torch.sum(queues.reshape(-1).to(rates) * rates)


class DirectedPhysicalChannelGAT(nn.Module):
    """Channel-only GAT that preserves incoming and outgoing directions."""

    def __init__(self, hidden_dim=16, heads=2):
        super().__init__()
        self.node_encoder = nn.Sequential(
            nn.Linear(1, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        head_dim = hidden_dim // heads
        self.incoming_gat = GATLayer(hidden_dim, 1, head_dim, heads)
        self.outgoing_gat = GATLayer(hidden_dim, 1, head_dim, heads)
        self.output_dim = 2 * hidden_dim

    def forward(self, effective_snr, edge_index, edge_log_inr):
        # log10(1+SNR_eff) has a fixed physical reference; no per-graph max.
        node_feature = torch.log10(1.0 + effective_snr).unsqueeze(1)
        hidden = self.node_encoder(node_feature)
        incoming = self.incoming_gat(hidden, edge_index, edge_log_inr)
        outgoing = self.outgoing_gat(
            hidden, edge_index.flip(0), edge_log_inr
        )
        return torch.cat([incoming, outgoing], dim=1)


class SequentialSetPolicy(nn.Module):
    """Repeatedly select a positive-marginal link with one shared policy."""

    def __init__(self, channel_hidden_dim=16, heads=2, policy_hidden_dim=32):
        super().__init__()
        self.channel_encoder = DirectedPhysicalChannelGAT(
            channel_hidden_dim, heads
        )
        self.choice_mlp = nn.Sequential(
            nn.Linear(self.channel_encoder.output_dim + 1, policy_hidden_dim),
            nn.ReLU(),
            nn.Linear(policy_hidden_dim, policy_hidden_dim),
            nn.ReLU(),
            nn.Linear(policy_hidden_dim, 1),
        )

    def channel_context(self, state, device=None):
        edge_index, effective_snr, inr_matrix, edge_log_inr = (
            complete_physical_graph(state, device)
        )
        context = self.channel_encoder(
            effective_snr, edge_index, edge_log_inr
        )
        return context, effective_snr, inr_matrix

    def trajectory_from_context(self, context, effective_snr, inr_matrix,
                                queues, sample=False):
        queues = queues.reshape(-1).to(effective_snr)
        selected = effective_snr.new_zeros(effective_snr.numel())
        log_probabilities = []
        choices = []
        scale = (queues * torch.log2(1.0 + effective_snr)).max().clamp_min(1e-8)
        while True:
            deltas = exact_addition_deltas(
                selected, queues, effective_snr, inr_matrix
            )
            eligible = (queues > 0) & (selected <= 0) & (deltas > 1e-9)
            candidates = eligible.nonzero(as_tuple=True)[0]
            if candidates.numel() == 0:
                break
            features = torch.cat([
                context[candidates],
                (deltas[candidates] / scale).unsqueeze(1),
            ], dim=1)
            logits = self.choice_mlp(features).reshape(-1)
            distribution = torch.distributions.Categorical(logits=logits)
            local_choice = distribution.sample() if sample else torch.argmax(logits)
            chosen = candidates[local_choice]
            log_probabilities.append(distribution.log_prob(local_choice))
            choices.append(chosen)
            selected[chosen] = 1.0
        utility = physical_set_utility(
            selected, queues, effective_snr, inr_matrix
        )
        return selected.reshape(-1, 1), {
            "log_probabilities": log_probabilities,
            "choices": choices,
            "utility": utility,
        }

    def trajectory(self, state, queues, sample=False):
        context, effective_snr, inr_matrix = self.channel_context(
            state, queues.device
        )
        return self.trajectory_from_context(
            context, effective_snr, inr_matrix, queues, sample=sample
        )

    def schedule_with_state(self, state, queues):
        action, _ = self.trajectory(state, queues, sample=False)
        return action


class QueueAwareSequentialSetPolicy(SequentialSetPolicy):
    """Sequential policy with a necessary queue-aware stage-two GAT."""

    def __init__(self, channel_hidden_dim=16, heads=2,
                 policy_hidden_dim=32, queue_hidden_dim=16):
        super().__init__(channel_hidden_dim, heads, policy_hidden_dim)
        channel_dim = self.channel_encoder.output_dim
        # Channel context + relative Qb + current selected indicator.
        self.queue_node_encoder = nn.Sequential(
            nn.Linear(channel_dim + 2, queue_hidden_dim), nn.ReLU(),
            nn.Linear(queue_hidden_dim, queue_hidden_dim),
        )
        head_dim = queue_hidden_dim // heads
        self.queue_incoming_gat = GATLayer(
            queue_hidden_dim, 1, head_dim, heads
        )
        self.queue_outgoing_gat = GATLayer(
            queue_hidden_dim, 1, head_dim, heads
        )
        self.choice_mlp = nn.Sequential(
            nn.Linear(2 * queue_hidden_dim + 1, policy_hidden_dim),
            nn.ReLU(), nn.Linear(policy_hidden_dim, policy_hidden_dim),
            nn.ReLU(), nn.Linear(policy_hidden_dim, 1),
        )

    def dynamic_queue_context(self, channel_context, queues, selected,
                              effective_snr, edge_index, edge_log_inr):
        weighted_value = queues * torch.log2(1.0 + effective_snr)
        relative_value = weighted_value / weighted_value.max().clamp_min(1e-8)
        node_input = torch.cat([
            channel_context, relative_value.unsqueeze(1),
            selected.unsqueeze(1),
        ], dim=1)
        hidden = self.queue_node_encoder(node_input)
        incoming = self.queue_incoming_gat(
            hidden, edge_index, edge_log_inr
        )
        outgoing = self.queue_outgoing_gat(
            hidden, edge_index.flip(0), edge_log_inr
        )
        return torch.cat([incoming, outgoing], dim=1)

    def trajectory(self, state, queues, sample=False):
        device = queues.device
        edge_index, effective_snr, inr_matrix, edge_log_inr = (
            complete_physical_graph(state, device)
        )
        channel_context = self.channel_encoder(
            effective_snr, edge_index, edge_log_inr
        )
        queues = queues.reshape(-1).to(effective_snr)
        selected = effective_snr.new_zeros(effective_snr.numel())
        log_probabilities, choices = [], []
        scale = (queues * torch.log2(1.0 + effective_snr)).max().clamp_min(1e-8)
        while True:
            deltas = exact_addition_deltas(
                selected, queues, effective_snr, inr_matrix
            )
            eligible = (queues > 0) & (selected <= 0) & (deltas > 1e-9)
            candidates = eligible.nonzero(as_tuple=True)[0]
            if candidates.numel() == 0:
                break
            dynamic_context = self.dynamic_queue_context(
                channel_context, queues, selected, effective_snr,
                edge_index, edge_log_inr,
            )
            logits = self.choice_mlp(torch.cat([
                dynamic_context[candidates],
                (deltas[candidates] / scale).unsqueeze(1),
            ], dim=1)).reshape(-1)
            distribution = torch.distributions.Categorical(logits=logits)
            local_choice = distribution.sample() if sample else torch.argmax(logits)
            chosen = candidates[local_choice]
            log_probabilities.append(distribution.log_prob(local_choice))
            choices.append(chosen)
            selected[chosen] = 1.0
        utility = physical_set_utility(
            selected, queues, effective_snr, inr_matrix
        )
        return selected.reshape(-1, 1), {
            "log_probabilities": log_probabilities,
            "choices": choices, "utility": utility,
        }


class QueueConditionedAnchorValueNetwork(nn.Module):
    """Predict anchor utility from explicit asymmetric queue-conditioned pairs."""

    def __init__(self, channel_hidden_dim=16, heads=2, pair_hidden_dim=32):
        super().__init__()
        self.channel_encoder = DirectedPhysicalChannelGAT(
            channel_hidden_dim, heads
        )
        channel_dim = self.channel_encoder.output_dim
        # h_i, h_j, relative values i/j, and both INR directions.
        self.pair_mlp = nn.Sequential(
            nn.Linear(2 * channel_dim + 4, pair_hidden_dim), nn.ReLU(),
            nn.Linear(pair_hidden_dim, pair_hidden_dim), nn.ReLU(),
        )
        self.value_head = nn.Sequential(
            nn.Linear(channel_dim + pair_hidden_dim + 1, pair_hidden_dim),
            nn.ReLU(), nn.Linear(pair_hidden_dim, 1),
        )

    def scores(self, state, queues):
        edge_index, snr, inr, edge_attr = complete_physical_graph(
            state, queues.device
        )
        channel = self.channel_encoder(snr, edge_index, edge_attr)
        weighted_value = queues * torch.log2(1.0 + snr)
        scale = weighted_value.max().clamp_min(1e-8)
        relative = weighted_value / scale
        num_links, channel_dim = channel.shape
        candidate_h = channel[:, None, :].expand(-1, num_links, -1)
        neighbor_h = channel[None, :, :].expand(num_links, -1, -1)
        candidate_q = relative[:, None].expand(-1, num_links)
        neighbor_q = relative[None, :].expand(num_links, -1)
        # Matrix row=target, column=source.
        candidate_harms_neighbor = inr.t()
        neighbor_harms_candidate = inr
        pair_feature = torch.cat([
            candidate_h, neighbor_h,
            candidate_q.unsqueeze(2), neighbor_q.unsqueeze(2),
            torch.log10(1.0 + candidate_harms_neighbor).unsqueeze(2),
            torch.log10(1.0 + neighbor_harms_candidate).unsqueeze(2),
        ], dim=2)
        messages = self.pair_mlp(pair_feature)
        eye = torch.eye(num_links, dtype=torch.bool, device=queues.device)
        active_neighbor = (queues > 0)[None, :] & ~eye
        messages = messages * active_neighbor.unsqueeze(2)
        aggregate = messages.sum(dim=1) / max(num_links ** 0.5, 1.0)
        scores = self.value_head(torch.cat([
            channel, aggregate, relative.unsqueeze(1),
        ], dim=1)).reshape(-1)
        return scores, weighted_value
