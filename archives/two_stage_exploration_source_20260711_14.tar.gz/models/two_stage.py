import torch
import torch.nn as nn
import torch.nn.functional as F

from models.model import GATLayer, NodeEmbedding
from utils.parallel_reuse import local_edge_gains


def local_relative_queue(queues, edge_index):
    """Normalize each queue by the largest queue visible in its one-hop neighborhood."""
    queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).clamp_min(0.0)
    local_max = queues.clone().clamp_min(1.0)
    if edge_index.numel() > 0:
        src, dst = edge_index[0], edge_index[1]
        if hasattr(local_max, "scatter_reduce_"):
            local_max.scatter_reduce_(0, dst, queues[src], reduce="amax")
            local_max.scatter_reduce_(0, src, queues[dst], reduce="amax")
        else:
            for u, v in zip(src.tolist(), dst.tolist()):
                pair_max = torch.maximum(queues[u], queues[v])
                local_max[u] = torch.maximum(local_max[u], pair_max)
                local_max[v] = torch.maximum(local_max[v], pair_max)
    return queues / local_max.clamp_min(1.0)


class TwoStageGATScheduler(nn.Module):
    """Frozen channel GAT followed by a shallow learned queue-competition GAT."""

    def __init__(self, channel_model, channel_dim=48, edge_dim=1,
                 hidden_dim=32, gat_dim=32):
        super().__init__()
        self.channel_model = channel_model
        for parameter in self.channel_model.parameters():
            parameter.requires_grad_(False)
        self.channel_model.eval()

        fusion_dim = channel_dim + 3
        self.queue_embed = NodeEmbedding(fusion_dim, [hidden_dim], gat_dim)
        self.queue_gat = GATLayer(gat_dim, edge_dim, gat_dim, num_heads=1)
        self.decision_head = nn.Sequential(
            nn.Linear(gat_dim + fusion_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self.decision_threshold = 0.5
        self.latest_scores = None

    def train(self, mode=True):
        super().train(mode)
        self.channel_model.eval()
        return self

    def forward(self, x, edge_index, edge_attr, queues=None, use_ste=False):
        del use_ste
        if queues is None:
            if x.size(1) < 2:
                raise ValueError("TwoStageGATScheduler requires explicit link queues.")
            queues = x[:, 1]
        queues = torch.as_tensor(queues, device=x.device, dtype=torch.float32).reshape(-1)

        with torch.no_grad():
            channel_scores, channel_embedding = self.channel_model.schedule_logits(
                x[:, :1], edge_index, edge_attr
            )
        queue_rel = local_relative_queue(queues, edge_index).to(x.device).unsqueeze(1)
        channel_potential = F.softplus(channel_scores)
        priority_seed = queue_rel * channel_potential
        fused = torch.cat(
            [channel_embedding, channel_scores, queue_rel, priority_seed], dim=1
        )
        h = F.elu(self.queue_embed(fused))
        h = self.queue_gat(h, edge_index, edge_attr)
        logits = self.decision_head(torch.cat([h, fused], dim=1))
        self.latest_scores = logits.detach()
        probabilities = torch.sigmoid(logits)
        probabilities = probabilities * (queues > 0).to(probabilities.dtype).unsqueeze(1)
        return probabilities, h

    def schedule_with_state(self, state, queues):
        probabilities, _ = self.forward(
            state.vertex_features.to(queues.device),
            state.edge_index.to(queues.device),
            state.edge_weights.to(queues.device),
            queues=queues,
        )
        return (probabilities > self.decision_threshold).to(probabilities.dtype)


class QueueChannelLocalMaxScheduler:
    """One-hop LocalMax skeleton with auditable priority definitions."""

    PRIORITY_MODES = {
        "local_relative_channel",
        "raw_queue_channel",
        "raw_queue_gat_rate",
        "raw_queue_solo",
        "raw_queue",
    }

    def __init__(self, channel_model, priority_mode="local_relative_channel"):
        if priority_mode not in self.PRIORITY_MODES:
            raise ValueError(
                f"Unknown priority_mode={priority_mode}; "
                f"expected one of {sorted(self.PRIORITY_MODES)}"
            )
        self.channel_model = channel_model
        self.priority_mode = priority_mode
        # Stage 1 depends on the channel graph, not on the fast queue state.
        # Reuse its logits while the same block-fading state object is active.
        self._channel_score_cache = {}

    def eval(self):
        self.channel_model.eval()
        return self

    def clear_cache(self):
        self._channel_score_cache.clear()

    def schedule_with_state(self, state, queues):
        device = queues.device
        edge_index = state.edge_index.to(device)
        if self.priority_mode in {
            "local_relative_channel", "raw_queue_channel",
            "raw_queue_gat_rate",
        }:
            cache_key = (id(state), str(device))
            cached = self._channel_score_cache.get(cache_key)
            logits = (
                cached[1]
                if cached is not None and cached[0] is state else None
            )
            if logits is None:
                with torch.no_grad():
                    logits, _ = self.channel_model.schedule_logits(
                        state.vertex_features[:, :1].to(device),
                        edge_index,
                        state.edge_weights.to(device),
                    )
                logits = logits.detach()
                self._channel_score_cache[cache_key] = (state, logits)
            channel_potential = F.softplus(logits.squeeze(1))

        if self.priority_mode == "local_relative_channel":
            queue_factor = local_relative_queue(queues, edge_index).to(device)
            priority = queue_factor * channel_potential
        elif self.priority_mode == "raw_queue_channel":
            priority = queues * channel_potential
        elif self.priority_mode == "raw_queue_gat_rate":
            direct, source, target, edge_gain = local_edge_gains(state)
            expected_interference = torch.zeros_like(direct)
            if source.numel() > 0:
                expected_activity = torch.sigmoid(
                    logits.squeeze(1)
                ).detach().cpu()
                expected_interference.index_add_(
                    0, target, edge_gain * expected_activity[source]
                )
            noise = torch.as_tensor(
                state.noise_power, dtype=torch.float32
            ).cpu()
            snr_gap = float(getattr(state, "snr_gap", 1.0))
            expected_rate = torch.log2(
                1.0
                + direct / (expected_interference + noise) / snr_gap
            ).to(device)
            priority = queues * expected_rate
        elif self.priority_mode == "raw_queue_solo":
            direct, _, _, _ = local_edge_gains(state)
            noise = torch.as_tensor(
                state.noise_power, dtype=torch.float32, device=device
            )
            snr_gap = float(getattr(state, "snr_gap", 1.0))
            solo_rate = torch.log2(
                1.0 + direct.to(device) / noise / snr_gap
            )
            priority = queues * solo_rate
        else:
            priority = queues
        winners = (queues > 0).clone()
        if edge_index.numel() > 0:
            src, dst = edge_index[0], edge_index[1]
            src_loses = (priority[src] < priority[dst]) | (
                (priority[src] == priority[dst]) & (src > dst)
            )
            dst_loses = (priority[dst] < priority[src]) | (
                (priority[dst] == priority[src]) & (dst > src)
            )
            losers = torch.zeros_like(winners)
            losers[src[src_loses]] = True
            losers[dst[dst_loses]] = True
            winners &= ~losers
        return winners.to(torch.float32).unsqueeze(1)
