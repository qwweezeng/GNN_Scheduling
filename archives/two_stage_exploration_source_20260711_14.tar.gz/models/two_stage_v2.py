"""Experimental structured local-competition scheduler for queue-aware GAT."""

import torch
import torch.nn as nn

from models.model import NodeEmbedding


def bidirectional_conflict_edges(edge_index, edge_attr, num_nodes):
    """Return both directions with max physical conflict strength per pair."""
    device = edge_index.device
    strength = torch.zeros(num_nodes, num_nodes, device=device, dtype=edge_attr.dtype)
    if edge_index.numel() > 0:
        source, target = edge_index[0], edge_index[1]
        values = edge_attr.reshape(-1)
        if hasattr(strength, "index_put_"):
            strength.index_put_((source, target), values, accumulate=False)
        else:
            strength[source, target] = values
    strength = torch.maximum(strength, strength.t())
    source, target = (strength > 0).nonzero(as_tuple=True)
    return torch.stack([source, target], dim=0), strength[source, target]


def structured_competition_logits(priority, queues, edge_index, edge_attr):
    """Compare local priorities while discounting weak physical conflicts.

    For an effective pair strength w_ji in (0, 1], link j threatens link i by
    s_j + log(w_ji).  Strong conflicts (w near 1) cause nearly direct priority
    competition.  Weak conflicts receive a negative discount, so both links can
    remain active and exploit spatial reuse.
    """
    priority = priority.reshape(-1)
    queues = queues.reshape(-1)
    num_nodes = priority.numel()
    competition_edges, strengths = bidirectional_conflict_edges(
        edge_index, edge_attr, num_nodes
    )
    active_priority = priority.masked_fill(queues <= 0, -1e9)
    strongest_threat = torch.full_like(priority, -1e9)
    if competition_edges.numel() > 0:
        source, target = competition_edges[0], competition_edges[1]
        threat = active_priority[source] + torch.log(strengths.clamp_min(1e-6))
        strongest_threat.scatter_reduce_(0, target, threat, reduce="amax")
    # An isolated link only needs positive local priority.  A competing link
    # must additionally exceed the strongest physically weighted neighbor.
    reference = torch.where(
        strongest_threat > -1e8,
        strongest_threat,
        torch.zeros_like(strongest_threat),
    )
    return (priority - reference).unsqueeze(1)


class TwoStageGATv2Scheduler(nn.Module):
    """Frozen channel embedding plus learned priority and structured competition."""

    def __init__(self, channel_model, channel_dim=48, hidden_dim=32,
                 queue_scale=20.0, use_channel_skip=False):
        super().__init__()
        self.channel_model = channel_model
        for parameter in self.channel_model.parameters():
            parameter.requires_grad_(False)
        self.channel_model.eval()
        self.queue_scale = float(queue_scale)
        self.use_channel_skip = bool(use_channel_skip)
        priority_input_dim = channel_dim + 2 + (2 if self.use_channel_skip else 0)
        self.priority_embed = NodeEmbedding(
            priority_input_dim, [hidden_dim], hidden_dim
        )
        self.priority_head = nn.Sequential(
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self.decision_threshold = 0.5
        self.latest_scores = None

    def train(self, mode=True):
        super().train(mode)
        self.channel_model.eval()
        return self

    def forward(self, x, edge_index, edge_attr, queues=None, use_ste=False):
        del use_ste
        if queues is None:
            if x.size(1) < 2:
                raise ValueError("TwoStageGATv2Scheduler requires explicit queues.")
            queues = x[:, 1]
        queues = torch.as_tensor(
            queues, device=x.device, dtype=torch.float32
        ).reshape(-1)
        with torch.no_grad():
            channel_score, channel_embedding = self.channel_model.schedule_logits(
                x[:, :1], edge_index, edge_attr
            )

        log_queue = torch.log1p(queues).unsqueeze(1)
        queue_feature = log_queue / torch.log1p(torch.tensor(
            self.queue_scale, device=x.device, dtype=log_queue.dtype
        ))
        nonempty = (queues > 0).to(queue_feature.dtype).unsqueeze(1)
        priority_features = [channel_embedding]
        if self.use_channel_skip:
            snr_normalized = (
                x[:, :1] - self.channel_model.input_feature_mean[:1]
            ) / self.channel_model.input_feature_std[:1]
            priority_features.extend([channel_score, snr_normalized])
        priority_features.extend([queue_feature, nonempty])
        priority_input = torch.cat(priority_features, dim=1)
        priority = self.priority_head(self.priority_embed(priority_input))
        logits = structured_competition_logits(
            priority, queues, edge_index, edge_attr
        )
        self.latest_scores = logits.detach()
        probabilities = torch.sigmoid(logits)
        probabilities = probabilities * nonempty
        return probabilities, priority

    def schedule_with_state(self, state, queues):
        probabilities, _ = self.forward(
            state.vertex_features.to(queues.device),
            state.edge_index.to(queues.device),
            state.edge_weights.to(queues.device),
            queues=queues,
        )
        return (probabilities > self.decision_threshold).to(probabilities.dtype)
