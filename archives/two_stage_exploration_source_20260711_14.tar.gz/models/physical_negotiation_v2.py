"""Degree-stable physical negotiation with harm-gated neighborhood summaries."""

import torch
import torch.nn as nn


class PhysicalNegotiationDecoderV2(nn.Module):
    """Negotiate using harm-weighted mean interaction plus total harm mass."""

    def __init__(self, hidden_dim=32, num_rounds=3):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)
        self.node_encoder = nn.Sequential(
            nn.Linear(2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        # rho is applied outside the MLP so zero physical harm means zero message.
        self.message_mlp = nn.Sequential(
            nn.Linear(2 * hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.update_mlp = nn.Sequential(
            nn.Linear(3 * hidden_dim + 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.decision_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5
        self.latest_scores = None

    @staticmethod
    def _normalize(weighted_sum, mass):
        return weighted_sum / mass.clamp_min(1e-8).unsqueeze(1)

    def forward(self, solo_rate, harm_fraction, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        weighted_value = queues * solo_rate
        hidden = self.node_encoder(torch.stack([
            torch.log1p(weighted_value), nonempty
        ], dim=1))

        for _ in range(self.num_rounds):
            outgoing_sum = torch.zeros_like(hidden)
            incoming_sum = torch.zeros_like(hidden)
            outgoing_mass = torch.zeros_like(nonempty)
            incoming_mass = torch.zeros_like(nonempty)
            if edge_index.numel() > 0:
                source, target = edge_index[0], edge_index[1]
                # An empty source cannot interfere and an empty target has no
                # queued service value to protect in this slot.
                gate = harm_fraction * nonempty[source] * nonempty[target]
                interaction = self.message_mlp(torch.cat([
                    hidden[source], hidden[target]
                ], dim=1))
                weighted_message = gate.unsqueeze(1) * interaction
                outgoing_sum.index_add_(0, source, weighted_message)
                incoming_sum.index_add_(0, target, weighted_message)
                outgoing_mass.index_add_(0, source, gate)
                incoming_mass.index_add_(0, target, gate)

            outgoing_mean = self._normalize(outgoing_sum, outgoing_mass)
            incoming_mean = self._normalize(incoming_sum, incoming_mass)
            mass_features = torch.stack([
                torch.log1p(outgoing_mass), torch.log1p(incoming_mass)
            ], dim=1)
            hidden = self.update_mlp(torch.cat([
                hidden, outgoing_mean, incoming_mean, mass_features
            ], dim=1))

        logits = self.decision_head(hidden)
        self.latest_scores = logits.detach()
        probabilities = torch.sigmoid(logits) * nonempty.unsqueeze(1)
        return probabilities, hidden
