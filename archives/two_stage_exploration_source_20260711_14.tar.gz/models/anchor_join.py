"""Anchor-first conditional set construction for queue-aware scheduling."""

import torch
import torch.nn as nn

from models.physical_negotiation_v3 import local_relative_weighted_value


class HarmGatedMessageBlock(nn.Module):
    """Shared directed message/update rule with bounded degree statistics."""

    def __init__(self, hidden_dim):
        super().__init__()
        self.message_mlp = nn.Sequential(
            nn.Linear(2 * hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.update_mlp = nn.Sequential(
            nn.Linear(3 * hidden_dim + 2, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    @staticmethod
    def _mean(weighted_sum, mass):
        return weighted_sum / mass.clamp_min(1e-8).unsqueeze(1)

    def forward(self, hidden, harm_fraction, nonempty, edge_index):
        outgoing_sum = torch.zeros_like(hidden)
        incoming_sum = torch.zeros_like(hidden)
        outgoing_mass = torch.zeros_like(nonempty)
        incoming_mass = torch.zeros_like(nonempty)
        if edge_index.numel() > 0:
            source, target = edge_index[0], edge_index[1]
            gate = harm_fraction * nonempty[source] * nonempty[target]
            interaction = self.message_mlp(torch.cat([
                hidden[source], hidden[target]
            ], dim=1))
            weighted_message = gate.unsqueeze(1) * interaction
            outgoing_sum.index_add_(0, source, weighted_message)
            incoming_sum.index_add_(0, target, weighted_message)
            outgoing_mass.index_add_(0, source, gate)
            incoming_mass.index_add_(0, target, gate)
        return self.update_mlp(torch.cat([
            hidden,
            self._mean(outgoing_sum, outgoing_mass),
            self._mean(incoming_sum, incoming_mass),
            torch.log1p(outgoing_mass).unsqueeze(1),
            torch.log1p(incoming_mass).unsqueeze(1),
        ], dim=1))


class AnchorJoinDecoder(nn.Module):
    """Elect one mandatory anchor, then condition all join decisions on it."""

    def __init__(self, hidden_dim=32, num_rounds=3):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.num_rounds = int(num_rounds)

        self.anchor_encoder = nn.Sequential(
            nn.Linear(2, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.anchor_block = HarmGatedMessageBlock(hidden_dim)
        self.anchor_head = nn.Linear(hidden_dim, 1)

        self.join_encoder = nn.Sequential(
            nn.Linear(3, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.join_block = HarmGatedMessageBlock(hidden_dim)
        self.join_head = nn.Linear(hidden_dim, 1)
        self.decision_threshold = 0.5
        self.latest_anchor = None
        self.latest_anchor_logits = None
        self.latest_join_logits = None

    def value_features(self, solo_rate, queues, edge_index):
        solo_rate = solo_rate.reshape(-1)
        queues = queues.reshape(-1).to(solo_rate)
        nonempty = (queues > 0).to(solo_rate.dtype)
        relative_value = local_relative_weighted_value(
            queues * solo_rate, edge_index
        )
        return relative_value, nonempty

    def anchor_logits(self, solo_rate, harm_fraction, queues, edge_index):
        relative_value, nonempty = self.value_features(
            solo_rate, queues, edge_index
        )
        hidden = self.anchor_encoder(torch.stack([
            relative_value, nonempty
        ], dim=1))
        for _ in range(self.num_rounds):
            hidden = self.anchor_block(
                hidden, harm_fraction, nonempty, edge_index
            )
        logits = self.anchor_head(hidden).reshape(-1)
        logits = logits.masked_fill(nonempty <= 0, -torch.inf)
        return logits, hidden, relative_value, nonempty

    @staticmethod
    def deterministic_anchor(logits, nonempty):
        if not (nonempty > 0).any():
            return None
        return torch.argmax(logits)

    def join_probabilities(self, solo_rate, harm_fraction, queues, edge_index,
                           anchor_index):
        relative_value, nonempty = self.value_features(
            solo_rate, queues, edge_index
        )
        is_anchor = torch.zeros_like(nonempty)
        if anchor_index is not None:
            is_anchor[anchor_index] = 1.0
        hidden = self.join_encoder(torch.stack([
            relative_value, nonempty, is_anchor
        ], dim=1))
        for _ in range(self.num_rounds):
            hidden = self.join_block(
                hidden, harm_fraction, nonempty, edge_index
            )
        logits = self.join_head(hidden).reshape(-1)
        probabilities = torch.sigmoid(logits) * nonempty
        if anchor_index is not None:
            probabilities = probabilities.clone()
            probabilities[anchor_index] = 1.0
        return probabilities.unsqueeze(1), logits, hidden

    def forward(self, solo_rate, harm_fraction, queues, edge_index,
                anchor_index=None):
        solo_rate = solo_rate.reshape(-1)
        harm_fraction = harm_fraction.reshape(-1).to(solo_rate)
        queues = queues.reshape(-1).to(solo_rate)
        logits, anchor_hidden, relative_value, nonempty = self.anchor_logits(
            solo_rate, harm_fraction, queues, edge_index
        )
        if anchor_index is None:
            anchor_index = self.deterministic_anchor(logits, nonempty)
        probabilities, join_logits, join_hidden = self.join_probabilities(
            solo_rate, harm_fraction, queues, edge_index, anchor_index
        )
        self.latest_anchor = (
            None if anchor_index is None else int(anchor_index.detach().cpu())
        )
        self.latest_anchor_logits = logits.detach()
        self.latest_join_logits = join_logits.detach()
        diagnostics = {
            "anchor_logits": logits,
            "anchor_hidden": anchor_hidden,
            "join_logits": join_logits,
            "join_hidden": join_hidden,
            "relative_value": relative_value,
            "nonempty": nonempty,
            "anchor_index": anchor_index,
        }
        return probabilities, diagnostics
