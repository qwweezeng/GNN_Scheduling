#!/usr/bin/env python3
"""Benchmark warm per-slot LocalPhysicalReuse cost at one network scale."""

import argparse
import json
import os
import sys
import time
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_localmax_reuse_headroom import jsonify
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _set_simulation_seed,
    build_generator,
    load_config,
)
from models.parallel_reuse import LocalPhysicalReuseScheduler
from models.two_stage import QueueChannelLocalMaxScheduler


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=50)
    parser.add_argument("--iterations", type=int, default=30)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def summarize_times(values):
    values = np.asarray(values, dtype=float)
    return {
        "mean_ms": float(1000.0 * values.mean()),
        "median_ms": float(1000.0 * np.median(values)),
        "p95_ms": float(1000.0 * np.percentile(values, 95)),
    }


def main():
    args = parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
    })
    _set_simulation_seed(args.seed)
    generator = build_generator(cfg)
    generation_start = time.perf_counter()
    state = generator.generate_network(
        csi_mode="perfect", include_queue_feature=False
    )
    generation_seconds = time.perf_counter() - generation_start
    channel_model, channel_path = load_channel_model(
        cfg, 10, torch.device("cpu")
    )
    queue_generator = torch.Generator().manual_seed(args.seed + 1000)
    queues = [
        torch.randint(
            0, 20, (state.num_vertices,), generator=queue_generator
        ).float()
        for _ in range(args.iterations + 1)
    ]
    results = {}
    for mode in (
        "local_relative_channel", "raw_queue_gat_rate", "raw_queue_solo"
    ):
        base = QueueChannelLocalMaxScheduler(
            channel_model, priority_mode=mode
        )
        scheduler = LocalPhysicalReuseScheduler(base)
        start = time.perf_counter()
        scheduler.schedule_with_state(state, queues[0])
        cold_seconds = time.perf_counter() - start
        warm = []
        for queue in queues[1:]:
            start = time.perf_counter()
            scheduler.schedule_with_state(state, queue)
            warm.append(time.perf_counter() - start)
        results[mode] = {
            "cold_first_slot_ms": 1000.0 * cold_seconds,
            "warm_per_slot": summarize_times(warm),
        }

    report = {
        "experiment": "local_physical_scale_benchmark",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "physical_setting": {
            "tx_power_dbm": 10.0,
            "csi_mode": "perfect",
            "channel_checkpoint": channel_path,
        },
        "graph": {
            "num_links": state.num_vertices,
            "num_directed_edges": state.edge_index.size(1),
            "average_directed_degree": (
                state.edge_index.size(1) / max(state.num_vertices, 1)
            ),
            "generation_seconds": generation_seconds,
        },
        "results": results,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/local_physical_scale_benchmark_"
        f"numUAV={args.num_uav}_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({"report": path, **report["graph"], **results}, indent=2))


if __name__ == "__main__":
    main()
