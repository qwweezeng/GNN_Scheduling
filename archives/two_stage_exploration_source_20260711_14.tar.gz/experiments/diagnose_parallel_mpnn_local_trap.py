#!/usr/bin/env python3
"""Measure whether all-active schedules are unilateral local optima."""

import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from models.model import calculate_achievable_rate
from utils.mws import mws_objective


def utility(action, queues, state):
    rates = calculate_achievable_rate(
        action.reshape(-1, 1), state, binary=True
    )
    return float(torch.sum(queues * rates))


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TRAIN_SIZE": 80, "VAL_SIZE": 20, "TEST_SIZE": 20,
    })
    generator = build_generator(cfg)
    states = _load_or_generate_dataset(
        generator, cfg, 10, False, "test", (0, 20)
    )
    grouped = build_stratified_samples(states, (0, 20), 44)
    records = []
    for group, samples in grouped.items():
        for state, queues, teacher in samples:
            active = (queues > 0).float()
            full_utility = utility(active, queues, state)
            teacher_utility = mws_objective(teacher, queues, state)
            deltas = []
            focal_indices = (queues > 0).nonzero(as_tuple=True)[0].tolist()
            for focal in focal_indices:
                without = active.clone()
                without[focal] = 0.0
                deltas.append(full_utility - utility(without, queues, state))
            local_action = torch.zeros_like(active)
            for focal, delta in zip(focal_indices, deltas):
                local_action[focal] = float(delta >= 0.0)
            local_utility = utility(local_action, queues, state)
            teacher_binary = teacher.reshape(-1) > 0.5
            local_binary = local_action > 0.5
            true_positive = int((local_binary & teacher_binary).sum())
            false_positive = int((local_binary & ~teacher_binary).sum())
            false_negative = int((~local_binary & teacher_binary).sum())
            records.append({
                "density_group": group,
                "num_nonempty": int((queues > 0).sum()),
                "all_active_to_teacher_ratio": (
                    full_utility / max(teacher_utility, 1e-8)
                ),
                "fraction_links_preferring_on_unilaterally": float(
                    np.mean(np.asarray(deltas) >= 0.0)
                ),
                "all_active_is_unilateral_local_optimum": bool(
                    all(value >= 0.0 for value in deltas)
                ),
                "parallel_unilateral_action_to_teacher_ratio": (
                    local_utility / max(teacher_utility, 1e-8)
                ),
                "label_true_positive": true_positive,
                "label_false_positive": false_positive,
                "label_false_negative": false_negative,
            })
    summary = {
        "setting": "10 UAV / 10 dBm / perfect CSI",
        "num_queue_states": len(records),
        "mean_all_active_to_teacher_ratio": float(np.mean([
            item["all_active_to_teacher_ratio"] for item in records
        ])),
        "mean_fraction_links_preferring_on_unilaterally": float(np.mean([
            item["fraction_links_preferring_on_unilaterally"]
            for item in records
        ])),
        "all_active_unilateral_local_optimum_rate": float(np.mean([
            item["all_active_is_unilateral_local_optimum"] for item in records
        ])),
        "mean_parallel_unilateral_action_to_teacher_ratio": float(np.mean([
            item["parallel_unilateral_action_to_teacher_ratio"]
            for item in records
        ])),
    }
    tp = sum(item["label_true_positive"] for item in records)
    fp = sum(item["label_false_positive"] for item in records)
    fn = sum(item["label_false_negative"] for item in records)
    summary["unilateral_label_precision_vs_teacher"] = tp / max(tp + fp, 1)
    summary["unilateral_label_recall_vs_teacher"] = tp / max(tp + fn, 1)
    summary["unilateral_label_f1_vs_teacher"] = (
        2 * tp / max(2 * tp + fp + fn, 1)
    )
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/parallel_mpnn_local_trap_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump({"summary": summary, "records": records}, file, indent=2)
    print(json.dumps({"report": path, "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
