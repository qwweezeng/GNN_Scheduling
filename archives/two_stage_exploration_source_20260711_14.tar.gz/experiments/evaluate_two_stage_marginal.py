#!/usr/bin/env python3
"""Information-path diagnostics for a trained TwoStage-Marginal-v1 model."""

import argparse
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model, set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.train_two_stage_stratified import flatten_group_samples
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from models.two_stage_marginal import TwoStageMarginalScheduler
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def correlation(first, second):
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    if first.size < 2 or np.std(first) < 1e-12 or np.std(second) < 1e-12:
        return 0.0
    return float(np.corrcoef(first, second)[0, 1])


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({"NUM_UAV": args.num_uav, "TEST_SIZE": args.test_size})
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", queue_range
    )
    grouped = build_stratified_samples(states, queue_range, args.seed + 2)
    samples = flatten_group_samples(grouped)
    channel_model, _ = load_channel_model(cfg, args.num_uav, device)
    model = TwoStageMarginalScheduler(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        edge_hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
    ).to(device)
    checkpoint = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    true_utility = uniform_utility = permuted_utility = 0.0
    uniform_flips = permuted_flips = nonempty_total = 0
    benefits, snrs, harms, edge_weights = [], [], [], []
    reciprocal_differences = []
    with torch.no_grad():
        for state, queues, _ in samples:
            x = state.vertex_features[:, :1].to(device)
            edge_index = state.edge_index.to(device)
            edge_attr = state.edge_weights.to(device)
            queues_device = queues.to(device)

            probability, _ = model(
                x, edge_index, edge_attr, queues=queues_device
            )
            hard = (probability > 0.5).float().cpu()
            true_utility += mws_objective(hard.squeeze(1), queues, state)

            uniform = (queues > 0).to(torch.float32).to(device)
            probability_uniform, _ = model(
                x, edge_index, edge_attr, queues=uniform
            )
            hard_uniform = (probability_uniform > 0.5).float().cpu()
            uniform_utility += mws_objective(
                hard_uniform.squeeze(1), queues, state
            )

            permutation = queues.clone()
            active = (queues > 0).nonzero(as_tuple=True)[0]
            permutation[active] = queues[active.flip(0)]
            probability_permuted, _ = model(
                x, edge_index, edge_attr, queues=permutation.to(device)
            )
            hard_permuted = (probability_permuted > 0.5).float().cpu()
            permuted_utility += mws_objective(
                hard_permuted.squeeze(1), queues, state
            )

            active_mask = (queues > 0).unsqueeze(1)
            nonempty_total += int(active_mask.sum())
            uniform_flips += int(((hard != hard_uniform) & active_mask).sum())
            permuted_flips += int(((hard != hard_permuted) & active_mask).sum())

            quantities = model.latest_channel_quantities
            benefits.extend(quantities["benefit"].cpu().tolist())
            snrs.extend(state.vertex_features[:, 0].cpu().tolist())
            harms.extend(quantities["harm_fraction"].cpu().tolist())
            edge_weights.extend(state.edge_weights.reshape(-1).cpu().tolist())

            edge_to_harm = {
                (int(source), int(target)): float(harm)
                for source, target, harm in zip(
                    edge_index[0].cpu(), edge_index[1].cpu(),
                    quantities["harm_fraction"].cpu()
                )
            }
            for (source, target), harm in edge_to_harm.items():
                reverse = edge_to_harm.get((target, source))
                if reverse is not None and source < target:
                    reciprocal_differences.append(abs(harm - reverse))

    report = {
        "checkpoint": args.checkpoint,
        "num_samples": len(samples),
        "normal_utility": true_utility / len(samples),
        "uniform_queue_utility_ratio_to_normal": uniform_utility / max(true_utility, 1e-12),
        "permuted_queue_utility_ratio_to_normal": permuted_utility / max(true_utility, 1e-12),
        "uniform_queue_hard_flip_rate": uniform_flips / max(nonempty_total, 1),
        "permuted_queue_hard_flip_rate": permuted_flips / max(nonempty_total, 1),
        "benefit_mean": float(np.mean(benefits)),
        "benefit_std": float(np.std(benefits)),
        "benefit_snr_correlation": correlation(benefits, snrs),
        "harm_fraction_mean": float(np.mean(harms)),
        "harm_fraction_std": float(np.std(harms)),
        "harm_edge_weight_correlation": correlation(harms, edge_weights),
        "reciprocal_harm_absolute_difference_mean": (
            float(np.mean(reciprocal_differences))
            if reciprocal_differences else 0.0
        ),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
