#!/usr/bin/env python3
"""Controlled queue-learning diagnostics and TwoStage-GAT-v1 training."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _get_model_path,
    _load_or_generate_dataset,
    _physics_tag,
    build_generator,
    build_model,
    load_config,
)
from models.model import calculate_achievable_rate
from models.two_stage import TwoStageGATScheduler
from train.trainer import sample_link_queues
from utils.mws import centralized_mws_greedy, mws_objective
from utils.queue_features import relative_queue_feature


CONTROL_MODES = (
    "A_base",
    "B_constant_q",
    "C_variable_q_unweighted",
    "D_weighted_continuous",
    "D_weighted_ste",
)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def build_samples(states, mode, queue_range, seed):
    generator = torch.Generator().manual_seed(seed + 104729)
    samples = []
    for state in states:
        if mode == "A_base":
            queues = None
        elif mode == "B_constant_q":
            queues = torch.ones(state.num_vertices)
        else:
            queues = sample_link_queues(state.num_vertices, queue_range, generator)
        samples.append((state, queues))
    return samples


def model_input(state, queues, mode, device):
    snr = state.vertex_features[:, :1].to(device)
    if mode == "A_base":
        return snr
    queue_feature = relative_queue_feature(queues).to(device).unsqueeze(1)
    return torch.cat([snr, queue_feature], dim=1)


def input_stats(samples, mode):
    features = [model_input(s, q, mode, "cpu") for s, q in samples]
    features = torch.cat(features, dim=0)
    return features.mean(0), features.std(0, unbiased=False).clamp_min(1e-6)


def is_weighted(mode):
    return mode.startswith("D_weighted")


def evaluate_control(model, samples, mode, packet_scale, random_seed=999):
    model.eval()
    total_utility = total_mws = total_random = 0.0
    active, probabilities = [], []
    queue_changes, snr_changes = [], []
    generator = torch.Generator().manual_seed(random_seed)
    with torch.no_grad():
        for index, (state, queues) in enumerate(samples):
            device = next(model.parameters()).device
            x = model_input(state, queues, mode, device)
            edge_index = state.edge_index.to(device)
            edge_weights = state.edge_weights.to(device)
            pi, _ = model(x, edge_index, edge_weights)
            probabilities.append(pi.detach().cpu().reshape(-1))
            hard = (pi > 0.5).float()
            if is_weighted(mode):
                q = queues.to(device)
                hard = hard * (q > 0).float().unsqueeze(1)
                utility = mws_objective(hard.squeeze(1).cpu(), queues, state)
                teacher = centralized_mws_greedy(state, queues)
                total_mws += mws_objective(teacher.squeeze(1), queues, state)
                random_pi = (
                    torch.rand(state.num_vertices, generator=generator) < 0.3
                ).float()
                random_pi *= (queues > 0).float()
                total_random += mws_objective(random_pi, queues, state)
            else:
                rates = calculate_achievable_rate(hard, state, binary=False)
                utility = rates.sum().item()
            total_utility += utility
            active.append(hard.sum().item())

            if index < 10 and queues is not None and (queues > 0).sum() >= 2:
                positive = (queues > 0).nonzero(as_tuple=True)[0]
                perm = positive[torch.randperm(positive.numel(), generator=generator)]
                q_perm = queues.clone()
                q_perm[positive] = queues[perm]
                x_perm = model_input(state, q_perm, mode, device)
                p_perm, _ = model(x_perm, edge_index, edge_weights)
                queue_changes.append((pi - p_perm).abs().mean().item())

                x_snr = x.clone()
                order = torch.randperm(x.size(0), generator=generator).to(device)
                x_snr[:, 0] = x[order, 0]
                p_snr, _ = model(x_snr, edge_index, edge_weights)
                snr_changes.append((pi - p_snr).abs().mean().item())

    count = max(len(samples), 1)
    result = {
        "utility": total_utility / count,
        "average_active_links": float(np.mean(active)),
        "probability_mean": torch.cat(probabilities).mean().item(),
        "probability_std": torch.cat(probabilities).std(unbiased=False).item(),
        "queue_probability_change": float(np.mean(queue_changes)) if queue_changes else 0.0,
        "snr_probability_change": float(np.mean(snr_changes)) if snr_changes else 0.0,
    }
    if is_weighted(mode):
        result.update({
            "mws_greedy_utility": total_mws / count,
            "random_utility": total_random / count,
            "mws_ratio": total_utility / max(total_mws, 1e-12),
            "random_mws_ratio": total_random / max(total_mws, 1e-12),
        })
    return result


def train_control(cfg, train_states, val_states, test_states, mode, seed,
                  queue_range, output_dir):
    set_seed(seed)
    train = build_samples(train_states, mode, queue_range, seed)
    val = build_samples(val_states, mode, queue_range, seed + 1)
    test = build_samples(test_states, mode, queue_range, seed + 2)
    raw_dim = 1 if mode == "A_base" else 2
    mean, std = (None, None) if raw_dim == 1 else input_stats(train, mode)
    model = build_model(
        cfg, raw_dim, input_feature_mean=mean, input_feature_std=std,
        use_input_skip=(raw_dim == 2),
    )
    model.stochastic_ste = mode == "D_weighted_ste"
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
    packet_scale = (
        cfg.get("BANDWIDTH", 5e6) * cfg.get("SLOT_DURATION", 0.001)
        / cfg.get("PACKET_SIZE", 12000)
    )
    best_state, best_value = None, -float("inf")
    epoch_logs = []

    for epoch in range(cfg["EPOCHS"]):
        model.train()
        order = list(range(len(train)))
        random.shuffle(order)
        losses, utilities, grad_sign_agreement = [], [], []
        previous_sign = None
        for sample_index in order:
            state, queues = train[sample_index]
            x = model_input(state, queues, mode, device)
            pi, _ = model(
                x, state.edge_index.to(device), state.edge_weights.to(device),
                use_ste=(mode == "D_weighted_ste"),
            )
            if is_weighted(mode):
                q = queues.to(device)
                pi = pi * (q > 0).float().unsqueeze(1)
            rates = calculate_achievable_rate(pi, state, binary=False)
            if is_weighted(mode):
                utility = torch.sum(q * rates * packet_scale)
                loss = -utility / (q.sum().detach() + 1e-8)
            else:
                utility = rates.sum()
                loss = -utility
            optimizer.zero_grad()
            loss.backward()
            final_weight = model.final_scheduler[-1].weight
            sign = torch.sign(final_weight.grad.detach().flatten())
            if previous_sign is not None:
                grad_sign_agreement.append((sign == previous_sign).float().mean().item())
            previous_sign = sign
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(loss.item())
            utilities.append(utility.item())

        val_metrics = evaluate_control(model, val, mode, packet_scale)
        score = val_metrics["utility"]
        if score > best_value:
            best_value, best_state = score, copy.deepcopy(model.state_dict())
        log = {
            "epoch": epoch,
            "loss": float(np.mean(losses)),
            "train_utility": float(np.mean(utilities)),
            "gradient_sign_agreement": float(np.mean(grad_sign_agreement))
            if grad_sign_agreement else None,
            **{f"val_{k}": v for k, v in val_metrics.items()},
        }
        epoch_logs.append(log)
        print(
            f"[{mode} seed={seed} epoch={epoch:02d}] "
            f"loss={log['loss']:.4f} val={score:.4f} "
            f"active={val_metrics['average_active_links']:.2f}"
        )

    model.load_state_dict(best_state)
    test_metrics = evaluate_control(model, test, mode, packet_scale)
    checkpoint_dir = os.path.join("results", "models", "diagnostics")
    os.makedirs(checkpoint_dir, exist_ok=True)
    checkpoint_path = os.path.join(checkpoint_dir, f"{mode}_numUAV={cfg['NUM_UAV']}_s{seed}.pth")
    torch.save({
        "mode": mode,
        "seed": seed,
        "model_state_dict": model.state_dict(),
        "input_feature_mean": mean,
        "input_feature_std": std,
    }, checkpoint_path)
    return {
        "mode": mode,
        "seed": seed,
        "checkpoint": checkpoint_path,
        "test": test_metrics,
        "epochs": epoch_logs,
    }


def load_channel_model(cfg, num_uav, device):
    path = _get_model_path(num_uav, False, cfg)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Base GAT checkpoint not found: {path}")
    model = build_model(cfg, 1)
    checkpoint = torch.load(path, map_location=device)
    if not isinstance(checkpoint, dict) or "model_state_dict" not in checkpoint:
        raise ValueError(
            f"Checkpoint {path} lacks physical metadata; legacy checkpoints "
            "must not be silently reused for the 10 dBm study."
        )
    if (
        checkpoint.get("tx_power_dbm") != float(cfg.get("TX_POWER", 10))
        or checkpoint.get("csi_mode") != cfg.get("CSI_MODE", "perfect")
    ):
        raise ValueError(f"Checkpoint physics mismatch: {path}")
    model.load_state_dict(checkpoint["model_state_dict"])
    return model.to(device).eval(), path


def teacher_samples(states, queue_range, seed):
    samples = build_samples(states, "D_weighted_continuous", queue_range, seed)
    return [(state, queues, centralized_mws_greedy(state, queues)) for state, queues in samples]


def evaluate_two_stage(model, samples, threshold=0.5):
    model.eval()
    utility = teacher_utility = 0.0
    true_positive = predicted_positive = target_positive = correct = total = 0
    empty_active = empty_total = 0
    queue_changes, snr_changes = [], []
    with torch.no_grad():
        for index, (state, queues, target) in enumerate(samples):
            device = next(model.parameters()).device
            x = torch.cat([
                state.vertex_features[:, :1],
                relative_queue_feature(queues).unsqueeze(1),
            ], dim=1).to(device)
            probabilities, _ = model(
                x, state.edge_index.to(device), state.edge_weights.to(device),
                queues=queues.to(device),
            )
            hard = (probabilities > threshold).float().cpu()
            empty = queues <= 0
            empty_active += int((hard.squeeze(1)[empty] > 0).sum())
            empty_total += int(empty.sum())
            utility += mws_objective(hard.squeeze(1), queues, state)
            teacher_utility += mws_objective(target.squeeze(1), queues, state)
            target_bool = target > 0.5
            hard_bool = hard > 0.5
            true_positive += int((hard_bool & target_bool).sum())
            predicted_positive += int(hard_bool.sum())
            target_positive += int(target_bool.sum())
            correct += int((hard_bool == target_bool).sum())
            total += target.numel()

            if index < 10 and (queues > 0).sum() >= 2:
                positive = (queues > 0).nonzero(as_tuple=True)[0]
                q_perm = queues.clone()
                q_perm[positive] = queues[positive.flip(0)]
                p_q, _ = model(
                    x, state.edge_index.to(device), state.edge_weights.to(device),
                    queues=q_perm.to(device),
                )
                queue_changes.append((probabilities - p_q).abs().mean().item())
                x_bad = x.clone()
                target_link = int(positive[0])
                x_bad[target_link, 0] -= 20.0
                p_snr, _ = model(
                    x_bad, state.edge_index.to(device), state.edge_weights.to(device),
                    queues=queues.to(device),
                )
                snr_changes.append(abs(
                    probabilities[target_link].item() - p_snr[target_link].item()
                ))

    precision = true_positive / max(predicted_positive, 1)
    recall = true_positive / max(target_positive, 1)
    return {
        "utility": utility / max(len(samples), 1),
        "teacher_utility": teacher_utility / max(len(samples), 1),
        "mws_ratio": utility / max(teacher_utility, 1e-12),
        "action_accuracy": correct / max(total, 1),
        "precision": precision,
        "recall": recall,
        "f1": 2 * precision * recall / max(precision + recall, 1e-12),
        "average_active_links": predicted_positive / max(len(samples), 1),
        "teacher_average_active_links": target_positive / max(len(samples), 1),
        "queue_probability_change": float(np.mean(queue_changes)) if queue_changes else 0.0,
        "snr_probability_change": float(np.mean(snr_changes)) if snr_changes else 0.0,
        "empty_activation_rate": empty_active / max(empty_total, 1),
    }


def train_two_stage(cfg, train_states, val_states, test_states, queue_range, seed,
                    smoke=False):
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    channel_model, channel_path = load_channel_model(cfg, cfg["NUM_UAV"], device)
    model = TwoStageGATScheduler(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        edge_dim=cfg.get("EDGE_DIM", 1),
        hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
        gat_dim=32,
    ).to(device)
    train = teacher_samples(train_states, queue_range, seed)
    val = teacher_samples(val_states, queue_range, seed + 1)
    test = teacher_samples(test_states, queue_range, seed + 2)
    positives = sum(target.sum().item() for _, _, target in train)
    total = sum(target.numel() for _, _, target in train)
    pos_weight = torch.tensor(
        [(total - positives) / max(positives, 1.0)], device=device
    )
    optimizer = torch.optim.Adam(
        [p for p in model.parameters() if p.requires_grad], lr=1e-4
    )
    best_state, best_ratio, logs = None, -float("inf"), []

    for epoch in range(cfg["EPOCHS"]):
        model.train()
        order = list(range(len(train)))
        random.shuffle(order)
        losses = []
        for idx in order:
            state, queues, target = train[idx]
            x = torch.cat([
                state.vertex_features[:, :1],
                relative_queue_feature(queues).unsqueeze(1),
            ], dim=1).to(device)
            probabilities, _ = model(
                x, state.edge_index.to(device), state.edge_weights.to(device),
                queues=queues.to(device),
            )
            probabilities = probabilities.clamp(1e-6, 1 - 1e-6)
            target = target.to(device)
            loss = F.binary_cross_entropy(
                probabilities, target,
                weight=torch.where(target > 0, pos_weight, torch.ones_like(target)),
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                [p for p in model.parameters() if p.requires_grad], 5.0
            )
            optimizer.step()
            losses.append(loss.item())
        metrics = evaluate_two_stage(model, val)
        logs.append({"epoch": epoch, "loss": float(np.mean(losses)), **metrics})
        if metrics["mws_ratio"] > best_ratio:
            best_ratio = metrics["mws_ratio"]
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[TwoStage epoch={epoch:02d}] loss={np.mean(losses):.4f} "
            f"F1={metrics['f1']:.3f} MWS-ratio={metrics['mws_ratio']:.3f}"
        )

    model.load_state_dict(best_state)
    test_metrics = evaluate_two_stage(model, test)
    model_dir = os.path.join("results", "models", "smoke") if smoke else os.path.join(
        "results", "models"
    )
    os.makedirs(model_dir, exist_ok=True)
    suffix = "_smoke" if smoke else ""
    path = os.path.join(
        model_dir,
        f"gat_queue_two_stage_v1_numUAV={cfg['NUM_UAV']}_"
        f"{_physics_tag(cfg)}{suffix}.pth",
    )
    torch.save({
        "model_version": "two_stage_v1",
        "model_state_dict": model.state_dict(),
        "channel_model_path": channel_path,
        "decision_threshold": 0.5,
        "queue_feature": "one_hop_relative",
        "teacher": "centralized_mws_greedy",
        "queue_range": list(queue_range),
        "seed": seed,
        "pos_weight": pos_weight.item(),
        "tx_power_dbm": float(cfg.get("TX_POWER", 10)),
        "csi_mode": cfg.get("CSI_MODE", "perfect"),
    }, path)
    return {"checkpoint": path, "test": test_metrics, "epochs": logs}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--stage", choices=("all", "controls", "two-stage"), default="all")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=500)
    parser.add_argument("--val_size", type=int, default=64)
    parser.add_argument("--test_size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--seeds", default="42,43,44")
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--quick", action="store_true")
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)
    if args.quick:
        args.train_size, args.val_size, args.test_size, args.epochs = 30, 12, 12, 3
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
        "EPOCHS": args.epochs,
        "LR": 1e-4,
    })
    queue_range = tuple(int(v.strip()) for v in args.queue_range.split(","))
    seeds = [int(v.strip()) for v in args.seeds.split(",") if v.strip()]
    net_gen = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            net_gen, cfg, args.num_uav, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    output_dir = os.path.join(
        "results", "diagnostics", datetime.now().strftime("queue_learning_%Y%m%d_%H%M%S")
    )
    os.makedirs(output_dir, exist_ok=True)
    report = {"config": vars(args), "controls": [], "decision": None}

    if args.stage in ("all", "controls"):
        for mode in CONTROL_MODES:
            for seed in seeds:
                report["controls"].append(train_control(
                    cfg, states["train"], states["val"], states["test"],
                    mode, seed, queue_range, output_dir,
                ))
        weighted = [
            item["test"] for item in report["controls"]
            if item["mode"] in ("D_weighted_continuous", "D_weighted_ste")
        ]
        median_ratio = float(np.median([m["mws_ratio"] for m in weighted]))
        beats_random = float(np.median([
            m["mws_ratio"] - m["random_mws_ratio"] for m in weighted
        ])) > 0
        failed = median_ratio < 0.30 or not beats_random
        report["decision"] = {
            "weighted_median_mws_ratio": median_ratio,
            "weighted_median_beats_random": beats_random,
            "end_to_end_failed": failed,
        }
    else:
        failed = True

    if args.stage == "two-stage" or (args.stage == "all" and failed):
        report["two_stage"] = train_two_stage(
            cfg, states["train"], states["val"], states["test"],
            queue_range, seeds[0], smoke=args.quick,
        )

    report_path = os.path.join(output_dir, "diagnostic_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"[Done] Diagnostic report: {report_path}")


if __name__ == "__main__":
    main()
