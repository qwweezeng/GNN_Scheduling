#!/usr/bin/env python3
"""Static evaluation of the complete predicted-channel two-stage scheduler."""

import argparse
import json
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import evaluate, precompute
from experiments.train_physical_channel_estimator import predicted_quantities
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from models.physical_channel_estimator import PhysicalChannelEstimator
from models.physical_negotiation_v2 import PhysicalNegotiationDecoderV2
from models.physical_negotiation_v3 import PhysicalNegotiationDecoderV3
from models.anchor_one_join import (
    AnchorExactGreedyJoinDecoder, AnchorExactOneJoinDecoder,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--channel_checkpoint", default="")
    parser.add_argument("--negotiation_checkpoint", required=True)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--join_mode", choices=("one", "greedy"), default="one",
        help="Diagnostic join-set constructor for anchor checkpoints.",
    )
    parser.add_argument(
        "--oracle_channel", action="store_true",
        help="Use exact state-derived b/rho to isolate the join structure.",
    )
    args = parser.parse_args()

    cfg = load_config(args.config)
    cfg.update({"NUM_UAV": args.num_uav, "TEST_SIZE": args.test_size})
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", queue_range
    )
    if not args.oracle_channel:
        if not args.channel_checkpoint:
            parser.error("--channel_checkpoint is required without --oracle_channel")
        channel_base, _ = load_channel_model(
            cfg, args.num_uav, torch.device("cpu")
        )
        estimator = PhysicalChannelEstimator(
            channel_base, channel_dim=cfg.get("GAT_OUT_DIM", 48),
            hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
        )
        channel_checkpoint = torch.load(
            args.channel_checkpoint, map_location="cpu"
        )
        estimator.load_state_dict(channel_checkpoint["model_state_dict"])

    negotiation_checkpoint = torch.load(
        args.negotiation_checkpoint, map_location="cpu"
    )
    if negotiation_checkpoint.get("model_version") in {
        "anchor_join_oracle_v1_experimental",
        "anchor_one_join_oracle_v1_experimental",
    }:
        decoder_class = (
            AnchorExactGreedyJoinDecoder
            if args.join_mode == "greedy" else AnchorExactOneJoinDecoder
        )
        decoder = decoder_class(
            hidden_dim=negotiation_checkpoint["hidden_dim"],
            num_rounds=negotiation_checkpoint["num_rounds"],
        )
        decoder.load_anchor_from_anchor_join(
            negotiation_checkpoint["model_state_dict"]
        )
    else:
        decoder_class = {
            "v2_mass_mean": PhysicalNegotiationDecoderV2,
            "v3_scale_invariant": PhysicalNegotiationDecoderV3,
        }[negotiation_checkpoint["decoder_version"]]
        decoder = decoder_class(
            hidden_dim=negotiation_checkpoint["hidden_dim"],
            num_rounds=negotiation_checkpoint["num_rounds"],
        )
        decoder.load_state_dict(negotiation_checkpoint["model_state_dict"])
    grouped = build_stratified_samples(states, queue_range, args.seed + 2)
    if args.oracle_channel:
        physical = precompute(states, cache_path=None)
    else:
        physical = predicted_quantities(estimator, states, torch.device("cpu"))
    print(json.dumps(
        evaluate(decoder, grouped, physical, torch.device("cpu")), indent=2
    ))


if __name__ == "__main__":
    main()
