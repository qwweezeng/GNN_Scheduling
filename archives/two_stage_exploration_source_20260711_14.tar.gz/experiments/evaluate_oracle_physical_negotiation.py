#!/usr/bin/env python3
"""Evaluate a saved oracle PhysicalNegotiation checkpoint on stratified queues."""

import argparse
import json
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.train_oracle_physical_negotiation import evaluate, precompute
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from models.physical_negotiation import PhysicalNegotiationDecoder
from models.physical_negotiation_v2 import PhysicalNegotiationDecoderV2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    cfg = load_config(args.config)
    cfg.update({"NUM_UAV": args.num_uav, "TEST_SIZE": args.test_size})
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", queue_range
    )
    grouped = build_stratified_samples(states, queue_range, args.seed + 2)
    cache_path = os.path.join(
        "results", "cache", "oracle_marginals",
        f"numUAV={args.num_uav}_test_n={len(states)}.pth",
    )
    physical = precompute(states, cache_path)
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    decoder_class = (
        PhysicalNegotiationDecoderV2
        if checkpoint["decoder_version"] == "v2_mass_mean"
        else PhysicalNegotiationDecoder
    )
    model = decoder_class(
        hidden_dim=checkpoint["hidden_dim"],
        num_rounds=checkpoint["num_rounds"],
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    print(json.dumps(evaluate(model, grouped, physical, torch.device("cpu")), indent=2))


if __name__ == "__main__":
    main()
