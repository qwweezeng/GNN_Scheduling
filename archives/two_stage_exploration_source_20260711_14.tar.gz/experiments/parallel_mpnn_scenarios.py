"""Exact micro-scenarios for fixed-round parallel negotiation research.

These scenarios are behavioral unit tests, not assumptions about real UAV
topology.  They use the exact weighted SINR utility and exhaustive schedules.
"""

import itertools

import torch

from models.sequential_set_policy import physical_set_utility


def exhaustive_schedules(queues, effective_snr, inr_matrix):
    """Return all binary schedules sorted by exact Q-weighted utility."""
    records = []
    for bits in itertools.product((0.0, 1.0), repeat=queues.numel()):
        action = torch.tensor(bits, dtype=torch.float32)
        utility = physical_set_utility(
            action, queues, effective_snr, inr_matrix
        )
        records.append((action, float(utility)))
    return sorted(records, key=lambda item: item[1], reverse=True)


def best_action(queues, effective_snr, inr_matrix):
    return exhaustive_schedules(queues, effective_snr, inr_matrix)[0]


def strong_two_link(queues):
    """Two mutually destructive links; queue swap must swap the winner."""
    snr = torch.tensor([10.0, 10.0])
    inr = torch.tensor([[0.0, 30.0], [30.0, 0.0]])
    return queues.float(), snr, inr


def weak_two_link(queues=None):
    """Two compatible links; concurrent service is optimal."""
    queues = torch.ones(2) if queues is None else queues.float()
    snr = torch.tensor([10.0, 10.0])
    inr = torch.tensor([[0.0, 0.05], [0.05, 0.0]])
    return queues, snr, inr


def asymmetric_three_link():
    """A hurts B, B barely hurts A, and C is compatible with A."""
    queues = torch.tensor([5.0, 5.0, 5.0])
    snr = torch.tensor([10.0, 10.0, 10.0])
    # Row=target/victim, column=source/interferer.
    inr = torch.tensor([
        [0.0, 0.10, 0.05],
        [30.0, 0.0, 20.0],
        [0.05, 20.0, 0.0],
    ])
    return queues, snr, inr


def two_weakly_coupled_regions():
    """Two strong-conflict local societies with negligible cross influence."""
    queues = torch.tensor([9.0, 2.0, 3.0, 8.0])
    snr = torch.full((4,), 10.0)
    inr = torch.zeros(4, 4)
    inr[0, 1] = inr[1, 0] = 30.0
    inr[2, 3] = inr[3, 2] = 30.0
    return queues, snr, inr


def scenario_report():
    scenarios = {}
    for name, values in {
        "strong_q_10_1": strong_two_link(torch.tensor([10.0, 1.0])),
        "strong_q_1_10": strong_two_link(torch.tensor([1.0, 10.0])),
        "weak_equal": weak_two_link(),
        "asymmetric_three": asymmetric_three_link(),
        "two_weakly_coupled_regions": two_weakly_coupled_regions(),
    }.items():
        queues, snr, inr = values
        records = exhaustive_schedules(queues, snr, inr)
        scenarios[name] = {
            "queues": queues.tolist(),
            "best_action": records[0][0].int().tolist(),
            "best_utility": records[0][1],
            "second_action": records[1][0].int().tolist(),
            "second_utility": records[1][1],
            "best_margin": records[0][1] - records[1][1],
        }
    return scenarios

