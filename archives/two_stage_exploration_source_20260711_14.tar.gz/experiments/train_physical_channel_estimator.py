#!/usr/bin/env python3
"""Train and evaluate the channel-only directed physical-loss estimator."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model, set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.train_oracle_physical_negotiation import evaluate, precompute
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from models.physical_channel_estimator import PhysicalChannelEstimator
from models.physical_negotiation_v2 import PhysicalNegotiationDecoderV2


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=200)
    parser.add_argument("--val_size", type=int, default=32)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--negotiation_checkpoint", required=True)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def regression_metrics(model, states, targets, device):
    predictions, truths = [], []
    model.eval()
    with torch.no_grad():
        for state, (_, target_harm) in zip(states, targets):
            _, prediction = model(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
                snr_gap=getattr(state, "snr_gap", 1.0),
            )
            predictions.append(prediction.cpu())
            truths.append(target_harm.cpu())
    prediction = torch.cat(predictions)
    truth = torch.cat(truths)
    error = prediction - truth
    correlation = float(np.corrcoef(
        prediction.numpy(), truth.numpy()
    )[0, 1])
    return {
        "mae": error.abs().mean().item(),
        "rmse": torch.sqrt(torch.mean(error.square())).item(),
        "correlation": correlation,
        "prediction_mean": prediction.mean().item(),
        "prediction_std": prediction.std().item(),
        "target_mean": truth.mean().item(),
        "target_std": truth.std().item(),
    }


def predicted_quantities(model, states, device):
    quantities = []
    model.eval()
    with torch.no_grad():
        for state in states:
            solo, harm = model(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
                snr_gap=getattr(state, "snr_gap", 1.0),
            )
            quantities.append((solo.cpu(), harm.cpu()))
    return quantities


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav, "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size, "TEST_SIZE": args.test_size,
    })
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, args.num_uav, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    cache_root = os.path.join("results", "cache", "oracle_marginals")
    targets = {
        split: precompute(split_states, os.path.join(
            cache_root,
            f"numUAV={args.num_uav}_{split}_n={len(split_states)}.pth"
        )) for split, split_states in states.items()
    }
    channel_model, channel_path = load_channel_model(cfg, args.num_uav, device)
    model = PhysicalChannelEstimator(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
    ).to(device)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.Adam(trainable, lr=cfg.get("LR", 1e-4))
    initial = regression_metrics(model, states["val"], targets["val"], device)
    best_state = copy.deepcopy(model.state_dict())
    best_rmse = initial["rmse"]
    best_epoch = -1
    logs = [{"epoch": -1, "loss": None, "validation": initial}]
    print(f"[Setup] trainable={sum(p.numel() for p in trainable)} initial={initial}")

    for epoch in range(args.epochs):
        model.train()
        order = list(range(len(states["train"])))
        random.shuffle(order)
        losses = []
        for index in order:
            state = states["train"][index]
            target_harm = targets["train"][index][1].to(device)
            _, prediction = model(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
                snr_gap=getattr(state, "snr_gap", 1.0),
            )
            loss = F.mse_loss(prediction, target_harm)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 5.0)
            optimizer.step()
            losses.append(loss.item())
        validation = regression_metrics(model, states["val"], targets["val"], device)
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "validation": validation,
        })
        if validation["rmse"] < best_rmse:
            best_rmse = validation["rmse"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.5f} "
            f"MAE={validation['mae']:.4f} RMSE={validation['rmse']:.4f} "
            f"corr={validation['correlation']:.3f}"
        )

    model.load_state_dict(best_state)
    test_regression = regression_metrics(model, states["test"], targets["test"], device)
    negotiation_checkpoint = torch.load(
        args.negotiation_checkpoint, map_location=device
    )
    negotiation = PhysicalNegotiationDecoderV2(
        hidden_dim=negotiation_checkpoint["hidden_dim"],
        num_rounds=negotiation_checkpoint["num_rounds"],
    ).to(device)
    negotiation.load_state_dict(negotiation_checkpoint["model_state_dict"])
    test_grouped = build_stratified_samples(
        states["test"], queue_range, args.seed + 2
    )
    predicted = predicted_quantities(model, states["test"], device)
    scheduling = evaluate(
        negotiation, test_grouped, predicted, device
    )

    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"physical_channel_estimator_numUAV={args.num_uav}_"
        f"train={args.train_size}_ep={args.epochs}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": "physical_channel_estimator_v1_experimental",
        "model_state_dict": model.state_dict(),
        "channel_model_path": channel_path,
        "target": "directed_pairwise_fractional_rate_loss",
        "seed": args.seed,
        "best_epoch": best_epoch,
    }, checkpoint_path)
    report_path = os.path.join(
        "results", "diagnostics",
        f"physical_channel_estimator_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args), "checkpoint": checkpoint_path,
            "best_epoch": best_epoch,
            "test_regression": test_regression,
            "scheduling_with_predicted_channel": scheduling,
            "epochs": logs,
        }, file, indent=2)
    print(f"[Done] checkpoint={checkpoint_path}")
    print(f"[Done] report={report_path}")
    print(json.dumps({
        "test_regression": test_regression,
        "scheduling_with_predicted_channel": scheduling,
    }, indent=2))


if __name__ == "__main__":
    main()
