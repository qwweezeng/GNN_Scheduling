#!/usr/bin/env python3
"""Quantify whether MWS-Greedy's individual action bits are unique targets."""

import argparse
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.two_stage_v1_diagnostics import (
    build_stratified_samples,
    load_model,
)
from utils.mws import mws_objective


def summarize(values):
    values = np.asarray(values, dtype=float)
    if values.size == 0:
        return {"count": 0}
    return {
        "count": int(values.size),
        "mean": float(values.mean()),
        "median": float(np.median(values)),
        "p90": float(np.quantile(values, 0.90)),
        "fraction_le_1pct": float((values <= 0.01).mean()),
        "fraction_le_5pct": float((values <= 0.05).mean()),
        "fraction_le_10pct": float((values <= 0.10).mean()),
    }


def sample_flip_regrets(state, queues, teacher):
    """Return utility-normalized regret caused by flipping every teacher bit."""
    teacher_schedule = teacher.squeeze(1).cpu()
    teacher_utility = mws_objective(teacher_schedule, queues, state)
    denominator = max(teacher_utility, 1e-12)
    regrets = []
    improvements = []
    for link_index in range(state.num_vertices):
        flipped = teacher_schedule.clone()
        flipped[link_index] = 1.0 - flipped[link_index]
        flipped_utility = mws_objective(flipped, queues, state)
        normalized_difference = (teacher_utility - flipped_utility) / denominator
        regrets.append(max(normalized_difference, 0.0))
        improvements.append(max(-normalized_difference, 0.0))
    return np.asarray(regrets), np.asarray(improvements), teacher_schedule.numpy()


def model_schedule(model, state, queues, threshold):
    device = next(model.parameters()).device
    with torch.no_grad():
        probabilities, _ = model(
            state.vertex_features.to(device),
            state.edge_index.to(device),
            state.edge_weights.to(device),
            queues=queues.to(device),
        )
    return (probabilities.cpu().squeeze(1) > threshold).numpy()


def evaluate_group(model, samples, threshold):
    all_regrets = []
    positive_regrets = []
    negative_regrets = []
    improvements = []
    mistake_regrets = []
    correct_regrets = []
    action_errors = 0
    total_actions = 0
    regret_weighted_errors = 0.0
    total_regret_mass = 0.0

    for state, queues, teacher in samples:
        regrets, sample_improvements, teacher_bits = sample_flip_regrets(
            state, queues, teacher
        )
        predictions = model_schedule(model, state, queues, threshold)
        mistakes = predictions != (teacher_bits > 0.5)

        all_regrets.extend(regrets.tolist())
        positive_regrets.extend(regrets[teacher_bits > 0.5].tolist())
        negative_regrets.extend(regrets[teacher_bits <= 0.5].tolist())
        improvements.extend(sample_improvements.tolist())
        mistake_regrets.extend(regrets[mistakes].tolist())
        correct_regrets.extend(regrets[~mistakes].tolist())
        action_errors += int(mistakes.sum())
        total_actions += int(mistakes.size)
        regret_weighted_errors += float(regrets[mistakes].sum())
        total_regret_mass += float(regrets.sum())

    return {
        "all_labels": summarize(all_regrets),
        "teacher_positive_labels": summarize(positive_regrets),
        "teacher_negative_labels": summarize(negative_regrets),
        "greedy_flip_improvements": summarize(improvements),
        "model_mistake_labels": summarize(mistake_regrets),
        "model_correct_labels": summarize(correct_regrets),
        "action_error_rate": action_errors / max(total_actions, 1),
        "regret_weighted_error_fraction": regret_weighted_errors
        / max(total_regret_mass, 1e-12),
    }


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=64)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=20260711)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument(
        "--checkpoint",
        default="results/models/gat_queue_two_stage_v1_numUAV=10.pth",
    )
    parser.add_argument("--output", default=None)
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)
    cfg.update({"NUM_UAV": args.num_uav, "TEST_SIZE": args.test_size})
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    network_generator = build_generator(cfg)
    states = _load_or_generate_dataset(
        network_generator, cfg, args.num_uav, False, "test", queue_range
    )[:args.test_size]
    samples = build_stratified_samples(states, queue_range, args.seed)
    model, _ = load_model(cfg, args.checkpoint, device)

    results = {
        group: evaluate_group(model, group_samples, args.threshold)
        for group, group_samples in samples.items()
    }
    report = {"config": vars(args), "results": results}
    output_path = args.output or os.path.join(
        "results", "diagnostics",
        f"teacher_label_ambiguity_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps(results, indent=2))
    print(f"[Done] report={output_path}")


if __name__ == "__main__":
    main()
