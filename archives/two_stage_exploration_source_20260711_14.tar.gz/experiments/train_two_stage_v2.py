#!/usr/bin/env python3
"""Train experimental TwoStage-GAT-v2 structured local competition."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import (
    evaluate_two_stage,
    load_channel_model,
    set_seed,
)
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.train_two_stage_stratified import (
    build_balanced_train_samples,
    flatten_group_samples,
    per_density_metrics,
)
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS,
    sample_queues_for_density,
)
from models.model import calculate_achievable_rate
from models.two_stage_v2 import TwoStageGATv2Scheduler


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--tx_power", type=float, default=10.0)
    parser.add_argument("--train_size", type=int, default=500)
    parser.add_argument("--val_size", type=int, default=64)
    parser.add_argument("--test_size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--channel_skip", action="store_true")
    parser.add_argument("--loss", choices=("bce", "utility"), default="bce")
    parser.add_argument("--resample_queues_each_epoch", action="store_true")
    parser.add_argument("--urgent_counterfactual", action="store_true")
    parser.add_argument("--init_checkpoint", default=None)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.resample_queues_each_epoch and args.loss != "utility":
        raise ValueError("Per-epoch queue resampling is currently defined for utility loss.")
    if args.urgent_counterfactual and args.loss != "utility":
        raise ValueError("Urgency counterfactuals are currently defined for utility loss.")
    if args.urgent_counterfactual and not args.resample_queues_each_epoch:
        raise ValueError("Urgency counterfactuals require per-epoch queue resampling.")
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power,
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
        "EPOCHS": args.epochs,
    })
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    network_generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            network_generator, cfg, args.num_uav, False, split, queue_range
        )
        for split in ("train", "val", "test")
    }
    train_samples, train_density_counts = build_balanced_train_samples(
        states["train"], queue_range, args.seed
    )
    val_grouped = build_stratified_samples(
        states["val"], queue_range, args.seed + 1
    )
    test_grouped = build_stratified_samples(
        states["test"], queue_range, args.seed + 2
    )
    val_samples = flatten_group_samples(val_grouped)

    channel_model, channel_path = load_channel_model(cfg, args.num_uav, device)
    model = TwoStageGATv2Scheduler(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
        queue_scale=max(queue_range[1], 1),
        use_channel_skip=args.channel_skip,
    ).to(device)
    if args.init_checkpoint:
        initial_checkpoint = torch.load(args.init_checkpoint, map_location=device)
        if initial_checkpoint.get("use_channel_skip", False) != args.channel_skip:
            raise ValueError("Initial checkpoint channel-skip setting is incompatible.")
        model.load_state_dict(initial_checkpoint["model_state_dict"])
        print(f"[Setup] initialized from {args.init_checkpoint}")
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.Adam(trainable, lr=1e-4)
    initial_validation = evaluate_two_stage(model, val_samples)
    best_state = copy.deepcopy(model.state_dict())
    best_ratio = initial_validation["mws_ratio"]
    best_epoch = -1
    logs = [{
        "epoch": -1,
        "loss": None,
        "validation": initial_validation,
        "validation_by_density": per_density_metrics(model, val_grouped),
    }]

    print(f"[Setup] device={device} train_density_counts={train_density_counts}")
    print(
        f"[Setup] loss={args.loss} structured_decoder=True "
        f"resample={args.resample_queues_each_epoch} "
        f"urgent_counterfactual={args.urgent_counterfactual}"
    )
    for epoch in range(args.epochs):
        model.train()
        current_train_samples = train_samples
        if args.resample_queues_each_epoch:
            groups = list(DENSITY_BOUNDS)
            assignments = [
                groups[index % len(groups)] for index in range(len(states["train"]))
            ]
            random.Random(args.seed + 7919 * epoch).shuffle(assignments)
            generators = {
                group: torch.Generator().manual_seed(
                    args.seed + 104729 * epoch + 1009 * group_index
                )
                for group_index, group in enumerate(groups)
            }
            current_train_samples = [
                (
                    state,
                    sample_queues_for_density(
                        state.num_vertices, group, queue_range, generators[group]
                    ),
                    None,
                )
                for state, group in zip(states["train"], assignments)
            ]
            if args.urgent_counterfactual:
                counterfactual_samples = []
                for state, queues, _ in current_train_samples:
                    active = (queues > 0).nonzero(as_tuple=True)[0]
                    if active.numel() < 2:
                        counterfactual_samples.append((state, queues, None))
                        continue
                    first, second = active[:2]
                    queue_a = queues.clone()
                    queue_b = queues.clone()
                    queue_a[first], queue_a[second] = 20.0, 1.0
                    queue_b[first], queue_b[second] = 1.0, 20.0
                    counterfactual_samples.extend([
                        (state, queue_a, None),
                        (state, queue_b, None),
                    ])
                current_train_samples = counterfactual_samples
        order = list(range(len(current_train_samples)))
        random.shuffle(order)
        losses = []
        for sample_index in order:
            state, queues, target = current_train_samples[sample_index]
            probabilities, _ = model(
                state.vertex_features.to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
                queues=queues.to(device),
            )
            if args.loss == "bce":
                loss = F.binary_cross_entropy(
                    probabilities.clamp(1e-6, 1 - 1e-6), target.to(device)
                )
            else:
                queue_device = queues.to(device)
                rates = calculate_achievable_rate(
                    probabilities, state, binary=False
                )
                utility = torch.sum(queue_device * rates)
                loss = -utility / (queue_device.sum().detach() + 1e-8)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 5.0)
            optimizer.step()
            losses.append(loss.item())

        validation = evaluate_two_stage(model, val_samples)
        density_validation = per_density_metrics(model, val_grouped)
        log = {
            "epoch": epoch,
            "loss": float(np.mean(losses)),
            "validation": validation,
            "validation_by_density": density_validation,
        }
        logs.append(log)
        if validation["mws_ratio"] > best_ratio:
            best_ratio = validation["mws_ratio"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={log['loss']:.4f} "
            f"MWS={validation['mws_ratio']:.3f} "
            f"active={validation['average_active_links']:.2f} "
            f"s/m/d={density_validation['sparse']['mws_ratio']:.3f}/"
            f"{density_validation['medium']['mws_ratio']:.3f}/"
            f"{density_validation['dense']['mws_ratio']:.3f}"
        )

    model.load_state_dict(best_state)
    test_by_density = per_density_metrics(model, test_grouped)
    test_combined = evaluate_two_stage(model, flatten_group_samples(test_grouped))
    os.makedirs(args.output_dir, exist_ok=True)
    variant = "channel_skip" if args.channel_skip else "structured"
    if args.loss == "utility":
        variant += "_utility"
    if args.resample_queues_each_epoch:
        variant += "_resampled"
    if args.urgent_counterfactual:
        variant += "_urgent_cf"
    if args.init_checkpoint:
        variant += "_finetune"
    checkpoint_path = os.path.join(
        args.output_dir,
        f"gat_queue_two_stage_v2_{variant}_numUAV={args.num_uav}_"
        f"tx={args.tx_power:g}dBm_csi={cfg.get('CSI_MODE', 'perfect')}_"
        f"s{args.seed}.pth",
    )
    torch.save({
        "model_version": "two_stage_v2_experimental",
        "model_state_dict": model.state_dict(),
        "channel_model_path": channel_path,
        "decision_threshold": 0.5,
        "queue_feature": "local_log_queue",
        "teacher": "centralized_mws_greedy",
        "loss": args.loss,
        "decoder": "bidirectional_weighted_local_competition",
        "use_channel_skip": args.channel_skip,
        "sampling": "balanced_sparse_medium_dense",
        "resample_queues_each_epoch": args.resample_queues_each_epoch,
        "urgent_counterfactual": args.urgent_counterfactual,
        "init_checkpoint": args.init_checkpoint,
        "queue_range": list(queue_range),
        "seed": args.seed,
        "best_epoch": best_epoch,
        "tx_power_dbm": args.tx_power,
        "csi_mode": cfg.get("CSI_MODE", "perfect"),
    }, checkpoint_path)
    report_path = os.path.join(
        "results", "diagnostics",
        f"two_stage_v2_structured_tx{args.tx_power:g}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args),
            "checkpoint": checkpoint_path,
            "train_density_counts": train_density_counts,
            "best_epoch": best_epoch,
            "best_validation_mws_ratio": best_ratio,
            "test_combined": test_combined,
            "test_by_density": test_by_density,
            "epochs": logs,
        }, file, indent=2)
    print(f"[Done] checkpoint={checkpoint_path}")
    print(f"[Done] report={report_path}")
    print(json.dumps(test_by_density, indent=2))


if __name__ == "__main__":
    main()
