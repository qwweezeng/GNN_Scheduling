#!/usr/bin/env python3
"""Train the one-join categorical policy around a frozen learned anchor."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import (
    precompute, resample_training_distribution,
)
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS, build_stratified_samples,
)
from models.anchor_one_join import AnchorOneJoinDecoder
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--anchor_checkpoint", required=True)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=200)
    parser.add_argument("--val_size", type=int, default=32)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--queue_sampling", default="mixed_hotspot")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def choice_rewards(model, state, queues, solo, harm, anchor, hidden,
                   relative, nonempty):
    probabilities, candidates, _ = model.join_distribution(
        anchor, hidden, relative, nonempty, state.edge_index, harm
    )
    rewards = []
    base_action = torch.zeros(state.num_vertices)
    base_action[anchor] = 1.0
    rewards.append(mws_objective(base_action, queues, state))
    for candidate in candidates.tolist():
        action = base_action.clone()
        action[candidate] = 1.0
        rewards.append(mws_objective(action, queues, state))
    reward_tensor = probabilities.new_tensor(rewards) / (
        float(queues.sum()) + 1e-8
    )
    return probabilities, reward_tensor, candidates


def evaluate(model, grouped, physical):
    result = {}
    model.eval()
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            utility = teacher_utility = expected_utility = 0.0
            active_total = join_total = permuted_utility = 0.0
            queue_flips = nonempty_total = all_zero = 0
            for index, (state, queues, teacher) in enumerate(grouped[group]):
                solo, harm = physical[index]
                action, diagnostics = model(
                    solo, harm, queues, state.edge_index
                )
                utility += mws_objective(action.squeeze(1), queues, state)
                teacher_utility += mws_objective(
                    teacher.squeeze(1), queues, state
                )
                active_total += action.sum().item()
                join_total += int(diagnostics["join"] is not None)
                all_zero += int(action.sum() == 0 and (queues > 0).any())
                probabilities, rewards, _ = choice_rewards(
                    model, state, queues, solo, harm,
                    diagnostics["anchor"], diagnostics["anchor_hidden"],
                    diagnostics["relative_value"], diagnostics["nonempty"],
                )
                expected_utility += float(
                    torch.sum(probabilities * rewards) * queues.sum()
                )

                positive = (queues > 0).nonzero(as_tuple=True)[0]
                permuted = queues.clone()
                permuted[positive] = queues[positive.flip(0)]
                permuted_action, _ = model(
                    solo, harm, permuted, state.edge_index
                )
                queue_flips += int(((action != permuted_action) &
                                    (queues > 0).unsqueeze(1)).sum())
                nonempty_total += int((queues > 0).sum())
                permuted_utility += mws_objective(
                    permuted_action.squeeze(1), queues, state
                )
            count = len(grouped[group])
            result[group] = {
                "mws_ratio": utility / teacher_utility,
                "expected_choice_mws_ratio": expected_utility / teacher_utility,
                "average_active_links": active_total / count,
                "join_selection_rate": join_total / count,
                "all_zero_rate": all_zero / count,
                "queue_permutation_hard_flip_rate": queue_flips / max(nonempty_total, 1),
                "permuted_queue_utility_ratio_to_normal": (
                    permuted_utility / max(utility, 1e-12)
                ),
                "_utility": utility,
                "_teacher": teacher_utility,
                "_expected": expected_utility,
                "_active": active_total,
                "_joins": join_total,
                "_count": count,
            }
    totals = {
        key: sum(result[group][key] for group in DENSITY_BOUNDS)
        for key in ("_utility", "_teacher", "_expected", "_active", "_joins", "_count")
    }
    result["combined"] = {
        "mws_ratio": totals["_utility"] / totals["_teacher"],
        "expected_choice_mws_ratio": totals["_expected"] / totals["_teacher"],
        "average_active_links": totals["_active"] / totals["_count"],
        "join_selection_rate": totals["_joins"] / totals["_count"],
        "all_zero_rate": 0.0,
    }
    for group in DENSITY_BOUNDS:
        for key in list(result[group]):
            if key.startswith("_"):
                del result[group][key]
    return result


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav, "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size, "TEST_SIZE": args.test_size,
    })
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    states = {
        split: _load_or_generate_dataset(
            build_generator(cfg), cfg, args.num_uav, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    cache_root = "results/cache/oracle_marginals"
    physical = {
        split: precompute(split_states, os.path.join(
            cache_root, f"numUAV={args.num_uav}_{split}_n={len(split_states)}.pth"
        )) for split, split_states in states.items()
    }
    val_grouped = build_stratified_samples(states["val"], queue_range, args.seed + 1)
    test_grouped = build_stratified_samples(states["test"], queue_range, args.seed + 2)

    anchor_checkpoint = torch.load(args.anchor_checkpoint, map_location="cpu")
    model = AnchorOneJoinDecoder(
        anchor_checkpoint["hidden_dim"], anchor_checkpoint["num_rounds"]
    )
    copied = model.load_anchor_from_anchor_join(
        anchor_checkpoint["model_state_dict"]
    )
    model.freeze_anchor()
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.Adam(trainable, lr=cfg.get("LR", 1e-4))
    initial = evaluate(model, val_grouped, physical["val"])
    best_value = initial["combined"]["mws_ratio"]
    best_state = copy.deepcopy(model.state_dict())
    best_epoch = -1
    logs = [{"epoch": -1, "loss": None, "validation": initial}]
    print(
        f"[Setup] copied_anchor_tensors={copied} "
        f"trainable_join_params={sum(p.numel() for p in trainable)} "
        f"initial_MWS={best_value:.3f}"
    )

    for epoch in range(args.epochs):
        model.train()
        samples = resample_training_distribution(
            states["train"], queue_range, args.seed + 104729 * epoch,
            args.queue_sampling,
        )
        order = list(range(len(samples)))
        random.shuffle(order)
        losses = []
        for index in order:
            state, queues = samples[index]
            solo, harm = physical["train"][index]
            logits, hidden, relative, nonempty = model.anchor_context(
                solo, harm, queues, state.edge_index
            )
            anchor = torch.argmax(logits)
            probabilities, rewards, _ = choice_rewards(
                model, state, queues, solo, harm, anchor, hidden,
                relative, nonempty,
            )
            loss = -torch.sum(probabilities * rewards.detach())
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 5.0)
            optimizer.step()
            losses.append(loss.item())
        validation = evaluate(model, val_grouped, physical["val"])
        combined = validation["combined"]
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "validation": validation,
        })
        if combined["mws_ratio"] > best_value:
            best_value = combined["mws_ratio"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.4f} "
            f"MWS={combined['mws_ratio']:.3f} "
            f"expected={combined['expected_choice_mws_ratio']:.3f} "
            f"active={combined['average_active_links']:.2f} "
            f"join_rate={combined['join_selection_rate']:.3f}"
        )

    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped, physical["test"])
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"anchor_one_join_oracle_numUAV={args.num_uav}_train={args.train_size}_"
        f"ep={args.epochs}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": "anchor_one_join_oracle_v1_experimental",
        "model_state_dict": model.state_dict(),
        "hidden_dim": model.hidden_dim, "num_rounds": model.num_rounds,
        "anchor_checkpoint": args.anchor_checkpoint,
        "best_epoch": best_epoch, "seed": args.seed,
    }, checkpoint_path)
    report_path = os.path.join(
        "results", "diagnostics",
        f"anchor_one_join_oracle_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args), "checkpoint": checkpoint_path,
            "best_epoch": best_epoch, "test": test, "epochs": logs,
        }, file, indent=2)
    print(f"[Done] checkpoint={checkpoint_path}")
    print(f"[Done] report={report_path}")
    print(json.dumps(test, indent=2))


if __name__ == "__main__":
    main()
