#!/usr/bin/env python3
"""Audit which minimal LocalMax priority is justified before large-scale use."""

import argparse
import json
import os
import sys
import time
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_localmax_reuse_headroom import (
    DENSITY_BOUNDS,
    build_static_samples,
    jsonify,
)
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from models.parallel_reuse import LocalPhysicalReuseScheduler
from models.two_stage import QueueChannelLocalMaxScheduler
from utils.mws import centralized_mws_greedy, mws_objective
from utils.parallel_reuse import exact_join_margins, local_margin_winners


PRIORITY_MODES = (
    "local_relative_channel",
    "raw_queue_channel",
    "raw_queue_gat_rate",
    "raw_queue_solo",
    "raw_queue",
)


def parse_int_list(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def empty_totals():
    return {
        "count": 0,
        "teacher": 0.0,
        "base": 0.0,
        "local_reuse": 0.0,
        "exact_reuse": 0.0,
        "base_active": 0.0,
        "local_active": 0.0,
        "exact_active": 0.0,
        "harmful_local": 0,
        "base_scale_changes": 0,
        "reuse_scale_changes": 0,
        "runtime_s": 0.0,
    }


def summarize(totals, has_teacher):
    count = max(totals["count"], 1)
    exact_gain = totals["exact_reuse"] - totals["base"]
    local_gain = totals["local_reuse"] - totals["base"]
    result = {
        "num_samples": totals["count"],
        "local_fraction_of_exact_gain": (
            local_gain / exact_gain if exact_gain > 1e-12 else None
        ),
        "local_to_exact_reuse_ratio": (
            totals["local_reuse"] / max(totals["exact_reuse"], 1e-12)
        ),
        "harmful_local_reuse_rate": totals["harmful_local"] / count,
        "base_scale_change_rate": totals["base_scale_changes"] / count,
        "reuse_scale_change_rate": totals["reuse_scale_changes"] / count,
        "average_active_links": {
            "base": totals["base_active"] / count,
            "local_reuse": totals["local_active"] / count,
            "exact_reuse": totals["exact_active"] / count,
        },
        "average_utility": {
            "base": totals["base"] / count,
            "local_reuse": totals["local_reuse"] / count,
            "exact_reuse": totals["exact_reuse"] / count,
        },
        "average_runtime_ms": 1000.0 * totals["runtime_s"] / count,
    }
    if has_teacher:
        teacher = max(totals["teacher"], 1e-12)
        result.update({
            "base_mws_ratio": totals["base"] / teacher,
            "local_reuse_mws_ratio": totals["local_reuse"] / teacher,
            "exact_reuse_mws_ratio": totals["exact_reuse"] / teacher,
        })
    return result


def add_sample(totals, state, queues, localmax, reuse, teacher_action=None):
    start = time.perf_counter()
    base = localmax.schedule_with_state(state, queues).reshape(-1).cpu()
    local_action = reuse.schedule_with_state(state, queues).reshape(-1).cpu()
    exact_margins = exact_join_margins(state, queues, base)
    exact_joiners = local_margin_winners(exact_margins, state.edge_index)
    exact_action = torch.maximum(base, exact_joiners.float())
    scaled_queues = 7.0 * queues
    scaled_base = localmax.schedule_with_state(
        state, scaled_queues
    ).reshape(-1).cpu()
    scaled_local = reuse.schedule_with_state(
        state, scaled_queues
    ).reshape(-1).cpu()
    totals["runtime_s"] += time.perf_counter() - start

    base_utility = mws_objective(base, queues, state)
    local_utility = mws_objective(local_action, queues, state)
    totals["base"] += base_utility
    totals["local_reuse"] += local_utility
    totals["exact_reuse"] += mws_objective(exact_action, queues, state)
    if teacher_action is not None:
        totals["teacher"] += mws_objective(teacher_action, queues, state)
    totals["base_active"] += float(base.sum())
    totals["local_active"] += float(local_action.sum())
    totals["exact_active"] += float(exact_action.sum())
    totals["harmful_local"] += int(local_utility + 1e-9 < base_utility)
    totals["base_scale_changes"] += int(not torch.equal(base, scaled_base))
    totals["reuse_scale_changes"] += int(
        not torch.equal(local_action, scaled_local)
    )
    totals["count"] += 1


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--queue_seeds", default="44,45,46")
    parser.add_argument("--channel_model_num_uav", type=int, default=10)
    parser.add_argument(
        "--skip_mws_teacher", action="store_true",
        help="Skip cubic centralized MWS-Greedy; recommended for 50 UAV.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "TEST_SIZE": args.test_size,
    })
    channel_model, channel_path = load_channel_model(
        cfg, args.channel_model_num_uav, torch.device("cpu")
    )
    schedulers = {
        mode: QueueChannelLocalMaxScheduler(
            channel_model, priority_mode=mode
        )
        for mode in PRIORITY_MODES
    }
    reuse_schedulers = {
        mode: LocalPhysicalReuseScheduler(scheduler)
        for mode, scheduler in schedulers.items()
    }
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", (0, 20)
    )
    grouped = build_static_samples(
        states, (0, 20), parse_int_list(args.queue_seeds)
    )
    has_teacher = not args.skip_mws_teacher
    results = {mode: {} for mode in PRIORITY_MODES}
    overall = {mode: empty_totals() for mode in PRIORITY_MODES}

    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            group_totals = {mode: empty_totals() for mode in PRIORITY_MODES}
            for state, queues in grouped[group]:
                teacher = (
                    centralized_mws_greedy(state, queues).reshape(-1).cpu()
                    if has_teacher else None
                )
                for mode in PRIORITY_MODES:
                    add_sample(
                        group_totals[mode], state, queues,
                        schedulers[mode], reuse_schedulers[mode], teacher,
                    )
            for mode in PRIORITY_MODES:
                results[mode][group] = summarize(
                    group_totals[mode], has_teacher
                )
                for key, value in group_totals[mode].items():
                    overall[mode][key] += value

    for mode in PRIORITY_MODES:
        results[mode]["overall"] = summarize(overall[mode], has_teacher)
        print(mode, results[mode]["overall"])

    graph_stats = {
        "num_states": len(states),
        "average_links": sum(s.num_vertices for s in states) / max(len(states), 1),
        "average_directed_edges": sum(
            s.edge_index.size(1) for s in states
        ) / max(len(states), 1),
    }
    graph_stats["average_directed_degree"] = (
        graph_stats["average_directed_edges"]
        / max(graph_stats["average_links"], 1e-12)
    )
    report = {
        "experiment": "localmax_priority_audit",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "physical_setting": {
            "tx_power_dbm": 10.0,
            "csi_mode": "perfect",
            "channel_checkpoint": channel_path,
        },
        "graph_stats": graph_stats,
        "results": results,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/localmax_priority_audit_"
        f"numUAV={args.num_uav}_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({"report": path, "graph_stats": graph_stats}, indent=2))


if __name__ == "__main__":
    main()
