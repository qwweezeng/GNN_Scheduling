#!/usr/bin/env python3
"""Check whether normalized edge weights can analytically recover pairwise loss."""

import json
import math
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import precompute


def reconstructed_rho(state, snr_threshold_db=5.0, assumed_max_raw=1e5):
    source, target = state.edge_index[0], state.edge_index[1]
    normalized_log_weight = state.edge_weights.reshape(-1)
    max_log = math.log10(assumed_max_raw + 1.0)
    raw_ratio = torch.pow(10.0, normalized_log_weight * max_log) - 1.0
    target_snr = torch.pow(10.0, state.vertex_features[target, 0] / 10.0)
    beta = 10.0 ** (snr_threshold_db / 10.0)
    interference_to_noise = raw_ratio * (target_snr / beta - 1.0).clamp_min(0.0)
    solo = torch.log2(1.0 + target_snr / getattr(state, "snr_gap", 1.0))
    pair = torch.log2(
        1.0 + target_snr /
        ((1.0 + interference_to_noise) * getattr(state, "snr_gap", 1.0))
    )
    return ((solo - pair) / solo.clamp_min(1e-8)).clamp(0.0, 1.0)


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    oracle = precompute(
        states, "results/cache/oracle_marginals/numUAV=10_test_n=32.pth"
    )
    prediction = torch.cat([
        reconstructed_rho(state, cfg.get("SNR_THRES", 5.0))
        for state in states
    ])
    target = torch.cat([item[1] for item in oracle])
    error = prediction - target
    report = {
        "assumption": (
            "per-graph maximum raw conflict weight is the shared-endpoint "
            "sentinel 1e5"
        ),
        "graphs_with_normalized_max_one": sum(
            abs(float(state.edge_weights.max()) - 1.0) < 1e-6
            for state in states
        ),
        "num_graphs": len(states),
        "mae": error.abs().mean().item(),
        "rmse": torch.sqrt(error.square().mean()).item(),
        "correlation": float(np.corrcoef(
            prediction.numpy(), target.numpy()
        )[0, 1]),
        "prediction_mean": prediction.mean().item(),
        "prediction_std": prediction.std().item(),
        "target_mean": target.mean().item(),
        "target_std": target.std().item(),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
