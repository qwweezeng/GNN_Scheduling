#!/usr/bin/env python3
"""Calibrate ParallelMPNN on queue states induced by its own rollouts."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_parallel_mpnn import (
    evaluate, full_oracle_quantities, model_action, training_loss,
)
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from models.model import calculate_achievable_rate
from models.parallel_mpnn import ParallelMPNN
from utils.mws import centralized_mws_greedy


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--rollout_slots", type=int, default=120)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--lr", type=float, default=3e-4)
    return parser.parse_args()


def load_initial(seed):
    path = (
        "results/models/experimental/parallel_mpnn_v1_tx=10dBm_"
        "numUAV=10_rounds=2_objective=local_best_response_"
        f"s{seed}.pth"
    )
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    model = ParallelMPNN(
        checkpoint["hidden_dim"], checkpoint["num_rounds"],
        checkpoint["channel_rounds"],
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    return model, path


def arrival_rates(num_links, total_lambda, generator):
    num_hotspot = min(max(1, int(np.ceil(0.20 * num_links))), num_links)
    hotspot = torch.randperm(num_links, generator=generator)[:num_hotspot]
    rates = torch.full((num_links,), total_lambda * 0.30 / max(num_links - num_hotspot, 1))
    rates[hotspot] = total_lambda * 0.70 / num_hotspot
    return rates


def rollout_samples(model, states, quantities, seed, num_slots):
    snapshots = {10, 30, 60, num_slots}
    samples = []
    for index, state in enumerate(states):
        generator = torch.Generator().manual_seed(seed + 104729 * index)
        total_lambda = (1.0, 2.0, 3.0)[index % 3]
        link_arrival_rates = arrival_rates(
            state.num_vertices, total_lambda, generator
        )
        queues = torch.zeros(state.num_vertices)
        for slot in range(1, num_slots + 1):
            with torch.no_grad():
                _, action, _ = model_action(
                    model, state, queues, quantities[id(state)]
                )
                rates = calculate_achievable_rate(
                    action, state, binary=True
                ).reshape(-1)
            departures = rates * getattr(state, "bandwidth", 5e6) * 0.001 / 12000.0
            arrivals = torch.poisson(link_arrival_rates, generator=generator)
            queues = torch.clamp(queues - torch.minimum(queues, departures), min=0.0)
            queues = queues + arrivals
            if slot in snapshots and (queues > 0).any():
                target = centralized_mws_greedy(state, queues)
                samples.append((state, queues.clone(), target))
    return samples


def calibration_loss(model, samples, quantities):
    """Held-out loss on policy-induced queue states; lower is better."""
    model.eval()
    losses = []
    with torch.no_grad():
        for state, queues, target in samples:
            losses.append(float(training_loss(
                model, state, queues, quantities[id(state)],
                "teacher_calibration", target,
            )))
    return float(np.mean(losses))


def main():
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TRAIN_SIZE": 80, "VAL_SIZE": 20, "TEST_SIZE": 20,
    })
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, 10, False, split, (0, 20)
        ) for split in ("train", "val", "test")
    }
    all_states = states["train"] + states["val"] + states["test"]
    quantities = {id(state): full_oracle_quantities(state) for state in all_states}
    val_grouped = build_stratified_samples(states["val"], (0, 20), args.seed + 1)
    test_grouped = build_stratified_samples(states["test"], (0, 20), args.seed + 2)
    model, initial_path = load_initial(args.seed)
    samples = rollout_samples(
        model, states["train"], quantities, args.seed, args.rollout_slots
    )
    validation_samples = rollout_samples(
        model, states["val"], quantities, args.seed + 1, args.rollout_slots
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    initial_validation = evaluate(model, val_grouped, quantities)
    initial_calibration_loss = calibration_loss(
        model, validation_samples, quantities
    )
    best_calibration_loss = initial_calibration_loss
    best_epoch = -1
    best_state = copy.deepcopy(model.state_dict())
    logs = []
    for epoch in range(args.epochs):
        model.train()
        order = list(range(len(samples)))
        random.shuffle(order)
        losses = []
        for index in order:
            state, queues, target = samples[index]
            loss = training_loss(
                model, state, queues, quantities[id(state)],
                "teacher_calibration", target,
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        validation = evaluate(model, val_grouped, quantities)
        held_out_calibration_loss = calibration_loss(
            model, validation_samples, quantities
        )
        ratio = validation["combined"]["mws_ratio"]
        if held_out_calibration_loss < best_calibration_loss:
            best_calibration_loss = held_out_calibration_loss
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "held_out_calibration_loss": held_out_calibration_loss,
            "validation": validation,
        })
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.4f} "
            f"heldout={held_out_calibration_loss:.4f} "
            f"MWS={ratio:.3f} active={validation['combined']['average_active']:.2f}"
        )
    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped, quantities)
    checkpoint_path = (
        "results/models/experimental/parallel_mpnn_v1_tx=10dBm_"
        "numUAV=10_rounds=2_objective=rollout_calibration_"
        f"s{args.seed}.pth"
    )
    torch.save({
        "model_version": model.model_version,
        "model_state_dict": model.state_dict(),
        "hidden_dim": model.hidden_dim,
        "num_rounds": model.num_rounds,
        "channel_rounds": model.channel_rounds,
        "objective": "rollout_calibration",
        "initial_checkpoint": initial_path,
        "num_rollout_samples": len(samples),
        "num_validation_rollout_samples": len(validation_samples),
        "rollout_slots": args.rollout_slots,
        "tx_power_dbm": 10.0,
        "csi_mode": "perfect",
        "best_epoch": best_epoch,
    }, checkpoint_path)
    os.makedirs("results/diagnostics", exist_ok=True)
    report_path = (
        "results/diagnostics/parallel_mpnn_v1_tx10_rollout_calibration_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args), "checkpoint": checkpoint_path,
            "initial_checkpoint": initial_path,
            "num_rollout_samples": len(samples),
            "num_validation_rollout_samples": len(validation_samples),
            "initial_calibration_loss": initial_calibration_loss,
            "best_calibration_loss": best_calibration_loss,
            "selection_metric": "held_out_policy_induced_teacher_loss",
            "best_epoch": best_epoch,
            "test": test, "epochs": logs,
        }, file, indent=2)
    print(json.dumps({
        "report": report_path, "checkpoint": checkpoint_path,
        "num_samples": len(samples), "test": test["combined"],
    }, indent=2))


if __name__ == "__main__":
    main()
