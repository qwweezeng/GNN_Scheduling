#!/usr/bin/env python3
"""Test the fixed marginal combiner with exact physical channel quantities."""

import argparse
import json
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS,
    build_stratified_samples,
)
from models.model import calculate_achievable_rate
from models.two_stage_marginal import marginal_utility_probabilities
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def exact_channel_marginals(state):
    """Return exact solo rate and directed pairwise fractional rate loss."""
    num_links = state.num_vertices
    solo_rate = torch.zeros(num_links, dtype=torch.float32)
    for link in range(num_links):
        schedule = torch.zeros(num_links, 1, dtype=torch.float32)
        schedule[link] = 1.0
        solo_rate[link] = calculate_achievable_rate(
            schedule, state, binary=True
        )[link]

    fractions = torch.zeros(state.edge_index.size(1), dtype=torch.float32)
    for edge, (source, target) in enumerate(state.edge_index.t().tolist()):
        schedule = torch.zeros(num_links, 1, dtype=torch.float32)
        schedule[source] = 1.0
        schedule[target] = 1.0
        pair_rate = calculate_achievable_rate(schedule, state, binary=True)[target]
        fractions[edge] = (
            (solo_rate[target] - pair_rate) / solo_rate[target].clamp_min(1e-8)
        ).clamp(0.0, 1.0)
    return solo_rate, fractions


def main():
    args = parse_args()
    cfg = load_config(args.config)
    cfg.update({"NUM_UAV": args.num_uav, "TEST_SIZE": args.test_size})
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", queue_range
    )
    grouped = build_stratified_samples(states, queue_range, args.seed + 2)
    channel_quantities = [exact_channel_marginals(state) for state in states]

    results = {}
    total_utility = total_teacher = 0.0
    for group in DENSITY_BOUNDS:
        utility = teacher_utility = 0.0
        active_links = teacher_active = 0.0
        for index, (state, queues, teacher) in enumerate(grouped[group]):
            solo_rate, harm_fraction = channel_quantities[index]
            probability, _ = marginal_utility_probabilities(
                solo_rate, queues, state.edge_index, harm_fraction
            )
            hard = (probability > 0.5).float()
            utility += mws_objective(hard, queues, state)
            teacher_utility += mws_objective(teacher.squeeze(1), queues, state)
            active_links += hard.sum().item()
            teacher_active += teacher.sum().item()
        results[group] = {
            "mws_ratio": utility / max(teacher_utility, 1e-12),
            "average_active_links": active_links / len(grouped[group]),
            "teacher_average_active_links": teacher_active / len(grouped[group]),
        }
        total_utility += utility
        total_teacher += teacher_utility

    all_solo = torch.cat([quantities[0] for quantities in channel_quantities])
    all_harm = torch.cat([
        quantities[1] for quantities in channel_quantities
        if quantities[1].numel() > 0
    ])
    print(json.dumps({
        "definition": {
            "benefit": "exact rate when the link transmits alone",
            "harm_fraction": (
                "fractional target-rate loss when source and target transmit together"
            ),
        },
        "combined_mws_ratio": total_utility / max(total_teacher, 1e-12),
        "by_density": results,
        "solo_rate_mean": all_solo.mean().item(),
        "harm_fraction_mean": all_harm.mean().item(),
        "harm_fraction_std": all_harm.std().item(),
    }, indent=2))


if __name__ == "__main__":
    main()
