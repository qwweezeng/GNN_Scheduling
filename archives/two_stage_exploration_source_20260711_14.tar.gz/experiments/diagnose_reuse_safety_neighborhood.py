#!/usr/bin/env python3
"""Diagnose whether a fixed number of weak safety neighbors explains reuse risk."""

import argparse
import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_local_margin_sufficiency import (
    empty_totals,
    summarize,
)
from experiments.diagnose_localmax_reuse_headroom import (
    DENSITY_BOUNDS,
    build_static_samples,
    jsonify,
)
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from models.two_stage import QueueChannelLocalMaxScheduler
from utils.mws import centralized_mws_greedy, mws_objective
from utils.parallel_reuse import (
    exact_join_margins,
    local_margin_winners,
    topk_safety_join_margins,
)


def parse_int_list(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def add_sample(totals, state, queues, localmax, topk):
    base = localmax.schedule_with_state(state, queues).reshape(-1).cpu()
    exact_margins = exact_join_margins(state, queues, base)
    safety_margins = topk_safety_join_margins(
        state, queues, base, topk=topk
    )
    valid = torch.isfinite(exact_margins)
    exact_positive = exact_margins[valid] > 0
    safety_positive = safety_margins[valid] > 0
    totals["candidate_count"] += int(valid.sum())
    totals["correct_sign"] += int((exact_positive == safety_positive).sum())
    totals["true_positive"] += int((exact_positive & safety_positive).sum())
    totals["predicted_positive"] += int(safety_positive.sum())
    totals["target_positive"] += int(exact_positive.sum())

    exact_joiners = local_margin_winners(exact_margins, state.edge_index)
    safety_joiners = local_margin_winners(safety_margins, state.edge_index)
    exact_action = torch.maximum(base, exact_joiners.float())
    safety_action = torch.maximum(base, safety_joiners.float())
    teacher = centralized_mws_greedy(state, queues).reshape(-1).cpu()
    base_utility = mws_objective(base, queues, state)
    safety_utility = mws_objective(safety_action, queues, state)
    totals["localmax_utility"] += base_utility
    totals["local_physical_utility"] += safety_utility
    totals["exact_utility"] += mws_objective(exact_action, queues, state)
    totals["teacher_utility"] += mws_objective(teacher, queues, state)
    totals["harmful_count"] += int(safety_utility + 1e-9 < base_utility)
    totals["count"] += 1


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--queue_seeds", default="44,45,46")
    parser.add_argument("--topk", default="0,1,2,4,8")
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "TEST_SIZE": args.test_size,
    })
    channel_model, channel_path = load_channel_model(
        cfg, 10, torch.device("cpu")
    )
    localmax = QueueChannelLocalMaxScheduler(channel_model)
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", (0, 20)
    )
    grouped = build_static_samples(
        states, (0, 20), parse_int_list(args.queue_seeds)
    )

    results = {}
    with torch.no_grad():
        for topk in parse_int_list(args.topk):
            overall = empty_totals()
            by_density = {}
            for group in DENSITY_BOUNDS:
                totals = empty_totals()
                for state, queues in grouped[group]:
                    add_sample(totals, state, queues, localmax, topk)
                by_density[group] = summarize(totals)
                for key, value in totals.items():
                    overall[key] += value
            results[str(topk)] = {
                "overall": summarize(overall),
                "by_density": by_density,
            }
            print(f"topk={topk}: {results[str(topk)]['overall']}")

    report = {
        "experiment": "fixed_degree_reuse_safety_neighborhood",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "definition": (
            "Each link adds its top-k strongest directed interferers omitted "
            "by the conflict graph for margin estimation only. Candidate "
            "competition still uses the original conflict graph."
        ),
        "settings": vars(args),
        "channel_checkpoint": channel_path,
        "results": results,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/reuse_safety_neighborhood_"
        f"numUAV={args.num_uav}_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({"report": path}, indent=2))


if __name__ == "__main__":
    main()
