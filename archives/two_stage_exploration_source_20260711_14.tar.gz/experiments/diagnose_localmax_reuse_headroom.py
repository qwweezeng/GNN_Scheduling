#!/usr/bin/env python3
"""Feasibility gate for LocalMax plus one-round parallel reuse.

This script does not train a new policy.  It asks whether the proposed
two-step structure has enough physical headroom before learning is attempted.
Exact join margins use global simulator state and are therefore an oracle, not
a deployable method.
"""

import argparse
import json
import os
import random
import sys
import time
from datetime import datetime
from types import SimpleNamespace

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    CentralizedMWSGreedyScheduler,
    _load_or_generate_dataset,
    build_generator,
    load_config,
    simulation_phase,
)
from models.two_stage import QueueChannelLocalMaxScheduler
from utils.mws import centralized_mws_greedy, mws_objective
from utils.parallel_reuse import exact_join_margins, local_margin_winners


DENSITY_BOUNDS = {
    "sparse": (0.0, 0.10),
    "medium": (0.10, 0.40),
    "dense": (0.40, 1.00),
}

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def parse_int_list(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def parse_float_list(text):
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def jsonify(value):
    if isinstance(value, dict):
        return {str(key): jsonify(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonify(item) for item in value]
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def sample_queues(num_links, group, queue_range, generator):
    """Generate scale-controlled sparse/medium/dense queue snapshots."""
    if num_links <= 0:
        return torch.empty(0, dtype=torch.float32)
    lower_ratio, upper_ratio = DENSITY_BOUNDS[group]
    lower = max(1, int(np.floor(lower_ratio * num_links)) + 1)
    upper = max(lower, int(np.ceil(upper_ratio * num_links)))
    upper = min(upper, num_links)
    num_nonempty = int(torch.randint(
        lower, upper + 1, (1,), generator=generator
    ).item())
    low, high = int(queue_range[0]), int(queue_range[1])
    low = max(low, 1)
    high = max(high, low + 1)
    active = torch.randperm(num_links, generator=generator)[:num_nonempty]
    queues = torch.zeros(num_links, dtype=torch.float32)
    queues[active] = torch.randint(
        low, high, (num_nonempty,), generator=generator
    ).float()
    return queues


def build_static_samples(states, queue_range, queue_seeds):
    grouped = {group: [] for group in DENSITY_BOUNDS}
    for queue_seed in queue_seeds:
        for group_index, group in enumerate(DENSITY_BOUNDS):
            generator = torch.Generator().manual_seed(
                queue_seed + 1009 * group_index
            )
            for state in states:
                queues = sample_queues(
                    state.num_vertices, group, queue_range, generator
                )
                grouped[group].append((state, queues))
    return grouped


class QueueAwareRandomScheduler:
    """Random baseline that never activates an empty queue."""

    def __init__(self, activation_probability=0.3, seed=12345):
        self.activation_probability = float(activation_probability)
        self.generator = torch.Generator().manual_seed(seed)

    def eval(self):
        return self

    def schedule_with_state(self, state, queues):
        del state
        action = (
            torch.rand(queues.numel(), generator=self.generator)
            < self.activation_probability
        ).float()
        return (action * (queues.cpu() > 0).float()).unsqueeze(1)


class ExactSequentialReuseScheduler:
    """Oracle upper bound: repeatedly add the largest exact positive margin."""

    def __init__(self, localmax):
        self.localmax = localmax

    def eval(self):
        self.localmax.eval()
        return self

    def schedule_with_state(self, state, queues):
        action = self.localmax.schedule_with_state(
            state, queues
        ).reshape(-1).cpu()
        while True:
            margins = exact_join_margins(state, queues, action)
            best = int(torch.argmax(margins))
            if not torch.isfinite(margins[best]) or margins[best] <= 1e-9:
                break
            action[best] = 1.0
        return action.unsqueeze(1)


class ExactParallelReuseScheduler:
    """Oracle test: one exact-margin computation and one local join round."""

    def __init__(self, localmax):
        self.localmax = localmax
        self.last_diagnostics = {}

    def eval(self):
        self.localmax.eval()
        return self

    def schedule_with_state(self, state, queues):
        base = self.localmax.schedule_with_state(
            state, queues
        ).reshape(-1).cpu()
        margins = exact_join_margins(state, queues, base)
        joiners = local_margin_winners(margins, state.edge_index)
        action = torch.maximum(base, joiners.float())
        base_utility = mws_objective(base, queues.cpu(), state)
        final_utility = mws_objective(action, queues.cpu(), state)
        selected_margin_sum = float(margins[joiners].sum()) if joiners.any() else 0.0
        self.last_diagnostics = {
            "positive_candidates": int((margins > 1e-9).sum()),
            "selected_joiners": int(joiners.sum()),
            "base_utility": base_utility,
            "final_utility": final_utility,
            "actual_gain": final_utility - base_utility,
            "sum_individual_selected_margins": selected_margin_sum,
            "interaction_loss": selected_margin_sum - (final_utility - base_utility),
            "harmful_parallel_join": final_utility + 1e-9 < base_utility,
        }
        return action.unsqueeze(1)


def empty_static_totals():
    return {
        "count": 0,
        "teacher": 0.0,
        "localmax": 0.0,
        "sequential": 0.0,
        "parallel": 0.0,
        "local_active": 0.0,
        "sequential_active": 0.0,
        "parallel_active": 0.0,
        "positive_candidates": 0.0,
        "selected_joiners": 0.0,
        "parallel_harmful_count": 0,
        "interaction_loss": 0.0,
        "local_runtime_s": 0.0,
        "sequential_runtime_s": 0.0,
        "parallel_runtime_s": 0.0,
        "teacher_runtime_s": 0.0,
    }


def update_totals(totals, state, queues, localmax, sequential, parallel):
    start = time.perf_counter()
    local_action = localmax.schedule_with_state(state, queues).reshape(-1)
    totals["local_runtime_s"] += time.perf_counter() - start

    start = time.perf_counter()
    sequential_action = sequential.schedule_with_state(state, queues).reshape(-1)
    totals["sequential_runtime_s"] += time.perf_counter() - start

    start = time.perf_counter()
    parallel_action = parallel.schedule_with_state(state, queues).reshape(-1)
    totals["parallel_runtime_s"] += time.perf_counter() - start

    start = time.perf_counter()
    teacher_action = centralized_mws_greedy(state, queues).reshape(-1)
    totals["teacher_runtime_s"] += time.perf_counter() - start

    totals["localmax"] += mws_objective(local_action, queues, state)
    totals["sequential"] += mws_objective(sequential_action, queues, state)
    totals["parallel"] += mws_objective(parallel_action, queues, state)
    totals["teacher"] += mws_objective(teacher_action, queues, state)
    totals["local_active"] += float(local_action.sum())
    totals["sequential_active"] += float(sequential_action.sum())
    totals["parallel_active"] += float(parallel_action.sum())
    totals["positive_candidates"] += parallel.last_diagnostics["positive_candidates"]
    totals["selected_joiners"] += parallel.last_diagnostics["selected_joiners"]
    totals["parallel_harmful_count"] += int(
        parallel.last_diagnostics["harmful_parallel_join"]
    )
    totals["interaction_loss"] += parallel.last_diagnostics["interaction_loss"]
    totals["count"] += 1


def summarize_static(totals):
    count = max(int(totals["count"]), 1)
    teacher = max(totals["teacher"], 1e-12)
    local_gain = totals["sequential"] - totals["localmax"]
    parallel_gain = totals["parallel"] - totals["localmax"]
    return {
        "num_samples": int(totals["count"]),
        "localmax_mws_ratio": totals["localmax"] / teacher,
        "sequential_reuse_mws_ratio": totals["sequential"] / teacher,
        "parallel_reuse_mws_ratio": totals["parallel"] / teacher,
        "parallel_fraction_of_sequential_gain": (
            parallel_gain / local_gain if local_gain > 1e-12 else None
        ),
        "localmax_average_active": totals["local_active"] / count,
        "sequential_average_active": totals["sequential_active"] / count,
        "parallel_average_active": totals["parallel_active"] / count,
        "average_positive_join_candidates": totals["positive_candidates"] / count,
        "average_selected_parallel_joiners": totals["selected_joiners"] / count,
        "harmful_parallel_join_rate": totals["parallel_harmful_count"] / count,
        "average_parallel_interaction_loss": totals["interaction_loss"] / count,
        "average_runtime_ms": {
            "localmax": 1000.0 * totals["local_runtime_s"] / count,
            "sequential_reuse": 1000.0 * totals["sequential_runtime_s"] / count,
            "parallel_reuse": 1000.0 * totals["parallel_runtime_s"] / count,
            "mws_greedy": 1000.0 * totals["teacher_runtime_s"] / count,
        },
    }


def static_gate(states, queue_range, queue_seeds, localmax, sequential, parallel):
    grouped = build_static_samples(states, queue_range, queue_seeds)
    overall = empty_static_totals()
    by_density = {}
    with torch.no_grad():
        for group, samples in grouped.items():
            group_totals = empty_static_totals()
            for state, queues in samples:
                update_totals(
                    group_totals, state, queues, localmax, sequential, parallel
                )
            for key, value in group_totals.items():
                overall[key] += value
            by_density[group] = summarize_static(group_totals)
    return {"overall": summarize_static(overall), "by_density": by_density}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument(
        "--channel_model_num_uav", type=int, default=10,
        help="Training scale of the frozen channel GAT; default tests 10->N transfer.",
    )
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--queue_seeds", default="44,45,46")
    parser.add_argument("--num_slots", type=int, default=500)
    parser.add_argument("--arrival_rates", default="0.5,1,2,4")
    parser.add_argument("--mc_seeds", default="42,43,44")
    parser.add_argument(
        "--slots_per_block", type=int, default=0,
        help="0 keeps one channel realization; positive values enable block fading.",
    )
    parser.add_argument("--skip_dynamic", action="store_true")
    parser.add_argument("--include_sequential_dynamic", action="store_true")
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(20260714 + args.num_uav)
    queue_range = tuple(parse_int_list(args.queue_range))
    if len(queue_range) != 2:
        raise ValueError("--queue_range must contain exactly two integers")
    queue_seeds = parse_int_list(args.queue_seeds)
    mc_seeds = parse_int_list(args.mc_seeds)
    arrival_rates = parse_float_list(args.arrival_rates)

    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "TEST_SIZE": args.test_size,
    })
    channel_model, checkpoint_path = load_channel_model(
        cfg, args.channel_model_num_uav, torch.device("cpu")
    )
    localmax = QueueChannelLocalMaxScheduler(channel_model)
    sequential = ExactSequentialReuseScheduler(localmax)
    parallel = ExactParallelReuseScheduler(localmax)

    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", queue_range
    )
    static = static_gate(
        states, queue_range, queue_seeds, localmax, sequential, parallel
    )

    dynamic = None
    dynamic_details = None
    if not args.skip_dynamic:
        models = {
            "Random-Q": (QueueAwareRandomScheduler(), "Queue-aware Random p=0.3"),
            "LocalMax": (localmax, "One-hop LocalMax"),
            "LocalMax+ParallelReuse": (
                parallel, "One-round exact parallel reuse oracle"
            ),
            "MWS-Greedy": (CentralizedMWSGreedyScheduler(), "MWS-Greedy"),
        }
        if args.include_sequential_dynamic:
            models["LocalMax+SequentialReuse"] = (
                sequential, "Sequential exact reuse oracle"
            )
        dynamic, dynamic_details = simulation_phase(
            build_generator(cfg), models, cfg,
            SimpleNamespace(
                num_slots=args.num_slots,
                arrival_rates=arrival_rates,
                mc_seeds=mc_seeds,
                slots_per_block=(
                    args.slots_per_block if args.slots_per_block > 0 else None
                ),
            ),
        )

    report = {
        "experiment": "localmax_parallel_reuse_feasibility_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "physical_setting": {
            "num_uav": args.num_uav,
            "tx_power_dbm": 10.0,
            "csi_mode": "perfect",
            "channel_model_training_num_uav": args.channel_model_num_uav,
            "channel_checkpoint": checkpoint_path,
        },
        "scope": (
            "Feasibility upper bound only. Exact reuse margins use centralized "
            "full physical state and are not deployable."
        ),
        "settings": {
            "test_size": args.test_size,
            "queue_range": queue_range,
            "queue_seeds": queue_seeds,
            "num_slots": args.num_slots,
            "arrival_rates": arrival_rates,
            "mc_seeds": mc_seeds,
            "slots_per_block": args.slots_per_block,
        },
        "static": static,
        "dynamic": dynamic,
        "dynamic_details": dynamic_details,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/localmax_parallel_reuse_gate_"
        f"numUAV={args.num_uav}_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({
        "report": path,
        "static_overall": static["overall"],
    }, indent=2))


if __name__ == "__main__":
    main()
