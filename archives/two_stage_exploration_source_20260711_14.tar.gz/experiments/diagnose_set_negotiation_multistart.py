#!/usr/bin/env python3
"""Test whether SetNegotiation-v3 can ever generate high-utility schedules.

This is an evaluation-only diagnostic.  For each fixed (channel, queue) state,
the trained policy is sampled repeatedly while only its initial set and binary
transition draws change.  Comparing expected single-rollout utility with
best-of-many utility separates "good schedules are rare" from "the generator
cannot produce good schedules".
"""

import argparse
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (  # noqa: E402
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.train_parallel_mpnn import full_oracle_quantities  # noqa: E402
from experiments.train_set_negotiation import (  # noqa: E402
    flatten,
    random_initial_action,
)
from experiments.two_stage_v1_diagnostics import (  # noqa: E402
    build_stratified_samples,
)
from models.set_negotiation import SetNegotiationV3  # noqa: E402
from utils.mws import centralized_mws_greedy, mws_objective  # noqa: E402


DEFAULT_CHECKPOINT = (
    "results/models/experimental/set_negotiation_v3_tx=10dBm_"
    "numUAV=10_revisions=2_objective=elite_set_"
    "init=uniform_cardinality_s42.pth"
)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def load_model(checkpoint_path):
    checkpoint = torch.load(
        checkpoint_path, map_location="cpu", weights_only=True
    )
    if checkpoint.get("model_version") != "set_negotiation_v3":
        raise ValueError("diagnostic requires a set_negotiation_v3 checkpoint")
    model = SetNegotiationV3(
        hidden_dim=checkpoint["hidden_dim"],
        num_revisions=checkpoint["num_revisions"],
        channel_rounds=checkpoint["channel_rounds"],
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    return model.eval(), checkpoint


def dense_hotspot_samples(states, repeats, seed):
    """Approximate the relative queue pattern seen after hotspot buildup."""
    generator = torch.Generator().manual_seed(seed)
    samples = []
    for state in states:
        for _ in range(repeats):
            num_links = state.num_vertices
            queues = torch.randint(
                1, 21, (num_links,), generator=generator
            ).float()
            num_hotspot = min(
                max(1, int(np.ceil(0.20 * num_links))), num_links
            )
            hotspot = torch.randperm(
                num_links, generator=generator
            )[:num_hotspot]
            queues[hotspot] = torch.randint(
                40, 101, (num_hotspot,), generator=generator
            ).float()
            teacher = centralized_mws_greedy(state, queues)
            samples.append((state, queues, teacher))
    return samples


def rollout_schedules(model, quantities, queues, num_samples,
                      randomness_mode="full"):
    solo, harm, edge_index = quantities
    schedules = []
    if randomness_mode not in (
        "full", "initial_only", "transition_only", "threshold_transition"
    ):
        raise ValueError(f"unknown randomness_mode: {randomness_mode}")
    fixed_initial = (
        random_initial_action(queues)
        if randomness_mode == "transition_only" else None
    )
    if randomness_mode == "initial_only":
        fixed_uniforms = [
            torch.rand(queues.numel()) for _ in range(model.num_revisions)
        ]
    elif randomness_mode == "threshold_transition":
        fixed_uniforms = [
            torch.full((queues.numel(),), 0.5)
            for _ in range(model.num_revisions)
        ]
    else:
        fixed_uniforms = None
    with torch.no_grad():
        for _ in range(num_samples):
            initial = (
                fixed_initial
                if fixed_initial is not None else random_initial_action(queues)
            )
            uniforms = (
                fixed_uniforms
                if fixed_uniforms is not None else [
                    torch.rand(queues.numel())
                    for _ in range(model.num_revisions)
                ]
            )
            action, _ = model(
                solo, harm, queues, edge_index,
                initial_action=initial,
                random_uniforms=uniforms,
            )
            schedules.append(action.reshape(-1).cpu())
    return torch.stack(schedules)


def pairwise_hamming(schedules):
    """Mean normalized Hamming distance over unique rollout pairs."""
    if schedules.size(0) < 2 or schedules.size(1) == 0:
        return 0.0
    difference = schedules.unsqueeze(1) != schedules.unsqueeze(0)
    distance = difference.float().mean(dim=2)
    upper = torch.triu(
        torch.ones_like(distance, dtype=torch.bool), diagonal=1
    )
    return float(distance[upper].mean())


def summarize_rollouts(utilities, active_counts, budgets, teacher_utility):
    utilities = torch.as_tensor(utilities, dtype=torch.float32)
    active_counts = torch.as_tensor(active_counts, dtype=torch.float32)
    best = {}
    for budget in budgets:
        used = min(int(budget), utilities.numel())
        index = int(torch.argmax(utilities[:used]))
        best[str(budget)] = {
            "utility": float(utilities[index]),
            "mws_greedy_ratio": float(utilities[index])
            / max(float(teacher_utility), 1e-12),
            "active_links": float(active_counts[index]),
        }
    return {
        "mean_utility": float(utilities.mean()),
        "mean_mws_greedy_ratio": float(utilities.mean())
        / max(float(teacher_utility), 1e-12),
        "mean_active_links": float(active_counts.mean()),
        "best_of": best,
    }


def evaluate_distribution(model, samples, quantities, num_rollouts, budgets,
                          seed, randomness_mode="full"):
    set_seed(seed)
    totals = {
        "teacher": 0.0,
        "expected": 0.0,
        "best": {str(k): 0.0 for k in budgets},
        "active": 0.0,
        "best_active": {str(k): 0.0 for k in budgets},
        "unique_fraction": 0.0,
        "pairwise_hamming": 0.0,
        "nonempty_coverage": 0.0,
        "states": 0,
    }
    per_state = []
    for state, queues, teacher in samples:
        schedules = rollout_schedules(
            model, quantities[id(state)], queues, num_rollouts,
            randomness_mode=randomness_mode,
        )
        utilities = torch.tensor([
            mws_objective(schedule, queues, state)
            for schedule in schedules
        ])
        active_counts = schedules.sum(dim=1)
        teacher_utility = mws_objective(
            teacher.reshape(-1), queues, state
        )
        summary = summarize_rollouts(
            utilities, active_counts, budgets, teacher_utility
        )
        nonempty = queues > 0
        coverage = (
            float(schedules[:, nonempty].bool().any(dim=0).float().mean())
            if bool(nonempty.any()) else 1.0
        )
        unique_fraction = len({
            tuple(schedule.to(torch.int8).tolist())
            for schedule in schedules
        }) / num_rollouts
        hamming = pairwise_hamming(schedules[:, nonempty])

        totals["teacher"] += teacher_utility
        totals["expected"] += summary["mean_utility"]
        totals["active"] += summary["mean_active_links"]
        totals["unique_fraction"] += unique_fraction
        totals["pairwise_hamming"] += hamming
        totals["nonempty_coverage"] += coverage
        totals["states"] += 1
        for budget in budgets:
            entry = summary["best_of"][str(budget)]
            totals["best"][str(budget)] += entry["utility"]
            totals["best_active"][str(budget)] += entry["active_links"]
        per_state.append({
            "num_links": int(state.num_vertices),
            "nonempty_links": int(nonempty.sum()),
            "teacher_utility": teacher_utility,
            "unique_schedule_fraction": unique_fraction,
            "pairwise_hamming": hamming,
            "nonempty_link_coverage": coverage,
            **summary,
        })

    count = max(totals["states"], 1)
    aggregate = {
        "num_states": totals["states"],
        "randomness_mode": randomness_mode,
        "single_rollout_expected_mws_ratio": (
            totals["expected"] / max(totals["teacher"], 1e-12)
        ),
        "single_rollout_mean_active_links": totals["active"] / count,
        "mean_unique_schedule_fraction": (
            totals["unique_fraction"] / count
        ),
        "mean_pairwise_hamming": totals["pairwise_hamming"] / count,
        "mean_nonempty_link_coverage": (
            totals["nonempty_coverage"] / count
        ),
        "best_of": {},
    }
    for budget in budgets:
        aggregate["best_of"][str(budget)] = {
            "mws_greedy_ratio": (
                totals["best"][str(budget)]
                / max(totals["teacher"], 1e-12)
            ),
            "mean_active_links": (
                totals["best_active"][str(budget)] / count
            ),
        }
    return {"aggregate": aggregate, "per_state": per_state}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", default=DEFAULT_CHECKPOINT)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--num_rollouts", type=int, default=64)
    parser.add_argument("--budgets", default="1,2,4,8,16,32,64")
    parser.add_argument("--hotspot_repeats", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20260713)
    parser.add_argument("--output", default=None)
    return parser.parse_args()


def main():
    args = parse_args()
    budgets = tuple(sorted({
        int(value) for value in args.budgets.split(",") if value.strip()
    }))
    if max(budgets) > args.num_rollouts:
        raise ValueError("all budgets must be <= num_rollouts")
    set_seed(args.seed)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "TEST_SIZE": args.test_size,
    })
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )[:args.test_size]
    quantities = {
        id(state): full_oracle_quantities(state) for state in states
    }
    stratified = flatten(build_stratified_samples(
        states, (0, 20), args.seed + 1
    ))
    dense_hotspot = dense_hotspot_samples(
        states, args.hotspot_repeats, args.seed + 2
    )
    model, checkpoint = load_model(args.checkpoint)
    report = {
        "scope": (
            "Evaluation-only multistart diagnostic; repeated rollouts are not "
            "a proposed deployment-time Best-of-K scheduler."
        ),
        "question": (
            "Can the fixed SetNegotiation-v3 policy ever generate a high-"
            "utility schedule when only its within-slot randomness changes?"
        ),
        "checkpoint": args.checkpoint,
        "checkpoint_metadata": {
            key: value for key, value in checkpoint.items()
            if key != "model_state_dict"
        },
        "settings": {
            "num_uav": 10,
            "tx_power_dbm": 10.0,
            "test_size": len(states),
            "num_rollouts": args.num_rollouts,
            "budgets": budgets,
            "hotspot_repeats": args.hotspot_repeats,
            "seed": args.seed,
        },
        "stratified_static": evaluate_distribution(
            model, stratified, quantities, args.num_rollouts, budgets,
            args.seed + 100,
        ),
        "dense_hotspot": {
            mode: evaluate_distribution(
                model, dense_hotspot, quantities, args.num_rollouts, budgets,
                args.seed + 200, randomness_mode=mode,
            )
            for mode in (
                "full", "initial_only", "transition_only",
                "threshold_transition",
            )
        },
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    output = args.output or (
        "results/diagnostics/set_negotiation_v3_multistart_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    with open(output, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({
        "report": output,
        "stratified_static": report["stratified_static"]["aggregate"],
        "dense_hotspot": {
            mode: result["aggregate"]
            for mode, result in report["dense_hotspot"].items()
        },
    }, indent=2))


if __name__ == "__main__":
    main()
