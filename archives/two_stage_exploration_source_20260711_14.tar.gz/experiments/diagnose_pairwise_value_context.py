#!/usr/bin/env python3
"""Ablate neighbor queues in the pairwise QoS anchor-value model."""

import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.sequential_set_policy import (
    QueueConditionedAnchorValueNetwork, complete_physical_graph,
)
from models.two_stage_physical import exact_state_greedy_from_anchor
from utils.mws import mws_objective


CHECKPOINT = "results/models/experimental/anchor_value_model_pairwise_value_numUAV=10_train=200_ep=10_s43.pth"


def ablated_scores(model, state, queues, mode):
    edge_index, snr, inr, edge_attr = complete_physical_graph(state)
    channel = model.channel_encoder(snr, edge_index, edge_attr)
    if mode == "zero_channel":
        channel = torch.zeros_like(channel)
    value = queues * torch.log2(1.0 + snr)
    relative = value / value.max().clamp_min(1e-8)
    neighbor_relative = relative
    if mode == "zero_neighbor_queue":
        neighbor_relative = torch.zeros_like(relative)
    elif mode == "shuffle_neighbor_queue":
        neighbor_relative = relative[torch.randperm(relative.numel())]
    num_links = relative.numel()
    pair_feature = torch.cat([
        channel[:, None, :].expand(-1, num_links, -1),
        channel[None, :, :].expand(num_links, -1, -1),
        relative[:, None, None].expand(-1, num_links, -1),
        neighbor_relative[None, :, None].expand(num_links, -1, -1),
        torch.log10(1.0 + inr.t()).unsqueeze(2),
        torch.log10(1.0 + inr).unsqueeze(2),
    ], dim=2)
    messages = model.pair_mlp(pair_feature)
    eye = torch.eye(num_links, dtype=torch.bool)
    active_neighbor = (queues > 0)[None, :] & ~eye
    messages = messages * active_neighbor.unsqueeze(2)
    aggregate = messages.sum(dim=1) / max(num_links ** 0.5, 1.0)
    return model.value_head(torch.cat([
        channel, aggregate, relative.unsqueeze(1)
    ], dim=1)).reshape(-1), value


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    grouped = build_stratified_samples(states, (0, 20), 45)
    checkpoint = torch.load(CHECKPOINT, map_location="cpu")
    model = QueueConditionedAnchorValueNetwork()
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    torch.manual_seed(20260712)
    report = {}
    with torch.no_grad():
        for mode in (
            "normal", "zero_channel", "zero_neighbor_queue",
            "shuffle_neighbor_queue",
        ):
            utility = greedy = teacher = agreements = samples = 0.0
            for group in DENSITY_BOUNDS:
                for state, queues, target in grouped[group]:
                    scores, value = ablated_scores(model, state, queues, mode)
                    active = (queues > 0).nonzero(as_tuple=True)[0]
                    anchor = active[torch.argmax(scores[active])]
                    greedy_anchor = active[torch.argmax(value[active])]
                    _, learned_utility = exact_state_greedy_from_anchor(
                        anchor, state, queues
                    )
                    _, greedy_utility = exact_state_greedy_from_anchor(
                        greedy_anchor, state, queues
                    )
                    utility += float(learned_utility)
                    greedy += float(greedy_utility)
                    teacher += mws_objective(target.squeeze(1), queues, state)
                    agreements += int(anchor == greedy_anchor)
                    samples += 1
            report[mode] = {
                "mws_ratio": utility / teacher,
                "to_immediate_greedy": utility / greedy,
                "anchor_agreement_with_immediate_greedy": agreements / samples,
            }
    report["control"] = (
        "Candidate own Qb remains exact; only other links' queue values are ablated."
    )
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"pairwise_value_context_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": report, "path": path}, indent=2))


if __name__ == "__main__":
    main()
