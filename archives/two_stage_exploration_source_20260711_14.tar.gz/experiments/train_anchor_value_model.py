#!/usr/bin/env python3
"""Learn anchor action-values from self-generated final physical utility."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_anchor_join import resample_training_distribution
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.sequential_set_policy import (
    QueueAwareSequentialSetPolicy, QueueConditionedAnchorValueNetwork,
    complete_physical_graph,
    exact_addition_deltas,
)
from models.two_stage_physical import exact_state_greedy_from_anchor
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=100)
    parser.add_argument("--val_size", type=int, default=32)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--sampled_anchors", type=int, default=8)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--init_checkpoint", default="")
    parser.add_argument(
        "--model_version", choices=("queue_gat", "pairwise_value"),
        default="queue_gat",
    )
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def anchor_scores(model, state, queues):
    if isinstance(model, QueueConditionedAnchorValueNetwork):
        return model.scores(state, queues)
    edge_index, snr, inr, edge_attr = complete_physical_graph(state)
    channel = model.channel_encoder(snr, edge_index, edge_attr)
    selected = torch.zeros_like(snr)
    context = model.dynamic_queue_context(
        channel, queues, selected, snr, edge_index, edge_attr
    )
    delta = exact_addition_deltas(selected, queues, snr, inr)
    scale = (queues * torch.log2(1.0 + snr)).max().clamp_min(1e-8)
    scores = model.choice_mlp(torch.cat([
        context, (delta / scale).unsqueeze(1)
    ], dim=1)).reshape(-1)
    return scores, delta


def self_generated_value_loss(model, state, queues, sampled_anchors, generator):
    scores, delta = anchor_scores(model, state, queues)
    active = (queues > 0).nonzero(as_tuple=True)[0]
    greedy_anchor = active[torch.argmax(delta[active])]
    predicted_anchor = active[torch.argmax(scores.detach()[active])]
    random_anchors = active[torch.randperm(
        active.numel(), generator=generator
    )[:min(sampled_anchors, active.numel())]]
    candidates = torch.unique(torch.cat([
        random_anchors, greedy_anchor.reshape(1), predicted_anchor.reshape(1)
    ]))
    _, baseline = exact_state_greedy_from_anchor(
        greedy_anchor, state, queues
    )
    targets = []
    for anchor in candidates:
        _, utility = exact_state_greedy_from_anchor(anchor, state, queues)
        targets.append((utility / baseline.clamp_min(1e-8)).detach())
    targets = torch.stack(targets)
    return F.mse_loss(scores[candidates], targets), targets.mean()


def evaluate(model, grouped):
    result = {}
    model.eval()
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            learned = greedy = teacher = 0.0
            learned_active = greedy_active = 0.0
            for state, queues, target in grouped[group]:
                scores, delta = anchor_scores(model, state, queues)
                active = (queues > 0).nonzero(as_tuple=True)[0]
                learned_anchor = active[torch.argmax(scores[active])]
                greedy_anchor = active[torch.argmax(delta[active])]
                learned_action, learned_utility = exact_state_greedy_from_anchor(
                    learned_anchor, state, queues
                )
                greedy_action, greedy_utility = exact_state_greedy_from_anchor(
                    greedy_anchor, state, queues
                )
                learned += float(learned_utility)
                greedy += float(greedy_utility)
                teacher += mws_objective(target.squeeze(1), queues, state)
                learned_active += float(learned_action.sum())
                greedy_active += float(greedy_action.sum())
            count = len(grouped[group])
            result[group] = {
                "learned_value_anchor_mws_ratio": learned / teacher,
                "immediate_greedy_mws_ratio": greedy / teacher,
                "learned_to_greedy": learned / greedy,
                "learned_average_active": learned_active / count,
                "greedy_average_active": greedy_active / count,
                "_raw": [learned, greedy, teacher, learned_active, greedy_active, count],
            }
    raw = [sum(result[group]["_raw"][i] for group in DENSITY_BOUNDS) for i in range(6)]
    result["combined"] = {
        "learned_value_anchor_mws_ratio": raw[0] / raw[2],
        "immediate_greedy_mws_ratio": raw[1] / raw[2],
        "learned_to_greedy": raw[0] / raw[1],
        "learned_average_active": raw[3] / raw[5],
        "greedy_average_active": raw[4] / raw[5],
    }
    for group in DENSITY_BOUNDS:
        del result[group]["_raw"]
    return result


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav, "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size, "TEST_SIZE": args.test_size,
    })
    queue_range = tuple(int(value) for value in args.queue_range.split(","))
    network_generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            network_generator, cfg, args.num_uav, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    val_grouped = build_stratified_samples(states["val"], queue_range, args.seed + 1)
    test_grouped = build_stratified_samples(states["test"], queue_range, args.seed + 2)
    model = (
        QueueConditionedAnchorValueNetwork()
        if args.model_version == "pairwise_value"
        else QueueAwareSequentialSetPolicy()
    )
    if args.init_checkpoint:
        initial_checkpoint = torch.load(args.init_checkpoint, map_location="cpu")
        model.load_state_dict(initial_checkpoint["model_state_dict"])
        print(f"[Setup] initialized from {args.init_checkpoint}")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    initial = evaluate(model, val_grouped)
    best_value = initial["combined"]["learned_value_anchor_mws_ratio"]
    best_state = copy.deepcopy(model.state_dict())
    best_epoch = -1
    logs = [{"epoch": -1, "validation": initial}]
    print(json.dumps({"initial_validation": initial["combined"]}, indent=2))
    for epoch in range(args.epochs):
        model.train()
        samples = resample_training_distribution(
            states["train"], queue_range, args.seed + 104729 * epoch,
            "mixed_hotspot",
        )
        order = list(range(len(samples)))
        random.shuffle(order)
        anchor_generator = torch.Generator().manual_seed(args.seed + 99991 * epoch)
        losses, target_means = [], []
        for index in order:
            state, queues = samples[index]
            loss, target_mean = self_generated_value_loss(
                model, state, queues, args.sampled_anchors, anchor_generator
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
            target_means.append(float(target_mean))
        validation = evaluate(model, val_grouped)
        value = validation["combined"]["learned_value_anchor_mws_ratio"]
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "sampled_target_mean": float(np.mean(target_means)),
            "validation": validation,
        })
        if value > best_value:
            best_value = value
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.5f} "
            f"val={value:.4f} "
            f"val_vs_greedy={validation['combined']['learned_to_greedy']:.4f}"
        )
    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped)
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"anchor_value_model_{args.model_version}_numUAV={args.num_uav}_train={args.train_size}_"
        f"ep={args.epochs}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": f"anchor_value_model_{args.model_version}_experimental",
        "model_state_dict": model.state_dict(), "best_epoch": best_epoch,
        "objective": "self_generated_final_utility_value_regression",
    }, checkpoint_path)
    os.makedirs("results/diagnostics", exist_ok=True)
    report_path = os.path.join(
        "results/diagnostics",
        f"anchor_value_model_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args), "checkpoint": checkpoint_path,
            "best_epoch": best_epoch, "initial_validation": initial,
            "test": test, "epochs": logs,
        }, file, indent=2)
    print(json.dumps({
        "checkpoint": checkpoint_path, "report": report_path,
        "best_epoch": best_epoch, "test": test,
    }, indent=2))


if __name__ == "__main__":
    main()
