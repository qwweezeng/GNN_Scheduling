#!/usr/bin/env python3
"""Test whether current conflict-graph physics is sufficient for join margins."""

import argparse
import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_localmax_reuse_headroom import (
    DENSITY_BOUNDS,
    build_static_samples,
    jsonify,
)
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from models.two_stage import QueueChannelLocalMaxScheduler
from utils.mws import centralized_mws_greedy, mws_objective
from utils.parallel_reuse import (
    conflict_graph_local_join_margins,
    exact_join_margins,
    local_margin_winners,
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--queue_seeds", default="44,45,46")
    return parser.parse_args()


def parse_seeds(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def empty_totals():
    return {
        "count": 0,
        "candidate_count": 0,
        "correct_sign": 0,
        "true_positive": 0,
        "predicted_positive": 0,
        "target_positive": 0,
        "localmax_utility": 0.0,
        "local_physical_utility": 0.0,
        "exact_utility": 0.0,
        "teacher_utility": 0.0,
        "harmful_count": 0,
    }


def summarize(totals):
    candidates = max(totals["candidate_count"], 1)
    count = max(totals["count"], 1)
    precision = totals["true_positive"] / max(totals["predicted_positive"], 1)
    recall = totals["true_positive"] / max(totals["target_positive"], 1)
    teacher = max(totals["teacher_utility"], 1e-12)
    exact_gain = totals["exact_utility"] - totals["localmax_utility"]
    local_gain = totals["local_physical_utility"] - totals["localmax_utility"]
    return {
        "num_samples": totals["count"],
        "num_candidates": totals["candidate_count"],
        "margin_sign_accuracy": totals["correct_sign"] / candidates,
        "positive_precision": precision,
        "positive_recall": recall,
        "positive_f1": 2 * precision * recall / max(precision + recall, 1e-12),
        "localmax_mws_ratio": totals["localmax_utility"] / teacher,
        "local_physical_reuse_mws_ratio": (
            totals["local_physical_utility"] / teacher
        ),
        "exact_parallel_mws_ratio": totals["exact_utility"] / teacher,
        "local_fraction_of_exact_gain": (
            local_gain / exact_gain if exact_gain > 1e-12 else None
        ),
        "harmful_local_join_rate": totals["harmful_count"] / count,
    }


def add_sample(totals, state, queues, localmax):
    base = localmax.schedule_with_state(state, queues).reshape(-1).cpu()
    exact_margins = exact_join_margins(state, queues, base)
    local_margins = conflict_graph_local_join_margins(state, queues, base)
    valid = torch.isfinite(exact_margins)
    exact_positive = exact_margins[valid] > 0
    local_positive = local_margins[valid] > 0
    totals["candidate_count"] += int(valid.sum())
    totals["correct_sign"] += int((exact_positive == local_positive).sum())
    totals["true_positive"] += int((exact_positive & local_positive).sum())
    totals["predicted_positive"] += int(local_positive.sum())
    totals["target_positive"] += int(exact_positive.sum())

    exact_joiners = local_margin_winners(exact_margins, state.edge_index)
    local_joiners = local_margin_winners(local_margins, state.edge_index)
    exact_action = torch.maximum(base, exact_joiners.float())
    local_action = torch.maximum(base, local_joiners.float())
    teacher = centralized_mws_greedy(state, queues).reshape(-1).cpu()
    base_utility = mws_objective(base, queues, state)
    local_utility = mws_objective(local_action, queues, state)
    totals["localmax_utility"] += base_utility
    totals["local_physical_utility"] += local_utility
    totals["exact_utility"] += mws_objective(exact_action, queues, state)
    totals["teacher_utility"] += mws_objective(teacher, queues, state)
    totals["harmful_count"] += int(local_utility + 1e-9 < base_utility)
    totals["count"] += 1


def main():
    args = parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "TEST_SIZE": args.test_size,
    })
    channel_model, channel_path = load_channel_model(
        cfg, 10, torch.device("cpu")
    )
    localmax = QueueChannelLocalMaxScheduler(channel_model)
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", (0, 20)
    )
    grouped = build_static_samples(
        states, (0, 20), parse_seeds(args.queue_seeds)
    )
    overall = empty_totals()
    by_density = {}
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            totals = empty_totals()
            for state, queues in grouped[group]:
                add_sample(totals, state, queues, localmax)
            by_density[group] = summarize(totals)
            for key, value in totals.items():
                overall[key] += value
    report = {
        "experiment": "conflict_graph_local_margin_sufficiency",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "physical_setting": {
            "num_uav": args.num_uav,
            "tx_power_dbm": 10.0,
            "csi_mode": "perfect",
            "channel_checkpoint": channel_path,
        },
        "definition": (
            "Local margins use exact directed gains only on existing conflict "
            "edges; omitted weak-interference pairs are treated as zero."
        ),
        "overall": summarize(overall),
        "by_density": by_density,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/local_margin_sufficiency_"
        f"numUAV={args.num_uav}_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({"report": path, "overall": report["overall"]}, indent=2))


if __name__ == "__main__":
    main()
