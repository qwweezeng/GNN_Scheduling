#!/usr/bin/env python3
"""Train the minimal ParallelReuse-v1 conditional margin predictor."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_localmax_reuse_headroom import (
    DENSITY_BOUNDS,
    ExactParallelReuseScheduler,
    build_static_samples,
    jsonify,
)
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from models.parallel_reuse import (
    ConditionalReuseMarginPredictor,
    LearnedParallelReuseScheduler,
)
from models.two_stage import QueueChannelLocalMaxScheduler
from utils.mws import centralized_mws_greedy, mws_objective
from utils.parallel_reuse import exact_join_margins


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def parse_int_list(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def candidate_target(state, queues, base):
    margins = exact_join_margins(state, queues, base)
    valid = torch.isfinite(margins)
    if not valid.any():
        return margins, valid, margins
    scale = margins[valid].abs().mean().clamp_min(1e-6)
    normalized = torch.zeros_like(margins)
    normalized[valid] = margins[valid] / scale
    return margins, valid, normalized


def training_samples(states, queue_range, seed):
    return build_static_samples(states, queue_range, [seed])


def flatten_grouped(grouped):
    return [item for group in DENSITY_BOUNDS for item in grouped[group]]


def empty_metrics():
    return {
        "count": 0,
        "candidate_count": 0,
        "correct_sign": 0,
        "true_positive": 0,
        "predicted_positive": 0,
        "target_positive": 0,
        "squared_error": 0.0,
        "local_utility": 0.0,
        "learned_utility": 0.0,
        "exact_utility": 0.0,
        "teacher_utility": 0.0,
        "harmful_count": 0,
        "local_active": 0.0,
        "learned_active": 0.0,
        "exact_active": 0.0,
    }


def summarize_metrics(totals):
    count = max(totals["count"], 1)
    candidates = max(totals["candidate_count"], 1)
    precision = totals["true_positive"] / max(totals["predicted_positive"], 1)
    recall = totals["true_positive"] / max(totals["target_positive"], 1)
    local_gain = totals["exact_utility"] - totals["local_utility"]
    learned_gain = totals["learned_utility"] - totals["local_utility"]
    teacher = max(totals["teacher_utility"], 1e-12)
    return {
        "num_samples": totals["count"],
        "num_candidates": totals["candidate_count"],
        "normalized_margin_rmse": (
            totals["squared_error"] / candidates
        ) ** 0.5,
        "sign_accuracy": totals["correct_sign"] / candidates,
        "positive_precision": precision,
        "positive_recall": recall,
        "positive_f1": 2 * precision * recall / max(precision + recall, 1e-12),
        "localmax_mws_ratio": totals["local_utility"] / teacher,
        "learned_reuse_mws_ratio": totals["learned_utility"] / teacher,
        "exact_parallel_mws_ratio": totals["exact_utility"] / teacher,
        "learned_fraction_of_exact_gain": (
            learned_gain / local_gain if local_gain > 1e-12 else None
        ),
        "harmful_learned_join_rate": totals["harmful_count"] / count,
        "average_active_links": {
            "localmax": totals["local_active"] / count,
            "learned_reuse": totals["learned_active"] / count,
            "exact_parallel": totals["exact_active"] / count,
        },
    }


def evaluate(predictor, grouped, localmax):
    predictor.eval()
    learned = LearnedParallelReuseScheduler(predictor, localmax)
    exact = ExactParallelReuseScheduler(localmax)
    overall = empty_metrics()
    by_density = {}
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            totals = empty_metrics()
            for state, queues in grouped[group]:
                base = localmax.schedule_with_state(state, queues).reshape(-1).cpu()
                exact_action = exact.schedule_with_state(
                    state, queues
                ).reshape(-1).cpu()
                learned_action = learned.schedule_with_state(
                    state, queues
                ).reshape(-1).cpu()
                teacher = centralized_mws_greedy(state, queues).reshape(-1).cpu()
                _, valid, target = candidate_target(state, queues, base)
                prediction = predictor(state, queues, base).detach().cpu()

                if valid.any():
                    predicted_positive = prediction[valid] > 0
                    target_positive = target[valid] > 0
                    totals["candidate_count"] += int(valid.sum())
                    totals["correct_sign"] += int(
                        (predicted_positive == target_positive).sum()
                    )
                    totals["true_positive"] += int(
                        (predicted_positive & target_positive).sum()
                    )
                    totals["predicted_positive"] += int(predicted_positive.sum())
                    totals["target_positive"] += int(target_positive.sum())
                    totals["squared_error"] += float(F.mse_loss(
                        prediction[valid], target[valid], reduction="sum"
                    ))

                base_utility = mws_objective(base, queues, state)
                learned_utility = mws_objective(learned_action, queues, state)
                exact_utility = mws_objective(exact_action, queues, state)
                teacher_utility = mws_objective(teacher, queues, state)
                totals["local_utility"] += base_utility
                totals["learned_utility"] += learned_utility
                totals["exact_utility"] += exact_utility
                totals["teacher_utility"] += teacher_utility
                totals["harmful_count"] += int(
                    learned_utility + 1e-9 < base_utility
                )
                totals["local_active"] += float(base.sum())
                totals["learned_active"] += float(learned_action.sum())
                totals["exact_active"] += float(exact_action.sum())
                totals["count"] += 1

            by_density[group] = summarize_metrics(totals)
            for key, value in totals.items():
                overall[key] += value
    return {"overall": summarize_metrics(overall), "by_density": by_density}


def train_epoch(predictor, localmax, samples, optimizer):
    predictor.train()
    random.shuffle(samples)
    total_loss = 0.0
    candidate_count = 0
    update_count = 0
    for state, queues in samples:
        base = localmax.schedule_with_state(state, queues).reshape(-1).cpu()
        _, valid, target = candidate_target(state, queues, base)
        if not valid.any():
            continue
        prediction = predictor(state, queues, base)
        valid_device = valid.to(prediction.device)
        target_device = target.to(prediction.device)
        loss = F.mse_loss(prediction[valid_device], target_device[valid_device])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        num_candidates = int(valid.sum())
        total_loss += float(loss.detach()) * num_candidates
        candidate_count += num_candidates
        update_count += 1
    return {
        "normalized_margin_mse": total_loss / max(candidate_count, 1),
        "num_candidates": candidate_count,
        "optimizer_updates": update_count,
    }


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--channel_model_num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=80)
    parser.add_argument("--val_size", type=int, default=20)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--hidden_dim", type=int, default=48)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--model_version", choices=("v1", "v2"), default="v2",
        help="v2 adds only the scale-invariant pairwise queue edge feature.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    queue_range_values = parse_int_list(args.queue_range)
    if len(queue_range_values) != 2:
        raise ValueError("--queue_range must contain exactly two integers")
    queue_range = tuple(queue_range_values)

    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
    })
    device = torch.device("cpu")
    channel_model, channel_checkpoint = load_channel_model(
        cfg, args.channel_model_num_uav, device
    )
    predictor = ConditionalReuseMarginPredictor(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        hidden_dim=args.hidden_dim,
        edge_dim=cfg.get("EDGE_DIM", 1),
        use_pairwise_queue_edge=(args.model_version == "v2"),
    ).to(device)
    localmax = QueueChannelLocalMaxScheduler(channel_model)

    generator = build_generator(cfg)
    train_states = _load_or_generate_dataset(
        generator, cfg, args.num_uav, False, "train", queue_range
    )
    val_states = _load_or_generate_dataset(
        generator, cfg, args.num_uav, False, "val", queue_range
    )
    test_states = _load_or_generate_dataset(
        generator, cfg, args.num_uav, False, "test", queue_range
    )
    val_grouped = training_samples(val_states, queue_range, args.seed + 10000)
    test_grouped = training_samples(test_states, queue_range, args.seed + 20000)

    optimizer = torch.optim.Adam(
        [parameter for parameter in predictor.parameters() if parameter.requires_grad],
        lr=args.lr,
    )
    best_state = None
    best_gain = -float("inf")
    epoch_logs = []
    for epoch in range(args.epochs):
        train_grouped = training_samples(
            train_states, queue_range, args.seed + 7919 * epoch
        )
        train_metrics = train_epoch(
            predictor, localmax, flatten_grouped(train_grouped), optimizer
        )
        val_metrics = evaluate(predictor, val_grouped, localmax)
        gain = val_metrics["overall"]["learned_fraction_of_exact_gain"]
        gain = float(gain) if gain is not None else -float("inf")
        if gain > best_gain:
            best_gain = gain
            best_state = copy.deepcopy(predictor.state_dict())
        log = {
            "epoch": epoch + 1,
            "train": train_metrics,
            "validation": val_metrics["overall"],
        }
        epoch_logs.append(log)
        print(
            f"Epoch {epoch + 1:02d}/{args.epochs} "
            f"MSE={train_metrics['normalized_margin_mse']:.4f} "
            f"ValLearned/MWS={val_metrics['overall']['learned_reuse_mws_ratio']:.3f} "
            f"ValExact/MWS={val_metrics['overall']['exact_parallel_mws_ratio']:.3f} "
            f"GainCapture={gain:.3f} "
            f"Harm={val_metrics['overall']['harmful_learned_join_rate']:.3f}"
        )

    if best_state is None:
        raise RuntimeError("Training produced no valid checkpoint")
    predictor.load_state_dict(best_state)
    test_metrics = evaluate(predictor, test_grouped, localmax)

    os.makedirs("results/models/experimental", exist_ok=True)
    model_path = (
        f"results/models/experimental/parallel_reuse_{args.model_version}_"
        f"numUAV={args.num_uav}_tx=10dBm_s{args.seed}.pth"
    )
    torch.save({
        "model_version": f"parallel_reuse_{args.model_version}",
        "model_state_dict": predictor.state_dict(),
        "num_uav": args.num_uav,
        "channel_model_num_uav": args.channel_model_num_uav,
        "channel_checkpoint": channel_checkpoint,
        "tx_power_dbm": 10.0,
        "csi_mode": "perfect",
        "hidden_dim": args.hidden_dim,
        "use_pairwise_queue_edge": args.model_version == "v2",
        "queue_feature": "one_hop_relative_queue",
        "target": "mean_abs_normalized_exact_join_margin",
        "seed": args.seed,
    }, model_path)

    report = {
        "experiment": f"parallel_reuse_{args.model_version}_training",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "scope": (
            "Learned local conditional margin prediction. MWS-Greedy is used "
            "only for evaluation; training labels are exact physical join margins."
        ),
        "settings": vars(args),
        "channel_checkpoint": channel_checkpoint,
        "model_checkpoint": model_path,
        "best_validation_gain_capture": best_gain,
        "epochs": epoch_logs,
        "test": test_metrics,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    report_path = (
        f"results/diagnostics/parallel_reuse_{args.model_version}_train_"
        f"numUAV={args.num_uav}_tx10_s{args.seed}_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({
        "model": model_path,
        "report": report_path,
        "test_overall": test_metrics["overall"],
    }, indent=2))


if __name__ == "__main__":
    main()
