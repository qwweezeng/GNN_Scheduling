#!/usr/bin/env python3
"""Measure how well unstructured full-set sampling covers useful schedules."""

import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS, build_stratified_samples,
)
from utils.mws import mws_objective


def sample_action(queues, method):
    if method == "half":
        density = torch.tensor(0.5)
    elif method == "uniform_cardinality":
        density = torch.rand(())
    else:
        raise ValueError(method)
    return ((torch.rand(queues.numel()) < density) & (queues > 0)).float()


def main():
    torch.manual_seed(20260713)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TEST_SIZE": 20,
    })
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    grouped = build_stratified_samples(states, (0, 20), 44)
    samples = [
        sample for group in DENSITY_BOUNDS for sample in grouped[group]
    ]
    budgets = (8, 32, 128, 512)
    report = {}
    for method in ("half", "uniform_cardinality"):
        totals = {
            budget: {"best": 0.0, "mean": 0.0, "teacher": 0.0}
            for budget in budgets
        }
        for state, queues, teacher in samples:
            teacher_utility = mws_objective(
                teacher.reshape(-1), queues, state
            )
            utilities = []
            for _ in range(max(budgets)):
                utilities.append(mws_objective(
                    sample_action(queues, method), queues, state
                ))
            utility = torch.tensor(utilities)
            for budget in budgets:
                totals[budget]["best"] += float(utility[:budget].max())
                totals[budget]["mean"] += float(utility[:budget].mean())
                totals[budget]["teacher"] += teacher_utility
        report[method] = {
            str(budget): {
                "best_of_k_mws_ratio": (
                    totals[budget]["best"] / totals[budget]["teacher"]
                ),
                "mean_sample_mws_ratio": (
                    totals[budget]["mean"] / totals[budget]["teacher"]
                ),
            } for budget in budgets
        }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/set_exploration_coverage_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": path, "results": report}, indent=2))


if __name__ == "__main__":
    main()
