#!/usr/bin/env python3
"""Test whether edge-local signal/interference measurements determine oracle rho.

This is a diagnostic, not a deployable estimator.  It reads the simulator's
power matrix only to reconstruct the two receiver-local quantities S/N and
I/N, then checks them against the independently computed pair-rate target.
"""

import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import precompute


def physical_edge_rho(state):
    source, target = state.edge_index
    links = state.links
    interfering_tx = links[source, 0]
    victim_tx = links[target, 0]
    victim_rx = links[target, 1]
    signal = state.signal_power[victim_tx, victim_rx]
    interference = state.signal_power[interfering_tx, victim_rx]
    noise = torch.as_tensor(state.noise_power, dtype=signal.dtype)
    gap = float(getattr(state, "snr_gap", 1.0))
    solo = torch.log2(1.0 + signal / (noise * gap))
    pair = torch.log2(1.0 + signal / ((noise + interference) * gap))
    rho = ((solo - pair) / solo.clamp_min(1e-8)).clamp(0.0, 1.0)
    shared = (
        (links[source, 0] == links[target, 0])
        | (links[source, 0] == links[target, 1])
        | (links[source, 1] == links[target, 0])
        | (links[source, 1] == links[target, 1])
    )
    return rho, signal / noise, interference / noise, shared


def metrics(prediction, target):
    error = prediction - target
    return {
        "count": int(target.numel()),
        "mae": float(error.abs().mean()),
        "rmse": float(torch.sqrt(error.square().mean())),
        "correlation": float(np.corrcoef(prediction.numpy(), target.numpy())[0, 1])
        if target.numel() > 1 else None,
        "prediction_mean": float(prediction.mean()),
        "target_mean": float(target.mean()),
    }


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    oracle = precompute(
        states, "results/cache/oracle_marginals/numUAV=10_test_n=32.pth"
    )
    predictions, targets, shared_masks, snr_values, inr_values = [], [], [], [], []
    for state, (_, target) in zip(states, oracle):
        prediction, snr, inr, shared = physical_edge_rho(state)
        predictions.append(prediction)
        targets.append(target)
        shared_masks.append(shared)
        snr_values.append(snr)
        inr_values.append(inr)
    prediction = torch.cat(predictions)
    target = torch.cat(targets)
    shared = torch.cat(shared_masks)
    snr = torch.cat(snr_values)
    inr = torch.cat(inr_values)
    report = {
        "interpretation": "SNR and INR are receiver-local physical measurements",
        "all_edges": metrics(prediction, target),
        "regular_edges": metrics(prediction[~shared], target[~shared]),
        "shared_endpoint_edges": metrics(prediction[shared], target[shared]),
        "snr_linear_range": [float(snr.min()), float(snr.max())],
        "inr_linear_range": [float(inr.min()), float(inr.max())],
        "shared_endpoint_fraction": float(shared.float().mean()),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
