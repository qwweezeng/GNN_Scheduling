#!/usr/bin/env python3
"""Isolate greedy set construction using exact full-interference utility."""

import argparse
import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import precompute
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.anchor_one_join import AnchorExactOneJoinDecoder
from utils.mws import mws_objective


DEFAULT_CHECKPOINT = (
    "results/models/experimental/anchor_join_oracle_numUAV=10_rounds=3_"
    "objective=teacher_calibration_init=0_sampling=mixed_hotspot_ep=15_s42.pth"
)


def exact_greedy_action(model, state, queues, solo, harm):
    logits, _, _, nonempty = model.anchor_context(
        solo, harm, queues, state.edge_index
    )
    action = torch.zeros(state.num_vertices)
    if not (nonempty > 0).any():
        return action
    action[torch.argmax(logits)] = 1.0
    current = mws_objective(action, queues, state)
    while True:
        candidates = ((queues > 0) & (action <= 0)).nonzero(as_tuple=True)[0]
        if candidates.numel() == 0:
            break
        candidate_utilities = []
        for candidate in candidates:
            proposed = action.clone()
            proposed[candidate] = 1.0
            candidate_utilities.append(mws_objective(proposed, queues, state))
        candidate_utilities = torch.as_tensor(candidate_utilities)
        best = torch.argmax(candidate_utilities)
        if candidate_utilities[best] <= current + 1e-9:
            break
        action[candidates[best]] = 1.0
        current = float(candidate_utilities[best])
    return action


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", default=DEFAULT_CHECKPOINT)
    parser.add_argument("--tx_power", type=float, default=10.0)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": args.tx_power,
        "TEST_SIZE": args.test_size,
    })
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    physical = precompute(
        states,
        f"results/cache/oracle_marginals/numUAV=10_"
        f"tx={args.tx_power:g}dBm_csi={cfg.get('CSI_MODE', 'perfect')}_"
        f"test_n={args.test_size}.pth",
    )
    grouped = build_stratified_samples(states, (0, 20), args.seed + 2)
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model = AnchorExactOneJoinDecoder(
        checkpoint["hidden_dim"], checkpoint["num_rounds"]
    )
    model.load_anchor_from_anchor_join(checkpoint["model_state_dict"])
    model.eval()
    report = {}
    totals = {"utility": 0.0, "teacher": 0.0, "active": 0.0, "samples": 0}
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            local = {"utility": 0.0, "teacher": 0.0, "active": 0.0, "samples": 0}
            for index, (state, queues, teacher) in enumerate(grouped[group]):
                solo, harm = physical[index]
                action = exact_greedy_action(model, state, queues, solo, harm)
                local["utility"] += mws_objective(action, queues, state)
                local["teacher"] += mws_objective(
                    teacher.squeeze(1), queues, state
                )
                local["active"] += float(action.sum())
                local["samples"] += 1
            report[group] = {
                "mws_ratio": local["utility"] / local["teacher"],
                "average_active_links": local["active"] / local["samples"],
            }
            for key in totals:
                totals[key] += local[key]
    report["combined"] = {
        "mws_ratio": totals["utility"] / totals["teacher"],
        "average_active_links": totals["active"] / totals["samples"],
    }
    report["scope"] = (
        "Diagnostic only: learned anchor plus centralized exact-utility greedy joins"
    )
    report["anchor_checkpoint"] = args.checkpoint
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"exact_set_greedy_tx{args.tx_power:g}_s{args.seed}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": report, "path": path}, indent=2))


if __name__ == "__main__":
    main()
