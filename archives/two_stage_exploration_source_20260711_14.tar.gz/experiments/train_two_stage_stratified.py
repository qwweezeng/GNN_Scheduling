#!/usr/bin/env python3
"""Train a preserved TwoStage-v1 control with balanced queue densities.

Only the queue-snapshot sampling distribution differs from TwoStage-v1.  The
architecture, MWS-Greedy teacher, weighted BCE, optimizer and fixed threshold
remain unchanged so that this experiment isolates distribution mismatch.
"""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import (
    evaluate_two_stage,
    load_channel_model,
    set_seed,
)
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS,
    build_stratified_samples,
    sample_queues_for_density,
)
from models.two_stage import TwoStageGATScheduler
from utils.mws import centralized_mws_greedy
from utils.queue_features import relative_queue_feature


def build_balanced_train_samples(states, queue_range, seed):
    """Use one queue sample per graph with approximately equal density counts."""
    groups = list(DENSITY_BOUNDS)
    assignments = [groups[index % len(groups)] for index in range(len(states))]
    random.Random(seed).shuffle(assignments)
    generators = {
        group: torch.Generator().manual_seed(seed + 1009 * index)
        for index, group in enumerate(groups)
    }
    samples = []
    counts = {group: 0 for group in groups}
    for state, group in zip(states, assignments):
        queues = sample_queues_for_density(
            state.num_vertices, group, queue_range, generators[group]
        )
        samples.append((state, queues, centralized_mws_greedy(state, queues)))
        counts[group] += 1
    return samples, counts


def flatten_group_samples(grouped_samples):
    return [sample for group in DENSITY_BOUNDS for sample in grouped_samples[group]]


def per_density_metrics(model, grouped_samples):
    return {
        group: evaluate_two_stage(model, samples)
        for group, samples in grouped_samples.items()
    }


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=500)
    parser.add_argument("--val_size", type=int, default=64)
    parser.add_argument("--test_size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
        "EPOCHS": args.epochs,
    })
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    network_generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            network_generator, cfg, args.num_uav, False, split, queue_range
        )
        for split in ("train", "val", "test")
    }
    train_samples, train_density_counts = build_balanced_train_samples(
        states["train"], queue_range, args.seed
    )
    val_grouped = build_stratified_samples(
        states["val"], queue_range, args.seed + 1
    )
    test_grouped = build_stratified_samples(
        states["test"], queue_range, args.seed + 2
    )
    val_samples = flatten_group_samples(val_grouped)

    channel_model, channel_path = load_channel_model(cfg, args.num_uav, device)
    model = TwoStageGATScheduler(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        edge_dim=cfg.get("EDGE_DIM", 1),
        hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
        gat_dim=32,
    ).to(device)

    positives = sum(target.sum().item() for _, _, target in train_samples)
    total = sum(target.numel() for _, _, target in train_samples)
    pos_weight = torch.tensor(
        [(total - positives) / max(positives, 1.0)], device=device
    )
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.Adam(trainable, lr=1e-4)
    best_state = None
    best_ratio = -float("inf")
    best_epoch = None
    logs = []

    print(f"[Setup] device={device} train_density_counts={train_density_counts}")
    print(f"[Setup] pos_weight={pos_weight.item():.3f}")
    for epoch in range(args.epochs):
        model.train()
        order = list(range(len(train_samples)))
        random.shuffle(order)
        losses = []
        for sample_index in order:
            state, queues, target = train_samples[sample_index]
            model_input = torch.cat([
                state.vertex_features[:, :1],
                relative_queue_feature(queues).unsqueeze(1),
            ], dim=1).to(device)
            probabilities, _ = model(
                model_input,
                state.edge_index.to(device),
                state.edge_weights.to(device),
                queues=queues.to(device),
            )
            probabilities = probabilities.clamp(1e-6, 1 - 1e-6)
            target_device = target.to(device)
            loss = F.binary_cross_entropy(
                probabilities,
                target_device,
                weight=torch.where(
                    target_device > 0, pos_weight, torch.ones_like(target_device)
                ),
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 5.0)
            optimizer.step()
            losses.append(loss.item())

        validation = evaluate_two_stage(model, val_samples)
        density_validation = per_density_metrics(model, val_grouped)
        log = {
            "epoch": epoch,
            "loss": float(np.mean(losses)),
            "validation": validation,
            "validation_by_density": density_validation,
        }
        logs.append(log)
        if validation["mws_ratio"] > best_ratio:
            best_ratio = validation["mws_ratio"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={log['loss']:.4f} "
            f"MWS={validation['mws_ratio']:.3f} "
            f"active={validation['average_active_links']:.2f} "
            f"s/m/d={density_validation['sparse']['mws_ratio']:.3f}/"
            f"{density_validation['medium']['mws_ratio']:.3f}/"
            f"{density_validation['dense']['mws_ratio']:.3f}"
        )

    model.load_state_dict(best_state)
    test_by_density = per_density_metrics(model, test_grouped)
    test_combined = evaluate_two_stage(model, flatten_group_samples(test_grouped))

    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"gat_queue_two_stage_v1_stratified_numUAV={args.num_uav}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": "two_stage_v1_stratified_control",
        "model_state_dict": model.state_dict(),
        "channel_model_path": channel_path,
        "decision_threshold": 0.5,
        "queue_feature": "one_hop_relative",
        "teacher": "centralized_mws_greedy",
        "loss": "weighted_bce",
        "sampling": "balanced_sparse_medium_dense",
        "density_bounds": DENSITY_BOUNDS,
        "queue_range": list(queue_range),
        "seed": args.seed,
        "pos_weight": pos_weight.item(),
        "best_epoch": best_epoch,
    }, checkpoint_path)

    report_path = os.path.join(
        "results", "diagnostics",
        f"two_stage_v1_stratified_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args),
            "checkpoint": checkpoint_path,
            "train_density_counts": train_density_counts,
            "best_epoch": best_epoch,
            "best_validation_mws_ratio": best_ratio,
            "test_combined": test_combined,
            "test_by_density": test_by_density,
            "epochs": logs,
        }, file, indent=2, ensure_ascii=False)
    print(f"[Done] checkpoint={checkpoint_path}")
    print(f"[Done] report={report_path}")
    print(json.dumps(test_by_density, indent=2))


if __name__ == "__main__":
    main()
