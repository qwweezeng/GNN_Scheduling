#!/usr/bin/env python3
"""Measure true one-link join opportunities around a learned anchor."""

import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import precompute
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS, build_stratified_samples,
)
from models.anchor_join import AnchorJoinDecoder
from utils.mws import mws_objective


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    physical = precompute(
        states, "results/cache/oracle_marginals/numUAV=10_test_n=32.pth"
    )
    grouped = build_stratified_samples(states, (0, 20), 44)
    path = (
        "results/models/experimental/anchor_join_oracle_numUAV=10_rounds=3_"
        "objective=hard_utility_init=1_sampling=mixed_hotspot_ep=10_s42.pth"
    )
    checkpoint = torch.load(path, map_location="cpu")
    model = AnchorJoinDecoder(
        checkpoint["hidden_dim"], checkpoint["num_rounds"]
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    report = {}
    for group in DENSITY_BOUNDS:
        anchor_utility = best_join_utility = teacher_utility = 0.0
        positive_counts, relative_gains = [], []
        predicted_probabilities, true_deltas = [], []
        with torch.no_grad():
            for index, (state, queues, teacher) in enumerate(grouped[group]):
                solo, harm = physical[index]
                probability, diagnostics = model(
                    solo, harm, queues, state.edge_index
                )
                anchor = diagnostics["anchor_index"]
                anchor_action = torch.zeros(state.num_vertices)
                anchor_action[anchor] = 1.0
                base = mws_objective(anchor_action, queues, state)
                anchor_utility += base
                teacher_utility += mws_objective(
                    teacher.squeeze(1), queues, state
                )
                best = base
                positives = 0
                candidates = (queues > 0).nonzero(as_tuple=True)[0]
                for candidate in candidates.tolist():
                    if candidate == int(anchor):
                        continue
                    joined = anchor_action.clone()
                    joined[candidate] = 1.0
                    utility = mws_objective(joined, queues, state)
                    delta = utility - base
                    true_deltas.append(delta)
                    predicted_probabilities.append(float(probability[candidate]))
                    if delta > 1e-9:
                        positives += 1
                    best = max(best, utility)
                positive_counts.append(positives)
                relative_gains.append((best - base) / max(base, 1e-12))
                best_join_utility += best
        correlation = (
            float(np.corrcoef(predicted_probabilities, true_deltas)[0, 1])
            if np.std(predicted_probabilities) > 1e-12
            and np.std(true_deltas) > 1e-12 else 0.0
        )
        report[group] = {
            "anchor_mws_ratio": anchor_utility / teacher_utility,
            "best_one_join_mws_ratio": best_join_utility / teacher_utility,
            "states_with_positive_join_fraction": float(np.mean(
                np.asarray(positive_counts) > 0
            )),
            "positive_join_candidates_mean": float(np.mean(positive_counts)),
            "best_join_relative_gain_mean": float(np.mean(relative_gains)),
            "predicted_join_probability_true_delta_correlation": correlation,
        }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
