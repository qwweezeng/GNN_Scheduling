#!/usr/bin/env python3
"""Fair stratified evaluation of an experimental TwoStage-GAT-v2 checkpoint."""

import argparse
import json
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import evaluate_two_stage, load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.two_stage_v1_diagnostics import build_stratified_samples
from models.two_stage_v2 import TwoStageGATv2Scheduler


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=64)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=20260711)
    parser.add_argument("--thresholds", default="0.3,0.5,0.7")
    parser.add_argument(
        "--checkpoint",
        default="results/models/experimental/"
        "gat_queue_two_stage_v2_structured_numUAV=10_s42.pth",
    )
    parser.add_argument(
        "--output",
        default="results/diagnostics/two_stage_v2_fair_eval_20260711.json",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)
    cfg.update({"NUM_UAV": args.num_uav, "TEST_SIZE": args.test_size})
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    thresholds = [float(value.strip()) for value in args.thresholds.split(",")]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    generator = build_generator(cfg)
    states = _load_or_generate_dataset(
        generator, cfg, args.num_uav, False, "test", queue_range
    )[:args.test_size]
    samples = build_stratified_samples(states, queue_range, args.seed)

    checkpoint = torch.load(args.checkpoint, map_location=device)
    compatible_versions = {
        "two_stage_v2_structured_experimental",
        "two_stage_v2_channel_skip_experimental",
        "two_stage_v2_experimental",
    }
    if checkpoint.get("model_version") not in compatible_versions:
        raise ValueError(f"Incompatible v2 checkpoint: {args.checkpoint}")
    channel_model, _ = load_channel_model(cfg, args.num_uav, device)
    model = TwoStageGATv2Scheduler(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
        queue_scale=max(queue_range[1], 1),
        use_channel_skip=checkpoint.get("use_channel_skip", False),
    ).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    results = {
        f"threshold_{threshold:.2f}": {
            group: evaluate_two_stage(model, group_samples, threshold=threshold)
            for group, group_samples in samples.items()
        }
        for threshold in thresholds
    }
    report = {
        "config": vars(args),
        "checkpoint_metadata": {
            key: value for key, value in checkpoint.items()
            if key != "model_state_dict"
        },
        "results": results,
    }
    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps(results, indent=2))
    print(f"[Done] report={args.output}")


if __name__ == "__main__":
    main()
