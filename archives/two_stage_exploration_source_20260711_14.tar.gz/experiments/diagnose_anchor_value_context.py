#!/usr/bin/env python3
"""Ablate propagated context in the self-generated anchor value model."""

import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.sequential_set_policy import (
    QueueAwareSequentialSetPolicy, complete_physical_graph,
    exact_addition_deltas,
)
from models.two_stage_physical import exact_state_greedy_from_anchor
from utils.mws import mws_objective


CHECKPOINT = "results/models/experimental/anchor_value_model_numUAV=10_train=200_ep=10_s43.pth"


def scores_with_ablation(model, state, queues, mode):
    edge_index, snr, inr, edge_attr = complete_physical_graph(state)
    channel = model.channel_encoder(snr, edge_index, edge_attr)
    if mode == "zero_channel":
        channel = torch.zeros_like(channel)
    value = queues * torch.log2(1.0 + snr)
    relative = value / value.max().clamp_min(1e-8)
    if mode == "zero_propagated_queue":
        relative = torch.zeros_like(relative)
    elif mode == "shuffle_propagated_queue":
        relative = relative[torch.randperm(relative.numel())]
    selected = torch.zeros_like(snr)
    hidden = model.queue_node_encoder(torch.cat([
        channel, relative.unsqueeze(1), selected.unsqueeze(1)
    ], dim=1))
    incoming = model.queue_incoming_gat(hidden, edge_index, edge_attr)
    outgoing = model.queue_outgoing_gat(hidden, edge_index.flip(0), edge_attr)
    context = torch.cat([incoming, outgoing], dim=1)
    delta = exact_addition_deltas(selected, queues, snr, inr)
    scale = value.max().clamp_min(1e-8)
    scores = model.choice_mlp(torch.cat([
        context, (delta / scale).unsqueeze(1)
    ], dim=1)).reshape(-1)
    return scores, delta


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    grouped = build_stratified_samples(states, (0, 20), 45)
    checkpoint = torch.load(CHECKPOINT, map_location="cpu")
    model = QueueAwareSequentialSetPolicy()
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    torch.manual_seed(20260712)
    report = {}
    with torch.no_grad():
        for mode in (
            "normal", "zero_channel", "zero_propagated_queue",
            "shuffle_propagated_queue",
        ):
            utility = greedy = teacher = agreements = samples = 0.0
            for group in DENSITY_BOUNDS:
                for state, queues, target in grouped[group]:
                    scores, delta = scores_with_ablation(
                        model, state, queues, mode
                    )
                    active = (queues > 0).nonzero(as_tuple=True)[0]
                    anchor = active[torch.argmax(scores[active])]
                    greedy_anchor = active[torch.argmax(delta[active])]
                    _, value = exact_state_greedy_from_anchor(anchor, state, queues)
                    _, greedy_value = exact_state_greedy_from_anchor(
                        greedy_anchor, state, queues
                    )
                    utility += float(value)
                    greedy += float(greedy_value)
                    teacher += mws_objective(target.squeeze(1), queues, state)
                    agreements += int(anchor == greedy_anchor)
                    samples += 1
            report[mode] = {
                "mws_ratio": utility / teacher,
                "to_immediate_greedy": utility / greedy,
                "anchor_agreement_with_immediate_greedy": agreements / samples,
            }
    report["control"] = (
        "Local exact Qb delta remains available in every ablation."
    )
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"anchor_value_context_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": report, "path": path}, indent=2))


if __name__ == "__main__":
    main()
