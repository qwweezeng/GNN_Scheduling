#!/usr/bin/env python3
"""Ablate channel and propagated queue context in the queue-GAT policy."""

import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.sequential_set_policy import (
    QueueAwareSequentialSetPolicy, complete_physical_graph,
    exact_addition_deltas, physical_set_utility,
)
from utils.mws import mws_objective


CHECKPOINT = "results/models/experimental/sequential_set_policy_queue_gat_numUAV=10_train=100_ep=10_s42.pth"


def dynamic_context(model, channel, queues, selected, snr, edge_index,
                    edge_attr, mode):
    relative = queues * torch.log2(1.0 + snr)
    relative = relative / relative.max().clamp_min(1e-8)
    if mode == "zero_propagated_queue":
        relative = torch.zeros_like(relative)
    elif mode == "shuffle_propagated_queue":
        relative = relative[torch.randperm(relative.numel())]
    hidden = model.queue_node_encoder(torch.cat([
        channel, relative.unsqueeze(1), selected.unsqueeze(1)
    ], dim=1))
    incoming = model.queue_incoming_gat(hidden, edge_index, edge_attr)
    outgoing = model.queue_outgoing_gat(hidden, edge_index.flip(0), edge_attr)
    return torch.cat([incoming, outgoing], dim=1)


def rollout(model, state, queues, mode):
    edge_index, snr, inr, edge_attr = complete_physical_graph(state)
    channel = model.channel_encoder(snr, edge_index, edge_attr)
    if mode == "zero_channel":
        channel = torch.zeros_like(channel)
    selected = torch.zeros_like(snr)
    scale = (queues * torch.log2(1.0 + snr)).max().clamp_min(1e-8)
    first_agreement = 0
    first = True
    while True:
        delta = exact_addition_deltas(selected, queues, snr, inr)
        eligible = (queues > 0) & (selected <= 0) & (delta > 1e-9)
        candidates = eligible.nonzero(as_tuple=True)[0]
        if candidates.numel() == 0:
            break
        context = dynamic_context(
            model, channel, queues, selected, snr, edge_index, edge_attr, mode
        )
        logits = model.choice_mlp(torch.cat([
            context[candidates], (delta[candidates] / scale).unsqueeze(1)
        ], dim=1)).reshape(-1)
        local = torch.argmax(logits)
        if first:
            first_agreement = int(local == torch.argmax(delta[candidates]))
            first = False
        selected[candidates[local]] = 1.0
    return selected, physical_set_utility(selected, queues, snr, inr), first_agreement


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    grouped = build_stratified_samples(states, (0, 20), 44)
    checkpoint = torch.load(CHECKPOINT, map_location="cpu")
    model = QueueAwareSequentialSetPolicy()
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    torch.manual_seed(20260712)
    report = {}
    with torch.no_grad():
        for mode in (
            "normal", "zero_channel", "zero_propagated_queue",
            "shuffle_propagated_queue",
        ):
            utility = teacher = active = agreements = samples = 0.0
            for group in DENSITY_BOUNDS:
                for state, queues, target in grouped[group]:
                    action, value, agreement = rollout(model, state, queues, mode)
                    utility += float(value)
                    teacher += mws_objective(target.squeeze(1), queues, state)
                    active += float(action.sum())
                    agreements += agreement
                    samples += 1
            report[mode] = {
                "mws_ratio": utility / teacher,
                "average_active_links": active / samples,
                "first_choice_agreement_with_max_delta": agreements / samples,
            }
    report["control"] = (
        "Exact candidate delta is preserved in every mode; only propagated context changes."
    )
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"queue_gat_policy_ablation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": report, "path": path}, indent=2))


if __name__ == "__main__":
    main()
