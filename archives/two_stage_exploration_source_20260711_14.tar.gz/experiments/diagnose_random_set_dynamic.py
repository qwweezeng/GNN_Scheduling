#!/usr/bin/env python3
"""Dynamic upper bound from selecting the best of random complete sets."""

import json
import os
import sys
from datetime import datetime
from types import SimpleNamespace

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_parallel_mpnn_queue_experiment import (
    QueueAwareRandomScheduler, jsonify,
)
from experiments.run_queue_experiment import (
    CentralizedMWSGreedyScheduler, build_generator, load_config,
    simulation_phase,
)
from utils.mws import mws_objective


class RandomSetBestOfK:
    """Diagnostic only: globally evaluate K random complete schedules."""

    def __init__(self, budget, seed):
        self.budget = int(budget)
        self.generator = torch.Generator().manual_seed(seed)

    def eval(self):
        return self

    def schedule_with_state(self, state, queues):
        queues = queues.cpu()
        best_action = torch.zeros(queues.numel())
        best_utility = 0.0
        for _ in range(self.budget):
            density = torch.rand((), generator=self.generator)
            action = (
                (torch.rand(queues.numel(), generator=self.generator) < density)
                & (queues > 0)
            ).float()
            utility = mws_objective(action, queues, state)
            if utility > best_utility:
                best_utility = utility
                best_action = action
        return best_action.unsqueeze(1)


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
    })
    models = {
        "Random-Q": (QueueAwareRandomScheduler(), "Queue-aware Random p=0.3"),
        "BestOf8": (RandomSetBestOfK(8, 8008), "Best of 8 random sets"),
        "BestOf32": (RandomSetBestOfK(32, 8032), "Best of 32 random sets"),
        "BestOf128": (RandomSetBestOfK(128, 8128), "Best of 128 random sets"),
        "MWS-Greedy": (CentralizedMWSGreedyScheduler(), "MWS-Greedy"),
    }
    results, details = simulation_phase(
        build_generator(cfg), models, cfg,
        SimpleNamespace(
            num_slots=500, arrival_rates=[1.0, 2.0], mc_seeds=[42],
            slots_per_block=None,
        ),
    )
    output_dir = os.path.join(
        "results",
        "random_set_dynamic_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S"),
    )
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, "simulation_results.json"), "w") as file:
        json.dump(jsonify({
            "scope": (
                "Diagnostic upper bound only: each slot globally evaluates "
                "complete random schedules with exact physical utility."
            ),
            "results": results,
        }), file, indent=2)
    with open(os.path.join(output_dir, "simulation_runs.json"), "w") as file:
        json.dump(jsonify(details), file, indent=2)
    print(json.dumps({"output_dir": output_dir}, indent=2))


if __name__ == "__main__":
    main()
