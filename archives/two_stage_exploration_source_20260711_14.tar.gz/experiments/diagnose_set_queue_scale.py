#!/usr/bin/env python3
"""Test whether learned set policies respect common queue-scale invariance."""

import json
import os
import sys
from datetime import datetime

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_parallel_mpnn import full_oracle_quantities
from experiments.train_set_negotiation import random_initial_action
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS, build_stratified_samples,
)
from models.set_negotiation import SetNegotiation, SetNegotiationV2
from utils.mws import mws_objective


CHECKPOINTS = {
    "v1": (
        "results/models/experimental/set_negotiation_v1_tx=10dBm_"
        "numUAV=10_revisions=2_objective=elite_set_"
        "init=uniform_cardinality_s42.pth"
    ),
    "v2": (
        "results/models/experimental/set_negotiation_v2_tx=10dBm_"
        "numUAV=10_revisions=2_objective=elite_set_"
        "init=uniform_cardinality_s42.pth"
    ),
}


def load_model(path):
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    model_class = (
        SetNegotiationV2
        if checkpoint["model_version"] == "set_negotiation_v2"
        else SetNegotiation
    )
    model = model_class(
        checkpoint["hidden_dim"], checkpoint["num_revisions"],
        checkpoint["channel_rounds"],
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model


def main():
    torch.manual_seed(24680)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TEST_SIZE": 20,
    })
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    grouped = build_stratified_samples(states, (0, 20), 44)
    samples = [
        sample for group in DENSITY_BOUNDS for sample in grouped[group]
    ]
    quantities = {id(state): full_oracle_quantities(state) for state in states}
    scales = (0.01, 0.1, 1.0, 10.0)
    report = {}
    for name, path in CHECKPOINTS.items():
        model = load_model(path)
        totals = {
            scale: {"utility": 0.0, "teacher": 0.0, "active": 0.0,
                    "flips": 0, "eligible": 0}
            for scale in scales
        }
        with torch.no_grad():
            for state, queues, teacher in samples:
                solo, harm, edge_index = quantities[id(state)]
                teacher_utility = mws_objective(
                    teacher.reshape(-1), queues, state
                )
                for _ in range(8):
                    initial = random_initial_action(queues)
                    uniforms = [
                        torch.rand(state.num_vertices)
                        for _ in range(model.num_revisions)
                    ]
                    actions = {}
                    for scale in scales:
                        action, _ = model(
                            solo, harm, scale * queues, edge_index,
                            initial_action=initial,
                            random_uniforms=uniforms,
                        )
                        actions[scale] = action.reshape(-1)
                    reference = actions[1.0]
                    nonempty = queues > 0
                    for scale in scales:
                        totals[scale]["utility"] += mws_objective(
                            actions[scale], queues, state
                        )
                        totals[scale]["teacher"] += teacher_utility
                        totals[scale]["active"] += float(actions[scale].sum())
                        totals[scale]["flips"] += int(
                            (actions[scale][nonempty] != reference[nonempty]).sum()
                        )
                        totals[scale]["eligible"] += int(nonempty.sum())
        report[name] = {
            str(scale): {
                "mws_ratio": (
                    totals[scale]["utility"] / totals[scale]["teacher"]
                ),
                "average_active": totals[scale]["active"] / (len(samples) * 8),
                "action_flip_vs_scale1": (
                    totals[scale]["flips"] / totals[scale]["eligible"]
                ),
            } for scale in scales
        }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/set_queue_scale_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": path, "results": report}, indent=2))


if __name__ == "__main__":
    main()
