#!/usr/bin/env python3
"""Train the oracle Anchor-Join conditional set scheduler."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import (
    precompute, resample_training_distribution,
)
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS, build_stratified_samples,
)
from models.anchor_join import AnchorJoinDecoder
from models.model import calculate_achievable_rate
from utils.mws import centralized_mws_greedy, mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--tx_power", type=float, default=10.0)
    parser.add_argument("--train_size", type=int, default=200)
    parser.add_argument("--val_size", type=int, default=32)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--hidden_dim", type=int, default=32)
    parser.add_argument("--num_rounds", type=int, default=3)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--queue_sampling", choices=(
        "balanced_random", "mixed_hotspot"
    ), default="mixed_hotspot")
    parser.add_argument("--objective", choices=(
        "teacher_calibration", "hard_utility"
    ), default="teacher_calibration")
    parser.add_argument("--policy_samples", type=int, default=2)
    parser.add_argument("--init_checkpoint", default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def normalized_reward(action, queues, state):
    return torch.sum(
        queues * calculate_achievable_rate(action, state, binary=True)
    ) / (queues.sum() + 1e-8)


def balanced_join_bce(probability, target, eligible):
    probability = probability.clamp(1e-6, 1 - 1e-6)
    positive = eligible & (target > 0.5)
    negative = eligible & (target <= 0.5)
    terms = []
    if positive.any():
        terms.append(-torch.log(probability[positive]).mean())
    if negative.any():
        terms.append(-torch.log(1 - probability[negative]).mean())
    return torch.stack(terms).mean() if terms else probability.sum() * 0.0


def teacher_loss(model, solo, harm, queues, edge_index, target):
    anchor_logits, _, _, nonempty = model.anchor_logits(
        solo, harm, queues, edge_index
    )
    target_bool = target.reshape(-1) > 0.5
    if not target_bool.any():
        raise ValueError("MWS teacher returned an empty set for a nonempty queue sample.")
    log_anchor_probability = torch.log_softmax(anchor_logits, dim=0)
    anchor_loss = -torch.logsumexp(
        log_anchor_probability[target_bool], dim=0
    )
    teacher_indices = target_bool.nonzero(as_tuple=True)[0]
    anchor = teacher_indices[
        anchor_logits.detach()[teacher_indices].argmax()
    ]
    join_probability, _, _ = model.join_probabilities(
        solo, harm, queues, edge_index, anchor
    )
    eligible = nonempty > 0
    eligible = eligible.clone()
    eligible[anchor] = False
    join_loss = balanced_join_bce(
        join_probability.reshape(-1), target.reshape(-1), eligible
    )
    return anchor_loss + join_loss, anchor_loss.detach(), join_loss.detach()


def hard_utility_loss(model, solo, harm, queues, edge_index, state,
                      num_samples):
    anchor_logits, _, _, nonempty = model.anchor_logits(
        solo, harm, queues, edge_index
    )
    active = (nonempty > 0).nonzero(as_tuple=True)[0]
    distribution = torch.distributions.Categorical(
        logits=anchor_logits[active]
    )
    anchor_log_probabilities = []
    rewards = []
    join_losses = []
    for _ in range(num_samples):
        sampled_local = distribution.sample()
        anchor = active[sampled_local]
        anchor_log_probabilities.append(distribution.log_prob(sampled_local))
        join_probability, _, _ = model.join_probabilities(
            solo, harm, queues, edge_index, anchor
        )
        join_probability = join_probability.reshape(-1)
        candidates = active[active != anchor]
        action = torch.zeros_like(queues).unsqueeze(1)
        action[anchor] = 1.0
        if candidates.numel() > 0:
            action[candidates, 0] = torch.bernoulli(
                join_probability[candidates]
            )
        rewards.append(normalized_reward(action, queues, state).detach())

        marginal_rewards = []
        for link in candidates.tolist():
            action_on = action.clone()
            action_off = action.clone()
            action_on[link] = 1.0
            action_off[link] = 0.0
            marginal_rewards.append((
                normalized_reward(action_on, queues, state)
                - normalized_reward(action_off, queues, state)
            ).detach())
        if marginal_rewards:
            delta = torch.stack(marginal_rewards)
            join_losses.append(-torch.mean(
                delta * join_probability[candidates]
            ))

    rewards = torch.stack(rewards)
    anchor_log_probabilities = torch.stack(anchor_log_probabilities)
    if num_samples > 1:
        baseline = (rewards.sum() - rewards) / (num_samples - 1)
    else:
        baseline = torch.zeros_like(rewards)
    anchor_loss = -torch.mean(
        (rewards - baseline) * anchor_log_probabilities
    )
    join_loss = (
        torch.stack(join_losses).mean()
        if join_losses else anchor_loss * 0.0
    )
    return anchor_loss + join_loss, anchor_loss.detach(), join_loss.detach()


def evaluate(model, grouped, physical, device, stochastic_samples=8):
    totals = {}
    model.eval()
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            accum = {
                "utility": 0.0, "teacher": 0.0, "sampled": 0.0,
                "active": 0.0, "teacher_active": 0.0, "joins": 0.0,
                "tp": 0, "pred": 0, "target": 0,
                "queue_flips": 0, "nonempty": 0,
                "permuted_utility": 0.0, "all_zero": 0,
            }
            for index, (state, queues, target) in enumerate(grouped[group]):
                solo, harm = physical[index]
                solo, harm, queues_device = (
                    solo.to(device), harm.to(device), queues.to(device)
                )
                probability, diagnostics = model(
                    solo, harm, queues_device, state.edge_index.to(device)
                )
                hard = (probability > 0.5).float().cpu()
                accum["utility"] += mws_objective(hard.squeeze(1), queues, state)
                accum["teacher"] += mws_objective(target.squeeze(1), queues, state)
                accum["active"] += hard.sum().item()
                accum["teacher_active"] += target.sum().item()
                accum["joins"] += max(hard.sum().item() - 1.0, 0.0)
                accum["all_zero"] += int(hard.sum() == 0 and (queues > 0).any())
                predicted_bool, target_bool = hard > 0.5, target > 0.5
                accum["tp"] += int((predicted_bool & target_bool).sum())
                accum["pred"] += int(predicted_bool.sum())
                accum["target"] += int(target_bool.sum())

                anchor_logits = diagnostics["anchor_logits"]
                active_indices = (queues_device > 0).nonzero(as_tuple=True)[0]
                distribution = torch.distributions.Categorical(
                    logits=anchor_logits[active_indices]
                )
                sampled_utility = 0.0
                for _ in range(stochastic_samples):
                    anchor = active_indices[distribution.sample()]
                    join_probability, _, _ = model.join_probabilities(
                        solo, harm, queues_device, state.edge_index.to(device), anchor
                    )
                    sampled_action = torch.bernoulli(join_probability)
                    sampled_action[anchor] = 1.0
                    sampled_utility += mws_objective(
                        sampled_action.squeeze(1).cpu(), queues, state
                    )
                accum["sampled"] += sampled_utility / stochastic_samples

                positive = (queues > 0).nonzero(as_tuple=True)[0]
                permuted_queues = queues.clone()
                permuted_queues[positive] = queues[positive.flip(0)]
                permuted_probability, _ = model(
                    solo, harm, permuted_queues.to(device),
                    state.edge_index.to(device)
                )
                permuted_hard = (permuted_probability > 0.5).float().cpu()
                mask = (queues > 0).unsqueeze(1)
                accum["queue_flips"] += int(((hard != permuted_hard) & mask).sum())
                accum["nonempty"] += int(mask.sum())
                accum["permuted_utility"] += mws_objective(
                    permuted_hard.squeeze(1), queues, state
                )

            count = len(grouped[group])
            precision = accum["tp"] / max(accum["pred"], 1)
            recall = accum["tp"] / max(accum["target"], 1)
            totals[group] = {
                "mws_ratio": accum["utility"] / max(accum["teacher"], 1e-12),
                "sampled_mws_ratio": accum["sampled"] / max(accum["teacher"], 1e-12),
                "average_active_links": accum["active"] / count,
                "average_join_links": accum["joins"] / count,
                "teacher_average_active_links": accum["teacher_active"] / count,
                "precision": precision, "recall": recall,
                "f1": 2 * precision * recall / max(precision + recall, 1e-12),
                "all_zero_rate": accum["all_zero"] / count,
                "queue_permutation_hard_flip_rate": (
                    accum["queue_flips"] / max(accum["nonempty"], 1)
                ),
                "permuted_queue_utility_ratio_to_normal": (
                    accum["permuted_utility"] / max(accum["utility"], 1e-12)
                ),
                "_raw": accum,
            }

    combined_raw = {
        key: sum(totals[group]["_raw"][key] for group in DENSITY_BOUNDS)
        for key in totals["sparse"]["_raw"]
    }
    count = sum(len(grouped[group]) for group in DENSITY_BOUNDS)
    precision = combined_raw["tp"] / max(combined_raw["pred"], 1)
    recall = combined_raw["tp"] / max(combined_raw["target"], 1)
    totals["combined"] = {
        "mws_ratio": combined_raw["utility"] / max(combined_raw["teacher"], 1e-12),
        "sampled_mws_ratio": combined_raw["sampled"] / max(combined_raw["teacher"], 1e-12),
        "average_active_links": combined_raw["active"] / count,
        "average_join_links": combined_raw["joins"] / count,
        "teacher_average_active_links": combined_raw["teacher_active"] / count,
        "precision": precision, "recall": recall,
        "f1": 2 * precision * recall / max(precision + recall, 1e-12),
        "all_zero_rate": combined_raw["all_zero"] / count,
        "queue_permutation_hard_flip_rate": (
            combined_raw["queue_flips"] / max(combined_raw["nonempty"], 1)
        ),
        "permuted_queue_utility_ratio_to_normal": (
            combined_raw["permuted_utility"] / max(combined_raw["utility"], 1e-12)
        ),
    }
    for group in DENSITY_BOUNDS:
        del totals[group]["_raw"]
    return totals


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav, "TX_POWER": args.tx_power,
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size, "TEST_SIZE": args.test_size,
    })
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, args.num_uav, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    cache_root = os.path.join("results", "cache", "oracle_marginals")
    physical = {
        split: precompute(split_states, os.path.join(
            cache_root,
            f"numUAV={args.num_uav}_tx={args.tx_power:g}dBm_"
            f"csi={cfg.get('CSI_MODE', 'perfect')}_{split}_"
            f"n={len(split_states)}.pth"
        )) for split, split_states in states.items()
    }
    val_grouped = build_stratified_samples(states["val"], queue_range, args.seed + 1)
    test_grouped = build_stratified_samples(states["test"], queue_range, args.seed + 2)
    model = AnchorJoinDecoder(args.hidden_dim, args.num_rounds).to(device)
    if args.init_checkpoint:
        checkpoint = torch.load(args.init_checkpoint, map_location=device)
        model.load_state_dict(checkpoint["model_state_dict"])
        print(f"[Setup] initialized from {args.init_checkpoint}")
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.get("LR", 1e-4))
    initial = evaluate(model, val_grouped, physical["val"], device)
    metric = "f1" if args.objective == "teacher_calibration" else "sampled_mws_ratio"
    best_value = initial["combined"][metric]
    best_state = copy.deepcopy(model.state_dict())
    best_epoch = -1
    logs = [{"epoch": -1, "loss": None, "validation": initial}]
    print(
        f"[Setup] params={sum(p.numel() for p in model.parameters())} "
        f"objective={args.objective} initial_{metric}={best_value:.3f}"
    )

    for epoch in range(args.epochs):
        model.train()
        samples = resample_training_distribution(
            states["train"], queue_range, args.seed + 104729 * epoch,
            args.queue_sampling,
        )
        order = list(range(len(samples)))
        random.shuffle(order)
        losses, anchor_losses, join_losses = [], [], []
        for index in order:
            state, queues = samples[index]
            solo, harm = physical["train"][index]
            solo, harm, queues_device = (
                solo.to(device), harm.to(device), queues.to(device)
            )
            edge_index = state.edge_index.to(device)
            if args.objective == "teacher_calibration":
                target = centralized_mws_greedy(state, queues).to(device)
                loss, anchor_loss, join_loss = teacher_loss(
                    model, solo, harm, queues_device, edge_index, target
                )
            else:
                loss, anchor_loss, join_loss = hard_utility_loss(
                    model, solo, harm, queues_device, edge_index, state,
                    args.policy_samples,
                )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(loss.item())
            anchor_losses.append(anchor_loss.item())
            join_losses.append(join_loss.item())

        validation = evaluate(model, val_grouped, physical["val"], device)
        combined = validation["combined"]
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "anchor_loss": float(np.mean(anchor_losses)),
            "join_loss": float(np.mean(join_losses)),
            "validation": validation,
        })
        if combined[metric] > best_value:
            best_value = combined[metric]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.4f} "
            f"anchor={np.mean(anchor_losses):.4f} join={np.mean(join_losses):.4f} "
            f"MWS={combined['mws_ratio']:.3f} sampled={combined['sampled_mws_ratio']:.3f} "
            f"active={combined['average_active_links']:.2f} "
            f"joins={combined['average_join_links']:.2f} "
            f"zero={combined['all_zero_rate']:.3f}"
        )

    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped, physical["test"], device)
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"anchor_join_oracle_numUAV={args.num_uav}_tx={args.tx_power:g}dBm_"
        f"csi={cfg.get('CSI_MODE', 'perfect')}_rounds={args.num_rounds}_"
        f"objective={args.objective}_init={int(args.init_checkpoint is not None)}_"
        f"sampling={args.queue_sampling}_ep={args.epochs}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": "anchor_join_oracle_v1_experimental",
        "model_state_dict": model.state_dict(),
        "hidden_dim": args.hidden_dim, "num_rounds": args.num_rounds,
        "objective": args.objective, "queue_sampling": args.queue_sampling,
        "init_checkpoint": args.init_checkpoint, "best_epoch": best_epoch,
        "seed": args.seed,
        "tx_power_dbm": args.tx_power,
        "csi_mode": cfg.get("CSI_MODE", "perfect"),
    }, checkpoint_path)
    report_path = os.path.join(
        "results", "diagnostics",
        f"anchor_join_oracle_tx{args.tx_power:g}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args), "checkpoint": checkpoint_path,
            "best_epoch": best_epoch, "best_metric": metric,
            "best_value": best_value, "test": test, "epochs": logs,
        }, file, indent=2)
    print(f"[Done] checkpoint={checkpoint_path}")
    print(f"[Done] report={report_path}")
    print(json.dumps(test, indent=2))


if __name__ == "__main__":
    main()
