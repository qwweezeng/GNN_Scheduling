# Two-stage 实验代码索引

> 本索引只整理 2026-07-11 之后的队列感知探索。原项目的基础吞吐量、功率控制、CSI、收敛性和尺度实验不属于本轮清理范围，全部保留。

## 当前主线直接使用

- `experiments/diagnose_localmax_reuse_headroom.py`：LocalMax + 精确顺序/单轮并行复用的可行性闸门；
- `models/parallel_reuse.py`：当前 LocalPhysicalReuse-v2、v1 基线和历史 LearnedReuse-v1/v2；
- `utils/parallel_reuse.py`：精确/冲突图局部条件增益与并行局部选举；
- `experiments/diagnose_local_margin_sufficiency.py`：局部物理量解释精确收益的充分性诊断；
- `experiments/diagnose_reuse_safety_neighborhood.py`：固定弱干扰安全邻居诊断；结果不支持进入正式模型；
- `experiments/train_parallel_reuse.py`、`evaluate_parallel_reuse.py`：LearnedReuse-v1/v2 失败复现及动态对照；
- `experiments/diagnose_localmax_priority.py`：v1、纯物理与 GAT Expected-Rate 骨架静态审查；
- `experiments/evaluate_localmax_priority.py`：10/20/50 UAV 动态骨架审查；
- `experiments/benchmark_local_physical_scale.py`：按 (L,E) 记录冷/暖时隙运行时间；
- `models/two_stage.py`：TwoStage-v1 与当前 LocalMax 诊断规则；
- `experiments/run_queue_experiment.py`：共享的动态队列仿真和 MWS-Greedy 对照；
- `experiments/queue_model_diagnostics.py`：加载物理口径一致的会议版信道 GAT；
- `utils/mws.py`：MWS 效用与集中式 greedy 对照。

## 仍有复现价值的历史代码组

| 代码前缀 | 对应路线 | 保留原因 |
|---|---|---|
| `train_two_stage_*`, `evaluate_two_stage_*`, `two_stage_v1_diagnostics.py` | Structure / Marginal | 轻量基线和两阶段消融 |
| `physical_*`, `train_oracle_physical_*`, `diagnose_analytic_rho.py` | PhysicalNegotiation | 有向物理损害与信道估计诊断 |
| `anchor_*`, `sequential_*`, `diagnose_exact_set_greedy.py` | Anchor--Join | 条件集合、局部最优和规模审计 |
| `parallel_mpnn*` | ParallelMPNN | 静态表示能力和动态失败复现 |
| `set_negotiation*`, `diagnose_set_*` | SetNegotiation | 联合信用分配失败证据 |
| `diagnose_candidate_portfolio.py`, `diagnose_random_set_dynamic.py` | Best-K | 候选多样性上限 |

这些代码不再继续演进，也不应从文件名推断为当前模型。它们暂时原位保留，避免移动后破坏历史脚本之间的导入关系；当前入口由本索引隔离，而不是冒险批量删除。

## 当前明确结论

- `LocalPhysicalReuse-v1` 是可用历史基线，`LocalPhysicalReuse-v2` 是当前推荐学习版；
- `ExactParallelReuse` 和 `ExactSequentialReuse` 使用全局状态，只是上限；
- `LearnedReuse-v1/v2` 是“完整增益预测过重”的负面证据，不是最终模型；
- 当前不继续学习完整边际收益；GAT 只通过期望干扰/有效速率这一物理接口进入快速队列调度。
- 动态到达 trace 现由 `(MC seed, Lambda数值)` 唯一决定；旧的下标种子报告不得与修正后的正式结果混用。

## 明确不作为正式证据

- 名称含 `smoke` 的结果只验证代码能运行；
- 单 seed、少于 500 时隙的动态结果只做方向筛选；
- 使用 `Oracle`、`Exact`、`Best-K` 的结果通常读取集中式信息，只能作为上限；
- 未显式包含 `tx=10dBm` 或报告中未写明功率的旧结果不得与当前结果混合。
