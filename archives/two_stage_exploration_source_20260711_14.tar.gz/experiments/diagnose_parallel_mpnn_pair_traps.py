#!/usr/bin/env python3
"""Measure single-flip and coordinated two-flip improvement opportunities."""

import argparse
import json
import os
import sys
from collections import Counter
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_parallel_mpnn import full_oracle_quantities, model_action
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.parallel_mpnn import ParallelMPNN
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", default="42,43,44")
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--objective", default="local_best_response")
    return parser.parse_args()


def load_model(seed, objective):
    path = (
        "results/models/experimental/parallel_mpnn_v1_tx=10dBm_"
        f"numUAV=10_rounds=2_objective={objective}_s{seed}.pth"
    )
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    model = ParallelMPNN(
        hidden_dim=checkpoint["hidden_dim"],
        num_rounds=checkpoint["num_rounds"],
        channel_rounds=checkpoint["channel_rounds"],
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, path


def flip_type(action, first, second):
    before = (int(action[first]), int(action[second]))
    mapping = {
        (0, 0): "double_on",
        (1, 1): "double_off",
        (0, 1): "swap",
        (1, 0): "swap",
    }
    return mapping[before]


def analyze_state(model, state, queues, teacher, quantities):
    with torch.no_grad():
        _, action, _ = model_action(model, state, queues, quantities)
    action = action.reshape(-1).cpu()
    eligible = (queues > 0).nonzero(as_tuple=True)[0].tolist()
    current = mws_objective(action, queues, state)
    teacher_utility = mws_objective(teacher.reshape(-1), queues, state)
    best_single = current
    for focal in eligible:
        candidate = action.clone()
        candidate[focal] = 1.0 - candidate[focal]
        best_single = max(best_single, mws_objective(candidate, queues, state))

    best_pair = current
    best_pair_type = None
    for offset, first in enumerate(eligible):
        for second in eligible[offset + 1:]:
            candidate = action.clone()
            candidate[first] = 1.0 - candidate[first]
            candidate[second] = 1.0 - candidate[second]
            value = mws_objective(candidate, queues, state)
            if value > best_pair + 1e-10:
                best_pair = value
                best_pair_type = flip_type(action, first, second)
    unilateral_local_optimum = best_single <= current + 1e-10
    pair_trap = unilateral_local_optimum and best_pair > current + 1e-10
    return {
        "current_to_teacher_ratio": current / max(teacher_utility, 1e-12),
        "best_single_to_teacher_ratio": best_single / max(teacher_utility, 1e-12),
        "best_pair_to_teacher_ratio": best_pair / max(teacher_utility, 1e-12),
        "single_gain_to_teacher": (best_single - current) / max(teacher_utility, 1e-12),
        "pair_gain_to_teacher": (best_pair - current) / max(teacher_utility, 1e-12),
        "unilateral_local_optimum": unilateral_local_optimum,
        "pair_trap": pair_trap,
        "best_pair_type": best_pair_type,
        "num_nonempty": len(eligible),
    }


def summarize(records):
    pair_types = Counter(
        record["best_pair_type"] for record in records
        if record["best_pair_type"] is not None
    )
    pair_traps = [record for record in records if record["pair_trap"]]
    return {
        "num_states": len(records),
        "mean_model_mws_ratio": float(np.mean([
            record["current_to_teacher_ratio"] for record in records
        ])),
        "unilateral_local_optimum_rate": float(np.mean([
            record["unilateral_local_optimum"] for record in records
        ])),
        "any_single_improvement_rate": float(np.mean([
            record["single_gain_to_teacher"] > 1e-10 for record in records
        ])),
        "any_pair_improvement_rate": float(np.mean([
            record["pair_gain_to_teacher"] > 1e-10 for record in records
        ])),
        "coordinated_pair_trap_rate": float(np.mean([
            record["pair_trap"] for record in records
        ])),
        "mean_best_single_gain_to_teacher": float(np.mean([
            record["single_gain_to_teacher"] for record in records
        ])),
        "mean_best_pair_gain_to_teacher": float(np.mean([
            record["pair_gain_to_teacher"] for record in records
        ])),
        "mean_pair_gain_within_pair_traps": float(np.mean([
            record["pair_gain_to_teacher"] for record in pair_traps
        ])) if pair_traps else 0.0,
        "best_pair_type_counts": dict(pair_types),
    }


def main():
    args = parse_args()
    seeds = [int(value) for value in args.seeds.split(",")]
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TEST_SIZE": args.test_size,
    })
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    quantities = {id(state): full_oracle_quantities(state) for state in states}
    by_seed = {}
    all_records = []
    checkpoints = {}
    for seed in seeds:
        model, path = load_model(seed, args.objective)
        checkpoints[str(seed)] = path
        grouped = build_stratified_samples(states, (0, 20), seed + 2)
        records = []
        for group in DENSITY_BOUNDS:
            for state, queues, teacher in grouped[group]:
                record = analyze_state(
                    model, state, queues, teacher, quantities[id(state)]
                )
                record["density_group"] = group
                records.append(record)
        by_seed[str(seed)] = summarize(records)
        all_records.extend(records)
    report = {
        "setting": "10 UAV / 10 dBm / perfect CSI",
        "model": f"ParallelMPNN-v1 / {args.objective} / 2 rounds",
        "definition": (
            "pair trap means no single hard action flip improves utility, "
            "but flipping two links together does"
        ),
        "checkpoints": checkpoints,
        "by_seed": by_seed,
        "combined": summarize(all_records),
        "records": all_records,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"parallel_mpnn_pair_traps_tx10_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": path, "combined": report["combined"]}, indent=2))


if __name__ == "__main__":
    main()
