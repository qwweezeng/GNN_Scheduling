#!/usr/bin/env python3
"""Evaluate a learned ParallelReuse checkpoint on static and dynamic queues."""

import argparse
import json
import os
import sys
from datetime import datetime
from types import SimpleNamespace

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_localmax_reuse_headroom import (
    ExactParallelReuseScheduler,
    QueueAwareRandomScheduler,
    build_static_samples,
    jsonify,
)
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    CentralizedMWSGreedyScheduler,
    _load_or_generate_dataset,
    build_generator,
    load_config,
    simulation_phase,
)
from experiments.train_parallel_reuse import evaluate
from models.parallel_reuse import (
    ConditionalReuseMarginPredictor,
    LearnedParallelReuseScheduler,
    LocalPhysicalReuseScheduler,
)
from models.two_stage import QueueChannelLocalMaxScheduler


def parse_int_list(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def parse_float_list(text):
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint",
        default=(
            "results/models/experimental/parallel_reuse_v1_"
            "numUAV=10_tx=10dBm_s42.pth"
        ),
    )
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--queue_seeds", default="20042")
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--arrival_rates", default="1,2,4")
    parser.add_argument("--mc_seeds", default="42,43,44")
    parser.add_argument("--skip_dynamic", action="store_true")
    return parser.parse_args()


def main():
    args = parse_args()
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model_version = checkpoint.get("model_version")
    if model_version not in {
        "parallel_reuse_v1", "parallel_reuse_v2"
    }:
        raise ValueError(f"Incompatible checkpoint: {args.checkpoint}")

    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": float(checkpoint.get("tx_power_dbm", 10.0)),
        "CSI_MODE": checkpoint.get("csi_mode", "perfect"),
        "TEST_SIZE": args.test_size,
    })
    channel_model, channel_path = load_channel_model(
        cfg, int(checkpoint["channel_model_num_uav"]), torch.device("cpu")
    )
    predictor = ConditionalReuseMarginPredictor(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        hidden_dim=int(checkpoint["hidden_dim"]),
        edge_dim=cfg.get("EDGE_DIM", 1),
        use_pairwise_queue_edge=bool(
            checkpoint.get("use_pairwise_queue_edge", False)
        ),
    )
    predictor.load_state_dict(checkpoint["model_state_dict"])
    predictor.eval()
    localmax = QueueChannelLocalMaxScheduler(channel_model)
    learned = LearnedParallelReuseScheduler(predictor, localmax)
    exact = ExactParallelReuseScheduler(localmax)
    local_physical = LocalPhysicalReuseScheduler(localmax)

    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, args.num_uav, False, "test", (0, 20)
    )
    grouped = build_static_samples(
        states, (0, 20), parse_int_list(args.queue_seeds)
    )
    static = evaluate(predictor, grouped, localmax)

    dynamic = None
    dynamic_details = None
    if not args.skip_dynamic:
        models = {
            "Random-Q": (QueueAwareRandomScheduler(), "Queue-aware Random p=0.3"),
            "LocalMax": (localmax, "One-hop LocalMax"),
            "LocalPhysicalReuse": (
                local_physical, "Conflict-graph local physical reuse"
            ),
            model_version: (learned, f"Learned {model_version}"),
            "ExactParallelReuse": (exact, "Exact parallel reuse oracle"),
            "MWS-Greedy": (CentralizedMWSGreedyScheduler(), "MWS-Greedy"),
        }
        dynamic, dynamic_details = simulation_phase(
            build_generator(cfg), models, cfg,
            SimpleNamespace(
                num_slots=args.num_slots,
                arrival_rates=parse_float_list(args.arrival_rates),
                mc_seeds=parse_int_list(args.mc_seeds),
                slots_per_block=None,
            ),
        )

    report = {
        "experiment": f"{model_version}_evaluation",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "checkpoint": args.checkpoint,
        "channel_checkpoint": channel_path,
        "settings": vars(args),
        "static": static,
        "dynamic": dynamic,
        "dynamic_details": dynamic_details,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        f"results/diagnostics/{model_version}_eval_"
        f"numUAV={args.num_uav}_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({
        "report": path,
        "static_overall": static["overall"],
    }, indent=2))


if __name__ == "__main__":
    main()
