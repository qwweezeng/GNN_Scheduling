#!/usr/bin/env python3
"""Fine-tune anchor election on the final exact-set utility, without a teacher."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_anchor_join import resample_training_distribution
from experiments.train_oracle_physical_negotiation import precompute
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.anchor_one_join import AnchorOneJoinDecoder
from models.two_stage_physical import exact_state_greedy_from_anchor
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--init_checkpoint", required=True)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=200)
    parser.add_argument("--val_size", type=int, default=32)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--policy_samples", type=int, default=4)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def policy_loss(model, solo, harm, queues, edge_index, state, num_samples):
    logits, _, _, nonempty = model.anchor_context(
        solo, harm, queues, edge_index
    )
    active = (nonempty > 0).nonzero(as_tuple=True)[0]
    distribution = torch.distributions.Categorical(logits=logits[active])
    log_probabilities, rewards = [], []
    for _ in range(num_samples):
        local_anchor = distribution.sample()
        anchor = active[local_anchor]
        _, utility = exact_state_greedy_from_anchor(anchor, state, queues)
        log_probabilities.append(distribution.log_prob(local_anchor))
        rewards.append((utility / queues.sum().clamp_min(1.0)).detach())
    log_probabilities = torch.stack(log_probabilities)
    rewards = torch.stack(rewards)
    if num_samples > 1:
        baseline = (rewards.sum() - rewards) / (num_samples - 1)
    else:
        baseline = torch.zeros_like(rewards)
    return -torch.mean((rewards - baseline) * log_probabilities), rewards.mean()


def evaluate(model, grouped, physical):
    report = {}
    totals = {"utility": 0.0, "teacher": 0.0, "active": 0.0, "samples": 0}
    model.eval()
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            local = {"utility": 0.0, "teacher": 0.0, "active": 0.0, "samples": 0}
            for index, (state, queues, teacher) in enumerate(grouped[group]):
                solo, harm = physical[index]
                logits, _, _, nonempty = model.anchor_context(
                    solo, harm, queues, state.edge_index
                )
                if (nonempty > 0).any():
                    action, utility = exact_state_greedy_from_anchor(
                        torch.argmax(logits), state, queues
                    )
                else:
                    action = torch.zeros(state.num_vertices)
                    utility = torch.tensor(0.0)
                local["utility"] += float(utility)
                local["teacher"] += mws_objective(
                    teacher.squeeze(1), queues, state
                )
                local["active"] += float(action.sum())
                local["samples"] += 1
            report[group] = {
                "mws_ratio": local["utility"] / local["teacher"],
                "average_active_links": local["active"] / local["samples"],
            }
            for key in totals:
                totals[key] += local[key]
    report["combined"] = {
        "mws_ratio": totals["utility"] / totals["teacher"],
        "average_active_links": totals["active"] / totals["samples"],
    }
    return report


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav, "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size, "TEST_SIZE": args.test_size,
    })
    queue_range = tuple(int(value) for value in args.queue_range.split(","))
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, args.num_uav, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    cache_root = "results/cache/oracle_marginals"
    physical = {
        split: precompute(split_states, os.path.join(
            cache_root,
            f"numUAV={args.num_uav}_{split}_n={len(split_states)}.pth",
        )) for split, split_states in states.items()
    }
    checkpoint = torch.load(args.init_checkpoint, map_location="cpu")
    model = AnchorOneJoinDecoder(
        checkpoint["hidden_dim"], checkpoint["num_rounds"]
    )
    model.load_anchor_from_anchor_join(checkpoint["model_state_dict"])
    for module in (model.join_mlp, model.stop_head):
        for parameter in module.parameters():
            parameter.requires_grad_(False)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.Adam(trainable, lr=cfg.get("LR", 1e-4))
    val_grouped = build_stratified_samples(states["val"], queue_range, args.seed + 1)
    test_grouped = build_stratified_samples(states["test"], queue_range, args.seed + 2)
    initial = evaluate(model, val_grouped, physical["val"])
    best_value = initial["combined"]["mws_ratio"]
    best_state = copy.deepcopy(model.state_dict())
    best_epoch = -1
    logs = [{"epoch": -1, "validation": initial}]
    print(f"[Setup] initial validation MWS={best_value:.4f}")
    for epoch in range(args.epochs):
        model.train()
        samples = resample_training_distribution(
            states["train"], queue_range, args.seed + 104729 * epoch,
            "mixed_hotspot",
        )
        order = list(range(len(samples)))
        random.shuffle(order)
        losses, rewards = [], []
        for index in order:
            state, queues = samples[index]
            solo, harm = physical["train"][index]
            loss, reward = policy_loss(
                model, solo, harm, queues, state.edge_index, state,
                args.policy_samples,
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
            rewards.append(float(reward))
        validation = evaluate(model, val_grouped, physical["val"])
        value = validation["combined"]["mws_ratio"]
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "sampled_normalized_reward": float(np.mean(rewards)),
            "validation": validation,
        })
        if value > best_value:
            best_value = value
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.5f} "
            f"reward={np.mean(rewards):.4f} validation_MWS={value:.4f}"
        )
    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped, physical["test"])
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"anchor_exact_set_utility_numUAV={args.num_uav}_train={args.train_size}_"
        f"ep={args.epochs}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": "anchor_exact_set_utility_v1_experimental",
        "model_state_dict": model.state_dict(),
        "hidden_dim": model.hidden_dim, "num_rounds": model.num_rounds,
        "init_checkpoint": args.init_checkpoint, "best_epoch": best_epoch,
        "objective": "teacher_free_final_exact_set_utility",
    }, checkpoint_path)
    report_path = os.path.join(
        "results/diagnostics",
        f"anchor_exact_set_utility_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args), "checkpoint": checkpoint_path,
            "best_epoch": best_epoch, "initial_validation": initial,
            "test": test, "epochs": logs,
        }, file, indent=2)
    print(json.dumps({
        "checkpoint": checkpoint_path, "report": report_path,
        "best_epoch": best_epoch, "test": test,
    }, indent=2))


if __name__ == "__main__":
    main()
