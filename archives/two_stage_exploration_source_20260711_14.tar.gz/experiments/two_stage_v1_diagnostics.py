#!/usr/bin/env python3
"""Stratified information-path diagnostics for a trained TwoStage-GAT-v1.

This script is intentionally evaluation-only.  It does not train a model or
overwrite a checkpoint.  Its purpose is to decide which information paths are
actually used before designing TwoStage-GAT-v2.
"""

import argparse
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from models.two_stage import TwoStageGATScheduler, local_relative_queue
from utils.mws import centralized_mws_greedy, mws_objective


DENSITY_BOUNDS = {
    "sparse": (0.0, 0.10),
    "medium": (0.10, 0.40),
    "dense": (0.40, 1.00),
}

ABLATIONS = (
    "baseline",
    "no_channel_embedding",
    "shuffle_channel_embedding",
    "no_channel_score",
    "no_priority_seed",
    "uniform_nonempty_queue",
    "no_stage2_edge_weight",
    "queue_only",
)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def density_k_range(num_links, group):
    """Return inclusive nonempty-link count bounds for one density group."""
    if num_links <= 0:
        return 0, 0
    lower_ratio, upper_ratio = DENSITY_BOUNDS[group]
    lower = max(1, int(np.floor(lower_ratio * num_links)) + 1)
    upper = max(lower, int(np.ceil(upper_ratio * num_links)))
    return min(lower, num_links), min(upper, num_links)


def sample_queues_for_density(num_links, group, queue_range, generator):
    """Sample link queues while controlling the fraction of nonempty queues."""
    lower_k, upper_k = density_k_range(num_links, group)
    if num_links <= 0:
        return torch.empty(0, dtype=torch.float32)
    num_nonempty = int(torch.randint(
        lower_k, upper_k + 1, (1,), generator=generator
    ).item())
    low, high = int(queue_range[0]), int(queue_range[1])
    low = max(low, 1)
    high = max(high, low + 1)
    active = torch.randperm(num_links, generator=generator)[:num_nonempty]
    queues = torch.zeros(num_links, dtype=torch.float32)
    queues[active] = torch.randint(
        low, high, (num_nonempty,), generator=generator
    ).float()
    return queues


def build_stratified_samples(states, queue_range, seed):
    """Create equally sized sparse, medium and dense teacher sets."""
    samples = {group: [] for group in DENSITY_BOUNDS}
    for group_index, group in enumerate(DENSITY_BOUNDS):
        generator = torch.Generator().manual_seed(seed + 1009 * group_index)
        for state in states:
            queues = sample_queues_for_density(
                state.num_vertices, group, queue_range, generator
            )
            target = centralized_mws_greedy(state, queues)
            samples[group].append((state, queues, target))
    return samples


def summarize_graph_directionality(states):
    """Measure how much information is lost if only incoming edges are read."""
    directed_edges = reciprocal_edges = 0
    nodes = nodes_with_incoming = nodes_with_outgoing = 0
    for state in states:
        edge_pairs = set(map(tuple, state.edge_index.t().cpu().tolist()))
        directed_edges += len(edge_pairs)
        reciprocal_edges += sum((target, source) in edge_pairs for source, target in edge_pairs)
        nodes += state.num_vertices
        incoming = {target for _, target in edge_pairs}
        outgoing = {source for source, _ in edge_pairs}
        nodes_with_incoming += len(incoming)
        nodes_with_outgoing += len(outgoing)
    return {
        "num_graphs": len(states),
        "directed_edges": directed_edges,
        "reciprocal_directed_edge_ratio": reciprocal_edges / max(directed_edges, 1),
        "nodes_with_incoming_edge_ratio": nodes_with_incoming / max(nodes, 1),
        "nodes_with_outgoing_edge_ratio": nodes_with_outgoing / max(nodes, 1),
        "interpretation": (
            "A low reciprocal ratio means incoming-only GAT aggregation cannot "
            "generally reveal whom the current link harms."
        ),
    }


def ablated_probabilities(model, state, queues, ablation, generator):
    """Run v1 while removing exactly one candidate information shortcut."""
    device = next(model.parameters()).device
    x = state.vertex_features[:, :1].to(device)
    edge_index = state.edge_index.to(device)
    edge_weight = state.edge_weights.to(device)
    queues = queues.to(device)

    with torch.no_grad():
        channel_score, channel_embedding = model.channel_model.schedule_logits(
            x, edge_index, edge_weight
        )

        queue_rel = local_relative_queue(queues, edge_index).to(device).unsqueeze(1)
        if ablation == "uniform_nonempty_queue":
            queue_rel = (queues > 0).to(torch.float32).unsqueeze(1)

        if ablation in ("no_channel_embedding", "queue_only"):
            channel_embedding = torch.zeros_like(channel_embedding)
        elif ablation == "shuffle_channel_embedding" and channel_embedding.size(0) > 1:
            permutation = torch.randperm(
                channel_embedding.size(0), generator=generator
            ).to(device)
            channel_embedding = channel_embedding[permutation]

        priority_seed = queue_rel * F.softplus(channel_score)
        if ablation in ("no_channel_score", "queue_only"):
            # Keep the already computed seed in no_channel_score so that this
            # ablation removes only the direct scalar-score path.  The separate
            # no_priority_seed case measures the hand-crafted shortcut.
            channel_score = torch.zeros_like(channel_score)
        if ablation in ("no_priority_seed", "queue_only"):
            priority_seed = torch.zeros_like(priority_seed)

        fused = torch.cat([
            channel_embedding, channel_score, queue_rel, priority_seed
        ], dim=1)
        hidden = F.elu(model.queue_embed(fused))
        stage2_edge_weight = (
            torch.zeros_like(edge_weight)
            if ablation == "no_stage2_edge_weight" else edge_weight
        )
        hidden = model.queue_gat(hidden, edge_index, stage2_edge_weight)
        logits = model.decision_head(torch.cat([hidden, fused], dim=1))
        probabilities = torch.sigmoid(logits)
        return probabilities * (queues > 0).to(probabilities.dtype).unsqueeze(1)


def metric_accumulator():
    return {
        "utility": 0.0,
        "teacher_utility": 0.0,
        "true_positive": 0,
        "predicted_positive": 0,
        "target_positive": 0,
        "correct": 0,
        "total": 0,
        "probability_change": 0.0,
        "samples": 0,
    }


def finalize_metrics(accumulator):
    predicted = accumulator["predicted_positive"]
    target = accumulator["target_positive"]
    true_positive = accumulator["true_positive"]
    count = max(accumulator["samples"], 1)
    precision = true_positive / max(predicted, 1)
    recall = true_positive / max(target, 1)
    return {
        "mws_ratio": accumulator["utility"]
        / max(accumulator["teacher_utility"], 1e-12),
        "utility": accumulator["utility"] / count,
        "teacher_utility": accumulator["teacher_utility"] / count,
        "action_accuracy": accumulator["correct"] / max(accumulator["total"], 1),
        "precision": precision,
        "recall": recall,
        "f1": 2 * precision * recall / max(precision + recall, 1e-12),
        "average_active_links": predicted / count,
        "teacher_average_active_links": target / count,
        "mean_probability_change_from_baseline": accumulator["probability_change"] / count,
        "num_samples": accumulator["samples"],
    }


def evaluate_ablation(model, samples, ablation, threshold, seed):
    accumulator = metric_accumulator()
    generator = torch.Generator().manual_seed(seed)
    model.eval()
    with torch.no_grad():
        for state, queues, teacher in samples:
            baseline = ablated_probabilities(
                model, state, queues, "baseline", generator
            ).cpu()
            probabilities = (
                baseline if ablation == "baseline" else ablated_probabilities(
                    model, state, queues, ablation, generator
                ).cpu()
            )
            schedule = (probabilities > threshold).to(torch.float32)
            schedule *= (queues > 0).to(torch.float32).unsqueeze(1)
            schedule_bool = schedule > 0.5
            teacher_bool = teacher > 0.5

            accumulator["utility"] += mws_objective(
                schedule.squeeze(1), queues, state
            )
            accumulator["teacher_utility"] += mws_objective(
                teacher.squeeze(1), queues, state
            )
            accumulator["true_positive"] += int(
                (schedule_bool & teacher_bool).sum()
            )
            accumulator["predicted_positive"] += int(schedule_bool.sum())
            accumulator["target_positive"] += int(teacher_bool.sum())
            accumulator["correct"] += int((schedule_bool == teacher_bool).sum())
            accumulator["total"] += teacher.numel()
            accumulator["probability_change"] += float(
                (probabilities - baseline).abs().mean()
            )
            accumulator["samples"] += 1
    return finalize_metrics(accumulator)


def load_model(cfg, checkpoint_path, device):
    channel_model, channel_path = load_channel_model(cfg, cfg["NUM_UAV"], device)
    checkpoint = torch.load(checkpoint_path, map_location=device)
    compatible_versions = {"two_stage_v1", "two_stage_v1_stratified_control"}
    if checkpoint.get("model_version") not in compatible_versions:
        raise ValueError(
            f"Expected a TwoStage-v1-compatible checkpoint: {checkpoint_path}"
        )
    if checkpoint.get("channel_model_path") not in (None, channel_path):
        print(
            "[Warning] checkpoint channel path differs from the currently loaded "
            f"base model: {checkpoint.get('channel_model_path')} vs {channel_path}"
        )
    model = TwoStageGATScheduler(
        channel_model,
        channel_dim=cfg.get("GAT_OUT_DIM", 48),
        edge_dim=cfg.get("EDGE_DIM", 1),
        hidden_dim=cfg.get("SCHEDULE_HIDDEN", 32),
        gat_dim=32,
    ).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    return model.eval(), checkpoint


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--test_size", type=int, default=64)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=20260711)
    parser.add_argument("--thresholds", default="0.3,0.5,0.7")
    parser.add_argument(
        "--checkpoint",
        default=None,
    )
    parser.add_argument("--output", default=None)
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({"NUM_UAV": args.num_uav, "TEST_SIZE": args.test_size})
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    thresholds = [float(value.strip()) for value in args.thresholds.split(",")]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint_path = args.checkpoint or os.path.join(
        "results", "models",
        f"gat_queue_two_stage_v1_numUAV={args.num_uav}.pth",
    )

    network_generator = build_generator(cfg)
    states = _load_or_generate_dataset(
        network_generator, cfg, args.num_uav, False, "test", queue_range
    )
    states = states[:args.test_size]
    model, checkpoint = load_model(cfg, checkpoint_path, device)
    samples = build_stratified_samples(states, queue_range, args.seed)

    report = {
        "purpose": "TwoStage-GAT-v1 information-path diagnosis",
        "config": vars(args),
        "device": str(device),
        "checkpoint_metadata": {
            key: value for key, value in checkpoint.items()
            if key != "model_state_dict"
        },
        "graph_directionality": summarize_graph_directionality(states),
        "density_bounds": DENSITY_BOUNDS,
        "results": {},
    }
    for group, group_samples in samples.items():
        report["results"][group] = {}
        for threshold in thresholds:
            threshold_key = f"threshold_{threshold:.2f}"
            report["results"][group][threshold_key] = {}
            for ablation_index, ablation in enumerate(ABLATIONS):
                metrics = evaluate_ablation(
                    model, group_samples, ablation, threshold,
                    args.seed + 100000 * ablation_index,
                )
                report["results"][group][threshold_key][ablation] = metrics
                print(
                    f"[{group:6s} t={threshold:.2f} {ablation:25s}] "
                    f"MWS={metrics['mws_ratio']:.3f} "
                    f"active={metrics['average_active_links']:.2f} "
                    f"teacher={metrics['teacher_average_active_links']:.2f}"
                )

    output_path = args.output or os.path.join(
        "results", "diagnostics",
        f"two_stage_v1_ablation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(f"[Done] Diagnostic report: {output_path}")


if __name__ == "__main__":
    main()
