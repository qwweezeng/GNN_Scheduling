#!/usr/bin/env python3
"""Training-free scalability audit for link-graph scheduling at 10 dBm."""

import argparse
import json
import os
import random
import sys
from collections import deque
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import build_generator, load_config


def undirected_adjacency(num_nodes, edge_index):
    adjacency = [set() for _ in range(num_nodes)]
    for source, target in edge_index.t().tolist():
        adjacency[source].add(target)
        adjacency[target].add(source)
    return adjacency


def components(adjacency):
    unseen = set(range(len(adjacency)))
    result = []
    while unseen:
        root = unseen.pop()
        queue = [root]
        component = [root]
        for node in queue:
            new_nodes = adjacency[node] & unseen
            unseen.difference_update(new_nodes)
            queue.extend(new_nodes)
            component.extend(new_nodes)
        result.append(component)
    return result


def farthest(start, adjacency, allowed):
    distance = {start: 0}
    queue = deque([start])
    while queue:
        node = queue.popleft()
        for neighbor in adjacency[node]:
            if neighbor in allowed and neighbor not in distance:
                distance[neighbor] = distance[node] + 1
                queue.append(neighbor)
    endpoint = max(distance, key=distance.get)
    return endpoint, distance[endpoint]


def approximate_diameter(component, adjacency):
    if len(component) <= 1:
        return 0
    allowed = set(component)
    endpoint, _ = farthest(component[0], adjacency, allowed)
    _, diameter = farthest(endpoint, adjacency, allowed)
    return diameter


def greedy_maximal_independent_set_size(adjacency):
    # Low-degree-first graph-only diagnostic, not a wireless-rate optimizer.
    blocked = set()
    selected = []
    for node in sorted(range(len(adjacency)), key=lambda item: len(adjacency[item])):
        if node in blocked:
            continue
        selected.append(node)
        blocked.add(node)
        blocked.update(adjacency[node])
    return len(selected)


def summarize_state(state):
    links = int(state.num_vertices)
    directed_edges = int(state.edge_index.size(1))
    possible_edges = max(links * (links - 1), 1)
    adjacency = undirected_adjacency(links, state.edge_index)
    graph_components = components(adjacency)
    largest = max(graph_components, key=len) if graph_components else []
    diameter = approximate_diameter(largest, adjacency)
    mis_size = greedy_maximal_independent_set_size(adjacency)
    return {
        "valid_directed_links": links,
        "directed_conflict_edges": directed_edges,
        "directed_edge_density": directed_edges / possible_edges,
        "mean_undirected_degree": float(np.mean([len(item) for item in adjacency])),
        "connected_components": len(graph_components),
        "largest_component_fraction": len(largest) / max(links, 1),
        "largest_component_approx_diameter": diameter,
        "graph_only_greedy_independent_set_size": mis_size,
        "three_round_gat_edge_updates": 3 * directed_edges,
        "single_anchor_consensus_edge_updates_lower_bound": diameter * directed_edges,
        "sequential_updates_if_join_count_equals_graph_mis": (
            max(mis_size, 1) * diameter * directed_edges
        ),
    }


def aggregate(records):
    keys = records[0].keys()
    return {
        key: float(np.mean([record[key] for record in records]))
        for key in keys
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="10,20,50")
    parser.add_argument("--small_samples", type=int, default=3)
    parser.add_argument("--large_samples", type=int, default=1)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    sizes = [int(value) for value in args.sizes.split(",")]
    cfg = load_config("configs/exp_example.yaml")
    cfg["TX_POWER"] = 10.0
    cfg["CSI_MODE"] = "perfect"
    report = {
        "scope": (
            "Training-free graph audit. MIS size and diameter are structural "
            "proxies, not scheduling performance."
        ),
        "tx_power_dbm": 10.0,
        "sizes": {},
    }
    for size in sizes:
        sample_count = args.small_samples if size <= 20 else args.large_samples
        records = []
        for sample in range(sample_count):
            seed = args.seed + 1009 * size + sample
            random.seed(seed)
            np.random.seed(seed)
            torch.manual_seed(seed)
            local = dict(cfg)
            local["NUM_UAV"] = size
            state = build_generator(local).generate_network(
                csi_mode=local["CSI_MODE"]
            )
            records.append(summarize_state(state))
        report["sizes"][str(size)] = {
            "num_uavs": size,
            "possible_directed_uav_links": size * (size - 1),
            "num_channel_samples": sample_count,
            "mean": aggregate(records),
            "samples": records,
        }
        print(json.dumps({str(size): report["sizes"][str(size)]["mean"]}, indent=2))
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"anchor_join_scalability_tx10_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(f"[Done] {path}")


if __name__ == "__main__":
    main()
