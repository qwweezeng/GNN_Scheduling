#!/usr/bin/env python3
"""Test whether the sequential policy uses channel context beyond exact delta."""

import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.sequential_set_policy import (
    SequentialSetPolicy, exact_addition_deltas, physical_set_utility,
)
from utils.mws import mws_objective


CHECKPOINT = "results/models/experimental/sequential_set_policy_numUAV=10_train=100_ep=10_s42.pth"


def rollout(model, state, queues, mode):
    context, snr, inr = model.channel_context(state, queues.device)
    if mode == "zero_context":
        context = torch.zeros_like(context)
    elif mode == "shuffle_context":
        context = context[torch.randperm(context.size(0))]
    selected = snr.new_zeros(snr.numel())
    scale = (queues * torch.log2(1.0 + snr)).max().clamp_min(1e-8)
    first_agreement = None
    correlations = []
    while True:
        delta = exact_addition_deltas(selected, queues, snr, inr)
        eligible = (queues > 0) & (selected <= 0) & (delta > 1e-9)
        candidates = eligible.nonzero(as_tuple=True)[0]
        if candidates.numel() == 0:
            break
        logits = model.choice_mlp(torch.cat([
            context[candidates], (delta[candidates] / scale).unsqueeze(1)
        ], dim=1)).reshape(-1)
        chosen_local = torch.argmax(logits)
        greedy_local = torch.argmax(delta[candidates])
        if first_agreement is None:
            first_agreement = int(chosen_local == greedy_local)
        if candidates.numel() > 1 and float(logits.std()) > 1e-10:
            correlations.append(float(np.corrcoef(
                logits.detach().numpy(), delta[candidates].detach().numpy()
            )[0, 1]))
        selected[candidates[chosen_local]] = 1.0
    return selected, physical_set_utility(selected, queues, snr, inr), (
        first_agreement or 0
    ), correlations


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    grouped = build_stratified_samples(states, (0, 20), 44)
    checkpoint = torch.load(CHECKPOINT, map_location="cpu")
    model = SequentialSetPolicy()
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    report = {}
    torch.manual_seed(20260712)
    with torch.no_grad():
        for mode in ("normal", "zero_context", "shuffle_context"):
            utility = teacher = active = agreements = samples = 0.0
            correlations = []
            for group in DENSITY_BOUNDS:
                for state, queues, target in grouped[group]:
                    action, value, agreement, local_corr = rollout(
                        model, state, queues, mode
                    )
                    utility += float(value)
                    teacher += mws_objective(
                        target.squeeze(1), queues, state
                    )
                    active += float(action.sum())
                    agreements += agreement
                    samples += 1
                    correlations.extend(local_corr)
            report[mode] = {
                "mws_ratio": utility / teacher,
                "average_active_links": active / samples,
                "first_choice_agreement_with_max_delta": agreements / samples,
                "logit_delta_correlation_mean": float(np.nanmean(correlations)),
            }
    report["question"] = (
        "Does learned channel context change decisions beyond the exact current marginal?"
    )
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"sequential_policy_context_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": report, "path": path}, indent=2))


if __name__ == "__main__":
    main()
