#!/usr/bin/env python3
"""Measure how much final exact-greedy utility depends on the first anchor."""

import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_oracle_physical_negotiation import precompute
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.anchor_one_join import AnchorOneJoinDecoder
from models.two_stage_physical import exact_state_greedy_from_anchor
from utils.mws import mws_objective


CHECKPOINT = (
    "results/models/experimental/anchor_join_oracle_numUAV=10_rounds=3_"
    "objective=teacher_calibration_init=0_sampling=mixed_hotspot_ep=15_s42.pth"
)


def main():
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TEST_SIZE": 32})
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    physical = precompute(
        states, "results/cache/oracle_marginals/numUAV=10_test_n=32.pth"
    )
    grouped = build_stratified_samples(states, (0, 20), 44)
    checkpoint = torch.load(CHECKPOINT, map_location="cpu")
    model = AnchorOneJoinDecoder(
        checkpoint["hidden_dim"], checkpoint["num_rounds"]
    )
    model.load_anchor_from_anchor_join(checkpoint["model_state_dict"])
    model.eval()
    generator = torch.Generator().manual_seed(20260712)
    report = {}
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            teacher_total = learned_total = sampled_mean_total = 0.0
            sampled_best_total = sampled_worst_total = 0.0
            relative_spreads = []
            for index, (state, queues, teacher) in enumerate(grouped[group]):
                solo, harm = physical[index]
                logits, _, _, nonempty = model.anchor_context(
                    solo, harm, queues, state.edge_index
                )
                active = (nonempty > 0).nonzero(as_tuple=True)[0]
                learned_anchor = torch.argmax(logits)
                _, learned_utility = exact_state_greedy_from_anchor(
                    learned_anchor, state, queues
                )
                permutation = active[torch.randperm(
                    active.numel(), generator=generator
                )]
                sampled = permutation[:min(8, active.numel())]
                if not (sampled == learned_anchor).any():
                    sampled = torch.cat([sampled, learned_anchor.reshape(1)])
                utilities = torch.stack([
                    exact_state_greedy_from_anchor(anchor, state, queues)[1]
                    for anchor in sampled
                ])
                teacher_total += mws_objective(
                    teacher.squeeze(1), queues, state
                )
                learned_total += float(learned_utility)
                sampled_mean_total += float(utilities.mean())
                sampled_best_total += float(utilities.max())
                sampled_worst_total += float(utilities.min())
                relative_spreads.append(float(
                    (utilities.max() - utilities.min())
                    / utilities.mean().clamp_min(1e-8)
                ))
            report[group] = {
                "learned_anchor_mws_ratio": learned_total / teacher_total,
                "sampled_anchor_mean_mws_ratio": sampled_mean_total / teacher_total,
                "best_of_up_to_9_anchors_mws_ratio": sampled_best_total / teacher_total,
                "worst_of_up_to_9_anchors_mws_ratio": sampled_worst_total / teacher_total,
                "within_state_relative_spread_mean": float(np.mean(relative_spreads)),
            }
    report["interpretation"] = (
        "Best/worst are over up to eight random nonempty anchors plus the learned anchor, not exhaustive optima."
    )
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"anchor_value_of_learning_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": report, "path": path}, indent=2))


if __name__ == "__main__":
    main()
