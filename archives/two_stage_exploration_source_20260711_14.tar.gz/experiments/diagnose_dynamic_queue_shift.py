#!/usr/bin/env python3
"""Probe queue-distribution shift on the exact channel used by dynamic MC seed 42."""

import json
import os
import random
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.evaluate_oracle_marginal import exact_channel_marginals
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import build_generator, load_config
from models.physical_channel_estimator import PhysicalChannelEstimator
from models.physical_negotiation_v3 import PhysicalNegotiationDecoderV3


def decision_summary(decoder, quantities, queues, edge_index):
    probability, _ = decoder(
        quantities[0], quantities[1], queues, edge_index
    )
    active = queues > 0
    active_probability = probability.squeeze(1)[active]
    return {
        "nonempty": int(active.sum()),
        "scheduled": int((probability > 0.5).sum()),
        "active_probability_mean": (
            float(active_probability.mean()) if active.any() else 0.0
        ),
        "active_probability_max": (
            float(active_probability.max()) if active.any() else 0.0
        ),
    }


def main():
    seed = 42
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": 10, "TX_POWER": 22.0})
    state = build_generator(cfg).generate_network(csi_mode=cfg.get("CSI_MODE", "perfect"))
    num_links = state.num_vertices
    num_hotspot = int(np.ceil(0.20 * num_links))
    hotspot = np.sort(np.random.default_rng(seed).choice(
        num_links, size=num_hotspot, replace=False
    ))

    channel_base, _ = load_channel_model(cfg, 10, torch.device("cpu"))
    estimator = PhysicalChannelEstimator(channel_base, channel_dim=48, hidden_dim=32)
    channel_checkpoint = torch.load(
        "results/models/experimental/physical_channel_estimator_numUAV=10_train=200_ep=15_s42.pth",
        map_location="cpu",
    )
    estimator.load_state_dict(channel_checkpoint["model_state_dict"])
    negotiation_checkpoint = torch.load(
        "results/models/experimental/physical_negotiation_oracle_v3_scale_invariant_"
        "numUAV=10_rounds=3_train=200_loss=counterfactual_policy_gradient_"
        "init=1_ep=10_s42.pth",
        map_location="cpu",
    )
    decoder = PhysicalNegotiationDecoderV3(
        negotiation_checkpoint["hidden_dim"], negotiation_checkpoint["num_rounds"]
    )
    decoder.load_state_dict(negotiation_checkpoint["model_state_dict"])
    decoder.eval()
    estimator.eval()
    with torch.no_grad():
        oracle = exact_channel_marginals(state)
        predicted = estimator(
            state.vertex_features[:, :1], state.edge_index, state.edge_weights,
            snr_gap=getattr(state, "snr_gap", 1.0),
        )

    generator = torch.Generator().manual_seed(123)
    patterns = {}
    hotspot_equal = torch.zeros(num_links)
    hotspot_equal[hotspot] = 1.0
    patterns["hotspot_only_equal_1"] = hotspot_equal
    hotspot_skew = torch.ones(num_links)
    hotspot_skew[hotspot] = 10.0
    patterns["hotspot_10_normal_1"] = hotspot_skew
    all_equal = torch.ones(num_links)
    patterns["all_equal_1"] = all_equal
    random_sparse = torch.zeros(num_links)
    selected = torch.randperm(num_links, generator=generator)[:num_hotspot]
    random_sparse[selected] = torch.randint(
        1, 20, (num_hotspot,), generator=generator
    ).float()
    patterns["random_sparse_uniform_1_19"] = random_sparse
    patterns["random_dense_uniform_1_19"] = torch.randint(
        1, 20, (num_links,), generator=generator
    ).float()

    single_oracle, single_predicted = [], []
    for link in range(num_links):
        queues = torch.zeros(num_links)
        queues[link] = 1.0
        single_oracle.append(decision_summary(
            decoder, oracle, queues, state.edge_index
        )["scheduled"])
        single_predicted.append(decision_summary(
            decoder, predicted, queues, state.edge_index
        )["scheduled"])

    report = {
        "channel": {
            "tx_power_dbm": 22.0,
            "num_links": num_links,
            "num_edges": state.edge_index.size(1),
            "hotspot_links": hotspot.tolist(),
        },
        "single_nonempty_schedule_fraction": {
            "oracle_channel": float(np.mean(single_oracle)),
            "predicted_channel": float(np.mean(single_predicted)),
        },
        "patterns": {
            name: {
                "oracle_channel": decision_summary(
                    decoder, oracle, queues, state.edge_index
                ),
                "predicted_channel": decision_summary(
                    decoder, predicted, queues, state.edge_index
                ),
            }
            for name, queues in patterns.items()
        },
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
