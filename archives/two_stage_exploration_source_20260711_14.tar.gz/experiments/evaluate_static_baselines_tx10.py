#!/usr/bin/env python3
"""Fair 10 dBm static baselines on the ParallelMPNN test protocol."""

import argparse
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.two_stage import QueueChannelLocalMaxScheduler
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", default="42,43,44")
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--random_samples", type=int, default=256)
    return parser.parse_args()


def evaluate_seed(states, channel_model, seed, random_samples):
    grouped = build_stratified_samples(states, (0, 20), seed + 2)
    local_max = QueueChannelLocalMaxScheduler(channel_model)
    generator = torch.Generator().manual_seed(seed + 9001)
    totals = {
        name: {"utility": 0.0, "teacher": 0.0, "active": 0.0, "count": 0}
        for name in ("random_p03", "random_teacher_k", "snr_one", "local_max")
    }
    for group in DENSITY_BOUNDS:
        for state, queues, teacher in grouped[group]:
            teacher_utility = mws_objective(teacher.reshape(-1), queues, state)
            nonempty = (queues > 0).nonzero(as_tuple=True)[0]
            k = int(teacher.sum())

            random_utility = random_active = 0.0
            random_k_utility = 0.0
            for _ in range(random_samples):
                action = torch.zeros(state.num_vertices)
                action[nonempty] = (
                    torch.rand(nonempty.numel(), generator=generator) < 0.3
                ).float()
                random_utility += mws_objective(action, queues, state)
                random_active += float(action.sum())

                action_k = torch.zeros(state.num_vertices)
                if k > 0:
                    selected = nonempty[
                        torch.randperm(nonempty.numel(), generator=generator)[:k]
                    ]
                    action_k[selected] = 1.0
                random_k_utility += mws_objective(action_k, queues, state)

            actions = {
                "random_p03": (
                    random_utility / random_samples,
                    random_active / random_samples,
                ),
                "random_teacher_k": (
                    random_k_utility / random_samples, float(k)
                ),
            }
            snr_action = torch.zeros(state.num_vertices)
            if nonempty.numel() > 0:
                snr = state.vertex_features[:, 0]
                snr_action[nonempty[snr[nonempty].argmax()]] = 1.0
            actions["snr_one"] = (
                mws_objective(snr_action, queues, state), float(snr_action.sum())
            )
            local_action = local_max.schedule_with_state(state, queues).reshape(-1)
            actions["local_max"] = (
                mws_objective(local_action, queues, state), float(local_action.sum())
            )
            for name, (utility, active) in actions.items():
                totals[name]["utility"] += utility
                totals[name]["teacher"] += teacher_utility
                totals[name]["active"] += active
                totals[name]["count"] += 1
    return {
        name: {
            "mws_ratio": values["utility"] / max(values["teacher"], 1e-12),
            "average_active_links": values["active"] / values["count"],
        }
        for name, values in totals.items()
    }


def main():
    args = parse_args()
    seeds = [int(value) for value in args.seeds.split(",")]
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TEST_SIZE": args.test_size,
    })
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )
    channel_model, channel_path = load_channel_model(cfg, 10, torch.device("cpu"))
    results = {
        str(seed): evaluate_seed(states, channel_model, seed, args.random_samples)
        for seed in seeds
    }
    summary = {}
    for name in next(iter(results.values())):
        ratios = [results[str(seed)][name]["mws_ratio"] for seed in seeds]
        actives = [results[str(seed)][name]["average_active_links"] for seed in seeds]
        summary[name] = {
            "mean_mws_ratio": float(np.mean(ratios)),
            "std_mws_ratio": float(np.std(ratios)),
            "mean_active_links": float(np.mean(actives)),
        }
    report = {
        "setting": "10 UAV / 10 dBm / perfect CSI",
        "test_protocol": "same states and seed-specific stratified queues as ParallelMPNN",
        "channel_checkpoint": channel_path,
        "random_samples_per_state": args.random_samples,
        "results": results,
        "summary": summary,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"static_baselines_tx10_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": path, "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
