#!/usr/bin/env python3
"""Dynamic queue comparison for ParallelMPNN at the canonical 10 dBm setting."""

import argparse
import json
import os
import sys
from datetime import datetime
from types import SimpleNamespace

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    CentralizedMWSGreedyScheduler,
    _load_two_stage_v2_model,
    build_generator,
    load_config,
    simulation_phase,
)
from experiments.train_parallel_mpnn import full_oracle_quantities
from models.parallel_mpnn import ParallelMPNN
from models.parallel_mpnn_v2 import ParallelMPNNv2
from models.parallel_mpnn_v3 import ParallelMPNNv3
from models.parallel_mpnn_v4 import ParallelMPNNv4
from models.set_negotiation import (
    SetNegotiation, SetNegotiationV2, SetNegotiationV3,
)
from models.two_stage import QueueChannelLocalMaxScheduler


class ParallelMPNNAdapter(nn.Module):
    """Expose a trained ParallelMPNN through QueueSimulator's local interface."""

    def __init__(self, checkpoint_path, deterministic_transitions=False):
        super().__init__()
        checkpoint = torch.load(
            checkpoint_path, map_location="cpu", weights_only=True
        )
        model_class = {
            "parallel_mpnn_v1": ParallelMPNN,
            "parallel_mpnn_v2": ParallelMPNNv2,
            "parallel_mpnn_v3": ParallelMPNNv3,
            "parallel_mpnn_v4": ParallelMPNNv4,
            "set_negotiation_v1": SetNegotiation,
            "set_negotiation_v2": SetNegotiationV2,
            "set_negotiation_v3": SetNegotiationV3,
        }.get(checkpoint.get("model_version"), ParallelMPNN)
        if issubclass(model_class, SetNegotiation):
            self.policy = model_class(
                hidden_dim=checkpoint["hidden_dim"],
                num_revisions=checkpoint["num_revisions"],
                channel_rounds=checkpoint["channel_rounds"],
            )
        else:
            self.policy = model_class(
                hidden_dim=checkpoint["hidden_dim"],
                num_rounds=checkpoint["num_rounds"],
                channel_rounds=checkpoint["channel_rounds"],
            )
        self.policy.load_state_dict(checkpoint["model_state_dict"])
        self.policy.eval()
        self.checkpoint_path = checkpoint_path
        self.deterministic_transitions = bool(deterministic_transitions)
        self._quantity_cache = {}

    def schedule_with_state(self, state, queues):
        key = id(state)
        if key not in self._quantity_cache:
            self._quantity_cache[key] = full_oracle_quantities(state)
        solo, harm, edge_index = self._quantity_cache[key]
        if isinstance(self.policy, SetNegotiation):
            density = torch.rand(())
            initial = (
                (torch.rand(queues.numel()) < density)
                & (queues.cpu() > 0)
            ).float()
            uniforms = None
            if self.deterministic_transitions:
                uniforms = [
                    torch.full((queues.numel(),), 0.5)
                    for _ in range(self.policy.num_revisions)
                ]
            action, _ = self.policy(
                solo, harm, queues.cpu(), edge_index,
                initial_action=initial,
                random_uniforms=uniforms,
            )
            return action.float()
        probability, _ = self.policy(solo, harm, queues.cpu(), edge_index)
        return (probability > self.policy.decision_threshold).float()


class QueueAwareRandomScheduler:
    """Random baseline that never wastes power on an empty queue."""

    def __init__(self, activation_probability=0.3, seed=12345):
        self.activation_probability = float(activation_probability)
        self.generator = torch.Generator().manual_seed(seed)

    def eval(self):
        return self

    def schedule_with_state(self, state, queues):
        del state
        action = (
            torch.rand(queues.numel(), generator=self.generator)
            < self.activation_probability
        ).float()
        return (action * (queues.cpu() > 0).float()).unsqueeze(1)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_slots", type=int, default=500)
    parser.add_argument("--arrival_rates", default="1,2,5,10")
    parser.add_argument("--mc_seeds", default="42,43,44")
    parser.add_argument("--slots_per_block", type=int, default=0)
    parser.add_argument("--model_seed", type=int, default=42)
    parser.add_argument(
        "--extra_checkpoint", default=None,
        help="Optional ParallelMPNN checkpoint included as Parallel-Extra.",
    )
    parser.add_argument(
        "--extra_deterministic_transitions", action="store_true",
        help=(
            "For a SetNegotiation extra checkpoint, replace Bernoulli "
            "transition draws by a fixed 0.5 decision threshold."
        ),
    )
    return parser.parse_args()


def jsonify(value):
    if isinstance(value, (np.floating, np.integer)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, dict):
        return {key: jsonify(item) for key, item in value.items()}
    if isinstance(value, list):
        return [jsonify(item) for item in value]
    return value


def main():
    args = parse_args()
    arrival_rates = [float(value) for value in args.arrival_rates.split(",")]
    mc_seeds = [int(value) for value in args.mc_seeds.split(",")]
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
    })
    channel_model, _ = load_channel_model(cfg, 10, torch.device("cpu"))
    structure_path = (
        "results/models/experimental/"
        "gat_queue_two_stage_v2_channel_skip_utility_resampled_"
        f"numUAV=10_tx=10dBm_csi=perfect_s{args.model_seed}.pth"
    )
    structure = _load_two_stage_v2_model(
        cfg, 10, channel_model, torch.device("cpu"), structure_path
    )
    local_path = (
        "results/models/experimental/parallel_mpnn_v1_tx=10dBm_"
        "numUAV=10_rounds=2_objective=local_best_response_"
        f"s{args.model_seed}.pth"
    )
    iterative_path = (
        "results/models/experimental/parallel_mpnn_v1_tx=10dBm_"
        "numUAV=10_rounds=2_objective=iterative_best_response_"
        f"s{args.model_seed}.pth"
    )
    models = {
        "Random-Q": (QueueAwareRandomScheduler(), "Queue-aware Random p=0.3"),
        "LocalMax": (
            QueueChannelLocalMaxScheduler(channel_model), "One-hop LocalMax"
        ),
        "Structure-v2.2": (structure, "Structure-v2.2"),
        "Parallel-LBR": (ParallelMPNNAdapter(local_path), "ParallelMPNN LBR"),
        "Parallel-IBR": (
            ParallelMPNNAdapter(iterative_path), "ParallelMPNN iterative BR"
        ),
        "MWS-Greedy": (CentralizedMWSGreedyScheduler(), "MWS-Greedy"),
    }
    if args.extra_checkpoint:
        models["Parallel-Extra"] = (
            ParallelMPNNAdapter(
                args.extra_checkpoint,
                deterministic_transitions=args.extra_deterministic_transitions,
            ),
            os.path.basename(args.extra_checkpoint),
        )
    sim_args = SimpleNamespace(
        num_slots=args.num_slots,
        arrival_rates=arrival_rates,
        mc_seeds=mc_seeds,
        slots_per_block=(args.slots_per_block or None),
    )
    results, details = simulation_phase(
        build_generator(cfg), models, cfg, sim_args
    )
    output_dir = os.path.join(
        "results",
        f"parallel_queue_tx10_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
    )
    os.makedirs(output_dir, exist_ok=True)
    report = {
        "config": vars(args),
        "physical_setting": "10 UAV / 10 dBm / perfect CSI",
        "model_checkpoints": {
            "structure": structure_path,
            "parallel_lbr": local_path,
            "parallel_iterative_br": iterative_path,
            "parallel_extra": args.extra_checkpoint,
        },
        "results": results,
    }
    with open(os.path.join(output_dir, "simulation_results.json"), "w") as file:
        json.dump(jsonify(report), file, indent=2)
    with open(os.path.join(output_dir, "simulation_runs.json"), "w") as file:
        json.dump(jsonify(details), file, indent=2)
    print(json.dumps({"output_dir": output_dir}, indent=2))


if __name__ == "__main__":
    main()
