#!/usr/bin/env python3
"""Dynamic queue audit for minimal LocalMax priority definitions."""

import argparse
import json
import os
import sys
from datetime import datetime
from types import SimpleNamespace

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_localmax_reuse_headroom import (
    QueueAwareRandomScheduler,
    jsonify,
)
from experiments.queue_model_diagnostics import load_channel_model
from experiments.run_queue_experiment import (
    CentralizedMWSGreedyScheduler,
    build_generator,
    load_config,
    simulation_phase,
)
from models.parallel_reuse import LocalPhysicalReuseScheduler
from models.two_stage import QueueChannelLocalMaxScheduler


PRIORITY_MODES = (
    "local_relative_channel",
    "raw_queue_channel",
    "raw_queue_gat_rate",
    "raw_queue_solo",
    "raw_queue",
)


def parse_int_list(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def parse_float_list(text):
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--arrival_rates", default="2,4")
    parser.add_argument("--mc_seeds", default="42,43,44")
    parser.add_argument("--channel_model_num_uav", type=int, default=10)
    parser.add_argument(
        "--modes", default=",".join(PRIORITY_MODES),
        help="Comma-separated subset of LocalMax priority modes.",
    )
    parser.add_argument("--include_mws", action="store_true")
    parser.add_argument(
        "--trace_cache", default="",
        help="Optional reusable fixed-channel graph/arrival cache.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
    })
    channel_model, channel_path = load_channel_model(
        cfg, args.channel_model_num_uav, torch.device("cpu")
    )
    selected_modes = tuple(
        item.strip() for item in args.modes.split(",") if item.strip()
    )
    unknown = sorted(set(selected_modes) - set(PRIORITY_MODES))
    if unknown:
        raise ValueError(f"Unknown priority modes: {unknown}")
    localmax = {
        mode: QueueChannelLocalMaxScheduler(
            channel_model, priority_mode=mode
        )
        for mode in selected_modes
    }
    models = {
        "Random-Q": (QueueAwareRandomScheduler(), "Queue-aware Random p=0.3")
    }
    for mode in selected_modes:
        models[f"Base-{mode}"] = (
            localmax[mode], f"LocalMax base: {mode}"
        )
        models[f"Reuse-{mode}"] = (
            LocalPhysicalReuseScheduler(localmax[mode]),
            f"LocalPhysicalReuse: {mode}",
        )
    if args.include_mws:
        models["MWS-Greedy"] = (
            CentralizedMWSGreedyScheduler(), "MWS-Greedy"
        )

    dynamic, details = simulation_phase(
        build_generator(cfg), models, cfg,
        SimpleNamespace(
            num_slots=args.num_slots,
            arrival_rates=parse_float_list(args.arrival_rates),
            mc_seeds=parse_int_list(args.mc_seeds),
            slots_per_block=None,
            trace_cache=args.trace_cache,
        ),
    )
    report = {
        "experiment": "localmax_priority_dynamic_audit",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "physical_setting": {
            "tx_power_dbm": 10.0,
            "csi_mode": "perfect",
            "channel_checkpoint": channel_path,
        },
        "dynamic": dynamic,
        "dynamic_details": details,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = (
        "results/diagnostics/localmax_priority_dynamic_"
        f"numUAV={args.num_uav}_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".json"
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(jsonify(report), file, indent=2)
    print(json.dumps({"report": path}, indent=2))


if __name__ == "__main__":
    main()
