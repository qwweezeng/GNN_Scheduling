#!/usr/bin/env python3
"""Train the unified sequential set policy from final utility only."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.queue_model_diagnostics import set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_anchor_join import resample_training_distribution
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.sequential_set_policy import (
    QueueAwareSequentialSetPolicy, SequentialSetPolicy,
    complete_physical_graph, exact_addition_deltas, physical_set_utility,
)
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=100)
    parser.add_argument("--val_size", type=int, default=32)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--policy_samples", type=int, default=4)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument(
        "--policy_version", choices=("local_mlp", "queue_gat"),
        default="local_mlp",
    )
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def immediate_greedy_action(state, queues):
    _, snr, inr, _ = complete_physical_graph(state, queues.device)
    selected = snr.new_zeros(snr.numel())
    while True:
        delta = exact_addition_deltas(selected, queues, snr, inr)
        eligible = (queues.reshape(-1) > 0) & (selected <= 0) & (delta > 1e-9)
        if not eligible.any():
            break
        masked = delta.masked_fill(~eligible, -torch.inf)
        selected[torch.argmax(masked)] = 1.0
    return selected.reshape(-1, 1)


def policy_gradient_loss(model, state, queues, num_samples):
    if isinstance(model, QueueAwareSequentialSetPolicy):
        log_probabilities, rewards = [], []
        for _ in range(num_samples):
            _, diagnostics = model.trajectory(state, queues, sample=True)
            log_probabilities.append(torch.stack(
                diagnostics["log_probabilities"]
            ).sum())
            rewards.append(
                diagnostics["utility"].detach()
                / queues.sum().clamp_min(1.0)
            )
        log_probabilities = torch.stack(log_probabilities)
        rewards = torch.stack(rewards)
        baseline = (
            (rewards.sum() - rewards) / (num_samples - 1)
            if num_samples > 1 else torch.zeros_like(rewards)
        )
        return -torch.mean(
            (rewards - baseline) * log_probabilities
        ), rewards.mean()
    context, snr, inr = model.channel_context(state, queues.device)
    log_probabilities, rewards = [], []
    for _ in range(num_samples):
        _, diagnostics = model.trajectory_from_context(
            context, snr, inr, queues, sample=True
        )
        log_probabilities.append(torch.stack(
            diagnostics["log_probabilities"]
        ).sum())
        rewards.append(
            diagnostics["utility"].detach()
            / queues.sum().clamp_min(1.0)
        )
    log_probabilities = torch.stack(log_probabilities)
    rewards = torch.stack(rewards)
    if num_samples > 1:
        baseline = (rewards.sum() - rewards) / (num_samples - 1)
    else:
        baseline = torch.zeros_like(rewards)
    loss = -torch.mean((rewards - baseline) * log_probabilities)
    return loss, rewards.mean()


def evaluate(model, grouped):
    result = {}
    model.eval()
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            values = {
                "policy": 0.0, "greedy": 0.0, "teacher": 0.0,
                "policy_active": 0.0, "greedy_active": 0.0, "samples": 0,
            }
            for state, queues, teacher in grouped[group]:
                policy_action = model.schedule_with_state(state, queues)
                greedy_action = immediate_greedy_action(state, queues)
                values["policy"] += mws_objective(
                    policy_action.squeeze(1), queues, state
                )
                values["greedy"] += mws_objective(
                    greedy_action.squeeze(1), queues, state
                )
                values["teacher"] += mws_objective(
                    teacher.squeeze(1), queues, state
                )
                values["policy_active"] += float(policy_action.sum())
                values["greedy_active"] += float(greedy_action.sum())
                values["samples"] += 1
            result[group] = {
                "policy_mws_ratio": values["policy"] / values["teacher"],
                "immediate_greedy_mws_ratio": values["greedy"] / values["teacher"],
                "policy_to_immediate_greedy": values["policy"] / values["greedy"],
                "policy_average_active": values["policy_active"] / values["samples"],
                "greedy_average_active": values["greedy_active"] / values["samples"],
                "_raw": values,
            }
    combined = {
        key: sum(result[group]["_raw"][key] for group in DENSITY_BOUNDS)
        for key in result["sparse"]["_raw"]
    }
    result["combined"] = {
        "policy_mws_ratio": combined["policy"] / combined["teacher"],
        "immediate_greedy_mws_ratio": combined["greedy"] / combined["teacher"],
        "policy_to_immediate_greedy": combined["policy"] / combined["greedy"],
        "policy_average_active": combined["policy_active"] / combined["samples"],
        "greedy_average_active": combined["greedy_active"] / combined["samples"],
    }
    for group in DENSITY_BOUNDS:
        del result[group]["_raw"]
    return result


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav, "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size, "TEST_SIZE": args.test_size,
    })
    queue_range = tuple(int(value) for value in args.queue_range.split(","))
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, args.num_uav, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    val_grouped = build_stratified_samples(states["val"], queue_range, args.seed + 1)
    test_grouped = build_stratified_samples(states["test"], queue_range, args.seed + 2)
    model = (
        QueueAwareSequentialSetPolicy()
        if args.policy_version == "queue_gat" else SequentialSetPolicy()
    ).cpu()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    initial = evaluate(model, val_grouped)
    best_value = initial["combined"]["policy_mws_ratio"]
    best_epoch = -1
    best_state = copy.deepcopy(model.state_dict())
    logs = [{"epoch": -1, "validation": initial}]
    print(json.dumps({"initial_validation": initial["combined"]}, indent=2))
    for epoch in range(args.epochs):
        model.train()
        samples = resample_training_distribution(
            states["train"], queue_range, args.seed + 104729 * epoch,
            "mixed_hotspot",
        )
        order = list(range(len(samples)))
        random.shuffle(order)
        losses, rewards = [], []
        for index in order:
            state, queues = samples[index]
            loss, reward = policy_gradient_loss(
                model, state, queues, args.policy_samples
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
            rewards.append(float(reward))
        validation = evaluate(model, val_grouped)
        value = validation["combined"]["policy_mws_ratio"]
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "sampled_normalized_reward": float(np.mean(rewards)),
            "validation": validation,
        })
        if value > best_value:
            best_value = value
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.5f} "
            f"reward={np.mean(rewards):.4f} val_policy={value:.4f} "
            f"val_vs_greedy={validation['combined']['policy_to_immediate_greedy']:.4f}"
        )
    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped)
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"sequential_set_policy_{args.policy_version}_numUAV={args.num_uav}_train={args.train_size}_"
        f"ep={args.epochs}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": f"sequential_set_policy_{args.policy_version}_experimental",
        "model_state_dict": model.state_dict(), "best_epoch": best_epoch,
        "objective": "teacher_free_final_set_utility",
        "physical_input": "complete_directed_absolute_snr_inr",
    }, checkpoint_path)
    os.makedirs("results/diagnostics", exist_ok=True)
    report_path = os.path.join(
        "results/diagnostics",
        f"sequential_set_policy_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args), "checkpoint": checkpoint_path,
            "best_epoch": best_epoch, "initial_validation": initial,
            "test": test, "epochs": logs,
        }, file, indent=2)
    print(json.dumps({
        "checkpoint": checkpoint_path, "report": report_path,
        "best_epoch": best_epoch, "test": test,
    }, indent=2))


if __name__ == "__main__":
    main()
