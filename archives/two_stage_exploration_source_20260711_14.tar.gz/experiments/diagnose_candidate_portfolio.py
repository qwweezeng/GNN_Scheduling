#!/usr/bin/env python3
"""Diagnose whether a small channel-specific schedule portfolio is sufficient.

This is a centralized, evaluation-only oracle.  For each fixed channel graph it
builds a pool of complete schedules from MWS-Greedy solutions under many queue
states, then selects a small portfolio that maximizes the best schedule utility
over a separate queue set.  It does not define a deployable scheduler and does
not train a neural network.
"""

import argparse
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (  # noqa: E402
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.two_stage_v1_diagnostics import (  # noqa: E402
    DENSITY_BOUNDS,
    sample_queues_for_density,
)
from models.model import calculate_achievable_rate  # noqa: E402
from utils.mws import centralized_mws_greedy  # noqa: E402


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def balanced_queue_samples(num_links, count, queue_range, seed):
    """Sample sparse/medium/dense queue states in equal proportions."""
    generator = torch.Generator().manual_seed(seed)
    groups = tuple(DENSITY_BOUNDS)
    return [
        sample_queues_for_density(
            num_links, groups[index % len(groups)], queue_range, generator
        )
        for index in range(count)
    ]


def schedule_key(schedule):
    return tuple((schedule.reshape(-1) > 0.5).to(torch.int8).tolist())


def build_candidate_pool(state, queues_list):
    """Collect unique greedy schedules and guaranteed singleton coverage."""
    candidates = {}
    for queues in queues_list:
        schedule = centralized_mws_greedy(state, queues).reshape(-1).cpu()
        candidates[schedule_key(schedule)] = schedule

    # A singleton urgency probe guarantees that every link has at least one
    # possible representative in the pool.  This is only an oracle diagnostic;
    # the learned generator must later earn coverage from its set-level goal.
    for link in range(state.num_vertices):
        queues = torch.zeros(state.num_vertices)
        queues[link] = 1.0
        schedule = centralized_mws_greedy(state, queues).reshape(-1).cpu()
        candidates[schedule_key(schedule)] = schedule
    return torch.stack(list(candidates.values()))


def candidate_rates(state, candidates):
    rates = []
    for schedule in candidates:
        rates.append(calculate_achievable_rate(
            schedule.reshape(-1, 1), state, binary=True
        ).reshape(-1).detach().cpu())
    return torch.stack(rates)


def greedy_utility_portfolio(utility, budget):
    """Greedily maximize mean best-of-selected utility."""
    selected = []
    current = torch.zeros(utility.size(0))
    available = torch.ones(utility.size(1), dtype=torch.bool)
    for _ in range(min(budget, utility.size(1))):
        gains = torch.maximum(
            current.unsqueeze(1), utility
        ).sum(dim=0) - current.sum()
        gains[~available] = -torch.inf
        choice = int(torch.argmax(gains))
        selected.append(choice)
        current = torch.maximum(current, utility[:, choice])
        available[choice] = False
    return selected, current


def greedy_set_cover(candidates, utility):
    """Construct a small coverage core, breaking ties by queue utility."""
    binary = candidates > 0.5
    uncovered = torch.ones(binary.size(1), dtype=torch.bool)
    available = torch.ones(binary.size(0), dtype=torch.bool)
    selected = []
    mean_utility = utility.mean(dim=0)
    while bool(uncovered.any()):
        new_coverage = (binary & uncovered.unsqueeze(0)).sum(dim=1)
        new_coverage[~available] = -1
        best_count = int(new_coverage.max())
        if best_count <= 0:
            raise RuntimeError("candidate pool cannot cover every link")
        tied = (new_coverage == best_count).nonzero(as_tuple=True)[0]
        choice = int(tied[torch.argmax(mean_utility[tied])])
        selected.append(choice)
        uncovered &= ~binary[choice]
        available[choice] = False
    return selected


def extend_portfolio(initial, utility, budget):
    selected = list(initial[:budget])
    current = (
        utility[:, selected].max(dim=1).values
        if selected else torch.zeros(utility.size(0))
    )
    available = torch.ones(utility.size(1), dtype=torch.bool)
    if selected:
        available[selected] = False
    while len(selected) < min(budget, utility.size(1)):
        gains = torch.maximum(
            current.unsqueeze(1), utility
        ).sum(dim=0) - current.sum()
        gains[~available] = -torch.inf
        choice = int(torch.argmax(gains))
        selected.append(choice)
        current = torch.maximum(current, utility[:, choice])
        available[choice] = False
    return selected, current


def coverage_ratio(candidates, selected):
    if not selected:
        return 0.0
    covered = (candidates[selected] > 0.5).any(dim=0)
    return float(covered.float().mean())


def diagnose_state(state, train_count, eval_count, queue_range, budgets, seed):
    train_queues = balanced_queue_samples(
        state.num_vertices, train_count, queue_range, seed
    )
    eval_queues = balanced_queue_samples(
        state.num_vertices, eval_count, queue_range, seed + 1000003
    )
    candidates = build_candidate_pool(state, train_queues)
    rates = candidate_rates(state, candidates)
    train_matrix = torch.stack(train_queues) @ rates.T
    eval_queue_tensor = torch.stack(eval_queues)
    eval_matrix = eval_queue_tensor @ rates.T

    reference_rates = []
    for queues in eval_queues:
        schedule = centralized_mws_greedy(state, queues).reshape(-1).cpu()
        reference_rates.append(calculate_achievable_rate(
            schedule.reshape(-1, 1), state, binary=True
        ).reshape(-1).detach().cpu())
    reference = (
        eval_queue_tensor * torch.stack(reference_rates)
    ).sum(dim=1)
    reference_total = float(reference.sum())

    coverage_core = greedy_set_cover(candidates, train_matrix)
    result = {
        "num_links": int(state.num_vertices),
        "pool_size": int(candidates.size(0)),
        "coverage_core_size": len(coverage_core),
        "utility_first": {},
        "coverage_first": {},
    }
    for budget in budgets:
        utility_selected, _ = greedy_utility_portfolio(train_matrix, budget)
        utility_eval = (
            eval_matrix[:, utility_selected].max(dim=1).values
            if utility_selected else torch.zeros(eval_matrix.size(0))
        )
        result["utility_first"][str(budget)] = {
            "mws_greedy_ratio": float(utility_eval.sum())
            / max(reference_total, 1e-12),
            "link_coverage": coverage_ratio(candidates, utility_selected),
            "selected_count": len(utility_selected),
        }

        if budget >= len(coverage_core):
            covered_selected, _ = extend_portfolio(
                coverage_core, train_matrix, budget
            )
            covered_eval = eval_matrix[:, covered_selected].max(dim=1).values
            result["coverage_first"][str(budget)] = {
                "mws_greedy_ratio": float(covered_eval.sum())
                / max(reference_total, 1e-12),
                "link_coverage": coverage_ratio(candidates, covered_selected),
                "selected_count": len(covered_selected),
            }
        else:
            result["coverage_first"][str(budget)] = {
                "mws_greedy_ratio": None,
                "link_coverage": None,
                "selected_count": budget,
                "reason": (
                    "budget smaller than the greedy full-coverage core"
                ),
            }
    return result


def aggregate(per_state, budgets):
    report = {
        "num_states": len(per_state),
        "mean_num_links": float(np.mean([x["num_links"] for x in per_state])),
        "mean_pool_size": float(np.mean([x["pool_size"] for x in per_state])),
        "mean_coverage_core_size": float(np.mean([
            x["coverage_core_size"] for x in per_state
        ])),
        "max_coverage_core_size": int(max(
            x["coverage_core_size"] for x in per_state
        )),
        "utility_first": {},
        "coverage_first": {},
    }
    for method in ("utility_first", "coverage_first"):
        for budget in budgets:
            entries = [x[method][str(budget)] for x in per_state]
            valid = [x for x in entries if x["mws_greedy_ratio"] is not None]
            report[method][str(budget)] = {
                "valid_states": len(valid),
                "mean_mws_greedy_ratio": (
                    float(np.mean([x["mws_greedy_ratio"] for x in valid]))
                    if valid else None
                ),
                "mean_link_coverage": (
                    float(np.mean([x["link_coverage"] for x in valid]))
                    if valid else None
                ),
            }
    return report


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--num_states", type=int, default=10)
    parser.add_argument("--train_queues", type=int, default=96)
    parser.add_argument("--eval_queues", type=int, default=96)
    parser.add_argument("--budgets", default="1,2,4,8,16,32")
    parser.add_argument("--seed", type=int, default=20260713)
    parser.add_argument("--output", default=None)
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    budgets = tuple(sorted({
        int(value) for value in args.budgets.split(",") if value.strip()
    }))
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "TEST_SIZE": args.num_states,
    })
    states = _load_or_generate_dataset(
        build_generator(cfg), cfg, 10, False, "test", (0, 20)
    )[:args.num_states]
    per_state = []
    for index, state in enumerate(states):
        print(f"[portfolio] state {index + 1}/{len(states)}")
        per_state.append(diagnose_state(
            state,
            args.train_queues,
            args.eval_queues,
            (0, 20),
            budgets,
            args.seed + 7919 * index,
        ))
    report = {
        "scope": (
            "Centralized oracle diagnostic only; candidates are channel-"
            "specific complete schedules drawn from MWS-Greedy solutions."
        ),
        "settings": {
            "num_uav": 10,
            "tx_power_dbm": 10.0,
            "num_states": len(states),
            "train_queues_per_state": args.train_queues,
            "eval_queues_per_state": args.eval_queues,
            "budgets": budgets,
            "seed": args.seed,
        },
        "aggregate": aggregate(per_state, budgets),
        "per_state": per_state,
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    output = args.output or (
        "results/diagnostics/candidate_portfolio_tx10_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    with open(output, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": output, "aggregate": report["aggregate"]}, indent=2))


if __name__ == "__main__":
    main()
