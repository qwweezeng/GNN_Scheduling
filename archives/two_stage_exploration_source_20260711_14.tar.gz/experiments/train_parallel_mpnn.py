#!/usr/bin/env python3
"""Train/evaluate ParallelMPNN-v1 at the canonical 10 dBm setting."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.parallel_mpnn_scenarios import (
    asymmetric_three_link, strong_two_link, two_weakly_coupled_regions,
    weak_two_link,
)
from experiments.queue_model_diagnostics import set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_anchor_join import resample_training_distribution
from experiments.two_stage_v1_diagnostics import DENSITY_BOUNDS, build_stratified_samples
from models.model import calculate_achievable_rate
from models.parallel_mpnn import ParallelMPNN
from models.parallel_mpnn_v2 import ParallelMPNNv2
from models.parallel_mpnn_v3 import ParallelMPNNv3
from models.parallel_mpnn_v4 import ParallelMPNNv4
from models.sequential_set_policy import complete_physical_graph
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument(
        "--model_version", choices=("v1", "v2", "v3", "v4"), default="v1"
    )
    parser.add_argument("--tx_power", type=float, default=10.0)
    parser.add_argument("--train_size", type=int, default=80)
    parser.add_argument("--val_size", type=int, default=20)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--rounds", default="1,2,3,4")
    parser.add_argument(
        "--objective", choices=(
            "direct_utility", "sampled_hard_utility",
            "counterfactual_hard_utility", "local_hard_advantage",
            "local_best_response", "iterative_best_response",
            "teacher_calibration",
        ),
        default="direct_utility",
    )
    parser.add_argument("--policy_samples", type=int, default=16)
    parser.add_argument("--inner_epochs", type=int, default=1)
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument(
        "--queue_sampling",
        choices=("mixed_hotspot", "mixed_dynamic"),
        default="mixed_hotspot",
    )
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def full_oracle_quantities(state):
    edge_index, effective_snr, inr, _ = complete_physical_graph(state)
    solo = torch.log2(1.0 + effective_snr)
    if edge_index.numel() == 0:
        harm = torch.empty(0)
    else:
        source, target = edge_index
        pair = torch.log2(
            1.0 + effective_snr[target] / (1.0 + inr[target, source])
        )
        harm = (
            (solo[target] - pair) / solo[target].clamp_min(1e-8)
        ).clamp(0.0, 1.0)
    return solo, harm, edge_index


def model_action(model, state, queues, quantities, ablate_intent=False,
                 ablate_dynamic_neighbor_state=False):
    solo, harm, edge_index = quantities
    probability, diagnostics = model(
        solo, harm, queues, edge_index,
        return_history=True,
        ablate_intent_messages=ablate_intent,
        ablate_dynamic_neighbor_state=ablate_dynamic_neighbor_state,
    )
    hard = (probability > model.decision_threshold).float()
    return probability, hard, diagnostics


def synthetic_quantities(values):
    queues, snr, inr = values
    num_nodes = queues.numel()
    source = torch.arange(num_nodes).repeat(num_nodes)
    target = torch.arange(num_nodes).repeat_interleave(num_nodes)
    keep = source != target
    source, target = source[keep], target[keep]
    edge_index = torch.stack([source, target])
    solo = torch.log2(1.0 + snr)
    pair = torch.log2(1.0 + snr[target] / (1.0 + inr[target, source]))
    harm = ((solo[target] - pair) / solo[target]).clamp(0.0, 1.0)
    return queues, (solo, harm, edge_index)


def scenario_metrics(model):
    expected = {
        "strong_q_10_1": [1, 0],
        "strong_q_1_10": [0, 1],
        "weak_equal": [1, 1],
        "asymmetric_three": [1, 0, 1],
        "two_regions": [1, 0, 0, 1],
    }
    values = {
        "strong_q_10_1": strong_two_link(torch.tensor([10.0, 1.0])),
        "strong_q_1_10": strong_two_link(torch.tensor([1.0, 10.0])),
        "weak_equal": weak_two_link(),
        "asymmetric_three": asymmetric_three_link(),
        "two_regions": two_weakly_coupled_regions(),
    }
    result = {}
    with torch.no_grad():
        for name, scenario in values.items():
            queues, quantities = synthetic_quantities(scenario)
            probability, _ = model(
                *quantities[:2], queues, quantities[2], return_history=True
            )
            action = (probability > 0.5).int().reshape(-1).tolist()
            result[name] = {
                "action": action,
                "expected": expected[name],
                "passed": action == expected[name],
                "probabilities": probability.reshape(-1).tolist(),
            }
    result["pass_rate"] = float(np.mean([
        item["passed"] for item in result.values()
    ]))
    return result


def evaluate(model, grouped, quantities_by_state):
    totals = {}
    model.eval()
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            accum = {
                "utility": 0.0, "teacher": 0.0,
                "ablated_utility": 0.0, "dynamic_ablated_utility": 0.0,
                "permuted_utility": 0.0,
                "active": 0.0, "all_zero": 0, "all_nonempty": 0,
                "intent_flips": 0, "intent_total": 0,
                "queue_flips": 0, "queue_nonempty": 0,
                "neighbor_queue_flips": 0, "neighbor_queue_trials": 0,
            }
            samples = grouped[group]
            for state, queues, teacher in samples:
                quantities = quantities_by_state[id(state)]
                probability, hard, diagnostics = model_action(
                    model, state, queues, quantities
                )
                _, ablated, _ = model_action(
                    model, state, queues, quantities, ablate_intent=True
                )
                _, dynamic_ablated, _ = model_action(
                    model, state, queues, quantities,
                    ablate_dynamic_neighbor_state=True,
                )
                utility = mws_objective(hard.reshape(-1), queues, state)
                accum["utility"] += utility
                accum["teacher"] += mws_objective(
                    teacher.reshape(-1), queues, state
                )
                accum["ablated_utility"] += mws_objective(
                    ablated.reshape(-1), queues, state
                )
                accum["dynamic_ablated_utility"] += mws_objective(
                    dynamic_ablated.reshape(-1), queues, state
                )
                accum["active"] += float(hard.sum())
                nonempty_count = int((queues > 0).sum())
                accum["all_zero"] += int(hard.sum() == 0 and nonempty_count > 0)
                accum["all_nonempty"] += int(
                    nonempty_count > 0 and int(hard.sum()) == nonempty_count
                )
                history = diagnostics["intent_history"]
                if len(history) > 1:
                    initial_hard = history[0] > 0.5
                    final_hard = history[-1] > 0.5
                    accum["intent_flips"] += int((initial_hard != final_hard).sum())
                    accum["intent_total"] += nonempty_count

                positive = (queues > 0).nonzero(as_tuple=True)[0]
                permuted_queues = queues.clone()
                permuted_queues[positive] = queues[positive.flip(0)]
                _, permuted_hard, _ = model_action(
                    model, state, permuted_queues, quantities
                )
                accum["permuted_utility"] += mws_objective(
                    permuted_hard.reshape(-1), queues, state
                )
                mask = queues > 0
                accum["queue_flips"] += int(
                    (hard.reshape(-1)[mask] != permuted_hard.reshape(-1)[mask]).sum()
                )
                accum["queue_nonempty"] += int(mask.sum())

                # Hold focal link i's own queue fixed and cyclically move only
                # the other nonempty queues.  A focal decision change is direct
                # evidence that neighbor urgency conditions its decision.
                indices = (queues > 0).nonzero(as_tuple=True)[0]
                if indices.numel() > 2:
                    shifted = queues.clone()
                    shifted[indices] = queues[indices.roll(1)]
                    for focal in indices.tolist():
                        counterfactual = shifted.clone()
                        counterfactual[focal] = queues[focal]
                        _, cf_hard, _ = model_action(
                            model, state, counterfactual, quantities
                        )
                        accum["neighbor_queue_flips"] += int(
                            hard.reshape(-1)[focal]
                            != cf_hard.reshape(-1)[focal]
                        )
                        accum["neighbor_queue_trials"] += 1
            count = max(len(samples), 1)
            totals[group] = {
                "mws_ratio": accum["utility"] / max(accum["teacher"], 1e-8),
                "intent_ablation_utility_ratio": (
                    accum["ablated_utility"] / max(accum["utility"], 1e-8)
                ),
                "dynamic_neighbor_ablation_utility_ratio": (
                    accum["dynamic_ablated_utility"]
                    / max(accum["utility"], 1e-8)
                ),
                "permuted_queue_utility_ratio": (
                    accum["permuted_utility"] / max(accum["utility"], 1e-8)
                ),
                "average_active": accum["active"] / count,
                "all_zero_rate": accum["all_zero"] / count,
                "all_nonempty_rate": accum["all_nonempty"] / count,
                "round_hard_flip_rate": (
                    accum["intent_flips"] / max(accum["intent_total"], 1)
                ),
                "queue_hard_flip_rate": (
                    accum["queue_flips"] / max(accum["queue_nonempty"], 1)
                ),
                "neighbor_queue_hard_flip_rate": (
                    accum["neighbor_queue_flips"]
                    / max(accum["neighbor_queue_trials"], 1)
                ),
                "_raw": accum,
                "_count": len(samples),
            }
    raw_keys = next(iter(totals.values()))["_raw"].keys()
    combined_raw = {
        key: sum(totals[group]["_raw"][key] for group in DENSITY_BOUNDS)
        for key in raw_keys
    }
    count = sum(totals[group]["_count"] for group in DENSITY_BOUNDS)
    totals["combined"] = {
        "mws_ratio": combined_raw["utility"] / max(combined_raw["teacher"], 1e-8),
        "intent_ablation_utility_ratio": (
            combined_raw["ablated_utility"] / max(combined_raw["utility"], 1e-8)
        ),
        "dynamic_neighbor_ablation_utility_ratio": (
            combined_raw["dynamic_ablated_utility"]
            / max(combined_raw["utility"], 1e-8)
        ),
        "permuted_queue_utility_ratio": (
            combined_raw["permuted_utility"] / max(combined_raw["utility"], 1e-8)
        ),
        "average_active": combined_raw["active"] / max(count, 1),
        "all_zero_rate": combined_raw["all_zero"] / max(count, 1),
        "all_nonempty_rate": combined_raw["all_nonempty"] / max(count, 1),
        "round_hard_flip_rate": (
            combined_raw["intent_flips"] / max(combined_raw["intent_total"], 1)
        ),
        "queue_hard_flip_rate": (
            combined_raw["queue_flips"] / max(combined_raw["queue_nonempty"], 1)
        ),
        "neighbor_queue_hard_flip_rate": (
            combined_raw["neighbor_queue_flips"]
            / max(combined_raw["neighbor_queue_trials"], 1)
        ),
    }
    for group in DENSITY_BOUNDS:
        del totals[group]["_raw"]
        del totals[group]["_count"]
    totals["scenarios"] = scenario_metrics(model)
    return totals


def training_loss(model, state, queues, quantities, objective, teacher=None,
                  policy_samples=16):
    solo, harm, edge_index = quantities
    probability, _ = model(solo, harm, queues, edge_index)
    if objective == "direct_utility":
        rates = calculate_achievable_rate(
            probability, state, binary=False
        )
        return -torch.sum(queues * rates) / queues.sum().clamp_min(1.0)
    if objective == "sampled_hard_utility":
        # Score-function gradient for the actual discrete scheduling action.
        # The mean sampled utility is only a baseline: it changes variance, not
        # which schedules are preferred, and introduces no handcrafted reward.
        prediction = probability.reshape(-1).clamp(1e-6, 1 - 1e-6)
        eligible = queues > 0
        if not eligible.any():
            return prediction.sum() * 0.0
        actions = torch.bernoulli(
            prediction.detach().expand(policy_samples, -1)
        )
        actions[:, ~eligible] = 0.0
        utilities = []
        for action in actions:
            rates = calculate_achievable_rate(
                action.unsqueeze(1), state, binary=True
            )
            utilities.append(
                torch.sum(queues * rates) / queues.sum().clamp_min(1.0)
            )
        utilities = torch.stack(utilities).detach()
        advantage = utilities - utilities.mean()
        log_probability = (
            actions * torch.log(prediction).unsqueeze(0)
            + (1.0 - actions) * torch.log1p(-prediction).unsqueeze(0)
        )[:, eligible].mean(dim=1)
        return -(advantage * log_probability).mean()
    if objective == "counterfactual_hard_utility":
        # For each link, compare two real 0/1 schedules that differ only in
        # that link.  This is the per-bit derivative of expected hard utility,
        # estimated over sampled states of all other links.  No external
        # scheduler supplies an action label.
        prediction = probability.reshape(-1).clamp(1e-6, 1 - 1e-6)
        eligible = queues > 0
        if not eligible.any():
            return prediction.sum() * 0.0
        deltas = torch.zeros_like(prediction)
        for _ in range(policy_samples):
            base_action = torch.bernoulli(prediction.detach())
            base_action[~eligible] = 0.0
            for focal in eligible.nonzero(as_tuple=True)[0].tolist():
                action_off = base_action.clone()
                action_on = base_action.clone()
                action_off[focal] = 0.0
                action_on[focal] = 1.0
                rate_off = calculate_achievable_rate(
                    action_off.unsqueeze(1), state, binary=True
                )
                rate_on = calculate_achievable_rate(
                    action_on.unsqueeze(1), state, binary=True
                )
                utility_off = (
                    torch.sum(queues * rate_off)
                    / queues.sum().clamp_min(1.0)
                )
                utility_on = (
                    torch.sum(queues * rate_on)
                    / queues.sum().clamp_min(1.0)
                )
                deltas[focal] += utility_on - utility_off
        deltas = (deltas / policy_samples).detach()
        return -(deltas[eligible] * prediction[eligible]).mean()
    if objective == "local_hard_advantage":
        # Condition on the schedule that will actually be deployed at the
        # current threshold.  Each link receives its exact unilateral utility
        # advantage, with all other hard decisions held fixed.
        prediction = probability.reshape(-1).clamp(1e-6, 1 - 1e-6)
        eligible = queues > 0
        if not eligible.any():
            return prediction.sum() * 0.0
        base_action = (prediction.detach() > model.decision_threshold).float()
        base_action[~eligible] = 0.0
        deltas = torch.zeros_like(prediction)
        for focal in eligible.nonzero(as_tuple=True)[0].tolist():
            action_off = base_action.clone()
            action_on = base_action.clone()
            action_off[focal] = 0.0
            action_on[focal] = 1.0
            rate_off = calculate_achievable_rate(
                action_off.unsqueeze(1), state, binary=True
            )
            rate_on = calculate_achievable_rate(
                action_on.unsqueeze(1), state, binary=True
            )
            deltas[focal] = (
                torch.sum(queues * (rate_on - rate_off))
                / queues.sum().clamp_min(1.0)
            )
        return -(deltas.detach()[eligible] * prediction[eligible]).mean()
    if objective == "local_best_response":
        # The target is generated by wireless utility itself: 1 iff this link
        # improves the current hard schedule when all other actions are fixed.
        # Unlike teacher_calibration, no centralized schedule is supplied.
        prediction = probability.reshape(-1).clamp(1e-6, 1 - 1e-6)
        eligible = queues > 0
        if not eligible.any():
            return prediction.sum() * 0.0
        base_action = (prediction.detach() > model.decision_threshold).float()
        base_action[~eligible] = 0.0
        target = torch.zeros_like(prediction)
        for focal in eligible.nonzero(as_tuple=True)[0].tolist():
            action_off = base_action.clone()
            action_on = base_action.clone()
            action_off[focal] = 0.0
            action_on[focal] = 1.0
            rate_off = calculate_achievable_rate(
                action_off.unsqueeze(1), state, binary=True
            )
            rate_on = calculate_achievable_rate(
                action_on.unsqueeze(1), state, binary=True
            )
            delta = torch.sum(queues * (rate_on - rate_off))
            target[focal] = float(delta >= 0.0)
        return F.binary_cross_entropy(
            prediction[eligible], target.detach()[eligible]
        )
    if objective == "iterative_best_response":
        if teacher is None:
            raise ValueError("iterative_best_response requires frozen targets")
        prediction = probability.reshape(-1).clamp(1e-6, 1 - 1e-6)
        eligible = queues > 0
        if not eligible.any():
            return prediction.sum() * 0.0
        return F.binary_cross_entropy(
            prediction[eligible], teacher.reshape(-1).to(prediction)[eligible]
        )
    if teacher is None:
        raise ValueError("teacher_calibration requires a teacher action")
    eligible = queues > 0
    prediction = probability.reshape(-1).clamp(1e-6, 1 - 1e-6)
    target = teacher.reshape(-1).to(prediction)
    positive = eligible & (target > 0.5)
    negative = eligible & (target <= 0.5)
    terms = []
    if positive.any():
        terms.append(F.binary_cross_entropy(
            prediction[positive], target[positive]
        ))
    if negative.any():
        terms.append(F.binary_cross_entropy(
            prediction[negative], target[negative]
        ))
    return torch.stack(terms).mean()


def frozen_local_best_response_target(model, state, queues, quantities):
    """Generate one physical best-response target with model parameters frozen."""
    with torch.no_grad():
        probability, _, _ = model_action(model, state, queues, quantities)
        prediction = probability.reshape(-1)
        eligible = queues > 0
        base_action = (prediction > model.decision_threshold).float()
        base_action[~eligible] = 0.0
        target = torch.zeros_like(prediction)
        for focal in eligible.nonzero(as_tuple=True)[0].tolist():
            action_off = base_action.clone()
            action_on = base_action.clone()
            action_off[focal] = 0.0
            action_on[focal] = 1.0
            rate_off = calculate_achievable_rate(
                action_off.unsqueeze(1), state, binary=True
            )
            rate_on = calculate_achievable_rate(
                action_on.unsqueeze(1), state, binary=True
            )
            delta = torch.sum(queues * (rate_on - rate_off))
            target[focal] = float(delta >= 0.0)
    return target


def sample_parallel_training_queues(states, queue_range, seed, sampling):
    samples = resample_training_distribution(
        states, queue_range, seed, "mixed_hotspot"
    )
    if sampling == "mixed_hotspot":
        return samples
    generator = torch.Generator().manual_seed(seed + 49979687)
    augmented = []
    for index, (state, queues) in enumerate(samples):
        if index % 3 != 2:
            augmented.append((state, queues))
            continue
        # Long-run hotspot snapshot: every link has backlog, while 20% carry
        # roughly one order of magnitude more urgent traffic.  The absolute
        # scale is irrelevant to MWS; the relative skew is the intended signal.
        num_links = state.num_vertices
        dense = torch.randint(1, 21, (num_links,), generator=generator).float()
        num_hotspot = min(max(1, int(np.ceil(0.20 * num_links))), num_links)
        hotspot = torch.randperm(num_links, generator=generator)[:num_hotspot]
        dense[hotspot] = torch.randint(
            40, 101, (num_hotspot,), generator=generator
        ).float()
        augmented.append((state, dense))
    return augmented


def train_one(args, rounds, states, quantities, val_grouped, test_grouped,
              queue_range):
    set_seed(args.seed + rounds)
    model_classes = {
        "v1": ParallelMPNN,
        "v2": ParallelMPNNv2,
        "v3": ParallelMPNNv3,
        "v4": ParallelMPNNv4,
    }
    model_class = model_classes[args.model_version]
    model = model_class(hidden_dim=32, num_rounds=rounds, channel_rounds=1)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    initial = evaluate(model, val_grouped, quantities)
    best_ratio = initial["combined"]["mws_ratio"]
    best_epoch = -1
    best_state = copy.deepcopy(model.state_dict())
    logs = [{"epoch": -1, "loss": None, "validation": initial}]
    print(f"[rounds={rounds}] initial={initial['combined']}")

    for epoch in range(args.epochs):
        model.train()
        samples = sample_parallel_training_queues(
            states["train"], queue_range,
            args.seed + rounds * 1000003 + epoch * 104729,
            args.queue_sampling,
        )
        frozen_targets = None
        if args.objective == "iterative_best_response":
            model.eval()
            frozen_targets = [
                frozen_local_best_response_target(
                    model, state, queues, quantities[id(state)]
                )
                for state, queues in samples
            ]
        losses = []
        inner_epochs = (
            args.inner_epochs
            if args.objective == "iterative_best_response" else 1
        )
        for _ in range(inner_epochs):
            order = list(range(len(samples)))
            random.shuffle(order)
            for index in order:
                state, queues = samples[index]
                teacher = None
                if args.objective == "teacher_calibration":
                    # Reuse the centralized greedy implementation only as an
                    # explicitly separated calibration control.
                    from utils.mws import centralized_mws_greedy
                    teacher = centralized_mws_greedy(state, queues)
                elif frozen_targets is not None:
                    teacher = frozen_targets[index]
                loss = training_loss(
                    model, state, queues, quantities[id(state)],
                    args.objective, teacher, args.policy_samples,
                )
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
                losses.append(float(loss.detach()))
        validation = evaluate(model, val_grouped, quantities)
        ratio = validation["combined"]["mws_ratio"]
        logs.append({
            "epoch": epoch, "loss": float(np.mean(losses)),
            "validation": validation,
        })
        if ratio > best_ratio:
            best_ratio = ratio
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[rounds={rounds} epoch={epoch:02d}] "
            f"loss={np.mean(losses):.5f} MWS={ratio:.3f} "
            f"active={validation['combined']['average_active']:.2f} "
            f"zero={validation['combined']['all_zero_rate']:.2f} "
            f"scenario={validation['scenarios']['pass_rate']:.2f}"
        )
    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped, quantities)
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"parallel_mpnn_{args.model_version}_tx=10dBm_numUAV={args.num_uav}_"
        f"rounds={rounds}_objective={args.objective}"
        f"{('_sampling=' + args.queue_sampling) if args.queue_sampling != 'mixed_hotspot' else ''}_"
        f"s{args.seed}.pth",
    )
    torch.save({
        "model_version": model.model_version,
        "model_state_dict": model.state_dict(),
        "num_rounds": rounds,
        "channel_rounds": model.channel_rounds,
        "hidden_dim": model.hidden_dim,
        "objective": args.objective,
        "queue_sampling": args.queue_sampling,
        "tx_power_dbm": args.tx_power,
        "csi_mode": "perfect",
        "best_epoch": best_epoch,
    }, checkpoint_path)
    return {
        "rounds": rounds, "checkpoint": checkpoint_path,
        "best_epoch": best_epoch, "initial_validation": initial,
        "test": test, "epochs": logs,
    }


def main():
    args = parse_args()
    if args.num_uav != 10 or args.tx_power != 10.0:
        raise ValueError("Stage D is intentionally limited to 10 UAV / 10 dBm.")
    rounds = [int(value) for value in args.rounds.split(",")]
    queue_range = tuple(int(value) for value in args.queue_range.split(","))
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TRAIN_SIZE": args.train_size, "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
    })
    set_seed(args.seed)
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, 10, False, split, queue_range
        ) for split in ("train", "val", "test")
    }
    all_states = states["train"] + states["val"] + states["test"]
    quantities = {id(state): full_oracle_quantities(state) for state in all_states}
    val_grouped = build_stratified_samples(
        states["val"], queue_range, args.seed + 1
    )
    test_grouped = build_stratified_samples(
        states["test"], queue_range, args.seed + 2
    )
    reports = []
    for value in rounds:
        reports.append(train_one(
            args, value, states, quantities,
            val_grouped, test_grouped, queue_range,
        ))
    os.makedirs("results/diagnostics", exist_ok=True)
    report_path = os.path.join(
        "results/diagnostics",
        f"parallel_mpnn_{args.model_version}_tx10_{args.objective}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({"config": vars(args), "rounds": reports}, file, indent=2)
    summary = {
        item["rounds"]: {
            "best_epoch": item["best_epoch"],
            "test_combined": item["test"]["combined"],
            "scenario_pass_rate": item["test"]["scenarios"]["pass_rate"],
        } for item in reports
    }
    print(json.dumps({"report": report_path, "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
