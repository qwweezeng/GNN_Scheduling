#!/usr/bin/env python3
"""Print and save exact truth for ParallelMPNN behavioral scenarios."""

import json
import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.parallel_mpnn_scenarios import scenario_report


def main():
    report = {
        "scope": (
            "Exact exhaustive micro-scenarios; behavioral tests only, not a "
            "real-network topology assumption."
        ),
        "scenarios": scenario_report(),
    }
    os.makedirs("results/diagnostics", exist_ok=True)
    path = os.path.join(
        "results/diagnostics",
        f"parallel_mpnn_scenarios_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    with open(path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2)
    print(json.dumps({"report": report, "path": path}, indent=2))


if __name__ == "__main__":
    main()

