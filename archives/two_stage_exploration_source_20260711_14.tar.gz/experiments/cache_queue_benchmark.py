#!/usr/bin/env python3
"""Save compact fixed-channel graphs and queue-arrival traces for reuse."""

import argparse
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _format_tag_number,
    build_fixed_channel_queue_trace_cache,
    build_generator,
    load_config,
)


def _float_list(text):
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def _int_list(text):
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=50)
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--arrival_rates", default="1,2,4,8")
    parser.add_argument("--mc_seeds", default="42,43,44")
    parser.add_argument("--tx_power", type=float, default=10.0)
    parser.add_argument("--output", default="")
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power,
        "CSI_MODE": "perfect",
    })
    arrival_rates = _float_list(args.arrival_rates)
    mc_seeds = _int_list(args.mc_seeds)
    if not arrival_rates or not mc_seeds:
        raise ValueError("arrival_rates and mc_seeds must be nonempty")

    output = args.output or (
        "datasets/queue_traces/"
        f"fixed_numUAV={args.num_uav}_tx={_format_tag_number(args.tx_power)}dBm_"
        f"csi=perfect_slots={args.num_slots}_mc={len(mc_seeds)}.pt"
    )
    print(f"[Trace cache] generating {len(mc_seeds)} fixed channel graph(s)")
    payload = build_fixed_channel_queue_trace_cache(
        build_generator(cfg), cfg, args.num_slots, arrival_rates, mc_seeds
    )
    os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
    torch.save(payload, output)
    size_mib = os.path.getsize(output) / 1024 ** 2
    print(f"[Trace cache] saved: {output} ({size_mib:.1f} MiB)")


if __name__ == "__main__":
    main()
