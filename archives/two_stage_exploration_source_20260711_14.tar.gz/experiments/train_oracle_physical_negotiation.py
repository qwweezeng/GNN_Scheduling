#!/usr/bin/env python3
"""Train the negotiation decoder using oracle physical channel marginals."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.evaluate_oracle_marginal import exact_channel_marginals
from experiments.queue_model_diagnostics import set_seed
from experiments.run_queue_experiment import (
    _load_or_generate_dataset,
    build_generator,
    load_config,
)
from experiments.train_two_stage_marginal import resample_training_queues
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS,
    build_stratified_samples,
)
from models.model import calculate_achievable_rate
from models.physical_negotiation import PhysicalNegotiationDecoder
from models.physical_negotiation_v2 import PhysicalNegotiationDecoderV2
from models.physical_negotiation_v3 import PhysicalNegotiationDecoderV3
from utils.mws import mws_objective
from utils.mws import centralized_mws_greedy


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_size", type=int, default=200)
    parser.add_argument("--val_size", type=int, default=32)
    parser.add_argument("--test_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--hidden_dim", type=int, default=32)
    parser.add_argument("--num_rounds", type=int, default=3)
    parser.add_argument(
        "--decoder_version", choices=(
            "v1_sum", "v2_mass_mean", "v3_scale_invariant"
        ),
        default="v1_sum"
    )
    parser.add_argument(
        "--loss", choices=(
            "continuous_utility", "discrete_policy_gradient",
            "counterfactual_policy_gradient", "teacher_calibration"
        ),
        default="continuous_utility"
    )
    parser.add_argument("--policy_samples", type=int, default=8)
    parser.add_argument("--init_checkpoint", default=None)
    parser.add_argument(
        "--queue_sampling", choices=("balanced_random", "mixed_hotspot"),
        default="balanced_random"
    )
    parser.add_argument("--queue_range", default="0,20")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results/models/experimental")
    return parser.parse_args()


def state_signatures(states):
    return [{
        "num_vertices": state.num_vertices,
        "num_edges": state.edge_index.size(1),
        "vertex_sum": float(state.vertex_features.sum()),
        "signal_sum": float(state.signal_power.sum()),
        "csi_mode": getattr(state, "csi_mode", "perfect"),
    } for state in states]


def precompute(states, cache_path=None):
    signatures = state_signatures(states)
    if cache_path and os.path.exists(cache_path):
        cached = torch.load(cache_path, map_location="cpu")
        if cached.get("state_signatures") == signatures:
            print(f"[Cache Hit] oracle marginals: {cache_path}")
            return cached["channel_quantities"]
    quantities = [exact_channel_marginals(state) for state in states]
    if cache_path:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        torch.save({
            "state_signatures": signatures,
            "channel_quantities": quantities,
        }, cache_path)
        print(f"[Cache Save] oracle marginals: {cache_path}")
    return quantities


def sample_hotspot_arrival_snapshot(num_links, queue_range, generator):
    """Sample backlog support/ratios from the dynamic experiment's traffic model."""
    if num_links <= 0:
        return torch.empty(0)
    num_hotspot = min(max(1, int(np.ceil(0.20 * num_links))), num_links)
    hotspot = torch.randperm(num_links, generator=generator)[:num_hotspot]
    total_lambda = float(torch.randint(1, 11, (1,), generator=generator).item())
    horizon = float(torch.randint(1, 21, (1,), generator=generator).item())
    rates = torch.full((num_links,), 0.0)
    if num_hotspot == num_links:
        rates[:] = total_lambda / num_hotspot
    else:
        rates[:] = total_lambda * 0.30 / (num_links - num_hotspot)
        rates[hotspot] = total_lambda * 0.70 / num_hotspot
    queues = torch.poisson(rates * horizon, generator=generator)
    queues.clamp_(max=float(queue_range[1]))
    if not (queues > 0).any():
        queues[hotspot[0]] = 1.0
    return queues


def resample_training_distribution(states, queue_range, seed, sampling):
    if sampling == "balanced_random":
        return resample_training_queues(states, queue_range, seed)
    balanced = resample_training_queues(states, queue_range, seed)
    generator = torch.Generator().manual_seed(seed + 32452843)
    mixed = []
    for index, (state, balanced_queues) in enumerate(balanced):
        queues = (
            balanced_queues
            if index % 2 == 0
            else sample_hotspot_arrival_snapshot(
                state.num_vertices, queue_range, generator
            )
        )
        mixed.append((state, queues))
    return mixed


def evaluate(model, grouped_samples, channel_quantities, device,
             stochastic_samples=16):
    result = {}
    totals = {
        "utility": 0.0, "teacher": 0.0, "active": 0.0,
        "teacher_active": 0.0, "samples": 0,
        "correct": 0, "predicted": 0, "target": 0, "tp": 0,
        "queue_flips": 0, "nonempty": 0, "soft_utility": 0.0,
        "sampled_utility": 0.0, "permuted_utility": 0.0,
    }
    model.eval()
    with torch.no_grad():
        for group in DENSITY_BOUNDS:
            local = {key: 0.0 for key in (
                "utility", "teacher", "active", "teacher_active", "soft_utility",
                "sampled_utility"
            )}
            local.update({"samples": 0, "correct": 0, "predicted": 0,
                          "target": 0, "tp": 0, "queue_flips": 0,
                          "nonempty": 0, "permuted_utility": 0.0})
            for index, (state, queues, teacher) in enumerate(grouped_samples[group]):
                solo, harm = channel_quantities[index]
                probability, _ = model(
                    solo.to(device), harm.to(device), queues.to(device),
                    state.edge_index.to(device)
                )
                hard = (probability > 0.5).float().cpu()
                local["utility"] += mws_objective(hard.squeeze(1), queues, state)
                local["teacher"] += mws_objective(
                    teacher.squeeze(1), queues, state
                )
                local["soft_utility"] += float(torch.sum(
                    queues.to(device) * calculate_achievable_rate(
                        probability, state, binary=False
                    )
                ))
                sampled_reward = 0.0
                for _ in range(stochastic_samples):
                    sampled = torch.bernoulli(probability).cpu()
                    sampled_reward += mws_objective(
                        sampled.squeeze(1), queues, state
                    )
                local["sampled_utility"] += sampled_reward / stochastic_samples
                local["active"] += hard.sum().item()
                local["teacher_active"] += teacher.sum().item()
                predicted = hard > 0.5
                target = teacher > 0.5
                local["correct"] += int((predicted == target).sum())
                local["predicted"] += int(predicted.sum())
                local["target"] += int(target.sum())
                local["tp"] += int((predicted & target).sum())

                active = (queues > 0).nonzero(as_tuple=True)[0]
                permutation = queues.clone()
                permutation[active] = queues[active.flip(0)]
                permuted, _ = model(
                    solo.to(device), harm.to(device), permutation.to(device),
                    state.edge_index.to(device)
                )
                hard_permuted = (permuted > 0.5).float().cpu()
                local["permuted_utility"] += mws_objective(
                    hard_permuted.squeeze(1), queues, state
                )
                mask = (queues > 0).unsqueeze(1)
                local["queue_flips"] += int(((hard != hard_permuted) & mask).sum())
                local["nonempty"] += int(mask.sum())
                local["samples"] += 1

            precision = local["tp"] / max(local["predicted"], 1)
            recall = local["tp"] / max(local["target"], 1)
            result[group] = {
                "mws_ratio": local["utility"] / max(local["teacher"], 1e-12),
                "soft_utility": local["soft_utility"] / local["samples"],
                "sampled_mws_ratio": (
                    local["sampled_utility"] / max(local["teacher"], 1e-12)
                ),
                "average_active_links": local["active"] / local["samples"],
                "teacher_average_active_links": (
                    local["teacher_active"] / local["samples"]
                ),
                "precision": precision,
                "recall": recall,
                "f1": 2 * precision * recall / max(precision + recall, 1e-12),
                "queue_permutation_hard_flip_rate": (
                    local["queue_flips"] / max(local["nonempty"], 1)
                ),
                "permuted_queue_utility_ratio_to_normal": (
                    local["permuted_utility"] / max(local["utility"], 1e-12)
                ),
            }
            for key in totals:
                totals[key] += local[key]

    precision = totals["tp"] / max(totals["predicted"], 1)
    recall = totals["tp"] / max(totals["target"], 1)
    result["combined"] = {
        "mws_ratio": totals["utility"] / max(totals["teacher"], 1e-12),
        "soft_utility": totals["soft_utility"] / totals["samples"],
        "sampled_mws_ratio": (
            totals["sampled_utility"] / max(totals["teacher"], 1e-12)
        ),
        "average_active_links": totals["active"] / totals["samples"],
        "teacher_average_active_links": totals["teacher_active"] / totals["samples"],
        "precision": precision,
        "recall": recall,
        "f1": 2 * precision * recall / max(precision + recall, 1e-12),
        "queue_permutation_hard_flip_rate": (
            totals["queue_flips"] / max(totals["nonempty"], 1)
        ),
        "permuted_queue_utility_ratio_to_normal": (
            totals["permuted_utility"] / max(totals["utility"], 1e-12)
        ),
    }
    return result


def main():
    args = parse_args()
    set_seed(args.seed)
    cfg = load_config(args.config)
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
    })
    queue_range = tuple(int(value.strip()) for value in args.queue_range.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, args.num_uav, False, split, queue_range
        )
        for split in ("train", "val", "test")
    }
    print("[Setup] precomputing exact solo rates and directed pairwise losses")
    cache_root = os.path.join("results", "cache", "oracle_marginals")
    physical = {
        split: precompute(
            split_states,
            os.path.join(
                cache_root,
                f"numUAV={args.num_uav}_{split}_n={len(split_states)}.pth",
            ),
        )
        for split, split_states in states.items()
    }
    val_grouped = build_stratified_samples(states["val"], queue_range, args.seed + 1)
    test_grouped = build_stratified_samples(states["test"], queue_range, args.seed + 2)

    decoder_class = {
        "v1_sum": PhysicalNegotiationDecoder,
        "v2_mass_mean": PhysicalNegotiationDecoderV2,
        "v3_scale_invariant": PhysicalNegotiationDecoderV3,
    }[args.decoder_version]
    model = decoder_class(
        hidden_dim=args.hidden_dim, num_rounds=args.num_rounds
    ).to(device)
    if args.init_checkpoint:
        initial_checkpoint = torch.load(args.init_checkpoint, map_location=device)
        if initial_checkpoint.get("decoder_version") != args.decoder_version:
            raise ValueError("Initial checkpoint decoder version is incompatible.")
        if initial_checkpoint.get("num_rounds") != args.num_rounds:
            raise ValueError("Initial checkpoint round count is incompatible.")
        model.load_state_dict(initial_checkpoint["model_state_dict"])
        print(f"[Setup] initialized from {args.init_checkpoint}")
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.get("LR", 1e-4))
    initial = evaluate(model, val_grouped, physical["val"], device)
    if args.loss in (
        "discrete_policy_gradient", "counterfactual_policy_gradient"
    ):
        metric_name = "sampled_mws_ratio"
    elif args.loss == "teacher_calibration":
        metric_name = "f1"
    else:
        metric_name = "mws_ratio"
    best_ratio = initial["combined"][metric_name]
    best_epoch = -1
    best_state = copy.deepcopy(model.state_dict())
    logs = [{"epoch": -1, "loss": None, "validation": initial}]
    print(
        f"[Setup] device={device} params={sum(p.numel() for p in model.parameters())} "
        f"rounds={args.num_rounds} initial_MWS={best_ratio:.3f}"
    )

    for epoch in range(args.epochs):
        model.train()
        train_samples = resample_training_distribution(
            states["train"], queue_range, args.seed + 104729 * epoch,
            args.queue_sampling,
        )
        order = list(range(len(train_samples)))
        random.shuffle(order)
        losses = []
        for index in order:
            state, queues = train_samples[index]
            solo, harm = physical["train"][index]
            queues_device = queues.to(device)
            probability, _ = model(
                solo.to(device), harm.to(device), queues_device,
                state.edge_index.to(device)
            )
            if args.loss == "continuous_utility":
                rates = calculate_achievable_rate(probability, state, binary=False)
                loss = -torch.sum(queues_device * rates) / (
                    queues_device.sum().detach() + 1e-8
                )
            elif args.loss == "discrete_policy_gradient":
                active = queues_device > 0
                active_probability = probability.squeeze(1)[active]
                log_probabilities = []
                rewards = []
                for _ in range(args.policy_samples):
                    action = torch.zeros_like(probability)
                    sampled_active = torch.bernoulli(active_probability)
                    action.squeeze(1)[active] = sampled_active
                    log_probability = torch.distributions.Bernoulli(
                        probs=active_probability
                    ).log_prob(sampled_active).sum()
                    reward = torch.sum(
                        queues_device * calculate_achievable_rate(
                            action, state, binary=True
                        )
                    ) / (queues_device.sum() + 1e-8)
                    log_probabilities.append(log_probability)
                    rewards.append(reward.detach())
                rewards = torch.stack(rewards)
                log_probabilities = torch.stack(log_probabilities)
                if args.policy_samples > 1:
                    baseline = (
                        rewards.sum() - rewards
                    ) / (args.policy_samples - 1)
                else:
                    baseline = torch.zeros_like(rewards)
                advantage = rewards - baseline
                loss = -torch.mean(advantage * log_probabilities)
            elif args.loss == "counterfactual_policy_gradient":
                active = queues_device > 0
                active_probability = probability.squeeze(1)[active]
                marginal_losses = []
                for _ in range(args.policy_samples):
                    base_action = torch.zeros_like(probability)
                    base_action.squeeze(1)[active] = torch.bernoulli(
                        active_probability
                    )
                    marginal_rewards = []
                    for link in active.nonzero(as_tuple=True)[0].tolist():
                        action_on = base_action.clone()
                        action_off = base_action.clone()
                        action_on[link] = 1.0
                        action_off[link] = 0.0
                        reward_on = torch.sum(
                            queues_device * calculate_achievable_rate(
                                action_on, state, binary=True
                            )
                        ) / (queues_device.sum() + 1e-8)
                        reward_off = torch.sum(
                            queues_device * calculate_achievable_rate(
                                action_off, state, binary=True
                            )
                        ) / (queues_device.sum() + 1e-8)
                        marginal_rewards.append((reward_on - reward_off).detach())
                    marginal_reward = torch.stack(marginal_rewards)
                    marginal_losses.append(-torch.mean(
                        marginal_reward * active_probability
                    ))
                loss = torch.stack(marginal_losses).mean()
            else:
                target = centralized_mws_greedy(state, queues).to(device).squeeze(1)
                predicted = probability.squeeze(1).clamp(1e-6, 1 - 1e-6)
                positive = target > 0.5
                negative = ~positive
                positive_loss = -torch.log(predicted[positive]).mean()
                negative_loss = -torch.log(1 - predicted[negative]).mean()
                # Equal positive/negative class averages prevent the roughly
                # 2-vs-80 class count from making "all zero" the easy solution.
                loss = 0.5 * (positive_loss + negative_loss)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(loss.item())

        validation = evaluate(model, val_grouped, physical["val"], device)
        combined = validation["combined"]
        logs.append({
            "epoch": epoch,
            "loss": float(np.mean(losses)),
            "validation": validation,
        })
        selection_value = combined[metric_name]
        if selection_value > best_ratio:
            best_ratio = selection_value
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"[epoch={epoch:02d}] loss={np.mean(losses):.4f} "
            f"MWS={combined['mws_ratio']:.3f} "
            f"sampled={combined['sampled_mws_ratio']:.3f} "
            f"active={combined['average_active_links']:.2f} "
            f"flip={combined['queue_permutation_hard_flip_rate']:.3f} "
            f"s/m/d={validation['sparse']['mws_ratio']:.3f}/"
            f"{validation['medium']['mws_ratio']:.3f}/"
            f"{validation['dense']['mws_ratio']:.3f}"
        )

    model.load_state_dict(best_state)
    test = evaluate(model, test_grouped, physical["test"], device)
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint_path = os.path.join(
        args.output_dir,
        f"physical_negotiation_oracle_{args.decoder_version}_numUAV={args.num_uav}_"
        f"rounds={args.num_rounds}_train={args.train_size}_"
        f"loss={args.loss}_init={int(args.init_checkpoint is not None)}_"
        f"sampling={args.queue_sampling}_ep={args.epochs}_s{args.seed}.pth",
    )
    torch.save({
        "model_version": f"physical_negotiation_oracle_{args.decoder_version}_experimental",
        "model_state_dict": model.state_dict(),
        "hidden_dim": args.hidden_dim,
        "num_rounds": args.num_rounds,
        "decoder_version": args.decoder_version,
        "channel_input": "exact_solo_rate_and_directed_pairwise_loss",
        "loss": "direct_queue_weighted_rate",
        "training_objective": args.loss,
        "policy_samples": args.policy_samples,
        "init_checkpoint": args.init_checkpoint,
        "queue_sampling": args.queue_sampling,
        "seed": args.seed,
        "best_epoch": best_epoch,
    }, checkpoint_path)
    report_path = os.path.join(
        "results", "diagnostics",
        f"physical_negotiation_oracle_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
    )
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args),
            "hypothesis": (
                "Shared directed message passing can negotiate a schedule from "
                "exact queue-weighted link values and pairwise physical harms."
            ),
            "checkpoint": checkpoint_path,
            "best_epoch": best_epoch,
            "best_validation_metric": metric_name,
            "best_validation_value": best_ratio,
            "test": test,
            "epochs": logs,
        }, file, indent=2)
    print(f"[Done] checkpoint={checkpoint_path}")
    print(f"[Done] report={report_path}")
    print(json.dumps(test, indent=2))


if __name__ == "__main__":
    main()
