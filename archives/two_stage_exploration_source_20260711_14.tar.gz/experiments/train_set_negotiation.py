#!/usr/bin/env python3
"""Train SetNegotiation-v1 with final-set discrete MWS utility only."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.run_queue_experiment import (
    _load_or_generate_dataset, build_generator, load_config,
)
from experiments.train_parallel_mpnn import full_oracle_quantities
from experiments.two_stage_v1_diagnostics import (
    DENSITY_BOUNDS, build_stratified_samples,
)
from models.set_negotiation import (
    SetNegotiation, SetNegotiationV2, SetNegotiationV3,
)
from utils.mws import mws_objective


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--model_version", choices=("v1", "v2", "v3"), default="v1"
    )
    parser.add_argument("--train_size", type=int, default=80)
    parser.add_argument("--val_size", type=int, default=20)
    parser.add_argument("--test_size", type=int, default=20)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--num_revisions", type=int, default=2)
    parser.add_argument("--policy_samples", type=int, default=8)
    parser.add_argument("--eval_samples", type=int, default=8)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument(
        "--initialization",
        choices=("learned_proposal", "uniform_cardinality"),
        default="uniform_cardinality",
    )
    parser.add_argument(
        "--objective",
        choices=("policy_gradient", "elite_set"),
        default="policy_gradient",
    )
    return parser.parse_args()


def flatten(grouped):
    return [
        sample for group in DENSITY_BOUNDS for sample in grouped[group]
    ]


def random_initial_action(queues):
    """Beta(1,1)-Bernoulli mixture gives uniform set cardinality."""
    density = torch.rand(())
    return (
        (torch.rand(queues.numel()) < density) & (queues > 0)
    ).float()


def policy_gradient_loss(model, state, queues, quantities, num_samples,
                         initialization):
    solo, harm, edge_index = quantities
    rewards = []
    log_probabilities = []
    for _ in range(num_samples):
        initial_action = (
            random_initial_action(queues)
            if initialization == "uniform_cardinality" else None
        )
        action, diagnostics = model(
            solo, harm, queues, edge_index, return_history=True,
            initial_action=initial_action,
        )
        utility = mws_objective(action.reshape(-1), queues, state)
        # sum(Q) is constant across candidate schedules of the same state, so
        # this changes gradient scale but not which schedule is preferred.
        rewards.append(utility / max(float(queues.sum()), 1.0))
        log_probabilities.append(
            diagnostics["trajectory_log_probability"]
        )
    reward = torch.tensor(rewards, dtype=log_probabilities[0].dtype)
    baseline = reward.mean()
    advantage = reward - baseline
    log_probability = torch.stack(log_probabilities)
    loss = -(advantage.detach() * log_probability).mean()
    return loss, {
        "mean_reward": float(reward.mean()),
        "best_reward": float(reward.max()),
        "reward_std": float(reward.std(unbiased=False)),
    }


def elite_set_loss(model, state, queues, quantities, num_samples,
                   initialization):
    """Increase probability of the best complete trajectory sampled."""
    solo, harm, edge_index = quantities
    rewards = []
    log_probabilities = []
    for _ in range(num_samples):
        initial_action = (
            random_initial_action(queues)
            if initialization == "uniform_cardinality" else None
        )
        action, diagnostics = model(
            solo, harm, queues, edge_index, return_history=True,
            initial_action=initial_action,
        )
        rewards.append(
            mws_objective(action.reshape(-1), queues, state)
            / max(float(queues.sum()), 1.0)
        )
        log_probabilities.append(
            diagnostics["trajectory_log_probability"]
        )
    reward = torch.tensor(rewards, dtype=log_probabilities[0].dtype)
    best = int(torch.argmax(reward))
    loss = -log_probabilities[best]
    return loss, {
        "mean_reward": float(reward.mean()),
        "best_reward": float(reward.max()),
        "reward_std": float(reward.std(unbiased=False)),
    }


def evaluate(model, grouped, quantities_by_state, num_samples, seed,
             initialization):
    torch.manual_seed(seed)
    totals = {
        "utility": 0.0, "teacher": 0.0, "ablated": 0.0,
        "active": 0.0, "all_zero": 0, "all_nonempty": 0,
        "proposal_final_flips": 0, "eligible": 0,
        "condition_action_flips": 0, "unique_fraction": 0.0,
        "states": 0, "rollouts": 0,
        "neighbor_ablated": 0.0, "neighbor_condition_action_flips": 0,
    }
    model.eval()
    with torch.no_grad():
        for state, queues, teacher in flatten(grouped):
            solo, harm, edge_index = quantities_by_state[id(state)]
            teacher_utility = mws_objective(
                teacher.reshape(-1), queues, state
            )
            schedules = set()
            for _ in range(num_samples):
                initial_action = (
                    random_initial_action(queues)
                    if initialization == "uniform_cardinality" else None
                )
                uniforms = [
                    torch.rand(state.num_vertices)
                    for _ in range(
                        model.num_revisions + int(initial_action is None)
                    )
                ]
                action, diagnostics = model(
                    solo, harm, queues, edge_index,
                    random_uniforms=uniforms, return_history=True,
                    initial_action=initial_action,
                )
                ablated, _ = model(
                    solo, harm, queues, edge_index,
                    random_uniforms=uniforms,
                    ablate_set_condition=True,
                    initial_action=initial_action,
                )
                if isinstance(model, SetNegotiationV2):
                    neighbor_ablated, _ = model(
                        solo, harm, queues, edge_index,
                        random_uniforms=uniforms,
                        initial_action=initial_action,
                        ablate_neighbor_set=True,
                    )
                else:
                    neighbor_ablated = ablated
                final = action.reshape(-1)
                ablated_final = ablated.reshape(-1)
                neighbor_ablated_final = neighbor_ablated.reshape(-1)
                proposal = diagnostics["action_history"][0]
                nonempty = queues > 0
                totals["utility"] += mws_objective(
                    final, queues, state
                )
                totals["teacher"] += teacher_utility
                totals["ablated"] += mws_objective(
                    ablated_final, queues, state
                )
                totals["neighbor_ablated"] += mws_objective(
                    neighbor_ablated_final, queues, state
                )
                totals["active"] += float(final.sum())
                totals["all_zero"] += int(
                    final.sum() == 0 and nonempty.any()
                )
                totals["all_nonempty"] += int(
                    nonempty.any()
                    and int(final.sum()) == int(nonempty.sum())
                )
                totals["proposal_final_flips"] += int(
                    (proposal[nonempty] != final[nonempty]).sum()
                )
                totals["condition_action_flips"] += int(
                    (final[nonempty] != ablated_final[nonempty]).sum()
                )
                totals["neighbor_condition_action_flips"] += int(
                    (final[nonempty] != neighbor_ablated_final[nonempty]).sum()
                )
                totals["eligible"] += int(nonempty.sum())
                totals["rollouts"] += 1
                schedules.add(tuple(final.int().tolist()))
            totals["unique_fraction"] += len(schedules) / num_samples
            totals["states"] += 1
    return {
        "expected_mws_ratio": (
            totals["utility"] / max(totals["teacher"], 1e-8)
        ),
        "set_condition_ablation_utility_ratio": (
            totals["ablated"] / max(totals["utility"], 1e-8)
        ),
        "neighbor_set_ablation_utility_ratio": (
            totals["neighbor_ablated"] / max(totals["utility"], 1e-8)
        ),
        "average_active": totals["active"] / max(totals["rollouts"], 1),
        "all_zero_rate": totals["all_zero"] / max(totals["rollouts"], 1),
        "all_nonempty_rate": (
            totals["all_nonempty"] / max(totals["rollouts"], 1)
        ),
        "proposal_final_flip_rate": (
            totals["proposal_final_flips"] / max(totals["eligible"], 1)
        ),
        "set_condition_action_flip_rate": (
            totals["condition_action_flips"] / max(totals["eligible"], 1)
        ),
        "neighbor_set_action_flip_rate": (
            totals["neighbor_condition_action_flips"]
            / max(totals["eligible"], 1)
        ),
        "mean_unique_schedule_fraction": (
            totals["unique_fraction"] / max(totals["states"], 1)
        ),
    }


def main():
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": 10, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "TRAIN_SIZE": args.train_size, "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
    })
    generator = build_generator(cfg)
    states = {
        split: _load_or_generate_dataset(
            generator, cfg, 10, False, split, (0, 20)
        ) for split in ("train", "val", "test")
    }
    grouped = {
        "train": build_stratified_samples(
            states["train"], (0, 20), args.seed
        ),
        "val": build_stratified_samples(
            states["val"], (0, 20), args.seed + 1
        ),
        "test": build_stratified_samples(
            states["test"], (0, 20), args.seed + 2
        ),
    }
    all_states = states["train"] + states["val"] + states["test"]
    quantities = {
        id(state): full_oracle_quantities(state) for state in all_states
    }
    if args.model_version in ("v2", "v3") and (
        args.initialization != "uniform_cardinality"
    ):
        raise ValueError("v2/v3 require uniform_cardinality initialization")
    model_class = {
        "v1": SetNegotiation,
        "v2": SetNegotiationV2,
        "v3": SetNegotiationV3,
    }[args.model_version]
    model = model_class(
        hidden_dim=32, num_revisions=args.num_revisions, channel_rounds=1
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    initial = evaluate(
        model, grouped["val"], quantities, args.eval_samples,
        args.seed + 1000, args.initialization,
    )
    best_ratio = initial["expected_mws_ratio"]
    best_epoch = -1
    best_state = copy.deepcopy(model.state_dict())
    epoch_logs = []
    training_samples = flatten(grouped["train"])
    print(f"initial={initial}")

    for epoch in range(args.epochs):
        model.train()
        random.shuffle(training_samples)
        losses = []
        rewards = []
        best_rewards = []
        reward_stds = []
        for state, queues, _ in training_samples:
            loss_function = (
                policy_gradient_loss
                if args.objective == "policy_gradient"
                else elite_set_loss
            )
            loss, diagnostics = loss_function(
                model, state, queues, quantities[id(state)],
                args.policy_samples, args.initialization,
            )
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach()))
            rewards.append(diagnostics["mean_reward"])
            # Kept separately because elite-set learning is driven by the
            # best complete trajectory, not by the average sampled set.
            best_rewards.append(diagnostics["best_reward"])
            reward_stds.append(diagnostics["reward_std"])
        validation = evaluate(
            model, grouped["val"], quantities, args.eval_samples,
            args.seed + 1000, args.initialization,
        )
        if validation["expected_mws_ratio"] > best_ratio:
            best_ratio = validation["expected_mws_ratio"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        log = {
            "epoch": epoch,
            "loss": float(np.mean(losses)),
            "mean_normalized_reward": float(np.mean(rewards)),
            "mean_best_normalized_reward": float(np.mean(best_rewards)),
            "mean_within_state_reward_std": float(np.mean(reward_stds)),
            "validation": validation,
        }
        epoch_logs.append(log)
        print(
            f"[epoch={epoch:02d}] loss={log['loss']:.4f} "
            f"reward={log['mean_normalized_reward']:.4f} "
            f"best={log['mean_best_normalized_reward']:.4f} "
            f"spread={log['mean_within_state_reward_std']:.4f} "
            f"MWS={validation['expected_mws_ratio']:.3f} "
            f"active={validation['average_active']:.2f} "
            f"condflip={validation['set_condition_action_flip_rate']:.3f}"
        )

    model.load_state_dict(best_state)
    test = evaluate(
        model, grouped["test"], quantities, args.eval_samples,
        args.seed + 2000, args.initialization,
    )
    os.makedirs("results/models/experimental", exist_ok=True)
    checkpoint_path = (
        f"results/models/experimental/set_negotiation_{args.model_version}_tx=10dBm_"
        f"numUAV=10_revisions={args.num_revisions}_"
        f"objective={args.objective}_init={args.initialization}_"
        f"s{args.seed}.pth"
    )
    torch.save({
        "model_version": model.model_version,
        "model_state_dict": model.state_dict(),
        "hidden_dim": model.hidden_dim,
        "num_revisions": model.num_revisions,
        "channel_rounds": model.channel_rounds,
        "objective": args.objective,
        "initialization": args.initialization,
        "tx_power_dbm": 10.0,
        "csi_mode": "perfect",
        "best_epoch": best_epoch,
    }, checkpoint_path)
    os.makedirs("results/diagnostics", exist_ok=True)
    report_path = (
        f"results/diagnostics/set_negotiation_{args.model_version}_tx10_"
        f"objective={args.objective}_init={args.initialization}_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    with open(report_path, "w", encoding="utf-8") as file:
        json.dump({
            "config": vars(args),
            "definition": (
                "queue-free channel encoder; sampled binary proposal; shared "
                "within-slot revisions conditioned on previous hard set; "
                "final-set MWS policy gradient; no teacher or cross-slot memory"
            ),
            "initial_validation": initial,
            "best_epoch": best_epoch,
            "test": test,
            "epochs": epoch_logs,
            "checkpoint": checkpoint_path,
        }, file, indent=2)
    print(json.dumps({
        "report": report_path,
        "checkpoint": checkpoint_path,
        "best_epoch": best_epoch,
        "test": test,
    }, indent=2))


if __name__ == "__main__":
    main()
