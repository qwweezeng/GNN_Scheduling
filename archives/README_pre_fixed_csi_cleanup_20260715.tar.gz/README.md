# GNN-Scheduling — 基于图神经网络的无人机密集集群链路调度

本项目是论文《GNN-based Dynamic Link Scheduling for Dense UAV Swarm Networks》的 PyTorch 仿真实现。

**研究背景：** 在大规模无人机密集集群自组网（FANET）中，大量链路并发争用无线信道资源，带来严重碰撞和干扰，使得网络资源难以高效利用。本项目提出基于图注意力网络（GAT）的分布式链路调度方案，目标是：**在每个时隙决策激活哪些链路，使全网效用（总吞吐量）最大化。**

**核心思路：** 将无人机网络中的通信链路建模为**冲突图（Conflict Graph）**：

- **节点** = 通信链路
- **边** = 链路间的干扰关系

通过 GAT 迭代地从局部节点特征（邻居干扰信息）学习整体网络态势，输出每条链路的激活概率。

**当前统一物理口径：** 后续正式实验默认使用 `TX_POWER=10 dBm`。历史上仅按 `numUAV` 命名的数据和模型可能来自 22 dBm，只用于复现实验，不与新的 10 dBm 结果混用。新产生的数据集和模型文件名会显式包含 `tx=10dBm` 与 CSI 模式。

---

## 安装与运行

### 环境准备

```bash
# 安装 uv（推荐，自动管理虚拟环境）
curl -LsSf https://astral.sh/uv/install.sh | sh

# 安装依赖（自动创建 .venv）
uv pip install -r pyproject.toml

# 或直接用 pip
pip install torch numpy matplotlib networkx tensorboard pyyaml pandas openpyxl
```

如果使用本机已有的 `conda/pytorch` 环境，可以把 README 中的：

```bash
uv run python <script.py> ...
```

等价替换为：

```bash
conda run --no-capture-output -n pytorch python -u <script.py> ...
```

其中 `--no-capture-output` 和 `python -u` 用于实时显示输出，适合长时间训练或多时隙仿真。

---

## 参数联动速查表（重要！）

本项目有多个**可选功能模块**，每个模块涉及一组必须联动设置的参数。若参数不一致，代码会在运行时报错（防呆设计）。

### 1. 队列感知模块（Queue-aware）

| 功能 | 参数 | 值 | 说明 |
|------|------|----|------|
| 启用开关 | `run_queue_experiment.py` | 固定 | 队列感知实验脚本，无开关 |
| 特征维度 | `raw_node_dim` | `2` | GAT 输入 `[SNR, Q]` |
| Loss | — | `-Σ(Q_i × μ_i) / ΣQ_i` | `μ_i` 为 packet/slot 服务量；分母只稳定梯度，不改变单快照 MWS 最优解 |

**运行命令：**

```bash
# 队列感知实验（快速单 seed 验证）
uv run python experiments/run_queue_experiment.py --num_uav 30 \
    --arrival_rates 0.5 --num_slots 1000 --seed 42

# 队列感知实验（推荐正式比较：paired Monte Carlo）
uv run python experiments/run_queue_experiment.py --num_uav 30 \
    --arrival_rates 0.5,1.0,2.0,4.0 --num_slots 5000 --seed 42 --mc_runs 5

# 自定义数据集规模和训练轮数；若模型已存在，会优先加载而不是重新训练
uv run python experiments/run_queue_experiment.py --num_uav 30 \
    --train_size 500 --val_size 64 --test_size 64 --epochs 30 --seed 42
```

**数据集目录：**
- 非队列数据：`datasets/dataset_numUAV=<N>_tx=10dBm_csi=perfect.pkl`
- 队列数据：`datasets/queue/dataset_numUAV=<N>_tx=10dBm_csi=perfect_linklevel.pkl`
- 动态评测轨迹：`datasets/queue_traces/`；每个 seed 只存信道块图，到达张量单独存，不属于训练集
- 物理配置变化时会使用不同文件名；旧的 `dataset_numUAV=<N>.pkl` 不会被覆盖。

**标准模型库：**
- 非队列模型：`results/models/gat_numUAV=<N>_tx=10dBm_csi=perfect.pth`
- 队列模型：`results/models/gat_queue_mws_v3_numUAV=<N>_tx=10dBm_csi=perfect.pth`
- checkpoint 同时保存功率和 CSI 元数据，避免静默加载物理条件不一致的模型。

端到端 v3 GAT-q 输入为 `[SNR_dB, Q/max(Q)]`，并使用训练集统计的 mean/std 分通道标准化；Loss 中的队列权重始终使用原始 packet 数。TwoStage-GAT-v1 不使用全局 `max(Q)`，而是在一跳邻居内计算相对队列。

### 1.1 队列感知两阶段研究

新 Chat 或第一次接手时先阅读 `docs/NEXT_CHAT_CONTEXT.md`；继续追溯路线时再阅读 `docs/TWO_STAGE_RESEARCH_OVERVIEW.md` 和当前实验流水 `docs/TWO_STAGE_LOCALMAX_REUSE_TUTORIAL.md`。过去的完整教学、路线审查、并行协商和旧 Chat 交接材料统一保存在 `docs/archive/two_stage/`，只用于历史追溯。

当前推荐学习版是 `LocalPhysicalReuse-v2`：信道 GAT 的活动先验先转换为期望干扰和有效速率，与当前队列形成 LocalMax 骨架；其他链路再依据冲突邻居的真实动作、队列和有向信道增益做一轮条件空间复用。完整公式见 `docs/LOCAL_PHYSICAL_REUSE_SYSTEM_MODEL.md`，实验演进见 `docs/TWO_STAGE_LOCALMAX_REUSE_TUTORIAL.md`。下方 `TwoStage-GAT-v1` 内容只保留用于早期 Structure 路线复现。

Markdown 数学公式统一使用 `$...$`（行内）和 `$$...$$`（独立公式），以兼容 Codex 内置预览。

```bash
# 当前结构上限闸门（Exact 只作集中式诊断）
conda run --no-capture-output -n pytorch python -u \
    experiments/diagnose_localmax_reuse_headroom.py \
    --num_uav 10 --test_size 20 --queue_seeds 44,45,46 \
    --num_slots 1000 --arrival_rates 0.5,1,2,4 --mc_seeds 42,43,44

# 检查冲突图局部物理收益能保留多少全局精确增益
conda run --no-capture-output -n pytorch python -u \
    experiments/diagnose_local_margin_sufficiency.py \
    --num_uav 10 --test_size 20 --queue_seeds 44,45,46
```

`experiments/queue_model_diagnostics.py` 用同一批信道、拓扑和队列快照做递进控制，专门判断 GAT-q 的失败来自网络结构、变化队列输入，还是 weighted-MWS 的训练信号。该脚本不会覆盖 `gat_queue_mws_v3_numUAV=<N>.pth`。

```bash
# 完整诊断：A-D 各训练 3 个 seed；确认失败后自动训练 TwoStage-GAT-v1
conda run --no-capture-output -n pytorch python -u \
    experiments/queue_model_diagnostics.py \
    --stage all --num_uav 10 --train_size 500 --val_size 64 \
    --test_size 64 --epochs 30 --seeds 42,43,44 --queue_range 0,20

# 只跑 A-D，不训练两阶段模型
conda run --no-capture-output -n pytorch python -u \
    experiments/queue_model_diagnostics.py --stage controls --num_uav 10

# 跳过 A-D，直接训练两阶段模型
conda run --no-capture-output -n pytorch python -u \
    experiments/queue_model_diagnostics.py --stage two-stage --num_uav 10

# 30/12/12 快照、3 epoch 的接口 smoke；不能用于论文结论
conda run --no-capture-output -n pytorch python -u \
    experiments/queue_model_diagnostics.py --quick --stage all \
    --num_uav 10 --seeds 42
```

| 参数 | 默认值 | 含义 |
|------|--------|------|
| `--stage` | `all` | `controls` 只跑 A-D；`two-stage` 只训练两阶段；`all` 按失败判据自动衔接 |
| `--seeds` | `42,43,44` | A-D 的独立训练种子；两阶段第一版使用列表中的第一个 seed |
| `--train_size` | `500` | 每个控制模型使用的共享训练信道快照数 |
| `--val_size` / `--test_size` | `64` | 共享验证/测试快照数 |
| `--epochs` | `30` | 每个模型训练轮数，所有模型学习率固定为 `1e-4` |
| `--queue_range` | `0,20` | C/D 与教师标签使用的 link-level 队列采样范围 |
| `--quick` | 关闭 | 强制改为 30/12/12 快照和 3 epoch，并把模型存入 smoke 目录 |

五组控制的含义：

| 模式 | 输入 | 目标 | 用途 |
|------|------|------|------|
| `A_base` | SNR | `sum R` | 复现基础 GAT 的稀疏信道调度能力 |
| `B_constant_q` | SNR + 恒定 Q | `sum R` | 检查 v3 双通道和 local input skip 是否破坏基础学习 |
| `C_variable_q_unweighted` | SNR + 变化 Q | `sum R` | 检查变化但不参与 loss 的 Q 是否成为干扰特征 |
| `D_weighted_continuous` | SNR + 变化 Q | `sum Q*R` | 检查连续松弛目标的行为 |
| `D_weighted_ste` | SNR + 变化 Q | `sum Q*R` | 单独观察 stochastic STE 的信用分配与坍缩 |

`TwoStage-GAT-v1` 的第一阶段冻结已有 `gat_numUAV=<N>.pth`，输出信道嵌入和信道分数；第二阶段显式构造一跳相对队列和 `Q_relative * softplus(channel_score)`，再由浅层 Queue-GAT 学习最终动作。集中式 MWS-Greedy 只生成离线教师标签；在线仿真只交换 GAT 邻居消息，并在每条链路本地阈值化。

模型和报告路径：

- 正式两阶段模型：`results/models/gat_queue_two_stage_v1_numUAV=<N>.pth`
- smoke 模型：`results/models/smoke/gat_queue_two_stage_v1_numUAV=<N>_smoke.pth`
- A-D 临时模型：`results/models/diagnostics/`
- 完整诊断数据：`results/diagnostics/queue_learning_<timestamp>/diagnostic_report.json`

正式两阶段 checkpoint 存在时，`run_queue_experiment.py` 会自动增加 `TwoStage-GAT` 和规则对照 `QxChannel-LocalMax`；若文件不存在则明确打印 `Skip`，不会加载随机权重。

### 2. 功率控制模块（Power Control）

| 功能 | 参数 | 值 | 说明 |
|------|------|----|------|
| 启用开关 | `USE_POWER_CONTROL` | `true` | 在实验脚本中设置 |
| 惩罚系数 | `LAMBDA_POWER_PENALTY` | `0.01` | 鼓励降低功率 |

**运行命令：**

```bash
# 功率控制实验
uv run python experiments/power_control_experiment.py --mode compare --num-uav 50
```

### 3. CSI 量化模块

| 功能 | 参数 | 值 | 说明 |
|------|------|----|------|
| CSI 模式 | `CSI_MODE` | `"quantized"` | 可选 `perfect`/`large_scale`/`quantized` |
| 量化精度 | `Q_BITS` | `4` | 比特数越小精度越低 |

**运行命令：**

```bash
uv run python bin/run_experiment.py --csi-mode quantized --q-bits 4 --seed 42
```

---

## 实验一览

> **⚠️ 重要提示：每个实验都有对应的专用脚本，请勿混用。**
> - 基础吞吐量实验 → `bin/run_experiment.py`
> - 队列感知实验 → `experiments/run_queue_experiment.py`
> - 功率控制实验 → `experiments/power_control_experiment.py`
> - 跨尺度扩展性 → `experiments/scaling_experiment.py`

| 实验 | 命令 | 主要用途 |
|------|------|----------|
| 基础吞吐量 | `bin/run_experiment.py` | 训练 GAT，输出 test utility |
| 队列感知仿真 | `run_queue_experiment.py` | 队列稳定性分析 |
| 功率控制对比 | `power_control_experiment.py` | 调度-功率联合优化 |
| 跨尺度扩展性 | `scaling_experiment.py --mode all` | 模型泛化能力 |
| CSI 不完美性 | `csi_imperfection_study.py` | 信道量化精度影响 |
| 收敛性分析 | `convergence_analysis.py` | 训练样本量分析 |
| 画图 | `utils.plot_paper` | 生成论文图表 |
| TensorBoard | `tensorboard --logdir=./logs/` | 可视化训练曲线 |

### 1. 基础吞吐量实验（推荐入口）

```bash
# 快速验证（不保存，10 条样本）
uv run python bin/run_experiment.py --config configs/exp_example.yaml --seed 42 --dry-run

# 正式训练
uv run python bin/run_experiment.py --config configs/exp_example.yaml --seed 42

# 量化 CSI 实验
uv run python bin/run_experiment.py --config configs/exp_example.yaml \
    --csi-mode quantized --q-bits 4 --seed 42
```

**输出：** `results/models/` 训练模型，`results/all_experiments_summary.xlsx` 汇总数据。

### 2. 队列感知实验

```bash
# 队列感知实验（训练/加载模型 + 多时隙仿真）
uv run python experiments/run_queue_experiment.py --num_uav 30 \
    --arrival_rates 0.5 --num_slots 5000 --seed 42

# 自定义数据集规模
uv run python experiments/run_queue_experiment.py --num_uav 30 \
    --train_size 500 --val_size 64 --test_size 64 --seed 42

# 测试不同全网总到达率；每个 Λ 都会独立生成共享的 channel/arrival trace
uv run python experiments/run_queue_experiment.py --num_uav 30 \
    --arrival_rates 0.5,1.0,2.0,4.0 --num_slots 5000 --seed 42 --mc_runs 5

# 显式指定 Monte Carlo seeds；会覆盖 --mc_runs
uv run python experiments/run_queue_experiment.py --num_uav 30 \
    --arrival_rates 0.5 --num_slots 5000 --mc_seeds 42,43,44,45,46

# 使用本机 conda/pytorch 环境（实时显示训练输出）
conda run --no-capture-output -n pytorch python -u \
    experiments/run_queue_experiment.py --num_uav 30 \
    --arrival_rates 0.5,1.0,2.0,4.0 --num_slots 5000 --seed 42 --mc_runs 5
```

> **注意**：`run_queue_experiment.py` 固定使用队列感知模式。队列数据集保存信道和冲突图快照，训练时不再把某个信道永久绑定到一组固定队列，而是每次前向重新生成 link-level 队列。
> 正式比较 GAT 与 GAT-base 时，推荐使用 `--mc_runs` 或 `--mc_seeds`，避免单次随机到达过程造成误判。

**命令行参数说明：**

| 参数 | 默认值 | 含义 | 什么时候改 |
|------|--------|------|------------|
| `--num_uav` | `30` | UAV 数量；链路数会随拓扑随机生成而变化 | 做不同网络规模实验时修改 |
| `--arrival_rates` | `0.5,1.0,1.5,2.0` | 全网总泊松到达率 Λ，单位 packets/slot；脚本会按 link-level hotspot 模型分配到各链路，并满足 `sum_i λ_i = Λ` | 做负载扫描时修改 |
| `--num_slots` | `5000` | 每个 Λ、每个 MC seed 的仿真时隙数 | 快速测试可设小，正式实验建议 5000 或更大 |
| `--seed` | `42` | 训练/数据加载的主 seed；未指定 `--mc_seeds` 时，也作为 MC seed 起点 | 复现实验时固定 |
| `--mc_runs` | `1` | Monte Carlo 次数；脚本会使用 `seed, seed+1, ...` | 正式比较建议 5-20 |
| `--mc_seeds` | 空 | 显式指定 Monte Carlo seeds，例如 `42,43,44`；优先级高于 `--mc_runs` | 需要严格复现实验批次时使用 |
| `--slots_per_block` | `0` | 信道块长度；`0` 表示整个仿真周期信道固定，正整数表示每 N 个 slot 更新一次信道 | 做快变信道实验时修改 |
| `--train_size` | `500` | 训练快照数量 | 重新训练模型或做样本量实验时修改 |
| `--val_size` | `64` | 验证快照数量 | 通常不用改 |
| `--test_size` | `64` | 测试快照数量 | 通常不用改 |
| `--epochs` | `30` | 训练轮数；若模型文件已存在，则优先加载模型，不会训练 | 重新训练时修改 |
| `--lr` | `1e-4` | 学习率 | 训练不收敛时再调 |
| `--queue_range` | `0,20` | GAT-q 在线训练队列范围；正队列生成后按当前快照最大队列归一化为 `Q/max(Q)` | 主要控制训练中的相对队列结构；修改后需重训 GAT-q |

**Monte Carlo 公平比较逻辑：**

```text
for each λ:
  for each mc_seed:
    生成一套共享 channel trace
    生成一套共享 arrival trace
    GAT / GAT-base / Random / Greedy 都跑同一套随机过程
  对多个 seed 的结果取 mean / std / 95% CI
```

这样做的目的不是固定死某一组到达包数，而是做 paired comparison：同一轮中算法面对完全相同的业务到达，不同轮之间再重新采样，最终用 Monte Carlo 平均降低随机波动。

**实验对比的调度算法：**

| 算法 | 特征输入 | 调度依据 | 说明 |
|------|----------|----------|------|
| `GAT` | `[SNR, Q]` (dim=2) | `Q_i × μ_i`，`μ_i` 为 packet/slot | 队列感知 GAT；空队列链路会被确定性屏蔽 |
| `GAT-base` | `[SNR]` (dim=1) | 纯 `R_i` | 非队列 GAT baseline |
| `Random` | — | 均匀概率 | 随机调度 |
| `Greedy` | `[SNR]` | SNR 排序 | 贪心选 SNR 最高链路 |
| `MWS-Greedy` | 全局 Q + 全局信道增益 | 逐步加入并重算 `ΣQ_iμ_i` | 集中式 MWS 贪心近似；不是穷举最优 |

> 通过 GAT vs GAT-base 对比可验证"队列感知特征"是否有额外价值。

**核心公式：**

```
μ_i(t) = π_i(t) × R_i(t) × B × τ / L   (可服务量，packets/slot)
D_i(t) = min(Q_i(t), μ_i(t))               (实际发送量)
Q_i(t+1) = max(0, Q_i(t) - D_i(t)) + A_i(t)   (Lindley 方程)
Loss = -Σ_i Q_i(t)μ_i(t) / (Σ_i Q_i(t) + eps)
```

队列训练使用 stochastic STE：前向随机采样二元 `pi`，反向通过连续概率传递梯度；验证和仿真使用验证集校准的全局阈值进行硬调度。验证使用固定队列 seed，并只按硬调度 MWS utility 选择和恢复最佳 checkpoint。

### 3. 功率控制实验

```bash
# 对比实验（有 vs 无功率控制）
uv run python experiments/power_control_experiment.py --num-uav 50 --train-size 300

# 仅运行功率控制模式
uv run python experiments/power_control_experiment.py --mode power-control-only --power-penalty 0.05

# 网格搜索最优 λ
uv run python experiments/power_control_experiment.py --mode grid-search \
    --power-penalty-search 0.001 0.01 0.05 0.1 0.5
```

### 4. 跨尺度扩展性实验

```bash
# 配对泛化（训练 X → 测试 Y）
uv run python -m experiments.scaling_experiment --mode paired --use-existing-models

# 混合训练
uv run python -m experiments.scaling_experiment --mode mixed

# 全部实验 + 快速模式
uv run python -m experiments.scaling_experiment --mode all --quick
```

### 5. CSI 不完美性实验

```bash
# 默认跑所有模式
uv run python experiments/csi_imperfection_study.py --gpu-id 0

# 跑 numUAV=50，测试 2/4/6/8 bit 量化
uv run python experiments/csi_imperfection_study.py --num-uav 50 --quantized-bits 2 4 6 8
```

### 6. 收敛性分析

```bash
uv run python -m experiments.convergence_analysis --gpu-id 0
```

---

## 队列感知仿真详解

### 物理场景

每个时隙的流程：

```
┌──────────────────────────────────────────────────────┐
│  时隙 t                                              │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐           │
│  │ 业务到达  │  │  MAC调度  │  │  物理传输  │           │
│  │ A_i~Poi(λ)│→ │ π_i(t)=0/1│→ │ R_i(SNR)  │           │
│  │(包/时隙) │  │ (链路激活) │  │ (bps/Hz)  │           │
│  └──────────┘  └──────────┘  └──────────┘           │
│       ↓              ↓              ↓                 │
│  队列更新:        发送决策:       发送包数:          │
│  Q_i += A_i       π_i ∈ {0,1}    D_i = π_i ×      │
│                                    R_i×B×τ/L          │
└──────────────────────────────────────────────────────┘
```

### 关键参数说明

| 参数 | 来源 | 说明 | 单位 |
|------|------|------|------|
| `arrival_lambda` | `--arrival_rates` | 全网总泊松到达均值 Λ；脚本内部再生成每条链路的 `λ_i` | packets/slot |
| `num_slots` | `--num_slots` | 每个到达率、每个 MC seed 的仿真时隙数 | slots |
| `slot_duration` | config / 默认值 | 时隙长度 τ | 秒 |
| `packet_size` | config / 默认值 | 包大小 L | bits |
| `bandwidth` | config / `NetworkState` | 带宽 B，用于把 `R_i` 换算成 packets/slot | Hz |
| `slots_per_block` | `--slots_per_block` | 信道块长度；`0` 为全程固定信道，正整数为每 N 个 slot 更新一次 | slots |
| `mc_runs` | `--mc_runs` | Monte Carlo 次数；用于降低随机到达过程的偶然性 | runs |
| `mc_seeds` | `--mc_seeds` | 显式 MC seed 列表；优先级高于 `mc_runs` | — |

**内部接口说明：**

| 参数 | 所在位置 | 是否命令行参数 | 作用 |
|------|----------|----------------|------|
| `channel_realizations` | `QueueSimulator.run()` | 否 | 预生成信道块；同一 MC seed 内所有调度算法共享 |
| `arrival_realizations` | `QueueSimulator.run()` | 否 | 预生成到达矩阵，shape 为 `[num_slots, num_links]`；同一 MC seed 内所有调度算法共享 |
| `include_queue_feature` | `QueueSimulator(...)` | 否 | 控制模型输入是否包含队列特征；GAT 使用 `[SNR, Q]`，GAT-base 只使用 `[SNR]` |

`arrival_realizations` 不需要手动设置。正常运行 `run_queue_experiment.py` 时，脚本会根据 `--arrival_rates` 和 `--mc_seeds` 自动生成它。

### GAT-q MWS v3 训练逻辑

1. 对每个信道/拓扑快照，每次训练前向都重新生成队列，因此同一信道会在不同 epoch 遇到不同的队列优先级。
2. 先均匀采样非空链路数 `K in [1, num_links]`，再从 `--queue_range` 中生成 `K` 个正队列；未选链路队列为 0。
3. 队列输入使用相对尺度 `Q_i / max_j Q_j`，因此把所有队列同时放大不会改变输入排序；SNR 和相对队列再使用训练统计进行标准化。
4. 最终调度头输入是 `[GAT embedding, normalized local SNR, normalized local Q]`。GAT embedding 表示邻居干扰/队列聚合信息，local skip 保留本链路状态。
5. 训练使用 stochastic STE：前向采用 Bernoulli 二元激活，反向使用 sigmoid 概率的梯度近似，减少连续目标将所有概率推向 1 后再阈值化的退化。
6. Loss 使用原始 packet 队列和 packet/slot 服务量；`sum(Q)` 只作为决策无关的梯度尺度，不改变单快照 MWS 的 argmax。
7. 空队列链路在训练和仿真中都执行 `pi_i=0`，不让无数据链路占用干扰资源。
8. 验证阶段从固定队列快照的概率分位点中选择一个全局阈值，以最大化硬 MWS utility；不再用 soft utility 作为平局裁决，避免保存后期全激活模型。

每次验证会输出以下诊断：

| 诊断字段 | 含义 |
|----------|------|
| `soft_utility` | 连续 `pi` 下的平均 MWS utility；仅在硬效用完全相同时作为 checkpoint 次级排序 |
| `soft_hard_gap` | 连续 `pi` 与阈值二值调度的 MWS utility 相对差异 |
| `raw_empty_activation_rate` | 施加空队列 mask 前，模型对空队列输出 `pi>0.5` 的比例 |
| `queue_probability_change` | 固定信道和非空集合，交换正队列大小后调度概率的平均变化 |
| `queue_hard_decision_change` | 交换队列大小后，二值调度改变的链路比例 |
| `snr_probability_change` | 固定队列和拓扑，打乱 SNR 后调度概率的平均变化 |
| `snr_hard_decision_change` | 打乱 SNR 后，二值调度改变的链路比例 |
| `hard_active_fraction` | 所有链路中被硬激活的平均比例 |
| `nonempty_activation_rate` | 非空链路中被硬激活的平均比例 |
| `average_active_links` | 每个时隙平均激活链路数 |
| `average_mws_utility` | 仿真中 `sum(Q(t) × service(t))` 的时均值 |
| `score_p01/p50/p99` | 调度 logit 分位数；用于检查是否再次出现极端饱和 |

**到达率怎么选：**

`--arrival_rates` 中的 Λ 是全网总到达率，不再是 per-link 到达率。当前默认使用 link-level hotspot 业务模型：随机选择约 20% 链路作为热点链路，让它们承担 70% 总业务；其余约 80% 链路承担 30% 背景业务。每条链路的到达率满足：

```text
sum_i lambda_i = Lambda

i in hotspot:
    lambda_i = 0.7 * Lambda / num_hotspot_links

i not in hotspot:
    lambda_i = 0.3 * Lambda / num_normal_links
```

例如当前拓扑有 `num_links=80`，且 `Λ=4 packets/slot`，则全网平均每 slot 到达约 4 个包，不会再变成 `4 × 80` 个包。热点链路的 per-link 到达率约为普通链路的 9 倍，因此更容易形成重点中继/热点区域的队列压力。建议先用 `0.5,1.0,2.0,4.0,8.0` 做短仿真扫描，再选择低负载、中等负载、过载三组点做正式 MC 实验。

### 性能指标

| 指标 | 说明 | 单位 |
|------|------|-------|
| `final_avg_queue` / `avg_queue` | 仿真结束时的平均队列长度；`avg_queue` 是历史兼容别名 | packets |
| `final_max_queue` / `max_queue` | 仿真结束时的最大队列长度；`max_queue` 是历史兼容别名 | packets |
| `long_term_avg_queue` | 长期平均队列长度 | packets |
| `average_queue_backlog` | 平均队列积压，等价于 `long_term_avg_queue` 的论文指标命名 | packets/link |
| `average_queue_backlog_mbit` | 平均队列积压换算成 Mbit | Mbit/link |
| `average_delay_slots` | Little's law 估计的平均排队时延 | slots |
| `average_delay_ms` | Little's law 估计的平均排队时延 | ms |
| `throughput_ratio` | 吞吐量比（departures/arrivals） | 无量纲，≈1 表示稳定 |
| `throughput_mbps` | 实际网络总吞吐量 | Mbps |
| `departure_rate_pps` | 每链路平均发送速率 | packets/slot |
| `arrival_total_rate_pps` | 全网每时隙平均到达包数 | packets/slot |
| `departure_total_rate_pps` | 全网每时隙平均发送包数 | packets/slot |
| `hotspot_avg_queue_mbit` | 热点链路平均队列积压 | Mbit/link |
| `normal_avg_queue_mbit` | 普通链路平均队列积压 | Mbit/link |
| `queue_overflow_prob` | 溢出概率（Q > 50 的比例） | — |
| `is_stable` | 最近窗口内队列增长斜率是否接近 0 | True/False/None |

**读结果时优先看：**

1. `average_queue_backlog_mbit`：平均队列积压，对应 MAB 论文 Fig.4 类似指标。
2. `average_delay_ms`：平均时延估计，对应 MAB 论文 Fig.5 类似指标。
3. `long_term_avg_queue`：长期平均队列，更适合评价整体队列稳定性。
4. `final_avg_queue`：最后时刻队列，对尾部随机波动更敏感。
5. `throughput_ratio`：实际发送包数 / 到达包数；在过载场景下通常远小于 1。
6. `*_ci95`：Monte Carlo 95% 置信区间半宽。若两个算法均值差小于 CI，不能轻易说谁显著更好。

当前 `average_delay_ms` 是 Little's law 估计：

```text
average_delay_slots = average_queue_backlog / departure_rate_pps
average_delay_ms    = average_delay_slots × slot_duration × 1000
```

这个口径不需要逐包 FIFO 记录，适合当前队列仿真快速对比。若后续需要严格统计 “successfully delivered packets” 的真实等待时间，需要额外维护每条链路的 packet age 队列。
如果某个方法在某个 MC seed 中没有成功发送任何包，则该轮 delay 无定义，结果中会记为 `None`；汇总表会显示 `N/A` 或仅对有效 delay 样本求平均。

> **关键对比**：GAT vs GAT-base 决定了队列感知特征 `[SNR, Q]` 是否有额外价值。

---

## 项目结构

```
GNN_Scheduling/
├── bin/
│   └── run_experiment.py        # CLI 统一入口（基础吞吐量实验）
│
├── configs/
│   └── exp_example.yaml         # 基础配置（所有复杂功能默认关闭）
│
├── models/
│   └── model.py                 # GATScheduler、calculate_achievable_rate
│
├── experiments/
│   ├── runner.py                # ExperimentRunner：实验编排器
│   ├── run_queue_experiment.py  # 队列感知调度实验
│   ├── csi_imperfection_study.py # CSI 不完美性实验
│   ├── scaling_experiment.py    # 跨尺度扩展性实验
│   ├── convergence_analysis.py  # 收敛性分析
│   ├── power_control_experiment.py # 功率控制实验
│   └── compare_gat_vs_spatial_dl.py # GAT vs Spatial DL 对比
│
├── simulator/
│   ├── __init__.py            # 模块说明文档
│   ├── base.py                # BaseSimulator、SimpleSimulator
│   └── queue_simulator.py     # QueueSimulator：队列感知仿真器
│
├── train/
│   └── trainer.py              # 训练循环、梯度裁剪、早停
│
├── utils/
│   ├── baseline.py             # 基线算法（Random/Greedy/FPLinQ/Spatial DL）
│   ├── network_generate.py     # 数据生成器、NetworkState
│   ├── plot_paper.py          # 论文图表绘制
│   ├── plot_config.py          # 配色方案
│   └── io.py                  # 文件 I/O、Excel 读写
│
├── results/                    # 实验结果（详见「结果文件详解」章节）
│
└── logs/
    └── tensorboard/            # TensorBoard 训练日志
```

---

## 结果文件详解

### 目录结构

```
results/
├── models/                                   # 标准模型库（共用）
│   ├── gat_numUAV=<N>.pth                   # 非队列模型（raw_node_dim=1）
│   ├── gat_queue_mws_v3_numUAV=<N>.pth      # 队列感知 MWS v3（raw_node_dim=2）
│   ├── scaling_numUAV<N>.pth                # 跨尺度实验模型（配对泛化）
│   └── mixed_numUAV20_30_40_50.pth          # 混合尺度训练模型
│
├── exp_<numUAV>_<timestamp>/                # 基础吞吐量实验输出（bin/run_experiment.py）
│   ├── exp_<numUAV>_<timestamp>_per_epoch.json  # 每 epoch 训练日志
│   ├── exp_<numUAV>_<timestamp>_model.pth       # 训练模型快照
│   └── exp_<numUAV>_<timestamp>_baselines.json  # 基线算法对比结果
│
├── queue_exp<timestamp>_s<seed>_mc<K>/      # 队列感知实验输出（run_queue_experiment.py）
│   ├── simulation_results.json              # Monte Carlo 汇总结果 JSON
│   ├── simulation_runs.json                 # 每个 MC seed 的紧凑明细
│   ├── trajectory_lambda<λ>.png             # 队列长度/发送量/吞吐量轨迹图
│   ├── queue_backlog_delay_vs_lambda.png    # 平均队列积压/平均时延随 λ 变化图
│   └── queue_comparison_bar.png             # 各算法最终平均队列长度柱状图
│
├── img/                                      # 论文图表（utils/plot_paper.py 生成）
│   ├── baseline_comparison.{eps,png}        # 各算法吞吐量对比
│   ├── training_curves_val_utility.{eps,png}# 验证集效用训练曲线
│   ├── training_curves_train_loss.{eps,png} # 训练 Loss 曲线
│   ├── performance_vs_samples.{eps,png}     # 性能随训练样本量变化
│   └── csi_imperfection.{eps,png}           # CSI 量化精度影响
│
└── all_experiments_summary.xlsx             # 所有实验汇总表
```

### 模型文件说明

| 文件名 | 训练脚本 | 节点特征 | Loss 函数 | 用途 |
|--------|----------|----------|-----------|------|
| `gat_numUAV=10.pth` | `bin/run_experiment.py` | `[SNR]` (dim=1) | `-Σ R_i`（纯吞吐量） | 基础 GAT 调度 |
| `gat_queue_mws_v3_numUAV=10.pth` | `run_queue_experiment.py` | `[SNR, Q/max(Q)]` (dim=2) | stochastic STE 下的 `-Σ(Q_i × μ_i)/ΣQ_i` | 相对队列 + 硬前向 MWS v3 |
| `scaling_numUAV20/30/40/50.pth` | `scaling_experiment.py` | `[SNR]` (dim=1) | `-Σ R_i` | 配对泛化实验 |
| `mixed_numUAV20_30_40_50.pth` | `scaling_experiment.py` | `[SNR]` (dim=1) | `-Σ R_i` | 混合尺度训练 |

> 注意：`scaling_*.pth` 命名不带 `=`，`gat_*_numUAV=*.pth` 带 `=`。

> **注意**：`gat_numUAV=<N>.pth` 是原有非队列 baseline；`gat_queue_mws_v3_numUAV=<N>.pth` 是本轮尝试的队列模型，其 checkpoint 包含版本、队列特征、训练决策方式、输入统计和 `queue_range`。旧 v2/v1 队列模型不会被新队列实验自动加载。

### 实验目录命名规则

**基础实验** `exp_<numUAV>_<YYYYMMDD>_<HHMM>`：
- `exp_20_20260130_2147`：numUAV=20，2026年1月30日 21:47 运行

**队列实验** `queue_exp<YYYYMMDD>_<HHMM>_s<seed>_mc<K>`：
- `queue_exp20260707_2323_s42_mc2`：队列实验，2026年7月7日 23:23，训练 seed=42，Monte Carlo 共 2 轮
- `s<seed>` 表示训练/数据加载主 seed；未显式指定 `--mc_seeds` 时，MC seeds 默认为 `seed, seed+1, ...`
- `mc<K>` 表示 Monte Carlo 轮数；正式比较时建议 `K>=5`

### Queue 实验结果解读（simulation_results.json）

`simulation_results.json` 保存 Monte Carlo 汇总结果。每个实验对比 4 种调度算法，字段含义如下：

| 算法 | 说明 | 特征输入 | 调度依据 |
|------|------|----------|----------|
| `GAT` | 队列感知 GAT | `[SNR, Q]` | `Q_i × R_i` 加权 |
| `GAT-base` | 非队列 GAT | `[SNR]` | 纯 `R_i` 最大化 |
| `Random` | 随机调度 | — | 均匀概率激活 |
| `Greedy` | 贪心调度 | `[SNR]` | 选 SNR 最高的链路 |

结果按全网总到达率 Λ 分组，格式为 `<algo>_<Λ>`（如 `GAT_0.5`）。每个 key 下包含标量均值、标准差、95% CI 和平均轨迹。关键指标：

| 指标 | 说明 | 稳定判断 |
|------|------|----------|
| `num_mc_runs` | Monte Carlo 轮数 | 越大越稳，但运行越慢 |
| `mc_seeds` | 实际使用的 MC seeds | 用于复现 |
| `final_avg_queue` | 仿真结束时平均队列长度 | 越小越好，但对尾部随机波动敏感 |
| `long_term_avg_queue` | 全时隙、全链路平均队列长度 | 更适合评价长期队列性能 |
| `average_queue_backlog_mbit` | 平均队列积压，Mbit/link | 越小越好 |
| `average_delay_ms` | Little's law 估计平均时延 | 越小越好 |
| `throughput_ratio` | 吞吐量比（departures/arrivals） | 越接近 1 越接近稳定 |
| `throughput_mbps` | 实际总吞吐量 | 越大越好 |
| `total_arrivals` | 总到达包数 | paired MC 下同一 Λ、同一 seed 内各算法相同 |
| `total_departures` | 总发送包数 | 越大通常越好 |
| `arrival_total_rate_pps` | 全网平均到达包数/slot | 应接近输入的 Λ |
| `departure_total_rate_pps` | 全网平均发送包数/slot | 反映实际服务能力 |
| `hotspot_avg_queue_mbit` | 热点链路平均 backlog | 越小越能说明热点 QoS 得到照顾 |
| `normal_avg_queue_mbit` | 普通链路平均 backlog | 用于观察是否过度牺牲普通链路 |
| `*_std` | 多个 MC seed 下的标准差 | 越小说明结果越稳定 |
| `*_ci95` | 均值的 95% 置信区间半宽 | 用于判断差异是否显著 |
| `is_stable` | 最近窗口内队列增长斜率是否接近 0 | `None` 表示仿真太短无法判断 |

`simulation_runs.json` 保存每个 MC seed 的明细，key 形如 `GAT_0.5_seed42`。为了避免文件过大，它不保存完整二维 `queue_trajectory`，只保留标量指标、一维轨迹和本轮使用的 hotspot arrival profile。

### 图片说明

| 图片文件 | 生成函数 | 数据来源 | 说明 |
|----------|----------|----------|------|
| `baseline_comparison` | `plot_baseline_comparison()` | `all_experiments_summary.xlsx` Sheet1 | GAT vs 基线算法吞吐量柱状图 |
| `training_curves_val_utility` | `plot_training_curves(metric='val_utility')` | 各 `exp_*/_per_epoch.json` | 验证集效用随 epoch 变化 |
| `training_curves_train_loss` | `plot_training_curves(metric='train_loss')` | 各 `exp_*/_per_epoch.json` | 训练 Loss 随 epoch 变化 |
| `performance_vs_samples` | `plot_performance_vs_samples()` | `all_experiments_summary.xlsx` Sheet2 | 性能随训练样本量变化（收敛性分析） |
| `csi_imperfection` | `plot_csi_imperfection()` | `all_experiments_summary.xlsx` Sheet3 | CSI 量化精度（2/4/6/8/10 bit）影响 |
| `trajectory_lambda<λ>.png` | `_plot_trajectories()` | `queue_exp*/simulation_results.json` | 队列长度/发送量/吞吐量随时隙变化轨迹 |
| `queue_comparison_bar.png` | `_plot_trajectories()` | `queue_exp*/simulation_results.json` | 各算法平均队列长度柱状对比 |
| `queue_backlog_delay_vs_lambda.png` | `_plot_trajectories()` | `queue_exp*/simulation_results.json` | 类似 MAB Fig.4/Fig.5，展示平均队列积压和平均时延随 λ 的变化 |

> 生成图片命令：`uv run python utils/plot_paper.py --plot <type>`，`<type>` 可选 `all`、`baseline`、`training`、`samples`、`csi`。

---

## 研究日志（Changelog）

> 本章节按时间顺序记录项目的每次重要迭代，包括成功的模块、失败的尝试、以及背后的理论分析。其他 chat 可以通过此日志快速了解项目全貌，避免重复踩坑。

---

### v0.5 - GAT-q MWS v3 与集中式 MWS baseline

**时间：** 2026 年 7 月

**尝试方向：** 针对 v2 模型出现“几乎所有非空链路都激活”的现象，加入 stochastic STE，使训练前向直接看到二元调度；将队列输入改为 `Q/max(Q)`；增加验证集全局阈值校准；补充 SNR/队列反事实敏感性、激活链路数和非空队列命中率等诊断。

**新增 baseline：** `MWS-Greedy (global CSI)` 使用全局队列和全局信道增益，按 `Σ Q_i μ_i` 目标逐步尝试加入链路，每次重新计算候选组合的实际 SINR，并做删除改进。它是集中式 MWS 的贪心近似，不是 `2^L` 组合空间上的精确最优解；加入它的目的是量化 GAT 与可解释的 MWS 求解上限之间的差距。

**理论判断：** 参考本地 GAT 论文，连续概率训练确实存在 all-ones collapse 风险，但论文也指出学习率和梯度稳定性是重要触发因素。因此本次不再把连续/二元差异当作唯一原因，而是把它与队列权重、独立 sigmoid、空队列外部 mask 和验证阈值一起作为联合诊断对象。

**验证重点：** `queue_hard_decision_change` 与 `snr_hard_decision_change` 是否同时大于 0；`average_active_links` 是否从“几乎全部非空链路”下降到合理的空间复用规模；GAT 的 `average_mws_utility` 是否接近 MWS-Greedy；以及 λ=1、2、5、10 下的 backlog、delay 和 throughput 是否保持优势。

**小规模 smoke 结果：** 30 个训练快照、3 epoch、30 slot 的测试中，λ=1 时 MWS-Greedy throughput ratio=0.955、GAT=0.250、Random=0.060。v3 的受控输入测试中，交换队列约改变 4.2% 的硬决策，打乱 SNR 约改变 8.8% 的硬决策；这说明模型开始利用两类输入，但距离 MWS-Greedy 仍有明显差距。

**数据/模型影响：** 信道/拓扑数据仍可复用；队列模型路径升级为 `gat_queue_mws_v3_numUAV=<N>.pth`，需要重新训练。旧 v2 模型保留作失败对照，不会自动加载。该版本仍是实验性尝试，不能直接作为最终论文模型。

### v0.4 - GAT-q MWS v2

**时间：** 2026 年 7 月

**核心修改：** 保留原 4 层 GAT 和连续 `pi` 训练，不增加手工正队列系数或额外惩罚项；改为输入分通道标准化、每次前向重采样稀疏队列、packet/slot MWS loss、空队列确定性 mask，并在最终调度头中拼接标准化后的本链路 SNR/Q。训练结束恢复 hard-validation utility 最好的 checkpoint，避免保存后期饱和模型。

**当前验证：** 小型对照已确认 local skip 能使队列交换改变二值调度，并明显提高硬验证 MWS utility。下一步是使用正式训练规模和 paired Monte Carlo 比较 backlog、delay 与 throughput；如果长期队列指标仍然无改善，再转向两阶段调度。

---

### v0.3 — 早期队列感知实验（历史记录，结论需重新评估）

**时间：** 2026 年 5 月

**目标：** 在 GAT 调度中加入队列长度信息，使调度器能够优先服务积压严重的链路，提升网络稳定性。

**实现方式：**
- 节点特征扩展：`[SNR]` → `[SNR, Q]`，即在输入特征中加入当前队列长度
- Loss 函数修改：`L = -Σ R_i` → `L = -Σ(Q_i × R_i)`，即 MWS（Maximum Weight Scheduling）加权效用
- 理论依据：Lyapunov 优化框架下的队列稳定性分析

**早期实验结果：**

| 指标 | GAT（队列感知） | GAT-base（非队列） |
|------|---------------|-----------------|
| 平均队列长度 | 更差 | 更好 |
| 吞吐量比 | 更差 | 更好 |
| 稳定性 | 更差 | 更好 |

**当时的失败原因判断：**

早期分析曾认为 MWS 加权 loss 在本场景下可能不适用，主要理由包括：

1. **证明前提失效**：Lyapunov 稳定性证明中要求 `π² = π`（二元调度）以及服务率恒定。但我们的场景中：
   - 调度值是连续概率 `π ∈ [0,1]`（而非二元 0/1）
   - 服务率由 Shannon 公式 `R = log₂(1+SINR)` 决定，是随信道连续变化的
   - 这使得 Lyapunov drift-plus-penalty 中的 `π² = π` 恒等式完全失效

2. **均匀到达抹平差异化需求**：所有链路的到达率 λ 相同，调度器无法从队列状态中识别"哪条链路更需要服务"

3. **训练-仿真分布不匹配**：训练时使用 `uniform(0, 500)` 的队列快照，仿真时使用 Poisson 累积队列

**后续修正：** 结合后续代码检查和 MAB/Lyapunov 论文讨论，早期结论不能直接作为最终判断。连续 Shannon rate 并不必然使 Lyapunov/MWS 思路失效；早期 GAT-q 表现差可能混有实现 bug、队列特征同步问题、link-level/UAV-level 队列语义错位、单次随机到达波动、以及负载设置过载等因素。因此当前更合理的做法是：先在修正后的 link-level 队列、动态队列同步、paired Monte Carlo 公平比较口径下重新评估 GAT-q，再决定是否转向 “GAT 学空间速率结构 + 队列感知 MWS/排序调度” 的 model-based 方案。

**相关脚本：** `experiments/run_queue_experiment.py`

**当前状态：** 代码中保留 `use_queue` 参数和 `raw_node_dim=2` 的支持。该路线尚未最终放弃，后续应以 Monte Carlo 汇总后的 `long_term_avg_queue`、`final_avg_queue`、`throughput_ratio` 及置信区间作为判断依据。

---

### v0.2 — 功率控制模块（已实现，效果有限）

**时间：** 2026 年 4-5 月

**目标：** 在 GAT 输出中增加功率控制头，使调度器不仅决定"哪些链路激活"，还决定"每条链路开多大功率"。

**实现方式：**
- GAT 输出双头：`[π_i, α_i]`，其中 `π_i ∈ [0,1]` 为激活概率，`α_i ∈ [0,1]` 为功率缩放因子
- 可达速率修改为：`R_i = α_i × log₂(1 + α_i × SINR_i / Γ)`，其中 Γ 为 SNR gap
- Loss 添加功率惩罚项：`L = -Σ R_i + λ × Σ α_i`

**实验结果：** 在密集集群（链路数足够多）场景下，功率控制**几乎没有效果提升**。

**原因分析：** 密集集群中，调度决策（"选择开哪几条链路"）已经是决定性能的主要因素。由于可选链路数量充足，简单地通过调度选择"开最好的那几条"已经接近性能上界。功率控制（"每条链路开多亮"）在这个基础上的边际收益极小。

**结论：** 功率控制在密集集群基础调度中价值有限。但如果在以下方向扩展，可能仍有意义：
- 与**队列感知**结合：优先为积压严重的链路分配更高功率
- 与**安全约束**结合：为某些链路设定最小功率保证
- 与**时间记忆模型**结合：在信道动态变化时动态调整功率

**相关脚本：** `experiments/power_control_experiment.py`

**遗留代码：** `models/model.py` 中仍保留 `use_power_control` 和双头输出的实现，代码路径未被删除。

---

### v0.1 — CSI 量化模块（已验证，效果良好）

**时间：** 2026 年 3 月

**目标：** 研究信道状态信息（CSI）不完美性对调度性能的影响。

**实现方式：**
- 三种 CSI 模式：
  - `perfect`：理想信道状态
  - `large_scale`：仅大尺度衰落（路径损耗 + 阴影），不含小尺度
  - `quantized`：对 SNR 做 q-bit 量化（q = 2, 4, 6, 8）
- 距离量化：对链路距离做 q-bit 二进制编码作为边特征

**实验结果：** 4-bit 以上量化性能接近完美 CSI，2-bit 量化有明显下降。

**相关脚本：** `experiments/csi_imperfection_study.py`

---

### v0.0 — 基础 GAT 调度（核心模块）

**时间：** 2026 年 3 月之前

**目标：** 构建基于 GAT 的链路调度框架，最大化全网总吞吐量。

**核心设计：**
- 冲突图建模：节点 = 链路，边 = 干扰关系，边权重 = 干扰强度
- GAT 消息传递：迭代地从局部邻居学习整体网络态势
- Loss 函数：`L = -Σ R_i`，直接最大化可达速率之和
- 自环机制：添加自环确保节点自身信息不丢失

**相关脚本：** `bin/run_experiment.py`，`experiments/scaling_experiment.py`

---

### 进行中 — 时空结合模型（STGNN）

**目标：** 将 GAT（空间推理）与 LSTM/GRU（时间记忆）结合，处理以下场景：
- **动态信道**：UAV 移动导致大尺度信道连续变化
- **队列历史**：队列长度的时序积累规律
- **QoS 公平性**：通过时间记忆实现长期公平性保证

**技术路线：**
- 信道模型升级：从 block fading 升级到 3GPP TR 38.901 大尺度衰落（路径损耗 + 阴影衰落随位置连续变化）
- 时间模型选型：**LSTM**（优于 GRU，原因见下）
- 架构设计：**GRU 先融合时间 → 作为 GAT 的输入特征**（方式 B，保持 GAT 空间模块相对独立）
- Loss 函数：**仍是 `-Σ π_i × R_i`**，不包含 Q。时间记忆通过 GRU 的隐状态隐式传递

**LSTM 优于 GRU 的理由：**
- RouteNet-Fermi (Purdue 2024) 的 ablation：在吞吐量相关指标上 LSTM 优于 GRU
- LSTM 的 cell state 提供显式长期存储，适合队列历史积累
- 参数量差异不大（LSTM 多约 20% 参数，但你的网络规模下可忽略）

**审稿人问题准备（Q: Why LSTM/GRU instead of ...）：**
> "We evaluate both LSTM and GRU as temporal encoders following the ablation study of RouteNet-Fermi [ref]. LSTM consistently achieves better performance on throughput-related metrics. The explicit memory cell in LSTM provides more stable long-term storage for queue state evolution, which aligns with our goal of capturing channel correlation over UAV trajectories. This is further supported by Chung et al. [2014], which demonstrates LSTM's superior capability in capturing long-range dependencies."

**待实现（TODO）：**
- [ ] 修改 `NetworkGenerator` 支持时序生成（UAV 轨迹 → 位置 → 3GPP 信道）
- [ ] 修改 `QueueSimulator` 支持动态信道（`slots_per_block` 参数）
- [ ] 实现 LSTM/GAT 联合模型类
- [ ] 生成多时隙序列训练数据
- [ ] BPTT 端到端训练

---

## 关键模块说明

### models/model.py — GATScheduler

| 参数 | 说明 |
|------|------|
| `raw_node_dim` | 节点原始特征维度（`USE_QUEUE=false` 时为 1，`USE_QUEUE=true` 时为 2）|
| `embed_node_dim` | 节点嵌入维度 |
| `edge_dim` | 边特征维度（干扰权重）|
| `num_heads` | 多头注意力头数 |
| `T_iterations` | GAT 消息传递轮数 |
| `gat_out_dim` | GAT 层总输出维度 |

**输入：** `[num_links, raw_node_dim]` 节点特征 + `[2, num_edges]` 边索引 + `[num_edges, 1]` 边特征
**输出：** `[num_links, 1]` 每条链路的激活概率 `π_v ∈ [0,1]`

### utils/baseline.py — 基线算法

| 算法 | 说明 |
|------|------|
| Random | 随机选择链路 |
| Simple Greedy | 贪心选 SNR 最高的链路 |
| Local Greedy | 局部干扰感知的贪心调度 |
| FPLinQ | 分数规划调度算法（Cui et al. 2019） |
| Spatial DL | 空间深度学习方法（Cui et al. 2019） |

### simulator/ — 仿真器模块

| 类 | 说明 |
|----|------|
| `BaseSimulator` | 仿真器抽象基类 |
| `SimpleSimulator` | 单时隙评估（无队列，用于训练） |
| `QueueSimulator` | 多时隙队列仿真（用于队列感知实验） |

**QueueSimulator 使用注意：**
- `include_queue_feature` 必须与模型训练时的 `USE_QUEUE` 一致
- `arrival_lambda` 需选择合理值（过大则队列爆炸）

---

## 训练监控

```bash
tensorboard --logdir=./logs/
```

浏览器打开 `http://localhost:6006`，查看：

- `train_loss`：训练 loss 曲线
- `val_utility`：验证集效用曲线
- `pi_mean` / `pi_std`：链路平均激活概率

---

## 注意事项

1. **参数管理**：所有超参数集中于 `configs/exp_example.yaml`，不要直接改代码。
2. **实验复现**：务必使用 `--seed` 设置随机种子，相同 seed + 相同配置 = 相同结果。
3. **数据集缓存**：按 `NUM_UAV` 分离；修改后会自动生成新数据集。
4. **GPU 选择**：多卡环境下用 `--gpu-id` 指定。
5. **Excel 汇总**：`ExperimentRunner` 自动将每次运行结果追加到 `results/all_experiments_summary.xlsx`。
6. **防呆设计**：队列感知实验中若参数不一致，会打印 ERROR 并终止运行。
