#!/usr/bin/env python3
"""Train one queue-conditioned graph negotiation round from physical contrasts."""

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.exp_fixed_csi_snapshot_utility import queue_snapshot  # noqa: E402
from models.channel_context_reuse import (  # noqa: E402
    ConditionalNegotiationReadout,
    solo_spectral_efficiency,
)
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
)
from train.train_channel_context_readout import (  # noqa: E402
    evaluate_schedulers,
    remove_local_neighborhood,
    unique_conflict_pairs,
)
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


def generate_graph_dataset(
    generator, channel_model, readout, graph_start, num_graphs,
    queues_per_graph, pairs_per_queue, seed
):
    records = []
    attempted = ties = positives = 0
    pure = PurePhysicalReuseScheduler(channel_model)
    for graph_offset in range(num_graphs):
        graph_seed = int(seed + graph_start + graph_offset)
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        with torch.no_grad():
            _, embedding = channel_model.encode(
                state.vertex_features[:, :1], state.edge_index, state.edge_weights
            )
        solo = solo_spectral_efficiency(state)
        pairs = unique_conflict_pairs(state.edge_index)
        rng = np.random.default_rng(graph_seed + 700_001)
        for queue_idx in range(queues_per_graph):
            queues = queue_snapshot(
                state.num_vertices, graph_seed + 100_003 + queue_idx
            )
            candidates = [
                pair for pair in pairs
                if queues[pair[0]] > 0 and queues[pair[1]] > 0
            ]
            if not candidates:
                continue
            chosen = rng.choice(
                len(candidates), size=min(pairs_per_queue, len(candidates)),
                replace=False,
            )
            base = pure.localmax.schedule_with_state(state, queues).reshape(-1)
            features = readout.features(
                embedding, queues, solo, state.edge_index
            ).detach()
            lefts, rights, log_diffs, labels = [], [], [], []
            for index in np.asarray(chosen).reshape(-1).tolist():
                left, right = candidates[int(index)]
                context = remove_local_neighborhood(
                    base, (left, right), state.edge_index
                )
                base_left, base_right = context.clone(), context.clone()
                base_left[left], base_right[right] = 1.0, 1.0
                action_left, _, _ = complete_physical_reuse_from_base(
                    state, queues, base_left
                )
                action_right, _, _ = complete_physical_reuse_from_base(
                    state, queues, base_right
                )
                utility_left = mws_objective(action_left, queues, state)
                utility_right = mws_objective(action_right, queues, state)
                attempted += 1
                scale = max(abs(utility_left), abs(utility_right), 1.0)
                if abs(utility_left - utility_right) <= 1e-6 * scale:
                    ties += 1
                    continue
                if rng.random() < 0.5:
                    left, right = right, left
                    utility_left, utility_right = utility_right, utility_left
                label = float(utility_left > utility_right)
                lefts.append(left)
                rights.append(right)
                log_diffs.append(float(torch.log(
                    (queues[left] * solo[left]).clamp_min(1e-12)
                ) - torch.log(
                    (queues[right] * solo[right]).clamp_min(1e-12)
                )))
                labels.append(label)
                positives += int(label)
            if labels:
                records.append({
                    "features": features,
                    "edge_index": state.edge_index.detach(),
                    "edge_attr": state.edge_weights.detach(),
                    "left": torch.tensor(lefts, dtype=torch.long),
                    "right": torch.tensor(rights, dtype=torch.long),
                    "log_base_diff": torch.tensor(log_diffs),
                    "label": torch.tensor(labels),
                })
    samples = sum(record["label"].numel() for record in records)
    return records, {
        "records": len(records), "samples": samples,
        "attempted": attempted, "ties_skipped": ties,
        "positive_fraction": positives / max(samples, 1),
    }


def record_difference(readout, record):
    raw = readout.forward_from_features(
        record["features"], record["edge_index"], record["edge_attr"]
    )
    return (
        record["log_base_diff"]
        + F.logsigmoid(raw[record["left"]])
        - F.logsigmoid(raw[record["right"]])
    )


def dataset_metrics(readout, records):
    losses, correct, pure_correct, count = 0.0, 0, 0, 0
    with torch.no_grad():
        for record in records:
            difference = record_difference(readout, record)
            labels = record["label"]
            losses += float(F.binary_cross_entropy_with_logits(
                difference, labels, reduction="sum"
            ))
            correct += int(((difference > 0) == (labels > 0.5)).sum())
            pure_correct += int((
                (record["log_base_diff"] > 0) == (labels > 0.5)
            ).sum())
            count += labels.numel()
    return {
        "loss": losses / max(count, 1),
        "accuracy": correct / max(count, 1),
        "pure_accuracy": pure_correct / max(count, 1),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_graphs", type=int, default=80)
    parser.add_argument("--val_graphs", type=int, default=20)
    parser.add_argument("--queues_per_graph", type=int, default=4)
    parser.add_argument("--pairs_per_queue", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--accumulate_records", type=int, default=8)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--eval_snapshots", type=int, default=200)
    parser.add_argument("--seed", type=int, default=8300)
    parser.add_argument("--output_dir", default="results/queue/fixed_csi/channel_context_v2")
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    config = load_config(args.config)
    config.update({"NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect"})
    generator = build_network_generator(config)
    channel_model, channel_checkpoint = load_channel_gat(config, 10, device="cpu")
    for parameter in channel_model.parameters():
        parameter.requires_grad_(False)
    readout = ConditionalNegotiationReadout(
        channel_dim=config.get("GAT_OUT_DIM", 48), message_dim=16
    )
    train_records, train_meta = generate_graph_dataset(
        generator, channel_model, readout, 0, args.train_graphs,
        args.queues_per_graph, args.pairs_per_queue, args.seed
    )
    val_records, val_meta = generate_graph_dataset(
        generator, channel_model, readout, 100_000, args.val_graphs,
        args.queues_per_graph, args.pairs_per_queue, args.seed
    )
    optimizer = torch.optim.Adam(readout.parameters(), lr=args.lr)
    best_val, best_state, history = float("inf"), None, []
    rng = np.random.default_rng(args.seed + 999)
    for epoch in range(args.epochs):
        readout.train()
        optimizer.zero_grad()
        order = rng.permutation(len(train_records))
        for step, index in enumerate(order):
            record = train_records[int(index)]
            difference = record_difference(readout, record)
            loss = F.binary_cross_entropy_with_logits(
                difference, record["label"]
            ) / args.accumulate_records
            loss.backward()
            if (
                (step + 1) % args.accumulate_records == 0
                or step + 1 == len(order)
            ):
                optimizer.step()
                optimizer.zero_grad()
        readout.eval()
        train_metrics = dataset_metrics(readout, train_records)
        val_metrics = dataset_metrics(readout, val_records)
        history.append({"epoch": epoch + 1, "train": train_metrics, "val": val_metrics})
        if val_metrics["loss"] < best_val:
            best_val = val_metrics["loss"]
            best_state = {
                key: value.detach().clone()
                for key, value in readout.state_dict().items()
            }
        if epoch == 0 or (epoch + 1) % 10 == 0:
            print(
                f"epoch={epoch + 1:02d} train_acc={train_metrics['accuracy']:.3f} "
                f"val_acc={val_metrics['accuracy']:.3f} "
                f"pure_val={val_metrics['pure_accuracy']:.3f}"
            )
    readout.load_state_dict(best_state)
    readout.eval()
    scheduler_metrics = evaluate_schedulers(
        generator, channel_model, readout,
        args.seed + 300_000, args.eval_snapshots
    )
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output_dir / "readout.pth"
    torch.save({
        "model_version": "channel_context_negotiation_v2",
        "channel_checkpoint": channel_checkpoint,
        "readout_state_dict": readout.state_dict(),
        "channel_dim": config.get("GAT_OUT_DIM", 48),
        "message_dim": 16,
        "training_target": "local_physical_counterfactual_pairwise_preference",
        "tx_power_dbm": 10.0,
        "csi_mode": "perfect",
    }, checkpoint_path)
    result = {
        "experiment": "channel_context_negotiation_v2",
        "definition": (
            "Frozen channel-only GAT embedding; one queue-conditioned GAT "
            "message round; analytic local physical reuse."
        ),
        "setting": vars(args),
        "channel_checkpoint": channel_checkpoint,
        "train_dataset": train_meta,
        "validation_dataset": val_meta,
        "best_validation": dataset_metrics(readout, val_records),
        "snapshot_utility_ratio_to_centralized_greedy": scheduler_metrics,
        "history": history,
        "checkpoint": str(checkpoint_path),
    }
    with open(output_dir / "metrics.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, ensure_ascii=False)
    print(json.dumps(result["best_validation"], indent=2))
    print(json.dumps(scheduler_metrics, indent=2))
    print(f"Saved to {output_dir}")


if __name__ == "__main__":
    main()
