"""Minimal queue-conditioned readout over a cached channel-only GAT embedding."""

import torch
import torch.nn as nn

from models.model import GATLayer
from models.local_physical_reuse import (
    LocalPhysicalReuseScheduler,
    local_edge_gains,
    select_local_maxima,
)
from utils.queue_features import local_relative_queue


def solo_spectral_efficiency(state):
    direct, _, _, _ = local_edge_gains(state)
    noise = torch.as_tensor(state.noise_power, dtype=torch.float32).cpu()
    gap = float(getattr(state, "snr_gap", 1.0))
    return torch.log2(1.0 + direct / noise / gap)


class ConditionalRetentionReadout(nn.Module):
    """Map rich channel context and current relative urgency to logit(rho)."""

    def __init__(self, channel_dim=48, hidden_dim=16):
        super().__init__()
        self.channel_dim = int(channel_dim)
        self.network = nn.Sequential(
            nn.Linear(self.channel_dim + 2, int(hidden_dim)),
            nn.ReLU(),
            nn.Linear(int(hidden_dim), 1),
        )
        # rho=0.5 for every link initially, so priority ordering is exactly
        # PurePhysicalReuse before learning any context-dependent correction.
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def features(self, channel_embedding, queues, solo_rate, edge_index):
        queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1)
        q_rel = local_relative_queue(queues, edge_index.to(queues.device))
        solo_rate = torch.as_tensor(
            solo_rate, dtype=torch.float32, device=queues.device
        ).reshape(-1)
        c_rel = solo_rate / solo_rate.max().clamp_min(1e-8)
        return torch.cat([
            channel_embedding.to(queues.device),
            q_rel.unsqueeze(1),
            c_rel.unsqueeze(1),
        ], dim=1)

    def forward(
        self, channel_embedding, queues, solo_rate, edge_index, edge_attr=None
    ):
        del edge_attr
        return self.network(self.features(
            channel_embedding, queues, solo_rate, edge_index
        )).reshape(-1)


class ConditionalNegotiationReadout(ConditionalRetentionReadout):
    """One queue-conditioned graph round before producing logit(rho_i(t))."""

    def __init__(self, channel_dim=48, message_dim=16):
        nn.Module.__init__(self)
        self.channel_dim = int(channel_dim)
        node_dim = self.channel_dim + 2
        self.negotiation = GATLayer(
            node_dim=node_dim,
            edge_dim=1,
            out_dim=int(message_dim),
            num_heads=1,
        )
        self.output = nn.Linear(int(message_dim), 1)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward_from_features(self, node_features, edge_index, edge_attr):
        negotiated = self.negotiation(
            node_features, edge_index, edge_attr
        )
        return self.output(torch.relu(negotiated)).reshape(-1)

    def forward(
        self, channel_embedding, queues, solo_rate, edge_index, edge_attr=None
    ):
        if edge_attr is None:
            raise ValueError("ConditionalNegotiationReadout requires edge_attr")
        node_features = self.features(
            channel_embedding, queues, solo_rate, edge_index
        )
        return self.forward_from_features(
            node_features, edge_index.to(node_features.device),
            edge_attr.to(node_features.device),
        )


class ChannelContextLocalMaxScheduler:
    """Local skeleton using cached channel embedding and fast queue readout."""

    def __init__(self, channel_encoder, readout):
        self.channel_encoder = channel_encoder
        self.readout = readout
        self._cache = {}
        self.last_rho = None

    def eval(self):
        self.channel_encoder.eval()
        self.readout.eval()
        return self

    def clear_cache(self):
        self._cache.clear()

    def channel_context(self, state, device="cpu"):
        key = (id(state), str(device))
        cached = self._cache.get(key)
        if cached is not None and cached[0] is state:
            return cached[1], cached[2]
        with torch.no_grad():
            _, embedding = self.channel_encoder.encode(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
            )
        solo_rate = solo_spectral_efficiency(state).to(device)
        self._cache[key] = (state, embedding.detach(), solo_rate)
        return embedding.detach(), solo_rate

    def schedule_with_state(self, state, queues):
        queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1)
        embedding, solo_rate = self.channel_context(state, queues.device)
        with torch.no_grad():
            rho_logits = self.readout(
                embedding, queues, solo_rate, state.edge_index,
                state.edge_weights,
            )
            rho = torch.sigmoid(rho_logits)
        self.last_rho = rho.detach().cpu()
        priority = queues * solo_rate * rho
        winners = select_local_maxima(
            priority, queues > 0, state.edge_index.to(queues.device)
        )
        return winners.float().unsqueeze(1)


class ChannelContextPhysicalReuseScheduler(LocalPhysicalReuseScheduler):
    """Candidate model: channel GAT + queue readout + analytic reuse messages."""

    model_version = "channel_context_physical_reuse_v1"

    def __init__(self, channel_encoder, readout):
        super().__init__(ChannelContextLocalMaxScheduler(
            channel_encoder, readout
        ))
