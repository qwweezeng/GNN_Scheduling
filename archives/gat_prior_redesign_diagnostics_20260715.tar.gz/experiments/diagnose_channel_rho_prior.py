#!/usr/bin/env python3
"""Test whether one channel-only rate-retention scalar is worth learning.

This is a target-sufficiency diagnostic, not a proposed training algorithm.
For each fixed channel graph, many queue probes are used offline to estimate
how much solo rate each link retains when it is active in PurePhysicalReuse.
The resulting per-link oracle rho is then frozen and evaluated on unseen queue
snapshots.  If even this unavailable oracle cannot improve the Pure priority,
training a GAT to predict rho would be unjustified.
"""

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from baseline.queue_schedulers import centralized_mws_greedy  # noqa: E402
from models.local_physical_reuse import (  # noqa: E402
    FixedChannelRatePhysicalReuseScheduler,
    GATExpectedRateLocalPhysicalReuseScheduler,
    PurePhysicalReuseScheduler,
)
from models.model import calculate_achievable_rate  # noqa: E402
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


def random_positive_queues(num_links, rng):
    """Scale-free queue probes covering many local priority orderings."""
    return torch.from_numpy(
        rng.lognormal(mean=0.0, sigma=1.25, size=num_links).astype(np.float32)
    )


def evaluation_queues(num_links, rng):
    queues = rng.poisson(2.0, size=num_links).astype(np.float32)
    count = max(1, int(np.ceil(0.2 * num_links)))
    hotspots = rng.choice(num_links, size=count, replace=False)
    queues[hotspots] += rng.poisson(8.0, size=count).astype(np.float32)
    if not np.any(queues > 0):
        queues[rng.integers(0, num_links)] = 1.0
    return torch.from_numpy(queues)


def rank_values(values):
    """Return deterministic ordinal ranks; ties are negligible here."""
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(values.size, dtype=float)
    return ranks


def correlation(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.size < 2 or np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return None
    return float(np.corrcoef(x, y)[0, 1])


def summarize(values):
    array = np.asarray(values, dtype=float)
    return {
        "mean": float(array.mean()),
        "ci95": (
            float(1.96 * array.std(ddof=1) / np.sqrt(array.size))
            if array.size > 1 else 0.0
        ),
        "median": float(np.median(array)),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_graphs", type=int, default=30)
    parser.add_argument("--calibration_queues", type=int, default=64)
    parser.add_argument("--evaluation_queues", type=int, default=8)
    parser.add_argument("--seed", type=int, default=4200)
    parser.add_argument("--output", default="")
    args = parser.parse_args()

    config = load_config(args.config)
    config.update({"NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect"})
    generator = build_network_generator(config)
    channel_model, checkpoint = load_channel_gat(config, 10, device="cpu")

    ratios = {"Pure": [], "CurrentGAT": [], "OracleRho": [], "ShuffledRho": []}
    active_counts = {key: [] for key in ratios}
    current_rhos, oracle_rhos = [], []
    per_graph_correlations = []
    coverage = []

    for graph_idx in range(args.num_graphs):
        graph_seed = args.seed + graph_idx
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        pure = PurePhysicalReuseScheduler(channel_model)
        current = GATExpectedRateLocalPhysicalReuseScheduler(channel_model)
        solo_rate = pure.localmax._expected_rate(state, "cpu").reshape(-1)
        current_rate = current.localmax._expected_rate(state, "cpu").reshape(-1)
        current_rho = torch.clamp(current_rate / torch.clamp(solo_rate, min=1e-12), 0.0, 1.0)

        calibration_rng = np.random.default_rng(graph_seed + 100_003)
        rho_sum = torch.zeros_like(solo_rate)
        rho_count = torch.zeros_like(solo_rate)
        for _ in range(args.calibration_queues):
            queues = random_positive_queues(state.num_vertices, calibration_rng)
            action = pure.schedule_with_state(state, queues)
            rates = calculate_achievable_rate(action, state, binary=True).reshape(-1).cpu()
            active = action.reshape(-1).cpu() > 0.5
            retention = rates / torch.clamp(solo_rate, min=1e-12)
            rho_sum[active] += retention[active]
            rho_count[active] += 1.0

        observed = rho_count > 0
        fallback = (
            float((rho_sum[observed] / rho_count[observed]).median())
            if observed.any() else 1.0
        )
        oracle_rho = torch.full_like(solo_rate, fallback)
        oracle_rho[observed] = rho_sum[observed] / rho_count[observed]
        oracle_rho = torch.clamp(oracle_rho, 0.0, 1.0)
        coverage.append(float(observed.float().mean()))

        current_rhos.extend(current_rho.tolist())
        oracle_rhos.extend(oracle_rho.tolist())
        pearson = correlation(current_rho, oracle_rho)
        spearman = correlation(rank_values(current_rho), rank_values(oracle_rho))
        per_graph_correlations.append({"pearson": pearson, "spearman": spearman})

        oracle = FixedChannelRatePhysicalReuseScheduler(solo_rate * oracle_rho)
        permutation = torch.randperm(state.num_vertices, generator=torch.Generator().manual_seed(graph_seed + 77))
        shuffled = FixedChannelRatePhysicalReuseScheduler(solo_rate * oracle_rho[permutation])
        methods = {
            "Pure": pure,
            "CurrentGAT": current,
            "OracleRho": oracle,
            "ShuffledRho": shuffled,
        }
        evaluation_rng = np.random.default_rng(graph_seed + 900_001)
        for _ in range(args.evaluation_queues):
            queues = evaluation_queues(state.num_vertices, evaluation_rng)
            reference_action = centralized_mws_greedy(state, queues)
            reference = mws_objective(reference_action, queues, state)
            for name, scheduler in methods.items():
                action = scheduler.schedule_with_state(state, queues)
                utility = mws_objective(action, queues, state)
                ratios[name].append(utility / reference if reference > 0 else 1.0)
                active_counts[name].append(float(action.sum()))

    pearsons = [item["pearson"] for item in per_graph_correlations if item["pearson"] is not None]
    spearmans = [item["spearman"] for item in per_graph_correlations if item["spearman"] is not None]
    summary = {
        "experiment": "channel_rho_target_sufficiency",
        "purpose": "Decide whether a channel-only scalar rho is worth learning before training a new GAT.",
        "setting": vars(args),
        "channel_checkpoint": checkpoint,
        "rho_definition": (
            "Per-link mean realized R_i(A)/C_i_solo, conditional on link i being active "
            "in PurePhysicalReuse over independent scale-free queue probes."
        ),
        "calibration_link_coverage": summarize(coverage),
        "current_vs_oracle_rho": {
            "global_pearson": correlation(current_rhos, oracle_rhos),
            "global_spearman": correlation(rank_values(current_rhos), rank_values(oracle_rhos)),
            "mean_per_graph_pearson": summarize(pearsons) if pearsons else None,
            "mean_per_graph_spearman": summarize(spearmans) if spearmans else None,
            "mean_absolute_error": float(np.mean(np.abs(np.asarray(current_rhos) - np.asarray(oracle_rhos)))),
        },
        "snapshot_utility_ratio_to_centralized_greedy": {
            name: {**summarize(values), "mean_active_links": float(np.mean(active_counts[name]))}
            for name, values in ratios.items()
        },
        "oracle_win_fraction_vs_pure": float(
            np.mean(np.asarray(ratios["OracleRho"]) > np.asarray(ratios["Pure"]) + 1e-9)
        ),
        "decision_rule": (
            "Train rho-GAT only if OracleRho improves Pure materially and consistently; "
            "otherwise reject the scalar target instead of tuning the learner."
        ),
    }
    output = Path(args.output or "results/queue/fixed_csi/channel_rho_diagnostic.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=2, ensure_ascii=False)
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    print(f"Saved to {output}")


if __name__ == "__main__":
    main()
