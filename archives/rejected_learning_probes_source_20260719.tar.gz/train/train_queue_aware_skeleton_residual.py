#!/usr/bin/env python3
"""Small gate for a Q-aware GAT that directly revises the Pure skeleton.

This is deliberately not another direct-sum(QR) training run.  The model first
asks a cheaper representation question: given channel context, current queues,
the Pure skeleton, and the completed Pure action, can a two-round GAT imitate
the best previously measured one-substitution oracle skeleton on unseen graphs?

The output is one membership logit per link.  A fixed residual skip starts from
the Pure skeleton, so the trainable head only needs to learn keep/add/drop
changes.  A same-input MLP is trained as the no-message attribution control.
Failure stops the route before any direct-sum(QR) fine tuning.
"""

import argparse
import copy
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_local_replacement_realizability import (  # noqa: E402
    enumerate_replacements,
)
from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    conflict_neighbors,
    queue_snapshot,
)
from models.channel_context_reuse import solo_spectral_efficiency  # noqa: E402
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
    select_local_maxima,
)
from models.model import GATLayer  # noqa: E402
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.queue_features import local_relative_queue  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


PROFILES = ("sparse", "heterogeneous", "saturated")


class SkeletonResidualHead(nn.Module):
    """Direct skeleton-membership residual with zero or two message rounds."""

    def __init__(self, input_dim, kind, hidden_dim=32, message_dim=16):
        super().__init__()
        self.kind = kind
        if kind == "mlp":
            self.body = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, 1),
            )
            nn.init.zeros_(self.body[-1].weight)
            nn.init.zeros_(self.body[-1].bias)
        elif kind == "gat":
            self.gat1 = GATLayer(
                node_dim=input_dim, edge_dim=1,
                out_dim=message_dim, num_heads=2,
            )
            self.gat2 = GATLayer(
                node_dim=2 * message_dim, edge_dim=1,
                out_dim=message_dim, num_heads=1,
            )
            self.output = nn.Linear(message_dim, 1)
            nn.init.zeros_(self.output.weight)
            nn.init.zeros_(self.output.bias)
        else:
            raise ValueError(f"Unknown head kind: {kind}")

    def forward(self, features, edge_index, edge_attr, pure_base):
        if self.kind == "mlp":
            residual = self.body(features).reshape(-1)
        else:
            hidden = torch.relu(self.gat1(features, edge_index, edge_attr))
            hidden = torch.relu(self.gat2(hidden, edge_index, edge_attr))
            residual = self.output(hidden).reshape(-1)
        # This is an identity residual, not a learned calibration bias:
        # residual=0 reproduces the Pure skeleton exactly at threshold zero.
        base_logit = 2.0 * pure_base.float() - 1.0
        return base_logit + residual


def build_features(state, queues, embedding, pure_base, pure_final):
    queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1)
    q_rel = local_relative_queue(queues, state.edge_index)
    solo = solo_spectral_efficiency(state)
    c_rel = solo / solo.max().clamp_min(1e-8)
    neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
    degree = torch.tensor(
        [len(items) for items in neighbors], dtype=torch.float32
    )
    degree = degree / degree.max().clamp_min(1.0)
    normalized_embedding = F.layer_norm(
        embedding.detach(), (embedding.shape[1],)
    )
    scalars = torch.stack([
        q_rel,
        c_rel,
        pure_base.float(),
        pure_final.float(),
        degree,
    ], dim=1)
    return torch.cat([normalized_embedding, scalars], dim=1)


def oracle_target_base(pure_base, pure_utility, candidates):
    target = pure_base.clone().reshape(-1).float()
    best = max(candidates, key=lambda row: row["final_utility"], default=None)
    if best is None or best["final_utility"] <= pure_utility + 1e-6 * max(
        abs(pure_utility), 1.0
    ):
        return target, None, []
    removed = [int(item) for item in best["removed_winners"]]
    if removed:
        target[torch.tensor(removed, dtype=torch.long)] = 0.0
    target[int(best["challenger"])] = 1.0
    return target, int(best["challenger"]), removed


def build_records(generator, channel_model, num_graphs, seed):
    pure = PurePhysicalReuseScheduler(channel_model)
    records = []
    metadata = {
        "graphs": int(num_graphs),
        "snapshots": 0,
        "oracle_changed_snapshots": 0,
        "target_additions": 0,
        "target_removals": 0,
    }
    for graph_offset in range(int(num_graphs)):
        graph_seed = int(seed + graph_offset)
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        with torch.no_grad():
            _, embedding = channel_model.encode(
                state.vertex_features[:, :1],
                state.edge_index,
                state.edge_weights,
            )
        for profile_index, profile in enumerate(PROFILES):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            pure_base, pure_final, pure_utility, candidates = enumerate_replacements(
                state, queues, pure
            )
            target_base, challenger, removed = oracle_target_base(
                pure_base, pure_utility, candidates
            )
            target_final, _, _ = complete_physical_reuse_from_base(
                state, queues, target_base
            )
            oracle_utility = float(mws_objective(target_final, queues, state))
            if challenger is not None:
                metadata["oracle_changed_snapshots"] += 1
                metadata["target_additions"] += 1
                metadata["target_removals"] += len(removed)
            records.append({
                "features": build_features(
                    state, queues, embedding, pure_base, pure_final.reshape(-1)
                ).detach(),
                "edge_index": state.edge_index.detach(),
                "edge_attr": state.edge_weights.detach(),
                "pure_base": pure_base.detach().float().reshape(-1),
                "target_base": target_base.detach().float().reshape(-1),
                "queues": queues.detach().float().reshape(-1),
                "state": state,
                "pure_utility": float(pure_utility),
                "oracle_utility": oracle_utility,
                "oracle_challenger": challenger,
                "oracle_removed": removed,
                "profile": profile,
                "graph_seed": graph_seed,
            })
            metadata["snapshots"] += 1
    metadata["oracle_changed_fraction"] = (
        metadata["oracle_changed_snapshots"] / max(metadata["snapshots"], 1)
    )
    return records, metadata


def balanced_membership_loss(logits, target):
    """Give active and inactive target classes equal graph-level weight."""
    target = target.float()
    positive = target > 0.5
    negative = ~positive
    terms = []
    if positive.any():
        terms.append(F.binary_cross_entropy_with_logits(
            logits[positive], target[positive]
        ))
    if negative.any():
        terms.append(F.binary_cross_entropy_with_logits(
            logits[negative], target[negative]
        ))
    return torch.stack(terms).mean()


def predict_base(model, record):
    logits = model(
        record["features"],
        record["edge_index"],
        record["edge_attr"],
        record["pure_base"],
    )
    proposed = logits > 0.0
    valid = proposed & (record["queues"] > 0)
    # Direct outputs that collide are resolved by the same deterministic
    # one-hop LocalMax rule used throughout the two-stage framework.
    projected = select_local_maxima(
        logits.detach(), valid.detach(), record["edge_index"]
    )
    return projected.float(), logits


def metrics(model, records):
    losses = []
    rows = []
    exact_sets = 0
    changed_correct = changed_total = 0
    unnecessary_flips = unchanged_total = 0
    with torch.no_grad():
        for record in records:
            predicted_base, logits = predict_base(model, record)
            losses.append(float(balanced_membership_loss(
                logits, record["target_base"]
            )))
            target_changed = record["target_base"] != record["pure_base"]
            predicted_changed = predicted_base != record["pure_base"]
            changed_correct += int(
                (predicted_changed[target_changed]
                 == target_changed[target_changed]).sum()
            )
            changed_total += int(target_changed.sum())
            unchanged = ~target_changed
            unnecessary_flips += int(predicted_changed[unchanged].sum())
            unchanged_total += int(unchanged.sum())
            exact_sets += int(torch.equal(
                predicted_base.round(), record["target_base"].round()
            ))
            final_action, _, _ = complete_physical_reuse_from_base(
                record["state"], record["queues"], predicted_base
            )
            utility = float(mws_objective(
                final_action, record["queues"], record["state"]
            ))
            rows.append({
                "graph_seed": record["graph_seed"],
                "profile": record["profile"],
                "pure_utility": record["pure_utility"],
                "oracle_utility": record["oracle_utility"],
                "candidate_utility": utility,
                "predicted_skeleton_links": int(predicted_base.sum()),
                "target_skeleton_links": int(record["target_base"].sum()),
            })
    return {
        "loss": float(np.mean(losses)),
        "exact_skeleton_fraction": exact_sets / max(len(records), 1),
        "changed_node_recall": changed_correct / max(changed_total, 1),
        "unnecessary_flip_fraction": (
            unnecessary_flips / max(unchanged_total, 1)
        ),
        "mean_ratio_vs_pure": float(np.mean([
            row["candidate_utility"] / max(abs(row["pure_utility"]), 1e-12)
            for row in rows
        ])),
    }, rows


def train_model(kind, input_dim, train_records, val_records, args):
    torch.manual_seed(args.seed + (0 if kind == "mlp" else 1))
    model = SkeletonResidualHead(
        input_dim=input_dim,
        kind=kind,
        hidden_dim=args.hidden_dim,
        message_dim=args.message_dim,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    rng = np.random.default_rng(args.seed + (100 if kind == "mlp" else 200))
    best_loss = float("inf")
    best_state = None
    history = []
    for epoch in range(args.epochs):
        model.train()
        order = rng.permutation(len(train_records))
        optimizer.zero_grad()
        for step, record_index in enumerate(order):
            record = train_records[int(record_index)]
            logits = model(
                record["features"], record["edge_index"], record["edge_attr"],
                record["pure_base"],
            )
            loss = balanced_membership_loss(
                logits, record["target_base"]
            ) / args.accumulate_records
            loss.backward()
            if (
                (step + 1) % args.accumulate_records == 0
                or step + 1 == len(order)
            ):
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
                optimizer.zero_grad()
        model.eval()
        train_metrics, _ = metrics(model, train_records)
        val_metrics, _ = metrics(model, val_records)
        history.append({
            "epoch": epoch + 1,
            "train": train_metrics,
            "validation": val_metrics,
        })
        if val_metrics["loss"] < best_loss:
            best_loss = val_metrics["loss"]
            best_state = copy.deepcopy(model.state_dict())
        print(
            f"{kind} epoch={epoch + 1:02d} "
            f"val_loss={val_metrics['loss']:.4f} "
            f"val_exact={val_metrics['exact_skeleton_fraction']:.3f} "
            f"val_ratio={val_metrics['mean_ratio_vs_pure']:.3f}"
        )
    model.load_state_dict(best_state)
    model.eval()
    final_metrics, _ = metrics(model, val_records)
    return model, history, final_metrics


def paired_summary(rows, candidate_key, reference_key):
    ratios = np.asarray([
        row[candidate_key] / max(abs(row[reference_key]), 1e-12)
        for row in rows
    ])
    return {
        "mean_ratio": float(np.mean(ratios)),
        "ci95": float(
            1.96 * np.std(ratios, ddof=1) / np.sqrt(len(ratios))
        ) if len(ratios) > 1 else 0.0,
        "strict_win_fraction": float(np.mean(ratios > 1.0 + 1e-9)),
        "strict_loss_fraction": float(np.mean(ratios < 1.0 - 1e-9)),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--train_graphs", type=int, default=8)
    parser.add_argument("--val_graphs", type=int, default=2)
    parser.add_argument("--eval_graphs", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--accumulate_records", type=int, default=6)
    parser.add_argument("--hidden_dim", type=int, default=32)
    parser.add_argument("--message_dim", type=int, default=16)
    parser.add_argument("--seed", type=int, default=91000)
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument("--minimum_gat_over_pure", type=float, default=1.02)
    parser.add_argument("--minimum_gat_over_mlp", type=float, default=1.01)
    parser.add_argument("--minimum_win_fraction", type=float, default=0.625)
    parser.add_argument("--maximum_loss_fraction", type=float, default=0.125)
    parser.add_argument("--minimum_sparse_ratio", type=float, default=0.99)
    parser.add_argument(
        "--output_dir",
        default=(
            "results/formal/queue_aware_skeleton_residual_gate_"
            "N20_rician_20260717"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("This gate is frozen to N=20 and 10 dBm.")

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    config = load_config(args.config)
    config.update({
        "NUM_UAV": 20,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config, args.channel_gat_checkpoint, 20,
        device="cpu", allow_power_transfer=False,
    )
    for parameter in channel_model.parameters():
        parameter.requires_grad_(False)

    train_records, train_meta = build_records(
        generator, channel_model, args.train_graphs, args.seed
    )
    val_records, val_meta = build_records(
        generator, channel_model, args.val_graphs, args.seed + 10_000
    )
    eval_records, eval_meta = build_records(
        generator, channel_model, args.eval_graphs, args.seed + 20_000
    )
    input_dim = int(train_records[0]["features"].shape[1])
    models = {}
    histories = {}
    validation = {}
    evaluation_rows = {}
    evaluation_metrics = {}
    for kind in ("mlp", "gat"):
        model, history, val_metrics = train_model(
            kind, input_dim, train_records, val_records, args
        )
        models[kind] = model
        histories[kind] = history
        validation[kind] = val_metrics
        evaluation_metrics[kind], evaluation_rows[kind] = metrics(
            model, eval_records
        )

    combined_rows = []
    for mlp_row, gat_row in zip(evaluation_rows["mlp"], evaluation_rows["gat"]):
        if (
            mlp_row["graph_seed"] != gat_row["graph_seed"]
            or mlp_row["profile"] != gat_row["profile"]
        ):
            raise RuntimeError("MLP/GAT evaluation rows lost pairing.")
        combined_rows.append({
            "graph_seed": gat_row["graph_seed"],
            "profile": gat_row["profile"],
            "pure_utility": gat_row["pure_utility"],
            "oracle_utility": gat_row["oracle_utility"],
            "mlp_utility": mlp_row["candidate_utility"],
            "gat_utility": gat_row["candidate_utility"],
            "mlp_skeleton_links": mlp_row["predicted_skeleton_links"],
            "gat_skeleton_links": gat_row["predicted_skeleton_links"],
            "target_skeleton_links": gat_row["target_skeleton_links"],
        })

    by_profile = {}
    for profile in PROFILES:
        selected = [row for row in combined_rows if row["profile"] == profile]
        by_profile[profile] = {
            "gat_over_pure": paired_summary(
                selected, "gat_utility", "pure_utility"
            ),
            "gat_over_mlp": paired_summary(
                selected, "gat_utility", "mlp_utility"
            ),
            "mlp_over_pure": paired_summary(
                selected, "mlp_utility", "pure_utility"
            ),
            "oracle_over_pure": paired_summary(
                selected, "oracle_utility", "pure_utility"
            ),
        }
    profile_passed = {}
    for profile in ("heterogeneous", "saturated"):
        vs_pure = by_profile[profile]["gat_over_pure"]
        vs_mlp = by_profile[profile]["gat_over_mlp"]
        profile_passed[profile] = bool(
            vs_pure["mean_ratio"] >= args.minimum_gat_over_pure
            and vs_pure["strict_win_fraction"] >= args.minimum_win_fraction
            and vs_pure["strict_loss_fraction"] <= args.maximum_loss_fraction
            and vs_mlp["mean_ratio"] >= args.minimum_gat_over_mlp
        )
    sparse_passed = bool(
        by_profile["sparse"]["gat_over_pure"]["mean_ratio"]
        >= args.minimum_sparse_ratio
    )
    gate_passed = sparse_passed and all(profile_passed.values())

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_version": "queue_aware_skeleton_residual_gat_probe_v1",
        "model_state_dict": models["gat"].state_dict(),
        "channel_checkpoint": checkpoint_path,
        "input_dim": input_dim,
        "message_dim": args.message_dim,
        "status": "accepted" if gate_passed else "rejected",
    }, output_dir / "gat_probe.pth")
    payload = {
        "experiment": "queue_aware_direct_skeleton_supervised_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "motivation": (
            "Test the user's hypothesis that Q must enter graph message passing "
            "and that GAT should directly output the revised skeleton."
        ),
        "difference_from_old_end_to_end_gat_q": (
            "Starts from the reliable Pure skeleton and learns only residual "
            "keep/add/drop membership; it does not discover the entire action "
            "from blank state using a direct sum(QR) gradient."
        ),
        "difference_from_r4_challenger": (
            "Outputs all revised skeleton memberships jointly instead of "
            "choosing only one challenger/no-change class."
        ),
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "input_features": [
            "normalized frozen conference channel embedding",
            "local relative queue",
            "normalized solo rate",
            "Pure skeleton indicator",
            "Pure completed-action indicator",
            "normalized conflict degree",
        ],
        "training_target": (
            "Exact Pure skeleton or the exact best one-substitution oracle "
            "skeleton, supervised with class-balanced membership BCE."
        ),
        "train_dataset": train_meta,
        "validation_dataset": val_meta,
        "evaluation_dataset": eval_meta,
        "validation": validation,
        "evaluation_metrics": evaluation_metrics,
        "evaluation_by_profile": by_profile,
        "evaluation_rows": combined_rows,
        "history": histories,
        "predeclared_gate": {
            "required_profiles": ["heterogeneous", "saturated"],
            "minimum_gat_over_pure_mean_ratio": args.minimum_gat_over_pure,
            "minimum_gat_over_mlp_mean_ratio": args.minimum_gat_over_mlp,
            "minimum_strict_win_fraction_vs_pure": args.minimum_win_fraction,
            "maximum_strict_loss_fraction_vs_pure": args.maximum_loss_fraction,
            "minimum_sparse_ratio_vs_pure": args.minimum_sparse_ratio,
            "profile_passed": profile_passed,
            "sparse_passed": sparse_passed,
            "gate_passed": gate_passed,
        },
        "decision": (
            "PROCEED_TO_ONE_DIRECT_SUM_QR_FINE_TUNE"
            if gate_passed
            else "STOP_BEFORE_DIRECT_SUM_QR_FINE_TUNE"
        ),
        "checkpoint": str(output_dir / "gat_probe.pth"),
    }
    with open(output_dir / "report.json", "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "validation": validation,
        "evaluation_by_profile": by_profile,
        "predeclared_gate": payload["predeclared_gate"],
        "decision": payload["decision"],
        "output": str(output_dir),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
