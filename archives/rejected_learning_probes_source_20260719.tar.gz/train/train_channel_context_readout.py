#!/usr/bin/env python3
"""Train the minimal queue-conditioned readout from physical counterfactuals.

The conference GAT encoder is frozen. Labels do not copy a centralized
scheduler: for one conflicting link pair and a shared remote skeleton, they
compare the true max-weight utility after choosing either local representative
and applying the same analytic physical-reuse completion.
"""

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from baseline.queue_schedulers import centralized_mws_greedy  # noqa: E402
from utils.queue_snapshots import (  # noqa: E402
    heterogeneous_queue_snapshot as queue_snapshot,
)
from models.channel_context_reuse import (  # noqa: E402
    ChannelContextPhysicalReuseScheduler,
    ConditionalRetentionReadout,
    solo_spectral_efficiency,
)
from models.local_physical_reuse import (  # noqa: E402
    GATExpectedRateLocalPhysicalReuseScheduler,
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
)
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


def unique_conflict_pairs(edge_index):
    pairs = set()
    source, target = edge_index.detach().cpu()
    for left, right in zip(source.tolist(), target.tolist()):
        if left != right:
            pairs.add((min(left, right), max(left, right)))
    return sorted(pairs)


def remove_local_neighborhood(base, pair, edge_index):
    """Keep the shared remote skeleton and remove both local neighborhoods."""
    context = torch.as_tensor(base, dtype=torch.float32).reshape(-1).clone()
    source, target = edge_index.detach().cpu()
    removed = {int(pair[0]), int(pair[1])}
    for node in pair:
        outgoing = target[source == int(node)].tolist()
        incoming = source[target == int(node)].tolist()
        removed.update(int(item) for item in outgoing + incoming)
    if removed:
        context[torch.tensor(sorted(removed), dtype=torch.long)] = 0.0
    return context


def generate_pair_dataset(
    generator, channel_model, readout, graph_start, num_graphs,
    queues_per_graph, pairs_per_queue, seed
):
    records = {"left": [], "right": [], "log_base_diff": [], "label": []}
    metadata = {"attempted": 0, "ties_skipped": 0, "positive": 0}
    pure = PurePhysicalReuseScheduler(channel_model)
    for graph_offset in range(num_graphs):
        graph_seed = int(seed + graph_start + graph_offset)
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        with torch.no_grad():
            _, embedding = channel_model.encode(
                state.vertex_features[:, :1], state.edge_index, state.edge_weights
            )
        solo = solo_spectral_efficiency(state)
        pairs = unique_conflict_pairs(state.edge_index)
        rng = np.random.default_rng(graph_seed + 700_001)
        for queue_idx in range(queues_per_graph):
            queues = queue_snapshot(
                state.num_vertices, graph_seed + 100_003 + queue_idx
            )
            valid_pairs = [
                pair for pair in pairs
                if queues[pair[0]] > 0 and queues[pair[1]] > 0
            ]
            if not valid_pairs:
                continue
            chosen = rng.choice(
                len(valid_pairs),
                size=min(int(pairs_per_queue), len(valid_pairs)),
                replace=False,
            )
            base = pure.localmax.schedule_with_state(state, queues).reshape(-1)
            features = readout.features(
                embedding, queues, solo, state.edge_index
            ).detach().cpu()
            for pair_index in np.asarray(chosen).reshape(-1).tolist():
                left, right = valid_pairs[int(pair_index)]
                context = remove_local_neighborhood(
                    base, (left, right), state.edge_index
                )
                base_left = context.clone()
                base_right = context.clone()
                base_left[left] = 1.0
                base_right[right] = 1.0
                action_left, _, _ = complete_physical_reuse_from_base(
                    state, queues, base_left
                )
                action_right, _, _ = complete_physical_reuse_from_base(
                    state, queues, base_right
                )
                utility_left = mws_objective(action_left, queues, state)
                utility_right = mws_objective(action_right, queues, state)
                metadata["attempted"] += 1
                scale = max(abs(utility_left), abs(utility_right), 1.0)
                if abs(utility_left - utility_right) <= 1e-6 * scale:
                    metadata["ties_skipped"] += 1
                    continue
                # Random orientation prevents link-ID/order leakage.
                if rng.random() < 0.5:
                    left, right = right, left
                    utility_left, utility_right = utility_right, utility_left
                label = float(utility_left > utility_right)
                records["left"].append(features[left])
                records["right"].append(features[right])
                log_left = torch.log(
                    (queues[left] * solo[left]).clamp_min(1e-12)
                )
                log_right = torch.log(
                    (queues[right] * solo[right]).clamp_min(1e-12)
                )
                records["log_base_diff"].append(float(log_left - log_right))
                records["label"].append(label)
                metadata["positive"] += int(label)
    tensors = {
        "left": torch.stack(records["left"]),
        "right": torch.stack(records["right"]),
        "log_base_diff": torch.tensor(records["log_base_diff"], dtype=torch.float32),
        "label": torch.tensor(records["label"], dtype=torch.float32),
    }
    metadata["samples"] = int(tensors["label"].numel())
    metadata["positive_fraction"] = float(tensors["label"].mean())
    return tensors, metadata


def priority_difference(readout, data, indices):
    raw_left = readout.network(data["left"][indices]).reshape(-1)
    raw_right = readout.network(data["right"][indices]).reshape(-1)
    # log W = log(Q*C_solo) + log(sigmoid(readout_logit)).
    return (
        data["log_base_diff"][indices]
        + F.logsigmoid(raw_left)
        - F.logsigmoid(raw_right)
    )


def pair_metrics(readout, data):
    with torch.no_grad():
        indices = torch.arange(data["label"].numel())
        learned = priority_difference(readout, data, indices)
        base = data["log_base_diff"]
        labels = data["label"]
        return {
            "loss": float(F.binary_cross_entropy_with_logits(learned, labels)),
            "accuracy": float(((learned > 0) == (labels > 0.5)).float().mean()),
            "pure_accuracy": float(((base > 0) == (labels > 0.5)).float().mean()),
        }


def evaluate_schedulers(generator, channel_model, readout, seed, num_snapshots):
    learned_name = (
        "ChannelContext-v2"
        if readout.__class__.__name__ == "ConditionalNegotiationReadout"
        else "ChannelContext-v1"
    )
    schedulers = {
        "Pure": PurePhysicalReuseScheduler(channel_model),
        "CurrentGAT": GATExpectedRateLocalPhysicalReuseScheduler(channel_model),
        learned_name: ChannelContextPhysicalReuseScheduler(
            channel_model, readout
        ),
    }
    ratios = {name: [] for name in schedulers}
    for offset in range(num_snapshots):
        snapshot_seed = int(seed + offset)
        torch.manual_seed(snapshot_seed)
        np.random.seed(snapshot_seed)
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        queues = queue_snapshot(state.num_vertices, snapshot_seed + 100_003)
        reference = mws_objective(
            centralized_mws_greedy(state, queues), queues, state
        )
        for name, scheduler in schedulers.items():
            action = scheduler.schedule_with_state(state, queues)
            value = mws_objective(action, queues, state)
            ratios[name].append(value / reference if reference > 0 else 1.0)
    return {
        name: {
            "mean": float(np.mean(values)),
            "ci95": float(1.96 * np.std(values, ddof=1) / np.sqrt(len(values))),
            "win_fraction_vs_pure": float(
                np.mean(np.asarray(values) > np.asarray(ratios["Pure"]) + 1e-9)
            ),
        }
        for name, values in ratios.items()
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--train_graphs", type=int, default=80)
    parser.add_argument("--val_graphs", type=int, default=20)
    parser.add_argument("--queues_per_graph", type=int, default=4)
    parser.add_argument("--pairs_per_queue", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--eval_snapshots", type=int, default=100)
    parser.add_argument("--seed", type=int, default=7300)
    parser.add_argument("--output_dir", default="results/queue/fixed_csi/channel_context_v1")
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    config = load_config(args.config)
    config.update({"NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect"})
    generator = build_network_generator(config)
    channel_model, channel_checkpoint = load_channel_gat(config, 10, device="cpu")
    for parameter in channel_model.parameters():
        parameter.requires_grad_(False)
    readout = ConditionalRetentionReadout(
        channel_dim=config.get("GAT_OUT_DIM", 48), hidden_dim=16
    )

    train_data, train_meta = generate_pair_dataset(
        generator, channel_model, readout, 0, args.train_graphs,
        args.queues_per_graph, args.pairs_per_queue, args.seed
    )
    val_data, val_meta = generate_pair_dataset(
        generator, channel_model, readout, 100_000, args.val_graphs,
        args.queues_per_graph, args.pairs_per_queue, args.seed
    )
    optimizer = torch.optim.Adam(readout.parameters(), lr=args.lr)
    best_state, best_val = None, float("inf")
    rng = torch.Generator().manual_seed(args.seed + 999)
    history = []
    for epoch in range(args.epochs):
        permutation = torch.randperm(train_data["label"].numel(), generator=rng)
        readout.train()
        for start in range(0, permutation.numel(), args.batch_size):
            indices = permutation[start:start + args.batch_size]
            difference = priority_difference(readout, train_data, indices)
            loss = F.binary_cross_entropy_with_logits(
                difference, train_data["label"][indices]
            )
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        readout.eval()
        train_metrics = pair_metrics(readout, train_data)
        val_metrics = pair_metrics(readout, val_data)
        history.append({"epoch": epoch + 1, "train": train_metrics, "val": val_metrics})
        if val_metrics["loss"] < best_val:
            best_val = val_metrics["loss"]
            best_state = {
                key: value.detach().clone()
                for key, value in readout.state_dict().items()
            }
        if epoch == 0 or (epoch + 1) % 10 == 0:
            print(
                f"epoch={epoch + 1:02d} train_acc={train_metrics['accuracy']:.3f} "
                f"val_acc={val_metrics['accuracy']:.3f} "
                f"pure_val={val_metrics['pure_accuracy']:.3f}"
            )
    readout.load_state_dict(best_state)
    readout.eval()
    scheduler_metrics = evaluate_schedulers(
        generator, channel_model, readout,
        args.seed + 300_000, args.eval_snapshots
    )

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output_dir / "readout.pth"
    torch.save({
        "model_version": "channel_context_readout_v1",
        "channel_checkpoint": channel_checkpoint,
        "readout_state_dict": readout.state_dict(),
        "channel_dim": config.get("GAT_OUT_DIM", 48),
        "hidden_dim": 16,
        "training_target": "local_physical_counterfactual_pairwise_preference",
        "tx_power_dbm": 10.0,
        "csi_mode": "perfect",
    }, checkpoint_path)
    result = {
        "experiment": "channel_context_readout_v1",
        "setting": vars(args),
        "channel_checkpoint": channel_checkpoint,
        "train_dataset": train_meta,
        "validation_dataset": val_meta,
        "best_validation": pair_metrics(readout, val_data),
        "snapshot_utility_ratio_to_centralized_greedy": scheduler_metrics,
        "history": history,
        "checkpoint": str(checkpoint_path),
    }
    with open(output_dir / "metrics.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, ensure_ascii=False)
    print(json.dumps(result["best_validation"], indent=2))
    print(json.dumps(scheduler_metrics, indent=2))
    print(f"Saved to {output_dir}")


if __name__ == "__main__":
    main()
