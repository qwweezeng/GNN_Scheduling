#!/usr/bin/env python3
"""One-shot gate for a set-conditioned GAT challenger head.

The frozen conference encoder is retained.  Pure first forms its queue-aware
LocalMax skeleton and the unchanged physical-reuse completion.  Every inactive
link then receives local candidate features describing what would happen if it
challenged its conflicting Pure winners.  A two-round GAT ranks these candidate
replacements against a fixed no-change option.

An MLP with the same per-link inputs is trained alongside the GAT.  The GAT is
credited only if it beats Pure and the no-message MLP on unseen graphs.  This
is the final low-cost neural gate; failure means stopping model iteration.
"""

import argparse
import copy
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_local_replacement_realizability import (  # noqa: E402
    enumerate_replacements,
)
from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    ConstantPriorModel,
    conflict_neighbors,
    queue_snapshot,
)
from models.channel_context_reuse import solo_spectral_efficiency  # noqa: E402
from models.local_physical_reuse import (  # noqa: E402
    GATExpectedRateLocalPhysicalReuseScheduler,
    PurePhysicalReuseScheduler,
)
from models.model import GATLayer  # noqa: E402
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.queue_features import local_relative_queue  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


PROFILES = ("sparse", "heterogeneous", "saturated")


class ChallengerHead(nn.Module):
    """Candidate scorer with either zero or two new message rounds."""

    def __init__(self, input_dim, kind, hidden_dim=32, message_dim=16):
        super().__init__()
        self.kind = kind
        if kind == "mlp":
            self.network = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, 1),
            )
        elif kind == "gat":
            self.gat1 = GATLayer(
                node_dim=input_dim, edge_dim=1,
                out_dim=message_dim, num_heads=2,
            )
            self.gat2 = GATLayer(
                node_dim=2 * message_dim, edge_dim=1,
                out_dim=message_dim, num_heads=1,
            )
            self.output = nn.Linear(message_dim, 1)
        else:
            raise ValueError(f"Unknown head kind: {kind}")

    def forward(self, features, edge_index, edge_attr):
        if self.kind == "mlp":
            return self.network(features).reshape(-1)
        hidden = torch.relu(self.gat1(features, edge_index, edge_attr))
        hidden = torch.relu(self.gat2(hidden, edge_index, edge_attr))
        return self.output(hidden).reshape(-1)


def build_node_features(
    state, queues, embedding, pure_base, pure_final, pure_utility, candidates,
):
    num_links = int(state.num_vertices)
    queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1)
    solo = solo_spectral_efficiency(state)
    q_rel = local_relative_queue(queues, state.edge_index)
    c_rel = solo / solo.max().clamp_min(1e-8)
    normalized_embedding = F.layer_norm(
        embedding.detach(), (embedding.shape[1],)
    )

    valid = torch.zeros(num_links)
    solo_exchange = torch.zeros(num_links)
    local_base_delta = torch.zeros(num_links)
    removed_fraction = torch.zeros(num_links)
    neighbors = conflict_neighbors(state.edge_index, num_links)
    max_degree = max(max((len(items) for items in neighbors), default=1), 1)
    for candidate in candidates:
        index = int(candidate["challenger"])
        valid[index] = 1.0
        solo_exchange[index] = float(
            candidate["proxy_scores"]["solo_exchange"]
        ) / max(abs(pure_utility), 1.0)
        local_base_delta[index] = float(
            candidate["proxy_scores"]["local_base_delta"]
        ) / max(abs(pure_utility), 1.0)
        removed_fraction[index] = (
            len(candidate["removed_winners"]) / float(max_degree)
        )
    scalar_features = torch.stack([
        q_rel,
        c_rel,
        pure_base.float(),
        pure_final.float(),
        valid,
        torch.clamp(solo_exchange, min=-2.0, max=2.0),
        torch.clamp(local_base_delta, min=-2.0, max=2.0),
        removed_fraction,
    ], dim=1)
    return torch.cat([normalized_embedding, scalar_features], dim=1)


def build_records(
    generator, channel_model, num_graphs, seed, include_baselines=False,
    constant_probability=0.050029350853525105,
):
    pure = PurePhysicalReuseScheduler(channel_model)
    current_gat = GATExpectedRateLocalPhysicalReuseScheduler(channel_model)
    constant = GATExpectedRateLocalPhysicalReuseScheduler(
        ConstantPriorModel(constant_probability)
    )
    records = []
    metadata = {
        "graphs": int(num_graphs),
        "snapshots": 0,
        "candidate_replacements": 0,
        "positive_best_snapshots": 0,
    }
    for graph_offset in range(int(num_graphs)):
        graph_seed = int(seed + graph_offset)
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        with torch.no_grad():
            _, embedding = channel_model.encode(
                state.vertex_features[:, :1],
                state.edge_index,
                state.edge_weights,
            )
        for profile_index, profile in enumerate(PROFILES):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            pure_base, pure_final, pure_utility, candidates = enumerate_replacements(
                state, queues, pure
            )
            if not candidates:
                continue
            candidate_indices = torch.tensor([
                int(row["challenger"]) for row in candidates
            ], dtype=torch.long)
            candidate_utilities = torch.tensor([
                float(row["final_utility"]) for row in candidates
            ], dtype=torch.float32)
            best_position = int(torch.argmax(candidate_utilities))
            if candidate_utilities[best_position] > pure_utility + 1e-6 * max(
                abs(pure_utility), 1.0
            ):
                target_position = best_position
                metadata["positive_best_snapshots"] += 1
            else:
                target_position = len(candidates)  # fixed no-change option
            record = {
                "features": build_node_features(
                    state, queues, embedding, pure_base, pure_final,
                    pure_utility, candidates,
                ).detach(),
                "edge_index": state.edge_index.detach(),
                "edge_attr": state.edge_weights.detach(),
                "candidate_indices": candidate_indices,
                "candidate_utilities": candidate_utilities,
                "target_position": target_position,
                "pure_utility": float(pure_utility),
                "oracle_utility": float(max(
                    pure_utility, float(candidate_utilities.max())
                )),
                "profile": profile,
                "graph_seed": graph_seed,
                "num_links": int(state.num_vertices),
            }
            if include_baselines:
                record["current_gat_utility"] = float(mws_objective(
                    current_gat.schedule_with_state(state, queues), queues, state
                ))
                record["constant_utility"] = float(mws_objective(
                    constant.schedule_with_state(state, queues), queues, state
                ))
            records.append(record)
            metadata["snapshots"] += 1
            metadata["candidate_replacements"] += len(candidates)
    metadata["positive_best_fraction"] = (
        metadata["positive_best_snapshots"] / max(metadata["snapshots"], 1)
    )
    return records, metadata


def candidate_logits(model, record):
    node_logits = model(
        record["features"], record["edge_index"], record["edge_attr"]
    )
    candidates = node_logits[record["candidate_indices"]]
    no_change = torch.zeros(1, dtype=candidates.dtype, device=candidates.device)
    return torch.cat([candidates, no_change])


def selected_utility(model, record):
    with torch.no_grad():
        choice = int(torch.argmax(candidate_logits(model, record)))
    if choice == len(record["candidate_indices"]):
        return float(record["pure_utility"]), None
    return float(record["candidate_utilities"][choice]), int(
        record["candidate_indices"][choice]
    )


def record_metrics(model, records):
    total_loss = 0.0
    correct = 0
    utilities = []
    for record in records:
        with torch.no_grad():
            logits = candidate_logits(model, record)
            target = torch.tensor([record["target_position"]], dtype=torch.long)
            total_loss += float(F.cross_entropy(logits.unsqueeze(0), target))
            correct += int(torch.argmax(logits) == record["target_position"])
            utility, _ = selected_utility(model, record)
            utilities.append(utility)
    return {
        "cross_entropy": total_loss / max(len(records), 1),
        "best_choice_accuracy": correct / max(len(records), 1),
        "mean_ratio_vs_pure": float(np.mean([
            utility / max(abs(record["pure_utility"]), 1e-12)
            for utility, record in zip(utilities, records)
        ])),
    }


def train_head(kind, input_dim, train_records, val_records, args):
    torch.manual_seed(args.seed + (0 if kind == "mlp" else 1))
    model = ChallengerHead(
        input_dim=input_dim,
        kind=kind,
        hidden_dim=args.hidden_dim,
        message_dim=args.message_dim,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    rng = np.random.default_rng(args.seed + (100 if kind == "mlp" else 200))
    best_loss = float("inf")
    best_state = None
    history = []
    for epoch in range(args.epochs):
        model.train()
        order = rng.permutation(len(train_records))
        optimizer.zero_grad()
        for step, record_index in enumerate(order):
            record = train_records[int(record_index)]
            logits = candidate_logits(model, record)
            target = torch.tensor([record["target_position"]], dtype=torch.long)
            loss = F.cross_entropy(logits.unsqueeze(0), target)
            loss = loss / args.accumulate_records
            loss.backward()
            if (
                (step + 1) % args.accumulate_records == 0
                or step + 1 == len(order)
            ):
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
                optimizer.zero_grad()
        model.eval()
        train_metrics = record_metrics(model, train_records)
        val_metrics = record_metrics(model, val_records)
        history.append({
            "epoch": epoch + 1,
            "train": train_metrics,
            "validation": val_metrics,
        })
        if val_metrics["cross_entropy"] < best_loss:
            best_loss = val_metrics["cross_entropy"]
            best_state = copy.deepcopy(model.state_dict())
        if epoch == 0 or (epoch + 1) % 5 == 0:
            print(
                f"{kind} epoch={epoch + 1:02d} "
                f"train_ce={train_metrics['cross_entropy']:.3f} "
                f"val_ce={val_metrics['cross_entropy']:.3f} "
                f"val_ratio={val_metrics['mean_ratio_vs_pure']:.3f}"
            )
    model.load_state_dict(best_state)
    model.eval()
    return model, history, record_metrics(model, val_records)


def evaluation_rows(models, records):
    rows = []
    for record in records:
        row = {
            "graph_seed": record["graph_seed"],
            "profile": record["profile"],
            "pure_utility": record["pure_utility"],
            "current_gat_utility": record["current_gat_utility"],
            "constant_utility": record["constant_utility"],
            "oracle_utility": record["oracle_utility"],
        }
        for name, model in models.items():
            utility, challenger = selected_utility(model, record)
            row[f"{name}_utility"] = utility
            row[f"{name}_challenger"] = challenger
        rows.append(row)
    return rows


def paired_summary(rows, candidate, reference):
    ratios = np.asarray([
        row[f"{candidate}_utility"]
        / max(abs(row[f"{reference}_utility"]), 1e-12)
        for row in rows
    ])
    return {
        "mean_ratio": float(np.mean(ratios)),
        "ci95": float(
            1.96 * np.std(ratios, ddof=1) / np.sqrt(len(ratios))
        ) if len(ratios) > 1 else 0.0,
        "strict_win_fraction": float(np.mean(ratios > 1.0 + 1e-9)),
        "strict_loss_fraction": float(np.mean(ratios < 1.0 - 1e-9)),
    }


def summarize(rows):
    output = {}
    for profile in PROFILES:
        selected = [row for row in rows if row["profile"] == profile]
        output[profile] = {
            "gat_over_pure": paired_summary(selected, "gat", "pure"),
            "gat_over_mlp": paired_summary(selected, "gat", "mlp"),
            "mlp_over_pure": paired_summary(selected, "mlp", "pure"),
            "current_gat_over_pure": paired_summary(
                selected, "current_gat", "pure"
            ),
            "constant_over_pure": paired_summary(
                selected, "constant", "pure"
            ),
            "gat_oracle_recovery": float(np.mean([
                max(row["gat_utility"] - row["pure_utility"], 0.0)
                / max(row["oracle_utility"] - row["pure_utility"], 1e-12)
                if row["oracle_utility"] > row["pure_utility"] + 1e-9 else 1.0
                for row in selected
            ])),
        }
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--train_graphs", type=int, default=12)
    parser.add_argument("--val_graphs", type=int, default=4)
    parser.add_argument("--eval_graphs", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--accumulate_records", type=int, default=6)
    parser.add_argument("--hidden_dim", type=int, default=32)
    parser.add_argument("--message_dim", type=int, default=16)
    parser.add_argument("--seed", type=int, default=61000)
    parser.add_argument(
        "--constant_prior_probability", type=float,
        default=0.050029350853525105,
    )
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument("--minimum_gat_over_pure", type=float, default=1.02)
    parser.add_argument("--minimum_gat_over_mlp", type=float, default=1.01)
    parser.add_argument("--minimum_win_fraction", type=float, default=0.70)
    parser.add_argument("--maximum_loss_fraction", type=float, default=0.10)
    parser.add_argument("--minimum_sparse_ratio", type=float, default=0.99)
    parser.add_argument(
        "--output_dir",
        default=(
            "results/formal/set_conditioned_challenger_gate_"
            "N20_rician_20260716"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("This gate is frozen to N=20 and 10 dBm.")

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    config = load_config(args.config)
    config.update({
        "NUM_UAV": 20,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config,
        args.channel_gat_checkpoint,
        20,
        device="cpu",
        allow_power_transfer=False,
    )
    for parameter in channel_model.parameters():
        parameter.requires_grad_(False)

    train_records, train_meta = build_records(
        generator, channel_model, args.train_graphs, args.seed
    )
    val_records, val_meta = build_records(
        generator, channel_model, args.val_graphs, args.seed + 10_000
    )
    eval_records, eval_meta = build_records(
        generator, channel_model, args.eval_graphs, args.seed + 20_000,
        include_baselines=True,
        constant_probability=args.constant_prior_probability,
    )
    input_dim = int(train_records[0]["features"].shape[1])
    models = {}
    histories = {}
    validation = {}
    for kind in ("mlp", "gat"):
        model, history, val_result = train_head(
            kind, input_dim, train_records, val_records, args
        )
        models[kind] = model
        histories[kind] = history
        validation[kind] = val_result

    rows = evaluation_rows(models, eval_records)
    evaluation = summarize(rows)
    competition_pass = {}
    for profile in ("heterogeneous", "saturated"):
        vs_pure = evaluation[profile]["gat_over_pure"]
        vs_mlp = evaluation[profile]["gat_over_mlp"]
        competition_pass[profile] = bool(
            vs_pure["mean_ratio"] >= args.minimum_gat_over_pure
            and vs_pure["strict_win_fraction"] >= args.minimum_win_fraction
            and vs_pure["strict_loss_fraction"] <= args.maximum_loss_fraction
            and vs_mlp["mean_ratio"] >= args.minimum_gat_over_mlp
            and vs_mlp["strict_win_fraction"] >= args.minimum_win_fraction
        )
    sparse_pass = bool(
        evaluation["sparse"]["gat_over_pure"]["mean_ratio"]
        >= args.minimum_sparse_ratio
    )
    gate_passed = sparse_pass and all(competition_pass.values())

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_version": "set_conditioned_challenger_gat_v1",
        "channel_checkpoint": checkpoint_path,
        "model_state_dict": models["gat"].state_dict(),
        "input_dim": input_dim,
        "message_dim": args.message_dim,
        "num_message_rounds_per_queue_slot": 2,
        "training_target": (
            "best exact final sum_qr one-substitution or no-change"
        ),
        "formal_setting": {
            "num_uav": 20,
            "tx_power_dbm": 10.0,
            "channel_model": "rician",
            "rician_k_db": args.rician_k_db,
        },
    }, output_dir / "gat_model.pth")
    payload = {
        "experiment": "set_conditioned_challenger_training_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "definition": (
            "Frozen conference channel encoder; Pure skeleton and completion; "
            "candidate-local features; two-round GAT chooses one challenger or "
            "no change.  Same-input MLP is the no-message attribution control."
        ),
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "input_features": [
            "normalized frozen conference channel embedding",
            "local relative queue",
            "normalized solo rate",
            "Pure skeleton indicator",
            "Pure completed-action indicator",
            "valid challenger indicator",
            "local solo-utility exchange divided by Pure utility",
            "one-hop base physical delta divided by Pure utility",
            "removed-winner fraction",
        ],
        "forbidden_input": (
            "No one-hop/two-hop final delta or exact global candidate utility "
            "is provided as a model input."
        ),
        "train_dataset": train_meta,
        "validation_dataset": val_meta,
        "evaluation_dataset": eval_meta,
        "validation": validation,
        "history": histories,
        "evaluation": evaluation,
        "evaluation_rows": rows,
        "message_rounds": {
            "conference_channel_encoder_per_channel_block": 4,
            "new_queue_conditioned_gat_per_queue_slot": 2,
            "candidate_arbitration_not_yet_counted": (
                "This is a learning feasibility gate, not yet a frozen "
                "distributed protocol."
            ),
        },
        "predeclared_gate": {
            "required_profiles": ["heterogeneous", "saturated"],
            "minimum_gat_over_pure_mean_ratio": args.minimum_gat_over_pure,
            "minimum_gat_over_mlp_mean_ratio": args.minimum_gat_over_mlp,
            "minimum_strict_win_fraction": args.minimum_win_fraction,
            "maximum_strict_loss_fraction_vs_pure": args.maximum_loss_fraction,
            "minimum_sparse_ratio_vs_pure": args.minimum_sparse_ratio,
            "profile_passed": competition_pass,
            "sparse_passed": sparse_pass,
            "gate_passed": gate_passed,
        },
        "decision": (
            "PROCEED_TO_DISTRIBUTED_PROTOCOL"
            if gate_passed
            else "STOP_MODEL_ITERATION_USE_BACKUP"
        ),
        "checkpoint": str(output_dir / "gat_model.pth"),
    }
    with open(output_dir / "report.json", "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "validation": validation,
        "evaluation": evaluation,
        "predeclared_gate": payload["predeclared_gate"],
        "decision": payload["decision"],
        "output": str(output_dir),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
