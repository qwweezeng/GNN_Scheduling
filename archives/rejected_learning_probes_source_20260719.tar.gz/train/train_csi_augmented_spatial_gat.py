#!/usr/bin/env python3
"""Fine-tune the conference spatial GAT on paired imperfect/true mobile CSI."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.model import calculate_achievable_rate
from simulator.mobile_block_fading import (
    build_observed_network_state,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import (
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)


MODE_SPECS = (
    ("latest", None),
    ("stale", None),
    ("large_scale", None),
    ("quantized", 4),
)


def _csv(text, cast):
    return [cast(item.strip()) for item in text.split(",") if item.strip()]


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--train_seeds", default="1000-1019")
    parser.add_argument("--val_seeds", default="2000-2004")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--learning_rate", type=float, default=1e-4)
    parser.add_argument(
        "--objective",
        choices=("teacher_logit_mse", "physical_soft_sum_rate"),
        default="teacher_logit_mse",
        help=(
            "teacher_logit_mse reconstructs the frozen conference prior from "
            "imperfect CSI; physical_soft_sum_rate retains the failed v1 audit."
        ),
    )
    parser.add_argument("--patience", type=int, default=5)
    parser.add_argument(
        "--val_blocks_per_trace", type=int, default=40,
        help="Evenly sampled validation blocks; 0 uses every block.",
    )
    parser.add_argument("--channel_model_num_uav", type=int, default=20)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument(
        "--base_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--output_model", default="")
    parser.add_argument("--output_report", default="")
    return parser.parse_args()


def _seed_spec(text):
    values = []
    for item in text.split(","):
        item = item.strip()
        if not item:
            continue
        if "-" in item:
            start, end = item.split("-", 1)
            values.extend(range(int(start), int(end) + 1))
        else:
            values.append(int(item))
    return values


def _set_seed(seed):
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))


def _generate_traces(net_gen, seeds, args, slot_duration):
    traces = {}
    for seed in seeds:
        traces[int(seed)] = generate_mobile_block_fading_trace(
            net_gen,
            num_slots=args.num_slots,
            slots_per_block=args.slots_per_block,
            slot_duration=slot_duration,
            speed_mps=args.speed_mps,
            seed=seed,
            quantization_bits=(4,),
            rician_k_db=args.rician_k_db,
        )
    return traces


def _training_samples(traces, epoch):
    """Use one balanced CSI mode per true block in each epoch.

    Every epoch visits every true block once.  The selected observation mode
    rotates deterministically with block, seed, and epoch, so the four modes
    are balanced without multiplying one epoch by four.
    """
    samples = []
    for seed, trace in traces.items():
        for block_index in range(len(trace.blocks)):
            mode_index = (block_index + seed + int(epoch)) % len(MODE_SPECS)
            samples.append((seed, block_index, MODE_SPECS[mode_index]))
    rng = random.Random(91_000_003 + int(epoch))
    rng.shuffle(samples)
    return samples


def _validation_block_indices(trace, requested):
    num_blocks = len(trace.blocks)
    if requested <= 0 or requested >= num_blocks:
        return list(range(num_blocks))
    return np.linspace(
        0, num_blocks - 1, num=int(requested), dtype=int
    ).tolist()


def _forward_probabilities(model, observed_state, device):
    pi, _ = model(
        observed_state.vertex_features[:, :1].to(device),
        observed_state.edge_index.to(device),
        observed_state.edge_weights.to(device),
        use_ste=False,
    )
    return pi


def _true_soft_sum_rate(model, observed_state, true_state, device):
    pi = _forward_probabilities(model, observed_state, device)
    rates = calculate_achievable_rate(
        pi, true_state, binary=False
    )
    return rates.sum()


def _logits(model, state, device):
    logits, _ = model.schedule_logits(
        state.vertex_features[:, :1].to(device),
        state.edge_index.to(device),
        state.edge_weights.to(device),
    )
    return logits


def _sample_loss(model, teacher, observed_state, true_state, device, objective):
    if objective == "physical_soft_sum_rate":
        return -_true_soft_sum_rate(
            model, observed_state, true_state, device
        )
    if objective == "teacher_logit_mse":
        student_logits = _logits(model, observed_state, device)
        with torch.no_grad():
            teacher_logits = _logits(teacher, true_state, device)
        return torch.mean((student_logits - teacher_logits) ** 2)
    raise ValueError(f"Unknown training objective: {objective}")


def _evaluate(model, teacher, traces, net_gen, requested_blocks, device, objective):
    model.eval()
    mode_values = {label: [] for label, _ in MODE_SPECS}
    with torch.no_grad():
        for trace in traces.values():
            for block_index in _validation_block_indices(
                trace, requested_blocks
            ):
                true_state, _ = build_true_network_state(
                    net_gen, trace, block_index
                )
                for mode, bits in MODE_SPECS:
                    observed_state, observed_indices = build_observed_network_state(
                        net_gen, trace, block_index, mode, bits or 4
                    )
                    true_indices = torch.where(
                        trace.blocks[block_index].available
                    )[0]
                    if not torch.equal(observed_indices, true_indices):
                        raise RuntimeError("Validation lost persistent-link alignment")
                    if objective == "physical_soft_sum_rate":
                        pi = _forward_probabilities(
                            model, observed_state, device
                        )
                        rates = calculate_achievable_rate(
                            pi, true_state, binary=True, detach_hard=True
                        )
                        value = rates.sum()
                    else:
                        loss = _sample_loss(
                            model, teacher, observed_state, true_state,
                            device, objective,
                        )
                        # Teacher reconstruction remains a negative error.
                        value = -loss
                    mode_values[mode].append(float(value.item()))
    summary = {
        mode: float(np.mean(values)) for mode, values in mode_values.items()
    }
    summary["mean_all_modes"] = float(np.mean(list(summary.values())))
    return summary


def _representation_audit(model, traces, net_gen, requested_blocks, device):
    """Check that CSI augmentation retains noncollapsed binary decisions."""
    per_mode = {}
    model.eval()
    with torch.no_grad():
        for mode, bits in MODE_SPECS:
            probabilities = []
            active_fractions = []
            all_active = []
            all_inactive = []
            for trace in traces.values():
                for block_index in _validation_block_indices(
                    trace, requested_blocks
                ):
                    observed_state, _ = build_observed_network_state(
                        net_gen, trace, block_index, mode, bits or 4
                    )
                    pi = _forward_probabilities(
                        model, observed_state, device
                    ).reshape(-1).cpu()
                    action = pi >= 0.5
                    probabilities.append(pi)
                    active_fractions.append(float(action.float().mean().item()))
                    all_active.append(bool(action.all().item()))
                    all_inactive.append(bool((~action).all().item()))
            merged = torch.cat(probabilities)
            per_mode[mode] = {
                "probability_mean": float(merged.mean().item()),
                "probability_std": float(merged.std(unbiased=False).item()),
                "mean_binary_active_fraction": float(np.mean(active_fractions)),
                "all_links_active_state_fraction": float(np.mean(all_active)),
                "all_links_inactive_state_fraction": float(np.mean(all_inactive)),
            }
    return per_mode


def main():
    args = parse_args()
    train_seeds = _seed_spec(args.train_seeds)
    val_seeds = _seed_spec(args.val_seeds)
    overlap = sorted(set(train_seeds) & set(val_seeds))
    if overlap:
        raise ValueError(f"Train/validation seeds overlap: {overlap}")
    _set_seed(20260715)
    device = torch.device(args.device)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    net_gen = build_network_generator(cfg)
    model, base_checkpoint = load_channel_gat_checkpoint(
        cfg,
        args.base_checkpoint,
        args.channel_model_num_uav,
        device=device,
    )
    model = model.to(device)
    teacher = copy.deepcopy(model).to(device).eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)

    print("Generating independent mobile training traces...")
    train_traces = _generate_traces(
        net_gen, train_seeds, args, cfg.get("SLOT_DURATION", 0.001)
    )
    print("Generating independent mobile validation traces...")
    val_traces = _generate_traces(
        net_gen, val_seeds, args, cfg.get("SLOT_DURATION", 0.001)
    )
    initial_validation = _evaluate(
        model, teacher, val_traces, net_gen,
        args.val_blocks_per_trace, device, args.objective,
    )
    print("Initial frozen validation:")
    print(json.dumps(initial_validation, indent=2))

    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    best_value = initial_validation["mean_all_modes"]
    best_state = copy.deepcopy(model.state_dict())
    best_epoch = -1
    epochs_without_improvement = 0
    logs = []

    for epoch in range(args.epochs):
        model.train()
        losses = []
        mode_counts = {mode: 0 for mode, _ in MODE_SPECS}
        for seed, block_index, (mode, bits) in _training_samples(
            train_traces, epoch
        ):
            trace = train_traces[seed]
            observed_state, observed_indices = build_observed_network_state(
                net_gen, trace, block_index, mode, bits or 4
            )
            true_state, true_indices = build_true_network_state(
                net_gen, trace, block_index
            )
            if not torch.equal(observed_indices, true_indices):
                raise RuntimeError("Training lost persistent-link alignment")
            loss = _sample_loss(
                model, teacher, observed_state, true_state,
                device, args.objective,
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.item()))
            mode_counts[mode] += 1

        validation = _evaluate(
            model, teacher, val_traces, net_gen,
            args.val_blocks_per_trace, device, args.objective,
        )
        value = validation["mean_all_modes"]
        improved = value > best_value + 1e-8
        if improved:
            best_value = value
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        log = {
            "epoch": epoch,
            "mean_training_loss": float(np.mean(losses)),
            "num_training_samples": len(losses),
            "mode_counts": mode_counts,
            "validation": validation,
            "best_validation_mean": best_value,
            "improved": improved,
        }
        logs.append(log)
        print(json.dumps(log, ensure_ascii=False))
        if epochs_without_improvement >= args.patience:
            print(
                f"Early stopping after {args.patience} validation checks "
                "without improvement."
            )
            break

    model.load_state_dict(best_state)
    final_validation = _evaluate(
        model, teacher, val_traces, net_gen,
        args.val_blocks_per_trace, device, args.objective,
    )
    output_audit = _representation_audit(
        model, val_traces, net_gen,
        args.val_blocks_per_trace, device,
    )
    os.makedirs("results/models", exist_ok=True)
    os.makedirs("results/diagnostics", exist_ok=True)
    output_model = args.output_model or (
        "results/models/gat_csi_augmented_spatial_v1_"
        f"numUAV={args.num_uav}_tx=10dBm.pth"
    )
    output_report = args.output_report or (
        "results/diagnostics/csi_augmented_spatial_train_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    os.makedirs(os.path.dirname(output_model) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(output_report) or ".", exist_ok=True)
    checkpoint = {
        "model_version": (
            "channel_gat_csi_augmented_spatial_teacher_v2"
            if args.objective == "teacher_logit_mse"
            else "channel_gat_csi_augmented_spatial_v1"
        ),
        "model_state_dict": model.state_dict(),
        "base_checkpoint": base_checkpoint,
        "tx_power_dbm": 10.0,
        "channel_model": "rician",
        "rician_k_db": args.rician_k_db,
        "num_uav": args.num_uav,
        "training_csi_modes": [mode for mode, _ in MODE_SPECS],
        "true_rate_channel": "paired current perfect instantaneous CSI",
        "training_objective": args.objective,
        "queue_input_used": False,
        "settings": vars(args),
        "best_epoch": best_epoch,
        "initial_validation": initial_validation,
        "final_validation": final_validation,
        "output_audit": output_audit,
    }
    torch.save(checkpoint, output_model)
    report = {
        "experiment": "csi_augmented_spatial_gat_training_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "train_seeds": train_seeds,
        "val_seeds": val_seeds,
        "test_seeds_reserved": [42, 43, 44, 45, 46],
        "base_checkpoint": base_checkpoint,
        "output_model": output_model,
        "initial_validation": initial_validation,
        "final_validation": final_validation,
        "output_audit": output_audit,
        "best_epoch": best_epoch,
        "best_validation_mean": best_value,
        "logs": logs,
    }
    with open(output_report, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "output_model": output_model,
        "output_report": output_report,
        "best_epoch": best_epoch,
        "initial_validation": initial_validation,
        "final_validation": final_validation,
        "output_audit": output_audit,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
