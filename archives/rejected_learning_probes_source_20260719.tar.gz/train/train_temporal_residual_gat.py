#!/usr/bin/env python3
"""Train one link-local GRU residual on top of the CSI-augmented spatial GAT."""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.temporal_residual_gat import TemporalResidualChannelGAT
from simulator.mobile_block_fading import (
    build_observed_network_state,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import (
    build_gat_scheduler,
    build_network_generator,
    load_channel_gat,
    load_config,
)


MODE_SPECS = (
    ("latest", None),
    ("stale", None),
    ("large_scale", None),
    ("quantized", 4),
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--spatial_model",
        default=(
            "results/models/gat_csi_augmented_spatial_teacher_v2_"
            "numUAV=10_tx=10dBm.pth"
        ),
    )
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument(
        "--rician_k_db", type=float, default=None,
        help=(
            "None keeps historical Rayleigh fading; a finite value uses "
            "normalized Rician fading and inf uses the pure-LoS boundary."
        ),
    )
    parser.add_argument(
        "--csi_modes", default="latest,stale,large_scale,quantized",
        help=(
            "Comma-separated training/validation modes. The formal universal "
            "model uses all four; a stale-only run is a temporal-feasibility probe."
        ),
    )
    parser.add_argument("--train_seeds", default="1000-1019")
    parser.add_argument("--val_seeds", default="2000-2004")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--learning_rate", type=float, default=1e-5)
    parser.add_argument("--temporal_hidden_dim", type=int, default=48)
    parser.add_argument(
        "--bptt_blocks", type=int, default=10,
        help="Number of consecutive channel blocks per truncated-gradient window.",
    )
    parser.add_argument("--patience", type=int, default=5)
    parser.add_argument(
        "--val_blocks_per_trace", type=int, default=40,
        help="Scored blocks per trace; every block is still processed for history.",
    )
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--output_model", default="")
    parser.add_argument("--output_report", default="")
    return parser.parse_args()


def _seed_spec(text):
    values = []
    for item in text.split(","):
        item = item.strip()
        if not item:
            continue
        if "-" in item:
            start, end = item.split("-", 1)
            values.extend(range(int(start), int(end) + 1))
        else:
            values.append(int(item))
    return values


def _set_seed(seed):
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))


def _generate_traces(net_gen, seeds, args, slot_duration):
    return {
        int(seed): generate_mobile_block_fading_trace(
            net_gen,
            num_slots=args.num_slots,
            slots_per_block=args.slots_per_block,
            slot_duration=slot_duration,
            speed_mps=args.speed_mps,
            seed=seed,
            quantization_bits=(4,),
            rician_k_db=args.rician_k_db,
        )
        for seed in seeds
    }


def _load_spatial_model(path, cfg, device):
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    if checkpoint.get("model_version") != "channel_gat_csi_augmented_spatial_teacher_v2":
        raise ValueError(
            "Temporal-v1 requires the non-collapsed teacher-prior spatial baseline; "
            f"got {checkpoint.get('model_version')} from {path}"
        )
    model = build_gat_scheduler(cfg, raw_node_dim=1)
    model.load_state_dict(checkpoint["model_state_dict"])
    return model.to(device).eval(), checkpoint


def _teacher_logits(teacher, true_state, device):
    with torch.no_grad():
        logits, _ = teacher.schedule_logits(
            true_state.vertex_features[:, :1].to(device),
            true_state.edge_index.to(device),
            true_state.edge_weights.to(device),
        )
    return logits


def _build_frozen_feature_cache(
    spatial_model, teacher, traces, net_gen, device, mode_specs
):
    """Precompute the frozen spatial embedding and true-CSI teacher target."""
    cache = {}
    with torch.no_grad():
        for seed, trace in traces.items():
            teacher_targets = {}
            for block_index in range(len(trace.blocks)):
                true_state, true_indices = build_true_network_state(
                    net_gen, trace, block_index
                )
                teacher_targets[block_index] = (
                    _teacher_logits(teacher, true_state, device).cpu(),
                    true_indices,
                )
            for mode, bits in mode_specs:
                sequence = []
                for block_index in range(len(trace.blocks)):
                    observed_state, observed_indices = build_observed_network_state(
                        net_gen, trace, block_index, mode, bits or 4
                    )
                    target, true_indices = teacher_targets[block_index]
                    if not torch.equal(observed_indices, true_indices):
                        raise RuntimeError("Feature cache lost persistent-link alignment")
                    base, embedding = spatial_model.schedule_logits(
                        observed_state.vertex_features[:, :1].to(device),
                        observed_state.edge_index.to(device),
                        observed_state.edge_weights.to(device),
                    )
                    sequence.append({
                        "link_keys": [
                            tuple(map(int, pair))
                            for pair in observed_state.links.cpu().tolist()
                        ],
                        "embedding": embedding.detach().cpu(),
                        "base_logits": base.detach().cpu(),
                        "teacher_logits": target,
                    })
                cache[(int(seed), mode)] = sequence
    return cache


def _validation_indices(num_blocks, requested):
    if requested <= 0 or requested >= num_blocks:
        return set(range(num_blocks))
    return set(np.linspace(
        0, num_blocks - 1, num=requested, dtype=int
    ).tolist())


def _evaluate(
    model, feature_cache, seeds, requested_blocks, device, mode_specs
):
    model.eval()
    values = {mode: [] for mode, _ in mode_specs}
    residuals = {mode: [] for mode, _ in mode_specs}
    with torch.no_grad():
        for seed in seeds:
            for mode, bits in mode_specs:
                del bits
                sequence = feature_cache[(int(seed), mode)]
                scored = _validation_indices(len(sequence), requested_blocks)
                hidden = {}
                for block_index, sample in enumerate(sequence):
                    logits, hidden = model.temporal_step_from_embedding(
                        sample["link_keys"], sample["embedding"],
                        sample["base_logits"], hidden, detach_update=True,
                    )
                    if block_index in scored:
                        target = sample["teacher_logits"].to(device)
                        values[mode].append(float(torch.mean(
                            (logits - target) ** 2
                        ).item()))
                        residuals[mode].append(float(torch.mean(
                            torch.abs(logits - sample["base_logits"].to(device))
                        ).item()))
    mean_mse = {mode: float(np.mean(items)) for mode, items in values.items()}
    mean_abs_residual = {
        mode: float(np.mean(items)) for mode, items in residuals.items()
    }
    return {
        "negative_mse": {
            **{mode: -value for mode, value in mean_mse.items()},
            "mean_all_modes": -float(np.mean(list(mean_mse.values()))),
        },
        "mean_absolute_logit_residual": {
            **mean_abs_residual,
            "mean_all_modes": float(np.mean(list(mean_abs_residual.values()))),
        },
    }


def _mode_for_trace(seed, epoch, mode_specs):
    return mode_specs[(int(seed) + int(epoch)) % len(mode_specs)]


def _selected_mode_specs(text):
    requested = [item.strip() for item in text.split(",") if item.strip()]
    available = {mode: (mode, bits) for mode, bits in MODE_SPECS}
    unknown = sorted(set(requested) - set(available))
    if unknown or not requested:
        raise ValueError(
            f"Invalid csi_modes={requested}; expected nonempty subset of "
            f"{sorted(available)}"
        )
    return tuple(available[mode] for mode in requested)


def _train_one_sequence(
    model, sequence, optimizer, device, bptt_blocks
):
    hidden = {}
    window_losses = []
    losses = []
    for block_index, sample in enumerate(sequence):
        logits, hidden = model.temporal_step_from_embedding(
            sample["link_keys"], sample["embedding"],
            sample["base_logits"], hidden, detach_update=False,
        )
        target = sample["teacher_logits"].to(device)
        loss = torch.mean((logits - target) ** 2)
        window_losses.append(loss)
        losses.append(float(loss.detach().item()))
        last = block_index == len(sequence) - 1
        if len(window_losses) >= bptt_blocks or last:
            mean_loss = torch.stack(window_losses).mean()
            optimizer.zero_grad()
            mean_loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(model.temporal_cell.parameters())
                + list(model.residual_head.parameters()),
                5.0,
            )
            optimizer.step()
            hidden = model.detach_hidden(hidden)
            window_losses = []
    return losses


def main():
    args = parse_args()
    if args.bptt_blocks < 1:
        raise ValueError("bptt_blocks must be >= 1")
    train_seeds = _seed_spec(args.train_seeds)
    val_seeds = _seed_spec(args.val_seeds)
    mode_specs = _selected_mode_specs(args.csi_modes)
    overlap = sorted(set(train_seeds) & set(val_seeds))
    if overlap:
        raise ValueError(f"Train/validation seeds overlap: {overlap}")
    _set_seed(20260715)
    device = torch.device(args.device)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect"})
    net_gen = build_network_generator(cfg)
    spatial, spatial_checkpoint = _load_spatial_model(
        args.spatial_model, cfg, device
    )
    teacher, teacher_checkpoint = load_channel_gat(
        cfg, args.num_uav, device=device
    )
    teacher.eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    model = TemporalResidualChannelGAT(
        spatial,
        embedding_dim=cfg.get("GAT_OUT_DIM", 48),
        temporal_hidden_dim=args.temporal_hidden_dim,
    ).to(device).freeze_spatial()

    print("Generating independent sequential mobile training traces...")
    train_traces = _generate_traces(
        net_gen, train_seeds, args, cfg.get("SLOT_DURATION", 0.001)
    )
    print("Generating independent sequential mobile validation traces...")
    val_traces = _generate_traces(
        net_gen, val_seeds, args, cfg.get("SLOT_DURATION", 0.001)
    )
    print("Caching frozen spatial embeddings and teacher targets...")
    train_cache = _build_frozen_feature_cache(
        model.spatial_model, teacher, train_traces, net_gen, device, mode_specs
    )
    val_cache = _build_frozen_feature_cache(
        model.spatial_model, teacher, val_traces, net_gen, device, mode_specs
    )
    initial_validation = _evaluate(
        model, val_cache, val_seeds, args.val_blocks_per_trace, device,
        mode_specs,
    )
    print("Initial zero-residual validation:")
    print(json.dumps(initial_validation, indent=2))

    trainable = (
        list(model.temporal_cell.parameters())
        + list(model.residual_head.parameters())
    )
    optimizer = torch.optim.Adam(trainable, lr=args.learning_rate)
    best_value = initial_validation["negative_mse"]["mean_all_modes"]
    best_state = copy.deepcopy(model.state_dict())
    best_epoch = -1
    epochs_without_improvement = 0
    logs = []

    for epoch in range(args.epochs):
        model.train()
        order = list(train_seeds)
        random.Random(20260715 + epoch).shuffle(order)
        losses = []
        mode_counts = {mode: 0 for mode, _ in mode_specs}
        for seed in order:
            mode, bits = _mode_for_trace(seed, epoch, mode_specs)
            del bits
            sequence_losses = _train_one_sequence(
                model, train_cache[(int(seed), mode)],
                optimizer, device, args.bptt_blocks,
            )
            losses.extend(sequence_losses)
            mode_counts[mode] += len(sequence_losses)
        validation = _evaluate(
            model, val_cache, val_seeds, args.val_blocks_per_trace, device,
            mode_specs,
        )
        value = validation["negative_mse"]["mean_all_modes"]
        improved = value > best_value + 1e-8
        if improved:
            best_value = value
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        log = {
            "epoch": epoch,
            "mean_training_mse": float(np.mean(losses)),
            "num_training_blocks": len(losses),
            "mode_counts": mode_counts,
            "validation": validation,
            "best_validation_negative_mse": best_value,
            "improved": improved,
        }
        logs.append(log)
        print(json.dumps(log, ensure_ascii=False))
        if epochs_without_improvement >= args.patience:
            print(
                f"Early stopping after {args.patience} validation checks "
                "without improvement."
            )
            break

    model.load_state_dict(best_state)
    final_validation = _evaluate(
        model, val_cache, val_seeds, args.val_blocks_per_trace, device,
        mode_specs,
    )
    os.makedirs("results/models", exist_ok=True)
    os.makedirs("results/diagnostics", exist_ok=True)
    output_model = args.output_model or (
        "results/models/gat_temporal_residual_v1_"
        f"numUAV={args.num_uav}_tx=10dBm.pth"
    )
    output_report = args.output_report or (
        "results/diagnostics/temporal_residual_train_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    checkpoint = {
        "model_version": model.model_version,
        "model_state_dict": model.state_dict(),
        "spatial_checkpoint": args.spatial_model,
        "spatial_model_version": spatial_checkpoint.get("model_version"),
        "teacher_checkpoint": teacher_checkpoint,
        "tx_power_dbm": 10.0,
        "num_uav": args.num_uav,
        "embedding_dim": cfg.get("GAT_OUT_DIM", 48),
        "temporal_hidden_dim": args.temporal_hidden_dim,
        "spatial_frozen": True,
        "residual_zero_initialized": True,
        "training_objective": "current_true_csi_teacher_logit_mse",
        "training_csi_modes": [mode for mode, _ in mode_specs],
        "rician_k_db": args.rician_k_db,
        "persistent_link_identity": "directed_uav_pair_(tx,rx)",
        "settings": vars(args),
        "best_epoch": best_epoch,
        "initial_validation": initial_validation,
        "final_validation": final_validation,
    }
    torch.save(checkpoint, output_model)
    report = {
        "experiment": "temporal_residual_channel_gat_training_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "train_seeds": train_seeds,
        "val_seeds": val_seeds,
        "test_seeds_reserved": [42, 43, 44, 45, 46],
        "spatial_checkpoint": args.spatial_model,
        "teacher_checkpoint": teacher_checkpoint,
        "output_model": output_model,
        "initial_validation": initial_validation,
        "final_validation": final_validation,
        "best_epoch": best_epoch,
        "best_validation_negative_mse": best_value,
        "logs": logs,
    }
    with open(output_report, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "output_model": output_model,
        "output_report": output_report,
        "best_epoch": best_epoch,
        "initial_validation": initial_validation,
        "final_validation": final_validation,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
