#!/usr/bin/env python3
"""Oracle message-budget gate for conditional physical MWS updates.

For every proposed binary toggle, the oracle keeps only the largest exact
per-receiver utility contributions.  Because it already knows the true
contributions, it is an optimistic lower bound on the communication fraction
needed by any learned edge-attention/sparsification method.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_conditional_negotiation_gate import (  # noqa: E402
    ExactToggleState,
    _UnusedChannelModel,
    positive_coordinate_sweeps,
)
from experiments.diagnose_mws_topology_scaling_headroom import queue_snapshot  # noqa: E402
from models.local_physical_reuse import PurePhysicalReuseScheduler  # noqa: E402
from utils.project_setup import build_network_generator, load_config  # noqa: E402


def top_contribution_sweeps(engine, fraction, sweeps, rng):
    engine = engine.clone()
    eligible = np.flatnonzero((engine.queues > 0).numpy())
    kept = max(1, int(np.ceil(float(fraction) * engine.queues.numel())))
    evaluated = accepted = false_positive = sign_matches = 0
    for _ in range(int(sweeps)):
        changed = False
        for link in rng.permutation(eligible):
            contributions = engine.toggle_contributions(link)
            global_delta = float(contributions.sum())
            indices = torch.topk(contributions.abs(), k=kept).indices
            compressed_delta = float(contributions[indices].sum())
            compressed_positive = compressed_delta > 1e-9
            global_positive = global_delta > 1e-9
            sign_matches += int(compressed_positive == global_positive)
            false_positive += int(compressed_positive and not global_positive)
            evaluated += 1
            if compressed_positive:
                engine.toggle(link)
                accepted += 1
                changed = True
        if not changed:
            break
    return {
        "utility": engine.utility(),
        "accepted": accepted,
        "sign_accuracy": sign_matches / max(evaluated, 1),
        "false_positive_fraction": false_positive / max(evaluated, 1),
    }


def summarize(records, method):
    gains = np.asarray([
        row[method]["utility"] / max(abs(row["pure_utility"]), 1e-12) - 1.0
        for row in records
    ])
    return {
        "num_snapshots": len(records),
        "mean_gain_fraction_vs_pure": float(gains.mean()),
        "gain_ci95": float(1.96 * gains.std(ddof=1) / np.sqrt(len(gains)))
        if len(gains) > 1 else 0.0,
        "strict_win_fraction_vs_pure": float(np.mean(gains > 1e-9)),
        "strict_loss_fraction_vs_pure": float(np.mean(gains < -1e-9)),
        "mean_sign_accuracy": float(np.mean([
            row[method].get("sign_accuracy", 1.0) for row in records
        ])),
        "mean_false_positive_fraction": float(np.mean([
            row[method].get("false_positive_fraction", 0.0) for row in records
        ])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--profiles", default="sparse,heterogeneous,saturated")
    parser.add_argument("--fractions", default="0.10,0.25,0.50,0.75")
    parser.add_argument(
        "--output",
        default="results/formal/weighted_message_budget_gate_N20_rician_20260717.json",
    )
    args = parser.parse_args()
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician", "RICIAN_K_DB": 5.0,
    })
    generator = build_network_generator(config)
    pure = PurePhysicalReuseScheduler(_UnusedChannelModel())
    profiles = [item.strip() for item in args.profiles.split(",") if item.strip()]
    fractions = [float(item) for item in args.fractions.split(",")]
    methods = ["global_2"] + [f"top_{int(100*f)}pct_2" for f in fractions]
    records = []
    for graph_index in range(args.num_graphs):
        graph_seed = args.seed + graph_index
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            base = ExactToggleState(
                state, queues, pure.schedule_with_state(state, queues)
            )
            order_seed = graph_seed + 20_000 * profile_index
            global_result = positive_coordinate_sweeps(
                base, 2, np.random.default_rng(order_seed)
            )
            row = {
                "graph_seed": graph_seed,
                "queue_profile": profile,
                "num_links": int(state.num_vertices),
                "pure_utility": base.utility(),
                "global_2": {"utility": global_result[0], "accepted": global_result[2]},
            }
            for fraction in fractions:
                row[f"top_{int(100*fraction)}pct_2"] = top_contribution_sweeps(
                    base, fraction, 2, np.random.default_rng(order_seed)
                )
            records.append(row)
            print(
                f"seed={graph_seed} profile={profile:<13} "
                + " ".join(
                    f"{int(100*f)}%={100*(row[f'top_{int(100*f)}pct_2']['utility']/row['pure_utility']-1):+.1f}%"
                    for f in fractions
                )
            )

    overall = {method: summarize(records, method) for method in methods}
    by_profile = {
        profile: {
            method: summarize(
                [row for row in records if row["queue_profile"] == profile], method
            ) for method in methods
        } for profile in profiles
    }
    global_gain = overall["global_2"]["mean_gain_fraction_vs_pure"]
    viable = []
    for fraction in fractions:
        name = f"top_{int(100*fraction)}pct_2"
        result = overall[name]
        recovery = result["mean_gain_fraction_vs_pure"] / max(global_gain, 1e-12)
        if recovery >= 0.50 and result["strict_loss_fraction_vs_pure"] <= 0.20:
            viable.append(fraction)
    minimum_viable = min(viable) if viable else None
    passed = minimum_viable is not None and minimum_viable <= 0.25
    payload = {
        "experiment": "weighted_message_budget_oracle_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definition": (
            "For each toggle, retain the largest exact receiver-level utility "
            "contributions. This is an optimistic nondeployable oracle."
        ),
        "predeclared_gate": {
            "maximum_message_fraction": 0.25,
            "minimum_global_gain_recovery": 0.50,
            "maximum_loss_fraction": 0.20,
        },
        "minimum_viable_fraction": minimum_viable,
        "gate_passed": passed,
        "decision": (
            "MESSAGE_COMPRESSION_FEASIBLE_REQUIRES_ATTRIBUTION_AUDIT"
            if passed else "STOP_LEARNED_SPARSIFICATION_ROUTE"
        ),
        "overall": overall,
        "by_profile": by_profile,
        "records": records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "decision": payload["decision"],
        "minimum_viable_fraction": minimum_viable,
        "overall": overall,
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
