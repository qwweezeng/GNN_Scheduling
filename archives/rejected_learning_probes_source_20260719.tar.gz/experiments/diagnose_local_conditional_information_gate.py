#!/usr/bin/env python3
"""Measure how much exact MWS toggle information is lost at one hop."""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_conditional_negotiation_gate import (  # noqa: E402
    ExactToggleState,
    _UnusedChannelModel,
    positive_coordinate_sweeps,
)
from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    conflict_neighbors,
    queue_snapshot,
)
from models.local_physical_reuse import PurePhysicalReuseScheduler  # noqa: E402
from utils.project_setup import build_network_generator, load_config  # noqa: E402


def hop_scopes(edge_index, num_links, hops):
    neighbors = conflict_neighbors(edge_index, num_links)
    scopes = []
    coverages = []
    for root in range(num_links):
        reached = {root}
        frontier = {root}
        for _ in range(int(hops)):
            frontier = set().union(*(neighbors[node] for node in frontier)) - reached
            reached.update(frontier)
        mask = torch.zeros(num_links, dtype=torch.bool)
        mask[torch.tensor(sorted(reached), dtype=torch.long)] = True
        scopes.append(mask)
        coverages.append(len(reached) / max(num_links, 1))
    return scopes, float(np.mean(coverages))


def local_positive_sweeps(engine, scopes, sweeps, rng):
    engine = engine.clone()
    eligible = np.flatnonzero((engine.queues > 0).numpy())
    sign_matches = 0
    evaluated = 0
    false_positive = 0
    accepted = 0
    for _ in range(int(sweeps)):
        changed = False
        for link in rng.permutation(eligible):
            local_delta = engine.toggle_delta_on_mask(link, scopes[int(link)])
            global_delta = engine.toggle_delta(link)
            local_positive = local_delta > 1e-9
            global_positive = global_delta > 1e-9
            sign_matches += int(local_positive == global_positive)
            false_positive += int(local_positive and not global_positive)
            evaluated += 1
            if local_positive:
                engine.toggle(link)
                accepted += 1
                changed = True
        if not changed:
            break
    return {
        "utility": engine.utility(),
        "action": engine.action.clone(),
        "accepted": accepted,
        "sign_accuracy": sign_matches / max(evaluated, 1),
        "false_positive_fraction": false_positive / max(evaluated, 1),
    }


def summarize(records, method):
    gains = np.asarray([
        row[method]["utility"] / max(abs(row["pure_utility"]), 1e-12) - 1.0
        for row in records
    ])
    return {
        "num_snapshots": len(records),
        "mean_gain_fraction_vs_pure": float(gains.mean()),
        "gain_ci95": float(1.96 * gains.std(ddof=1) / np.sqrt(len(gains)))
        if len(gains) > 1 else 0.0,
        "strict_win_fraction_vs_pure": float(np.mean(gains > 1e-9)),
        "strict_loss_fraction_vs_pure": float(np.mean(gains < -1e-9)),
        "mean_sign_accuracy": float(np.mean([
            row[method].get("sign_accuracy", 1.0) for row in records
        ])),
        "mean_false_positive_fraction": float(np.mean([
            row[method].get("false_positive_fraction", 0.0) for row in records
        ])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--profiles", default="sparse,heterogeneous,saturated")
    parser.add_argument(
        "--output",
        default="results/formal/local_conditional_information_gate_N20_rician_20260717.json",
    )
    args = parser.parse_args()

    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    pure = PurePhysicalReuseScheduler(_UnusedChannelModel())
    profiles = [item.strip() for item in args.profiles.split(",") if item.strip()]
    methods = ("global_2", "one_hop_2", "two_hop_2")
    records = []
    for graph_index in range(args.num_graphs):
        graph_seed = args.seed + graph_index
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        one_hop, one_coverage = hop_scopes(state.edge_index, state.num_vertices, 1)
        two_hop, two_coverage = hop_scopes(state.edge_index, state.num_vertices, 2)
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            pure_action = pure.schedule_with_state(state, queues)
            base = ExactToggleState(state, queues, pure_action)
            order_seed = graph_seed + 20_000 * profile_index
            global_result = positive_coordinate_sweeps(
                base, 2, np.random.default_rng(order_seed)
            )
            row = {
                "graph_seed": graph_seed,
                "queue_profile": profile,
                "num_links": int(state.num_vertices),
                "pure_utility": base.utility(),
                "one_hop_mean_coverage": one_coverage,
                "two_hop_mean_coverage": two_coverage,
                "global_2": {"utility": global_result[0], "accepted": global_result[2]},
                "one_hop_2": local_positive_sweeps(
                    base, one_hop, 2, np.random.default_rng(order_seed)
                ),
                "two_hop_2": local_positive_sweeps(
                    base, two_hop, 2, np.random.default_rng(order_seed)
                ),
            }
            for value in row.values():
                if isinstance(value, dict):
                    value.pop("action", None)
            records.append(row)
            print(
                f"seed={graph_seed} profile={profile:<13} "
                f"global={100*(row['global_2']['utility']/row['pure_utility']-1):+.1f}% "
                f"1hop={100*(row['one_hop_2']['utility']/row['pure_utility']-1):+.1f}% "
                f"sign={100*row['one_hop_2']['sign_accuracy']:.1f}%"
            )

    overall = {method: summarize(records, method) for method in methods}
    by_profile = {
        profile: {
            method: summarize(
                [row for row in records if row["queue_profile"] == profile], method
            ) for method in methods
        } for profile in profiles
    }
    global_gain = overall["global_2"]["mean_gain_fraction_vs_pure"]
    local_gain = overall["one_hop_2"]["mean_gain_fraction_vs_pure"]
    recovery = local_gain / max(global_gain, 1e-12)
    if local_gain >= 0.02 and overall["one_hop_2"]["strict_loss_fraction_vs_pure"] <= 0.20:
        decision = "LOCAL_INFORMATION_IS_USABLE_TEST_PARALLEL_COORDINATION"
    elif global_gain >= 0.02 and recovery < 0.50:
        decision = "TRAIN_MINIMAL_GAT_ONLY_FOR_MISSING_EXTERNALITY"
    else:
        decision = "STOP_SINGLE_TOGGLE_ROUTE"
    payload = {
        "experiment": "local_conditional_information_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definitions": {
            "global_2": "Nondeployable exact global positive-toggle oracle.",
            "one_hop_2": "Uses only the toggled link and its conflict-graph neighbors to decide each toggle.",
            "two_hop_2": "Diagnostic only; prior audits show this scope can approach the whole graph.",
            "sequential_order_is_not_yet_deployable": True,
        },
        "mean_global_gain_recovered_by_one_hop": float(recovery),
        "decision": decision,
        "overall": overall,
        "by_profile": by_profile,
        "records": records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"decision": decision, "recovery": recovery, "overall": overall, "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
