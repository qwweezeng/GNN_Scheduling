#!/usr/bin/env python3
"""No-training audit of queue-masked continuous-pi expected SINR.

LocalPhysicalReuse-v2 already inserts the continuous conference probability
``pi_j`` into expected interference.  The current production formula does not,
however, suppress ``pi_j`` when link j has an empty queue and therefore cannot
actually transmit.  This diagnostic compares the original formula with the
physically feasible activity ``pi_j * 1[Q_j > 0]``.

A same-mean constant-pi control separates graph-specific GAT information from
the generic benefit of removing empty-queue phantom interference.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    ConstantPriorModel,
    queue_snapshot,
)
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
    local_edge_gains,
    select_local_maxima,
)
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


PROFILES = ("sparse", "heterogeneous", "saturated")
METHODS = (
    "gat_unmasked",
    "gat_nonempty_masked",
    "constant_unmasked",
    "constant_nonempty_masked",
)


def continuous_activity(model, state):
    with torch.no_grad():
        if hasattr(model, "schedule_logits_with_state"):
            logits, _ = model.schedule_logits_with_state(state)
        else:
            logits, _ = model.schedule_logits(
                state.vertex_features[:, :1],
                state.edge_index,
                state.edge_weights,
            )
    return torch.sigmoid(logits.detach().reshape(-1)).cpu()


def expected_rate_action(model, state, queues, nonempty_mask):
    queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).cpu()
    direct, source, target, edge_gain = local_edge_gains(state)
    noise = torch.as_tensor(state.noise_power, dtype=torch.float32).cpu()
    snr_gap = float(getattr(state, "snr_gap", 1.0))
    activity = continuous_activity(model, state)
    if nonempty_mask:
        activity = activity * (queues > 0).float()
    expected_interference = torch.zeros_like(direct)
    if source.numel() > 0:
        expected_interference.index_add_(
            0, target, edge_gain * activity[source]
        )
    expected_rate = torch.log2(
        1.0 + direct / (noise + expected_interference) / snr_gap
    )
    priority = queues * expected_rate
    base = select_local_maxima(
        priority, queues > 0, state.edge_index
    ).float()
    final, _, _ = complete_physical_reuse_from_base(
        state, queues, base
    )
    return final, base, activity, expected_rate


def paired_summary(records, candidate, reference):
    ratios = np.asarray([
        row["utilities"][candidate]
        / max(abs(row["utilities"][reference]), 1e-12)
        for row in records
    ])
    return {
        "mean_ratio": float(np.mean(ratios)),
        "ci95": float(
            1.96 * np.std(ratios, ddof=1) / np.sqrt(len(ratios))
        ) if len(ratios) > 1 else 0.0,
        "strict_win_fraction": float(np.mean(ratios > 1.0 + 1e-9)),
        "strict_loss_fraction": float(np.mean(ratios < 1.0 - 1e-9)),
    }


def summarize(records):
    return {
        "gat_masked_over_unmasked": paired_summary(
            records, "gat_nonempty_masked", "gat_unmasked"
        ),
        "constant_masked_over_unmasked": paired_summary(
            records, "constant_nonempty_masked", "constant_unmasked"
        ),
        "gat_masked_over_pure": paired_summary(
            records, "gat_nonempty_masked", "pure"
        ),
        "gat_masked_over_constant_masked": paired_summary(
            records, "gat_nonempty_masked", "constant_nonempty_masked"
        ),
        "gat_unmasked_over_pure": paired_summary(
            records, "gat_unmasked", "pure"
        ),
        "constant_masked_over_pure": paired_summary(
            records, "constant_nonempty_masked", "pure"
        ),
        "mean_nonempty_fraction": float(np.mean([
            row["nonempty_fraction"] for row in records
        ])),
        "gat_mask_changes_final_action_fraction": float(np.mean([
            row["gat_mask_changes_final_action"] for row in records
        ])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument(
        "--constant_probability", type=float,
        default=0.050029350853525105,
    )
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument(
        "--minimum_material_ratio", type=float, default=1.01
    )
    parser.add_argument(
        "--minimum_win_fraction", type=float, default=0.60
    )
    parser.add_argument(
        "--output",
        default=(
            "results/formal/queue_masked_expected_rate_probe_"
            "N20_rician_20260717.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("This probe is frozen to N=20 and 10 dBm.")

    config = load_config(args.config)
    config.update({
        "NUM_UAV": 20,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config, args.channel_gat_checkpoint, 20,
        device="cpu", allow_power_transfer=False,
    )
    constant_model = ConstantPriorModel(args.constant_probability)
    pure = PurePhysicalReuseScheduler(channel_model)

    records = []
    for graph_offset in range(args.num_graphs):
        graph_seed = args.seed + graph_offset
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        for profile_index, profile in enumerate(PROFILES):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            actions = {}
            bases = {}
            for prefix, model in (
                ("gat", channel_model),
                ("constant", constant_model),
            ):
                for label, masked in (
                    ("unmasked", False),
                    ("nonempty_masked", True),
                ):
                    action, base, _, _ = expected_rate_action(
                        model, state, queues, masked
                    )
                    actions[f"{prefix}_{label}"] = action
                    bases[f"{prefix}_{label}"] = base
            actions["pure"] = pure.schedule_with_state(state, queues)
            utilities = {
                name: float(mws_objective(action, queues, state))
                for name, action in actions.items()
            }
            if profile == "saturated":
                if not torch.equal(
                    actions["gat_unmasked"].reshape(-1).round(),
                    actions["gat_nonempty_masked"].reshape(-1).round(),
                ):
                    raise RuntimeError(
                        "Nonempty mask changed an all-nonempty saturated action."
                    )
            record = {
                "graph_seed": graph_seed,
                "profile": profile,
                "num_links": int(state.num_vertices),
                "nonempty_fraction": float((queues > 0).float().mean()),
                "utilities": utilities,
                "skeleton_links": {
                    name: int(base.sum()) for name, base in bases.items()
                },
                "final_active_links": {
                    name: int(action.sum()) for name, action in actions.items()
                },
                "gat_mask_changes_final_action": float(not torch.equal(
                    actions["gat_unmasked"].reshape(-1).round(),
                    actions["gat_nonempty_masked"].reshape(-1).round(),
                )),
            }
            records.append(record)
            print(
                f"seed={graph_seed} profile={profile:<13} "
                f"nonempty={100*record['nonempty_fraction']:.1f}% "
                f"mask/current={utilities['gat_nonempty_masked']/utilities['gat_unmasked']:.3f} "
                f"mask/Pure={utilities['gat_nonempty_masked']/utilities['pure']:.3f}"
            )

    by_profile = {
        profile: summarize([
            row for row in records if row["profile"] == profile
        ])
        for profile in PROFILES
    }
    sparse_material = bool(
        by_profile["sparse"]["gat_masked_over_unmasked"]["mean_ratio"]
        >= args.minimum_material_ratio
        and by_profile["sparse"]["gat_masked_over_unmasked"][
            "strict_win_fraction"
        ] >= args.minimum_win_fraction
    )
    graph_specific = all(
        by_profile[profile]["gat_masked_over_pure"]["mean_ratio"]
        >= args.minimum_material_ratio
        and by_profile[profile]["gat_masked_over_constant_masked"]["mean_ratio"]
        >= args.minimum_material_ratio
        and by_profile[profile]["gat_masked_over_pure"]["strict_win_fraction"]
        >= args.minimum_win_fraction
        for profile in ("heterogeneous", "saturated")
    )
    payload = {
        "experiment": "queue_masked_continuous_pi_expected_rate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "motivation": (
            "Check whether the continuous conference pi expected-SINR idea "
            "was already tested, and correct phantom interference from links "
            "whose current queues are empty."
        ),
        "current_v2_formula": (
            "Ihat_i=sum_j pi_j*g_ji; Rhat_i=log2(1+g_ii/(noise+Ihat_i)); "
            "W_i=Q_i*Rhat_i. The pi values are continuous and not rounded."
        ),
        "new_formula": (
            "Ihat_i=sum_j pi_j*1[Q_j>0]*g_ji; all later LocalMax and "
            "physical-reuse steps are unchanged."
        ),
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "by_profile": by_profile,
        "records": records,
        "predeclared_gate": {
            "minimum_material_ratio": args.minimum_material_ratio,
            "minimum_win_fraction": args.minimum_win_fraction,
            "sparse_mask_correction_material": sparse_material,
            "graph_specific_value_vs_pure_and_masked_constant": graph_specific,
        },
        "decision": (
            "MASK_CORRECTION_HAS_GRAPH_SPECIFIC_VALUE"
            if graph_specific
            else (
                "KEEP_MASK_AS_PHYSICAL_CORRECTION_ONLY"
                if sparse_material
                else "MASK_CORRECTION_NOT_MATERIAL"
            )
        ),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "by_profile": by_profile,
        "predeclared_gate": payload["predeclared_gate"],
        "decision": payload["decision"],
        "output": str(output),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
