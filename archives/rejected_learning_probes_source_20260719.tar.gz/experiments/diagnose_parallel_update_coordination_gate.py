#!/usr/bin/env python3
"""Zero-training gate for learned parallel conditional-update priorities."""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_conditional_negotiation_gate import (  # noqa: E402
    ExactToggleState,
    _UnusedChannelModel,
    positive_coordinate_sweeps,
)
from experiments.diagnose_mws_topology_scaling_headroom import queue_snapshot  # noqa: E402
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    select_local_positive_maxima,
)
from utils.project_setup import build_network_generator, load_config  # noqa: E402


def parallel_rounds(engine, rounds, priority_mode, rng):
    engine = engine.clone()
    total_selected = 0
    for _ in range(int(rounds)):
        deltas = torch.tensor([
            engine.toggle_delta(link) if engine.queues[link] > 0 else -float("inf")
            for link in range(engine.queues.numel())
        ], dtype=torch.float32)
        valid = torch.isfinite(deltas) & (deltas > 1e-6)
        if not valid.any():
            break
        if priority_mode == "delta":
            priorities = deltas
            selected = select_local_positive_maxima(
                priorities, valid, engine.state.edge_index
            )
        elif priority_mode == "random":
            priorities = torch.from_numpy(
                rng.random(engine.queues.numel()).astype(np.float32)
            ) + 1e-6
            selected = select_local_positive_maxima(
                priorities, valid, engine.state.edge_index
            )
        elif priority_mode == "single_best":
            selected = torch.zeros_like(valid)
            selected[int(torch.argmax(deltas))] = True
        else:
            raise ValueError(priority_mode)
        indices = torch.nonzero(selected, as_tuple=True)[0].tolist()
        if not indices:
            break
        for link in indices:
            engine.toggle(link)
        total_selected += len(indices)
    return engine.utility(), total_selected


def summarize(records, method):
    gains = np.asarray([
        row[method] / max(abs(row["pure_utility"]), 1e-12) - 1.0
        for row in records
    ])
    return {
        "num_snapshots": len(records),
        "mean_gain_fraction_vs_pure": float(gains.mean()),
        "gain_ci95": float(1.96 * gains.std(ddof=1) / np.sqrt(len(gains)))
        if len(gains) > 1 else 0.0,
        "strict_win_fraction_vs_pure": float(np.mean(gains > 1e-9)),
        "strict_loss_fraction_vs_pure": float(np.mean(gains < -1e-9)),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--random_trials", type=int, default=8)
    parser.add_argument(
        "--output",
        default="results/formal/parallel_update_coordination_gate_N20_rician_20260717.json",
    )
    args = parser.parse_args()
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician", "RICIAN_K_DB": 5.0,
    })
    generator = build_network_generator(config)
    pure = PurePhysicalReuseScheduler(_UnusedChannelModel())
    profiles = ("sparse", "heterogeneous", "saturated")
    methods = (
        "sequential_2", "single_best_2", "parallel_delta_2",
        "parallel_random_mean_2", "parallel_random_bestof8_2",
    )
    records = []
    for graph_index in range(args.num_graphs):
        graph_seed = args.seed + graph_index
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            base = ExactToggleState(
                state, queues, pure.schedule_with_state(state, queues)
            )
            order_seed = graph_seed + 20_000 * profile_index
            sequential = positive_coordinate_sweeps(
                base, 2, np.random.default_rng(order_seed)
            )[0]
            single = parallel_rounds(
                base, 2, "single_best", np.random.default_rng(order_seed)
            )[0]
            delta = parallel_rounds(
                base, 2, "delta", np.random.default_rng(order_seed)
            )[0]
            random_utilities = [
                parallel_rounds(
                    base, 2, "random",
                    np.random.default_rng(order_seed + 1000 + trial),
                )[0]
                for trial in range(args.random_trials)
            ]
            row = {
                "graph_seed": graph_seed,
                "queue_profile": profile,
                "num_links": int(state.num_vertices),
                "pure_utility": base.utility(),
                "sequential_2": sequential,
                "single_best_2": single,
                "parallel_delta_2": delta,
                "parallel_random_mean_2": float(np.mean(random_utilities)),
                "parallel_random_bestof8_2": float(np.max(random_utilities)),
            }
            records.append(row)
            print(
                f"seed={graph_seed} profile={profile:<13} "
                f"seq={100*(sequential/row['pure_utility']-1):+.1f}% "
                f"delta={100*(delta/row['pure_utility']-1):+.1f}% "
                f"best8={100*(row['parallel_random_bestof8_2']/row['pure_utility']-1):+.1f}%"
            )

    overall = {method: summarize(records, method) for method in methods}
    by_profile = {
        profile: {
            method: summarize(
                [row for row in records if row["queue_profile"] == profile], method
            ) for method in methods
        } for profile in profiles
    }
    delta = overall["parallel_delta_2"]
    best = overall["parallel_random_bestof8_2"]
    ranking_headroom = (
        best["mean_gain_fraction_vs_pure"]
        - delta["mean_gain_fraction_vs_pure"]
    )
    passed = (
        best["mean_gain_fraction_vs_pure"] >= 0.02
        and best["strict_loss_fraction_vs_pure"] <= 0.20
        and ranking_headroom >= 0.02
    )
    payload = {
        "experiment": "parallel_update_coordination_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definitions": {
            "sequential_2": "Exact positive toggles in a full sequential sweep; oracle reference.",
            "single_best_2": "At most one exact best toggle per round; centralized reference.",
            "parallel_delta_2": "Conflict-local maxima ranked by exact current toggle margin.",
            "parallel_random_bestof8_2": "Centralized best of eight random local-max priority trials; nondeployable policy headroom probe.",
        },
        "predeclared_gate": {
            "minimum_best_policy_gain": 0.02,
            "maximum_best_policy_loss_fraction": 0.20,
            "minimum_priority_learning_headroom_over_delta": 0.02,
        },
        "ranking_headroom_over_delta": float(ranking_headroom),
        "gate_passed": passed,
        "decision": (
            "PROCEED_TO_MINIMAL_GAT_PRIORITY_POLICY"
            if passed else "STOP_GAT_PARALLEL_COORDINATION_ROUTE"
        ),
        "overall": overall,
        "by_profile": by_profile,
        "records": records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "decision": payload["decision"],
        "ranking_headroom_over_delta": ranking_headroom,
        "overall": overall,
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
