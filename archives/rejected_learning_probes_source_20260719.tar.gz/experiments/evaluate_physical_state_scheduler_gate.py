#!/usr/bin/env python3
"""Downstream channel-only gate for the accepted link-local CSI predictor."""

import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from baseline.queue_schedulers import centralized_mws_greedy
from models.local_physical_reuse import (
    GATExpectedRateLocalPhysicalReuseScheduler,
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
)
from models.model import calculate_achievable_rate
from models.physical_state_stgnn import PhysicalStateTemporalPredictor
from simulator.mobile_block_fading import (
    build_network_state_from_power,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import build_network_generator, load_channel_gat, load_config


MODES = ("latest", "stale", "current_large_scale", "affine_ar", "link_gru")
ALGORITHMS = ("centralized_greedy", "gat_assisted", "pure")


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_slots", type=int, default=600)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--test_seeds", default="42,43,44,45,46")
    parser.add_argument(
        "--predictor_checkpoint",
        default=(
            "results/models/physical_state_temporal_gate_"
            "N10_ricianK5_20260716.pth"
        ),
    )
    parser.add_argument(
        "--prediction_report",
        default=(
            "results/diagnostics/physical_state_stgnn_gate_"
            "N10_ricianK5_20260716.json"
        ),
    )
    parser.add_argument(
        "--output",
        default=(
            "results/diagnostics/physical_state_scheduler_gate_"
            "N10_ricianK5_20260716.json"
        ),
    )
    return parser.parse_args()


def _db(power):
    return 10.0 * torch.log10(torch.as_tensor(power).clamp_min(1e-30))


def _seeds(text):
    return [int(item) for item in str(text).split(",") if item.strip()]


def _jaccard(left, right):
    left = torch.as_tensor(left).reshape(-1) > 0
    right = torch.as_tensor(right).reshape(-1) > 0
    union = left | right
    return float(((left & right).sum() / union.sum()).item()) if union.any() else 1.0


def _settled_se(action, true_state):
    rates = calculate_achievable_rate(
        torch.as_tensor(action).float().reshape(-1, 1), true_state, binary=True
    )
    return float(rates.sum().item())


def _features(previous, current, pairs):
    tx, rx = pairs[:, 0], pairs[:, 1]
    stale_db = _db(previous.true_power[tx, rx])
    previous_ls_db = _db(previous.large_scale_power[tx, rx])
    current_ls_db = _db(current.large_scale_power[tx, rx])
    previous_distance = torch.linalg.vector_norm(
        previous.positions[tx] - previous.positions[rx], dim=1
    )
    current_distance = torch.linalg.vector_norm(
        current.positions[tx] - current.positions[rx], dim=1
    )
    return torch.stack([
        stale_db - previous_ls_db,
        current_ls_db,
        current_distance,
        current_distance - previous_distance,
    ], dim=1).float()


def _matrix_from_pair_db(pair_db, pairs, num_uav):
    power = torch.zeros(num_uav, num_uav, dtype=torch.float32)
    power[pairs[:, 0], pairs[:, 1]] = torch.pow(10.0, pair_db.float() / 10.0)
    return power


def _actions(state, queues, gat_model):
    output = {}
    greedy = centralized_mws_greedy(state, queues).reshape(-1).float()
    output["centralized_greedy"] = (greedy, None)
    for name, scheduler in (
        ("gat_assisted", GATExpectedRateLocalPhysicalReuseScheduler(gat_model)),
        ("pure", PurePhysicalReuseScheduler(gat_model)),
    ):
        scheduler.localmax.clear_cache()
        skeleton = scheduler.localmax.schedule_with_state(state, queues).reshape(-1)
        final, _, _ = complete_physical_reuse_from_base(
            state, queues, skeleton
        )
        output[name] = (final.reshape(-1), skeleton)
    return output


def _aggregate(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[(row["mode"], row["algorithm"])].append(row)
    output = {}
    for (mode, algorithm), items in groups.items():
        key = f"{mode}/{algorithm}"
        output[key] = {
            "num_blocks": len(items),
            "true_settled_se": float(np.mean([
                item["true_settled_se"] for item in items
            ])),
            "ratio_to_latest_same_algorithm": float(np.mean([
                item["ratio_to_latest_same_algorithm"] for item in items
            ])),
            "final_jaccard_to_latest": float(np.mean([
                item["final_jaccard_to_latest"] for item in items
            ])),
            "average_active_links": float(np.mean([
                item["active_links"] for item in items
            ])),
            "skeleton_true_settled_se": (
                float(np.mean([
                    item["skeleton_true_settled_se"] for item in items
                    if item["skeleton_true_settled_se"] is not None
                ])) if algorithm != "centralized_greedy" else None
            ),
        }
    return output


def main():
    args = parse_args()
    predictor_payload = torch.load(
        args.predictor_checkpoint, map_location="cpu", weights_only=False
    )
    prediction_report = json.loads(Path(args.prediction_report).read_text())
    if not predictor_payload["gate"]["proceed_to_scheduler_gate_with_link_gru"]:
        raise RuntimeError("Physical prediction gate did not permit scheduler evaluation")
    pairs = predictor_payload["pair_catalog"].long()
    predictor = PhysicalStateTemporalPredictor(
        input_dim=4,
        embedding_dim=int(predictor_payload["embedding_dim"]),
        hidden_dim=int(predictor_payload["hidden_dim"]),
        edge_dim=4,
        use_spatial=False,
    )
    predictor.load_state_dict(predictor_payload["link_gru_state_dict"])
    predictor.eval()
    feature_mean = predictor_payload["feature_mean"]
    feature_std = predictor_payload["feature_std"]
    target_mean = predictor_payload["target_mean"]
    target_std = predictor_payload["target_std"]
    edge_index = predictor_payload["pair_edge_index"]
    edge_attr = predictor_payload["pair_edge_attr"]
    ar_intercept = float(prediction_report["affine_ar"]["intercept"])
    ar_beta = float(prediction_report["affine_ar"]["beta"])

    config = load_config("configs/exp_example.yaml")
    config.update({
        "NUM_UAV": args.num_uav,
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
        "CSI_MODE": "perfect",
    })
    net_gen = build_network_generator(config)
    gat_model, gat_path = load_channel_gat(config, train_num_uav=args.num_uav)
    rows = []
    for seed in _seeds(args.test_seeds):
        trace = generate_mobile_block_fading_trace(
            net_gen,
            num_slots=args.num_slots,
            slots_per_block=args.slots_per_block,
            slot_duration=0.001,
            speed_mps=args.speed_mps,
            seed=seed,
            quantization_bits=(4,),
            rician_k_db=args.rician_k_db,
        )
        hidden = predictor.initial_hidden(pairs.size(0))
        for block_index in range(1, len(trace.blocks)):
            previous, current = trace.blocks[block_index - 1:block_index + 1]
            raw_features = _features(previous, current, pairs)
            normalized = (raw_features - feature_mean) / feature_std
            with torch.no_grad():
                normalized_residual, hidden = predictor.forward_step(
                    normalized, edge_index, edge_attr, hidden
                )
            predicted_pair_db = (
                _db(current.large_scale_power[pairs[:, 0], pairs[:, 1]])
                + normalized_residual * target_std + target_mean
            )
            ar_pair_db = (
                _db(current.large_scale_power[pairs[:, 0], pairs[:, 1]])
                + ar_intercept + ar_beta * raw_features[:, 0]
            )
            powers = {
                "latest": current.true_power,
                "stale": previous.true_power,
                "current_large_scale": current.large_scale_power,
                "affine_ar": _matrix_from_pair_db(ar_pair_db, pairs, args.num_uav),
                "link_gru": _matrix_from_pair_db(
                    predicted_pair_db, pairs, args.num_uav
                ),
            }
            true_state, true_indices = build_true_network_state(
                net_gen, trace, block_index
            )
            queues = torch.ones(true_state.num_vertices)
            block_actions, block_values = {}, {}
            for mode in MODES:
                observed_state, observed_indices = build_network_state_from_power(
                    net_gen, trace, block_index, powers[mode], csi_label=mode
                )
                if not torch.equal(observed_indices, true_indices):
                    raise RuntimeError("Scheduler gate lost persistent link alignment")
                actions = _actions(observed_state, queues, gat_model)
                for algorithm in ALGORITHMS:
                    action, skeleton = actions[algorithm]
                    block_actions[(mode, algorithm)] = action
                    block_values[(mode, algorithm)] = _settled_se(action, true_state)
                    skeleton_value = (
                        _settled_se(skeleton, true_state)
                        if skeleton is not None else None
                    )
                    rows.append({
                        "seed": seed,
                        "block": block_index,
                        "mode": mode,
                        "algorithm": algorithm,
                        "true_settled_se": block_values[(mode, algorithm)],
                        "skeleton_true_settled_se": skeleton_value,
                        "active_links": float(action.sum()),
                    })
            for row in rows[-len(MODES) * len(ALGORITHMS):]:
                latest_key = ("latest", row["algorithm"])
                current_key = (row["mode"], row["algorithm"])
                latest_value = block_values[latest_key]
                row["ratio_to_latest_same_algorithm"] = (
                    block_values[current_key] / latest_value
                    if latest_value > 0 else 1.0
                )
                row["final_jaccard_to_latest"] = _jaccard(
                    block_actions[current_key], block_actions[latest_key]
                )

    aggregate = _aggregate(rows)
    gate = {}
    for algorithm in ALGORITHMS:
        reference = aggregate[f"affine_ar/{algorithm}"]["true_settled_se"]
        candidate = aggregate[f"link_gru/{algorithm}"]["true_settled_se"]
        gate[algorithm] = {
            "link_gru_vs_affine_ar_relative_se_gain": (
                candidate / reference - 1.0 if reference > 0 else 0.0
            ),
            "link_gru_beats_affine_ar": candidate > reference,
        }
    payload = {
        "experiment": "physical_state_downstream_scheduler_gate",
        "timestamp": datetime.now().isoformat(),
        "settings": vars(args),
        "channel_gat_checkpoint": gat_path,
        "purpose": (
            "Determine whether lower physical CSI prediction error improves "
            "true-channel-settled Shannon scheduling before queue simulation."
        ),
        "aggregate": aggregate,
        "gate": gate,
        "raw_rows": rows,
        "conclusion_boundary": (
            "Channel-only gains permit but do not prove dynamic queue gains."
        ),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "output": str(output),
        "key_results": {
            key: aggregate[key]
            for key in aggregate
            if key.startswith(("affine_ar/", "link_gru/", "latest/"))
        },
        "gate": gate,
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
