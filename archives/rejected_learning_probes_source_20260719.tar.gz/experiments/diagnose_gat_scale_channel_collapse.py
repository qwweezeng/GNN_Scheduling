#!/usr/bin/env python3
"""Controlled regeneration audit for channel-GAT collapse across N and fading.

Every case regenerates its own dataset and trains from scratch.  Diagnostic
artifacts are isolated from production datasets/checkpoints so this experiment
cannot silently reuse or overwrite a previous model.
"""

from __future__ import annotations

import argparse
import json
import os
import pickle
import random
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from train.train_channel_gat_rician import _output_audit
from train.trainer import Trainer
from utils.io import generate_dataset
from utils.project_setup import (
    build_gat_scheduler,
    build_network_generator,
    load_config,
)


VALID_CHANNELS = {"rayleigh", "rician"}


def parse_case(text: str) -> tuple[int, str]:
    try:
        n_text, channel_model = text.lower().split(":", maxsplit=1)
        num_uav = int(n_text.removeprefix("n"))
    except (TypeError, ValueError) as exc:
        raise argparse.ArgumentTypeError(
            f"case must look like N10:rayleigh, got {text!r}"
        ) from exc
    if num_uav <= 1 or channel_model not in VALID_CHANNELS:
        raise argparse.ArgumentTypeError(
            f"invalid case {text!r}; channel must be {sorted(VALID_CHANNELS)}"
        )
    return num_uav, channel_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--cases",
        nargs="+",
        type=parse_case,
        default=[(10, "rayleigh"), (10, "rician")],
    )
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--train_size", type=int, default=500)
    parser.add_argument("--val_size", type=int, default=128)
    parser.add_argument("--test_size", type=int, default=128)
    parser.add_argument("--seed", type=int, default=10086)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument(
        "--tx_power_dbm",
        type=float,
        default=None,
        help="Override YAML TX_POWER while preserving all other YAML settings.",
    )
    parser.add_argument(
        "--artifact_root",
        type=Path,
        default=ROOT / "results/diagnostics/gat_scale_channel_regeneration_20260716",
    )
    return parser.parse_args()


def reset_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def dataset_summary(dataset) -> dict[str, float]:
    links = np.asarray([state.num_vertices for state in dataset], dtype=float)
    edges = np.asarray([state.edge_index.shape[1] for state in dataset], dtype=float)
    return {
        "mean_num_links": float(links.mean()),
        "median_num_links": float(np.median(links)),
        "mean_directed_conflict_edges": float(edges.mean()),
        "mean_in_degree": float(np.mean(edges / np.maximum(links, 1.0))),
    }


def make_scheduler(config, optimizer):
    scheduler_type = config.get("LR_SCHEDULER_TYPE")
    scheduler_config = config.get("LR_SCHEDULER_CONFIG", {}) or {}
    if scheduler_type == "ReduceLROnPlateau":
        return torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, **scheduler_config
        )
    if scheduler_type == "StepLR":
        return torch.optim.lr_scheduler.StepLR(optimizer, **scheduler_config)
    if scheduler_type in (None, ""):
        return None
    raise ValueError(f"Unsupported LR_SCHEDULER_TYPE={scheduler_type!r}")


def run_case(args, base_config, num_uav: int, channel_model: str) -> dict:
    case_name = f"N{num_uav}_{channel_model}"
    case_dir = args.artifact_root / case_name
    case_dir.mkdir(parents=True, exist_ok=True)
    reset_seed(args.seed)

    config = dict(base_config)
    config.update({
        "NUM_UAV": num_uav,
        "CHANNEL_MODEL": channel_model,
        "RICIAN_K_DB": args.rician_k_db,
        "CSI_MODE": "perfect",
        "USE_QUEUE": False,
        "NODE_RAW_DIM": 1,
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
        "EPOCHS": args.epochs,
        "SEED": args.seed,
    })
    if args.tx_power_dbm is not None:
        config["TX_POWER"] = float(args.tx_power_dbm)
    generator = build_network_generator(config)
    print(
        f"\n[{case_name}] regenerating train/val/test="
        f"{args.train_size}/{args.val_size}/{args.test_size}; "
        f"tx={config['TX_POWER']} dBm, channel={channel_model}, "
        f"K={args.rician_k_db:g} dB, seed={args.seed}",
        flush=True,
    )
    train_set = generate_dataset(
        args.train_size,
        generator,
        batch_size=config.get("GEN_BATCH_SIZE", 50),
        csi_mode="perfect",
        include_queue_feature=False,
    )
    val_set = generate_dataset(
        args.val_size,
        generator,
        batch_size=config.get("GEN_BATCH_SIZE", 50),
        csi_mode="perfect",
        include_queue_feature=False,
    )
    test_set = generate_dataset(
        args.test_size,
        generator,
        batch_size=config.get("GEN_BATCH_SIZE", 50),
        csi_mode="perfect",
        include_queue_feature=False,
    )
    dataset_path = case_dir / "regenerated_dataset.pkl"
    with dataset_path.open("wb") as handle:
        pickle.dump({
            "metadata": {
                "purpose": "isolated GAT scale/channel collapse audit",
                "num_uav": num_uav,
                "channel_model": channel_model,
                "rician_k_db": args.rician_k_db,
                "tx_power_dbm": float(config["TX_POWER"]),
                "seed": args.seed,
                "sizes": [args.train_size, args.val_size, args.test_size],
            },
            "train_set": train_set,
            "val_set": val_set,
            "test_set": test_set,
        }, handle)

    model = build_gat_scheduler(config, raw_node_dim=1)
    optimizer = torch.optim.Adam(model.parameters(), lr=float(config["LR"]))
    lr_scheduler = make_scheduler(config, optimizer)
    trainer = Trainer(
        model,
        optimizer,
        device="cpu",
        use_queue=False,
        log_dir=str(case_dir / "logs"),
        grad_clip_config=config.get("GRAD_CLIP_CONFIG"),
    )
    trained = trainer.train(
        num_epochs=args.epochs,
        train_dataset=train_set,
        val_dataset=val_set,
        eval_interval=int(config.get("EVAL_INTERVAL", 1)),
        lr_scheduler=lr_scheduler,
        use_queue=False,
    )
    test_utility = float(trainer.evaluate(model, test_set, use_queue=False))
    output_audit = _output_audit(model, test_set)
    checkpoint_path = case_dir / "trained_checkpoint.pth"
    torch.save({
        "model_version": "channel_gat_regeneration_audit_v1",
        "model_state_dict": model.state_dict(),
        "case": case_name,
        "config": config,
        "best_epoch": trained["best_epoch"],
        "best_val_utility": trained["best_val_util"],
        "test_utility": test_utility,
        "output_audit": output_audit,
    }, checkpoint_path)

    report = {
        "case": case_name,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "regenerated_from_scratch": True,
        "dataset_path": str(dataset_path),
        "checkpoint_path": str(checkpoint_path),
        "settings": {
            "num_uav": num_uav,
            "channel_model": channel_model,
            "rician_k_db": args.rician_k_db,
            "tx_power_dbm": float(config["TX_POWER"]),
            "area_width_m": float(config["AREA_WIDTH"]),
            "height_range_m": config["HEIGHT_RANGE"],
            "min_distance_m": float(config["MIN_DISTANCE"]),
            "snr_threshold_db": float(config["SNR_THRES"]),
            "train_size": args.train_size,
            "val_size": args.val_size,
            "test_size": args.test_size,
            "epochs": args.epochs,
            "seed": args.seed,
            "learning_rate": float(config["LR"]),
            "lr_scheduler_type": config.get("LR_SCHEDULER_TYPE"),
            "lr_scheduler_config": config.get("LR_SCHEDULER_CONFIG"),
        },
        "train_dataset_summary": dataset_summary(train_set),
        "val_dataset_summary": dataset_summary(val_set),
        "test_dataset_summary": dataset_summary(test_set),
        "best_epoch": trained["best_epoch"],
        "best_val_utility": float(trained["best_val_util"]),
        "test_utility": test_utility,
        "output_audit": output_audit,
        "per_epoch": trained["per_epoch_logs"],
    }
    report_path = case_dir / "report.json"
    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(
        f"[{case_name}] COMPLETE: test={test_utility:.4f}, "
        f"active={output_audit['mean_binary_active_fraction']:.4%}, "
        f"all-active={output_audit['all_links_active_state_fraction']:.2%}, "
        f"integrity={output_audit['integrity_passed']}",
        flush=True,
    )
    return report


def main() -> None:
    args = parse_args()
    args.artifact_root.mkdir(parents=True, exist_ok=True)
    base_config = load_config(ROOT / "configs/exp_example.yaml")
    required = {
        "EPOCHS": args.epochs,
        "TRAIN_SIZE": args.train_size,
        "VAL_SIZE": args.val_size,
        "TEST_SIZE": args.test_size,
        "SEED": args.seed,
        "TX_POWER": (
            float(args.tx_power_dbm)
            if args.tx_power_dbm is not None
            else float(base_config["TX_POWER"])
        ),
    }
    print(
        "Controlled overrides: " + json.dumps(required, ensure_ascii=False),
        flush=True,
    )
    reports = [
        run_case(args, base_config, num_uav, channel_model)
        for num_uav, channel_model in args.cases
    ]
    # A long audit may be run one case at a time. Preserve completed sibling
    # reports in the same artifact root instead of silently replacing the
    # summary with only the most recent invocation.
    reports_by_case = {report["case"]: report for report in reports}
    for report_path in sorted(args.artifact_root.glob("*/report.json")):
        try:
            existing = json.loads(report_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        reports_by_case.setdefault(existing.get("case", report_path.parent.name), existing)
    reports = [reports_by_case[key] for key in sorted(reports_by_case)]
    summary = {
        "purpose": "Detect channel- or scale-specific all-active GAT collapse",
        "yaml_source": str(ROOT / "configs/exp_example.yaml"),
        "controlled_overrides": required,
        "cases": [{
            "case": report["case"],
            "test_utility": report["test_utility"],
            "best_val_utility": report["best_val_utility"],
            "output_audit": report["output_audit"],
            "test_dataset_summary": report["test_dataset_summary"],
            "report_path": str(args.artifact_root / report["case"] / "report.json"),
        } for report in reports],
    }
    summary_path = args.artifact_root / "summary.json"
    summary_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
