#!/usr/bin/env python3
"""Cheap feasibility gate for an MWS-aligned topology-scaling GAT.

The diagnostic starts from the PurePhysicalReuse LocalMax skeleton.  A
centralized one-substitution oracle may promote one nonwinner and remove all
conflicting skeleton winners, after which the unchanged physical-reuse
completion is applied.  The oracle is not deployable and is not a proposed
algorithm.  It measures whether changing the scalar skeleton ordering has
enough final sum(QR) headroom to justify training a GAT to learn the change.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.local_physical_reuse import (  # noqa: E402
    GATExpectedRateLocalPhysicalReuseScheduler,
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
)
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


class ConstantPriorModel:
    """No-learning attribution control with identical link probabilities."""

    def __init__(self, probability):
        probability = float(probability)
        if not 0.0 < probability < 1.0:
            raise ValueError("probability must lie in (0, 1)")
        self.logit = float(np.log(probability / (1.0 - probability)))

    def eval(self):
        return self

    def schedule_logits(self, x, edge_index, edge_attr):
        del edge_index, edge_attr
        logits = torch.full(
            (x.shape[0], 1), self.logit, dtype=x.dtype, device=x.device
        )
        return logits, torch.empty(
            (x.shape[0], 0), dtype=x.dtype, device=x.device
        )


def queue_snapshot(num_links, seed, profile):
    """Generate sparse, heterogeneous, or saturated queue snapshots."""
    rng = np.random.default_rng(int(seed))
    if profile == "sparse":
        queues = rng.poisson(0.25, size=num_links).astype(np.float32)
        hotspot_count = max(1, int(np.ceil(0.1 * num_links)))
        hotspots = rng.choice(num_links, size=hotspot_count, replace=False)
        queues[hotspots] += rng.poisson(2.0, size=hotspot_count).astype(np.float32)
    elif profile == "heterogeneous":
        queues = rng.poisson(2.0, size=num_links).astype(np.float32)
        hotspot_count = max(1, int(np.ceil(0.2 * num_links)))
        hotspots = rng.choice(num_links, size=hotspot_count, replace=False)
        queues[hotspots] += rng.poisson(8.0, size=hotspot_count).astype(np.float32)
    elif profile == "saturated":
        queues = 1.0 + rng.poisson(8.0, size=num_links).astype(np.float32)
    else:
        raise ValueError(f"Unknown queue profile: {profile}")
    if not np.any(queues > 0):
        queues[rng.integers(0, num_links)] = 1.0
    return torch.from_numpy(queues)


def conflict_neighbors(edge_index, num_links):
    neighbors = [set() for _ in range(int(num_links))]
    source, target = edge_index.detach().cpu()
    for left, right in zip(source.tolist(), target.tolist()):
        if left == right:
            continue
        neighbors[int(left)].add(int(right))
        neighbors[int(right)].add(int(left))
    return neighbors


def best_one_substitution(state, queues, pure_scheduler):
    """Return the best final action after at most one skeleton promotion."""
    base = pure_scheduler.localmax.schedule_with_state(
        state, queues
    ).reshape(-1).detach().cpu()
    pure_action, _, _ = complete_physical_reuse_from_base(
        state, queues, base
    )
    best_action = pure_action
    best_utility = mws_objective(pure_action, queues, state)
    best_promoted = None
    best_removed = []
    evaluated = 0

    neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
    base_active = set(torch.nonzero(base > 0.5, as_tuple=True)[0].tolist())
    nonempty = torch.as_tensor(queues).reshape(-1) > 0
    for challenger in torch.nonzero(nonempty & (base <= 0.5), as_tuple=True)[0].tolist():
        removed = sorted(base_active.intersection(neighbors[int(challenger)]))
        if not removed:
            continue
        candidate_base = base.clone()
        candidate_base[torch.tensor(removed, dtype=torch.long)] = 0.0
        candidate_base[int(challenger)] = 1.0
        candidate_action, _, _ = complete_physical_reuse_from_base(
            state, queues, candidate_base
        )
        utility = mws_objective(candidate_action, queues, state)
        evaluated += 1
        if utility > best_utility + 1e-9:
            best_utility = utility
            best_action = candidate_action
            best_promoted = int(challenger)
            best_removed = removed
    return {
        "action": best_action,
        "utility": float(best_utility),
        "pure_skeleton_links": int(base.sum()),
        "promoted_link": best_promoted,
        "removed_winners": best_removed,
        "evaluated_substitutions": int(evaluated),
    }


def summarize(records):
    keys = (
        "pure_utility",
        "current_gat_utility",
        "constant_utility",
        "oracle_utility",
        "oracle_gain_fraction",
    )
    summary = {
        key: {
            "mean": float(np.mean([row[key] for row in records])),
            "ci95": float(
                1.96
                * np.std([row[key] for row in records], ddof=1)
                / np.sqrt(len(records))
            ) if len(records) > 1 else 0.0,
        }
        for key in keys
    }
    summary.update({
        "num_snapshots": len(records),
        "oracle_strict_win_fraction_vs_pure": float(np.mean([
            row["oracle_utility"] > row["pure_utility"] + 1e-9
            for row in records
        ])),
        "current_gat_strict_win_fraction_vs_pure": float(np.mean([
            row["current_gat_utility"] > row["pure_utility"] + 1e-9
            for row in records
        ])),
        "constant_strict_win_fraction_vs_pure": float(np.mean([
            row["constant_utility"] > row["pure_utility"] + 1e-9
            for row in records
        ])),
        "mean_pure_skeleton_links": float(np.mean([
            row["pure_skeleton_links"] for row in records
        ])),
        "mean_evaluated_substitutions": float(np.mean([
            row["evaluated_substitutions"] for row in records
        ])),
    })
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--channel_model", choices=("rician",), default="rician")
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument("--constant_prior_probability", type=float, default=0.050029350853525105)
    parser.add_argument(
        "--profiles", default="sparse,heterogeneous,saturated"
    )
    parser.add_argument(
        "--minimum_mean_gain_fraction", type=float, default=0.02
    )
    parser.add_argument(
        "--minimum_win_fraction", type=float, default=0.70
    )
    parser.add_argument(
        "--output",
        default=(
            "results/formal/mws_topology_scaling_headroom_"
            "N20_rician_20260716.json"
        ),
    )
    args = parser.parse_args()

    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError(
            "The formal feasibility gate is frozen to N=20 and 10 dBm."
        )
    profiles = [item.strip() for item in args.profiles.split(",") if item.strip()]
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": args.channel_model,
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config,
        args.channel_gat_checkpoint,
        args.num_uav,
        device="cpu",
        allow_power_transfer=False,
    )
    pure = PurePhysicalReuseScheduler(channel_model)
    current_gat = GATExpectedRateLocalPhysicalReuseScheduler(channel_model)
    constant = GATExpectedRateLocalPhysicalReuseScheduler(
        ConstantPriorModel(args.constant_prior_probability)
    )

    records = []
    for graph_index in range(args.num_graphs):
        graph_seed = args.seed + graph_index
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            pure_action = pure.schedule_with_state(state, queues)
            gat_action = current_gat.schedule_with_state(state, queues)
            constant_action = constant.schedule_with_state(state, queues)
            pure_utility = mws_objective(pure_action, queues, state)
            oracle = best_one_substitution(state, queues, pure)
            record = {
                "graph_seed": graph_seed,
                "queue_profile": profile,
                "num_links": int(state.num_vertices),
                "pure_utility": float(pure_utility),
                "current_gat_utility": float(
                    mws_objective(gat_action, queues, state)
                ),
                "constant_utility": float(
                    mws_objective(constant_action, queues, state)
                ),
                "oracle_utility": oracle["utility"],
                "oracle_gain_fraction": float(
                    (oracle["utility"] - pure_utility)
                    / max(abs(pure_utility), 1e-12)
                ),
                "pure_skeleton_links": oracle["pure_skeleton_links"],
                "promoted_link": oracle["promoted_link"],
                "removed_winners": oracle["removed_winners"],
                "evaluated_substitutions": oracle["evaluated_substitutions"],
            }
            records.append(record)
            print(
                f"seed={graph_seed} profile={profile:<13} "
                f"links={state.num_vertices:>3} "
                f"oracle_gain={100 * record['oracle_gain_fraction']:+.2f}%"
            )

    by_profile = {
        profile: summarize([
            row for row in records if row["queue_profile"] == profile
        ])
        for profile in profiles
    }
    overall = summarize(records)
    competition_profiles = [
        profile for profile in profiles
        if profile in {"heterogeneous", "saturated"}
    ]
    passed_profiles = {
        profile: (
            values["oracle_gain_fraction"]["mean"]
            >= args.minimum_mean_gain_fraction
            and values["oracle_strict_win_fraction_vs_pure"]
            >= args.minimum_win_fraction
        )
        for profile, values in by_profile.items()
    }
    if not competition_profiles:
        raise ValueError(
            "At least one heterogeneous or saturated profile is required."
        )
    gate_passed = all(
        passed_profiles[profile] for profile in competition_profiles
    )
    payload = {
        "experiment": "mws_topology_scaling_headroom_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "purpose": (
            "Non-deployable one-substitution lower-bound oracle used only to "
            "decide whether training a topology-aware scalar skeleton weight "
            "has material headroom."
        ),
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "definitions": {
            "pure": "Q times interference-free solo spectral efficiency",
            "oracle": (
                "Promote at most one nonwinner, remove every conflicting Pure "
                "skeleton winner, then run the unchanged physical-reuse completion."
            ),
            "not_a_proposed_method": True,
        },
        "predeclared_gate": {
            "minimum_mean_gain_fraction_per_profile": args.minimum_mean_gain_fraction,
            "minimum_strict_win_fraction_per_profile": args.minimum_win_fraction,
            "required_profiles": competition_profiles,
            "sparse_profile_role": (
                "No positive headroom is required when few queues compete; "
                "a trained model must later preserve the Pure identity there."
            ),
            "profile_passed": passed_profiles,
            "gate_passed": gate_passed,
        },
        "overall": overall,
        "by_profile": by_profile,
        "records": records,
        "decision": (
            "PROCEED_TO_MINIMAL_GAT_TRAINING"
            if gate_passed
            else "STOP_SCALAR_TOPOLOGY_SCALING_AND_USE_BACKUP"
        ),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "profile_passed": passed_profiles,
        "overall_mean_gain": overall["oracle_gain_fraction"]["mean"],
        "decision": payload["decision"],
        "output": str(output),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
