#!/usr/bin/env python3
"""Low-cost feasibility gate for a channel-block skeleton codebook.

The codebook contains K queue-independent binary skeletons for one channel
graph.  At a queue slot, a selector compares the true Q-weighted rate of the
masked skeletons, chooses exactly one, and only then runs the existing single
conditional physical-reuse round.  An all-completions oracle is reported only
to distinguish codebook coverage from selector error; it is not deployable.

No model is trained.  The first gate uses a broad channel-physics multistart
pool.  Only when that ceiling passes do we evaluate codebooks decoded from the
frozen conference GAT, solo-SNR scores, and shuffled-GAT attribution controls.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    queue_snapshot,
)
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
    local_edge_gains,
)
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


PROFILES = ("sparse", "heterogeneous", "saturated")
K_VALUES = (2, 4, 8)


def standardize(values):
    values = torch.as_tensor(values, dtype=torch.float32).reshape(-1).cpu()
    scale = values.std(unbiased=False).clamp_min(1e-6)
    return (values - values.mean()) / scale


def conflict_neighbors(edge_index, num_links):
    neighbors = [set() for _ in range(int(num_links))]
    source, target = edge_index.detach().cpu()
    for left, right in zip(source.tolist(), target.tolist()):
        if left == right:
            continue
        neighbors[int(left)].add(int(right))
        neighbors[int(right)].add(int(left))
    return neighbors


def greedy_independent_skeleton(scores, neighbors):
    """Decode a score ordering into a deterministic independent skeleton."""
    scores = torch.as_tensor(scores).reshape(-1).cpu()
    order = sorted(
        range(scores.numel()), key=lambda index: (-float(scores[index]), index)
    )
    selected = set()
    action = torch.zeros(scores.numel(), dtype=torch.float32)
    for link in order:
        if selected.isdisjoint(neighbors[link]):
            selected.add(link)
            action[link] = 1.0
    return action


def skeleton_key(action):
    return bytes(torch.as_tensor(action).reshape(-1).to(torch.uint8).tolist())


def jaccard_distance(left, right):
    left = torch.as_tensor(left).reshape(-1) > 0.5
    right = torch.as_tensor(right).reshape(-1) > 0.5
    union = (left | right).sum().item()
    if union == 0:
        return 0.0
    return float((left ^ right).sum().item() / union)


def build_score_pool(base_scores, neighbors, rng, pool_size, noise_scales):
    """Create queue-independent skeletons from fixed score perturbations."""
    base_scores = standardize(base_scores)
    pool = [greedy_independent_skeleton(base_scores, neighbors)]
    trial = 0
    while len(pool) < pool_size:
        scale = noise_scales[trial % len(noise_scales)]
        noise = torch.from_numpy(
            rng.gumbel(size=base_scores.numel()).astype(np.float32)
        )
        pool.append(greedy_independent_skeleton(
            base_scores + float(scale) * noise, neighbors
        ))
        trial += 1
    return pool


def unique_actions(actions):
    unique = {}
    for action in actions:
        unique.setdefault(skeleton_key(action), action.clone())
    return list(unique.values())


def select_diverse_channel_codebook(actions, state, max_k):
    """Keep high-sum-rate candidates, then use farthest-first diversity."""
    actions = unique_actions(actions)
    unit_queue = torch.ones(state.num_vertices, dtype=torch.float32)
    channel_utility = np.asarray([
        mws_objective(action.unsqueeze(1), unit_queue, state)
        for action in actions
    ], dtype=np.float64)
    order = np.argsort(-channel_utility, kind="stable").tolist()
    if not order:
        raise RuntimeError("candidate pool is empty")
    best = max(channel_utility[order[0]], 1e-12)
    eligible = [index for index in order if channel_utility[index] >= 0.75 * best]
    selected = [eligible.pop(0)]
    while eligible and len(selected) < max_k:
        next_index = max(
            eligible,
            key=lambda index: (
                min(jaccard_distance(actions[index], actions[old]) for old in selected),
                channel_utility[index],
                -index,
            ),
        )
        selected.append(next_index)
        eligible.remove(next_index)
    for index in order:
        if len(selected) >= max_k:
            break
        if index not in selected:
            selected.append(index)
    codebook = [actions[index] for index in selected[:max_k]]
    return codebook, {
        "pool_unique": len(actions),
        "eligible_above_75pct_best": int(np.sum(channel_utility >= 0.75 * best)),
        "selected_channel_utilities": [float(channel_utility[index]) for index in selected[:max_k]],
    }


def physics_multistart_codebook(state, rng, pool_size, max_k):
    direct, source, target, edge_gain = local_edge_gains(state)
    noise = float(state.noise_power)
    solo = torch.log2(1.0 + direct / noise)
    all_interference = torch.zeros_like(direct)
    outgoing_harm = torch.zeros_like(direct)
    if source.numel() > 0:
        all_interference.index_add_(0, target, edge_gain)
        outgoing_harm.index_add_(0, source, edge_gain)
    all_on_rate = torch.log2(1.0 + direct / (noise + all_interference))
    harm_aware = standardize(solo) - 0.5 * standardize(torch.log1p(outgoing_harm / noise))
    neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
    score_families = (solo, all_on_rate, harm_aware)
    actions = []
    per_family = max(8, int(np.ceil(pool_size / len(score_families))))
    for scores in score_families:
        actions.extend(build_score_pool(
            scores, neighbors, rng, per_family,
            noise_scales=(0.10, 0.25, 0.50, 1.00, 2.00),
        ))
    return select_diverse_channel_codebook(actions, state, max_k)


def score_codebook(scores, state, rng, pool_size, max_k):
    neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
    actions = build_score_pool(
        scores, neighbors, rng, pool_size,
        noise_scales=(0.10, 0.25, 0.50, 1.00, 2.00),
    )
    return select_diverse_channel_codebook(actions, state, max_k)


def best_one_substitution_base(state, queues, pure):
    """Return a queue-specific teacher skeleton after at most one replacement."""
    base = pure.localmax.schedule_with_state(state, queues).reshape(-1).cpu()
    best_base = base.clone()
    completed, _, _ = complete_physical_reuse_from_base(state, queues, base)
    best_utility = float(mws_objective(completed, queues, state))
    neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
    active = set(torch.nonzero(base > 0.5, as_tuple=True)[0].tolist())
    nonempty = torch.as_tensor(queues).reshape(-1).cpu() > 0
    challengers = torch.nonzero(nonempty & (base <= 0.5), as_tuple=True)[0]
    for challenger in challengers.tolist():
        removed = sorted(active.intersection(neighbors[int(challenger)]))
        if not removed:
            continue
        candidate = base.clone()
        candidate[torch.tensor(removed, dtype=torch.long)] = 0.0
        candidate[int(challenger)] = 1.0
        action, _, _ = complete_physical_reuse_from_base(
            state, queues, candidate
        )
        utility = float(mws_objective(action, queues, state))
        if utility > best_utility + 1e-9:
            best_utility = utility
            best_base = candidate
    return best_base


def calibration_teacher_codebook(
    state, pure, physics_codebook, seed, samples_per_profile, max_k
):
    """Build a fixed teacher codebook from held-out calibration queues.

    Queue samples are used only offline to define diverse teacher targets.  The
    resulting binary skeleton list is frozen before evaluation queues are seen.
    """
    candidates = list(physics_codebook)
    calibration = []
    for profile_index, profile in enumerate(PROFILES):
        for sample in range(samples_per_profile):
            queues = queue_snapshot(
                state.num_vertices,
                seed + 400_000 + 50_000 * profile_index + sample,
                profile,
            )
            base = pure.localmax.schedule_with_state(
                state, queues
            ).reshape(-1).cpu()
            candidates.append(base)
            candidates.append(best_one_substitution_base(
                state, queues, pure
            ))
            calibration.append(queues)
    candidates = unique_actions(candidates)
    utility = np.zeros((len(candidates), len(calibration)), dtype=np.float64)
    reference = np.zeros(len(calibration), dtype=np.float64)
    for queue_index, queues in enumerate(calibration):
        pure_action = pure.schedule_with_state(state, queues)
        reference[queue_index] = max(
            float(mws_objective(pure_action, queues, state)), 1e-12
        )
        for candidate_index, candidate in enumerate(candidates):
            nonempty = torch.as_tensor(queues).reshape(-1).cpu() > 0
            base = candidate * nonempty.float()
            action, _, _ = complete_physical_reuse_from_base(
                state, queues, base
            )
            utility[candidate_index, queue_index] = float(
                mws_objective(action, queues, state)
            ) / reference[queue_index]
    selected = []
    covered = np.zeros(len(calibration), dtype=np.float64)
    available = set(range(len(candidates)))
    while available and len(selected) < max_k:
        choice = max(
            available,
            key=lambda index: (
                float(np.mean(np.maximum(covered, utility[index]))),
                float(np.mean(utility[index])),
                -index,
            ),
        )
        selected.append(choice)
        available.remove(choice)
        covered = np.maximum(covered, utility[choice])
    return [candidates[index] for index in selected], {
        "offline_calibration_only": True,
        "calibration_samples": len(calibration),
        "candidate_pool_unique": len(candidates),
        "greedy_coverage_ratio_by_prefix": [
            float(np.mean(np.max(utility[selected[:prefix]], axis=0)))
            for prefix in range(1, len(selected) + 1)
        ],
    }


def channel_logits(model, state):
    with torch.no_grad():
        if hasattr(model, "schedule_logits_with_state"):
            logits, _ = model.schedule_logits_with_state(state)
        else:
            logits, _ = model.schedule_logits(
                state.vertex_features[:, :1],
                state.edge_index,
                state.edge_weights,
            )
    return logits.detach().reshape(-1).cpu()


def codebook_diversity(codebook):
    if len(codebook) < 2:
        return 0.0
    distances = [
        jaccard_distance(codebook[left], codebook[right])
        for left in range(len(codebook))
        for right in range(left + 1, len(codebook))
    ]
    return float(np.mean(distances))


def evaluate_codebook(codebook, state, queues, k):
    """Select a skeleton first, then run the common completion exactly once."""
    nonempty = torch.as_tensor(queues).reshape(-1).cpu() > 0
    skeletons = [
        (action.reshape(-1).cpu() > 0.5).float() * nonempty.float()
        for action in codebook[:k]
    ]
    selector_utilities = [
        float(mws_objective(action.unsqueeze(1), queues, state))
        for action in skeletons
    ]
    selected = int(np.argmax(selector_utilities))
    final_action, _, joiners = complete_physical_reuse_from_base(
        state, queues, skeletons[selected]
    )
    selected_utility = float(mws_objective(final_action, queues, state))

    # Diagnostic only: completing every candidate is forbidden in deployment.
    oracle_utilities = []
    for action in skeletons:
        completed, _, _ = complete_physical_reuse_from_base(state, queues, action)
        oracle_utilities.append(float(mws_objective(completed, queues, state)))
    oracle_selected = int(np.argmax(oracle_utilities))
    return {
        "selected_utility": selected_utility,
        "selected_index": selected,
        "selected_skeleton_links": int(skeletons[selected].sum()),
        "selected_joiners": int(joiners.sum()),
        "oracle_utility": float(oracle_utilities[oracle_selected]),
        "oracle_selected_index": oracle_selected,
        "selector_matches_oracle": selected == oracle_selected,
    }


def paired_summary(rows, candidate, reference="pure_utility"):
    ratios = np.asarray([
        row[candidate] / max(abs(row[reference]), 1e-12) for row in rows
    ], dtype=np.float64)
    return {
        "mean_ratio": float(np.mean(ratios)),
        "ci95": float(1.96 * np.std(ratios, ddof=1) / np.sqrt(len(ratios)))
        if len(ratios) > 1 else 0.0,
        "strict_win_fraction": float(np.mean(ratios > 1.0 + 1e-9)),
        "strict_loss_fraction": float(np.mean(ratios < 1.0 - 1e-9)),
    }


def family_summary(records, family, k):
    rows = [row for row in records if row["family"] == family and row["k"] == k]
    return {
        "selected_over_pure": paired_summary(rows, "selected_utility"),
        "oracle_over_pure": paired_summary(rows, "oracle_utility"),
        "selector_match_oracle_fraction": float(np.mean([
            row["selector_matches_oracle"] for row in rows
        ])),
        "mean_codebook_diversity": float(np.mean([
            row["codebook_diversity"] for row in rows
        ])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--pool_size", type=int, default=48)
    parser.add_argument("--calibration_samples_per_profile", type=int, default=4)
    parser.add_argument("--shuffle_repeats", type=int, default=3)
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument("--minimum_ceiling_ratio", type=float, default=1.05)
    parser.add_argument("--minimum_win_fraction", type=float, default=0.60)
    parser.add_argument("--minimum_gat_ratio", type=float, default=1.03)
    parser.add_argument("--minimum_attribution_ratio", type=float, default=1.02)
    parser.add_argument(
        "--output",
        default=(
            "results/formal/skeleton_codebook_gate_N20_rician_20260717.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("This gate is frozen to N=20 and 10 dBm.")
    if args.pool_size < max(K_VALUES):
        raise ValueError("pool_size must be at least max(K_VALUES)")

    config = load_config(args.config)
    config.update({
        "NUM_UAV": 20,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config, args.channel_gat_checkpoint, 20,
        device="cpu", allow_power_transfer=False,
    )
    pure = PurePhysicalReuseScheduler(channel_model)

    records = []
    graph_metadata = []
    stage_a_rows = []
    cached_graphs = []
    for graph_offset in range(args.num_graphs):
        graph_seed = args.seed + graph_offset
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        rng = np.random.default_rng(graph_seed + 700_001)
        physics_codebook, physics_meta = physics_multistart_codebook(
            state, rng, args.pool_size, max(K_VALUES)
        )
        teacher_codebook, teacher_meta = calibration_teacher_codebook(
            state, pure, physics_codebook, graph_seed,
            args.calibration_samples_per_profile, max(K_VALUES),
        )
        cached_graphs.append((
            graph_seed, state, physics_codebook, teacher_codebook
        ))
        graph_metadata.append({
            "graph_seed": graph_seed,
            "num_links": int(state.num_vertices),
            "physics": physics_meta,
            "calibration_teacher": teacher_meta,
        })
        for profile_index, profile in enumerate(PROFILES):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            pure_action = pure.schedule_with_state(state, queues)
            pure_utility = float(mws_objective(pure_action, queues, state))
            for k in K_VALUES:
                for family, codebook in (
                    ("physics_multistart", physics_codebook),
                    ("calibration_teacher", teacher_codebook),
                ):
                    result = evaluate_codebook(codebook, state, queues, k)
                    row = {
                        "stage": "A",
                        "family": family,
                        "graph_seed": graph_seed,
                        "profile": profile,
                        "k": k,
                        "pure_utility": pure_utility,
                        "codebook_diversity": codebook_diversity(codebook[:k]),
                        **result,
                    }
                    records.append(row)
                    stage_a_rows.append(row)

    stage_a_summary = {
        profile: {
            family: {
                str(k): family_summary(
                    [row for row in stage_a_rows if row["profile"] == profile],
                    family, k,
                )
                for k in K_VALUES
            }
            for family in ("physics_multistart", "calibration_teacher")
        }
        for profile in PROFILES
    }
    ceiling_profile_pass = {}
    for profile in ("heterogeneous", "saturated"):
        metric = stage_a_summary[profile]["calibration_teacher"]["8"][
            "selected_over_pure"
        ]
        ceiling_profile_pass[profile] = bool(
            metric["mean_ratio"] >= args.minimum_ceiling_ratio
            and metric["strict_win_fraction"] >= args.minimum_win_fraction
        )
    stage_a_passed = all(ceiling_profile_pass.values())

    stage_b_summary = None
    attribution_gate = None
    if stage_a_passed:
        for graph_seed, state, physics_codebook, teacher_codebook in cached_graphs:
            del physics_codebook, teacher_codebook
            logits = channel_logits(channel_model, state)
            direct, _, _, _ = local_edge_gains(state)
            solo = torch.log2(1.0 + direct / float(state.noise_power))
            gat_codebook, gat_meta = score_codebook(
                logits, state,
                np.random.default_rng(graph_seed + 800_001),
                args.pool_size, max(K_VALUES),
            )
            solo_codebook, solo_meta = score_codebook(
                solo, state,
                np.random.default_rng(graph_seed + 810_001),
                args.pool_size, max(K_VALUES),
            )
            shuffled_codebooks = []
            shuffled_meta = []
            for repeat in range(args.shuffle_repeats):
                rng = np.random.default_rng(graph_seed + 820_001 + repeat)
                permutation = torch.from_numpy(rng.permutation(logits.numel()))
                codebook, meta = score_codebook(
                    logits[permutation], state, rng,
                    args.pool_size, max(K_VALUES),
                )
                shuffled_codebooks.append(codebook)
                shuffled_meta.append(meta)
            for item in graph_metadata:
                if item["graph_seed"] == graph_seed:
                    item.update({
                        "gat": gat_meta,
                        "solo": solo_meta,
                        "shuffled": shuffled_meta,
                    })
                    break
            for profile_index, profile in enumerate(PROFILES):
                queues = queue_snapshot(
                    state.num_vertices,
                    graph_seed + 100_003 + 10_000 * profile_index,
                    profile,
                )
                pure_action = pure.schedule_with_state(state, queues)
                pure_utility = float(mws_objective(pure_action, queues, state))
                families = [("gat", gat_codebook), ("solo", solo_codebook)]
                families.extend([
                    (f"shuffled_{repeat}", codebook)
                    for repeat, codebook in enumerate(shuffled_codebooks)
                ])
                for family, codebook in families:
                    for k in K_VALUES:
                        result = evaluate_codebook(codebook, state, queues, k)
                        records.append({
                            "stage": "B",
                            "family": family,
                            "graph_seed": graph_seed,
                            "profile": profile,
                            "k": k,
                            "pure_utility": pure_utility,
                            "codebook_diversity": codebook_diversity(codebook[:k]),
                            **result,
                        })

        stage_b_summary = {}
        for profile in PROFILES:
            profile_rows = [row for row in records if row["profile"] == profile]
            stage_b_summary[profile] = {}
            for k in K_VALUES:
                gat = family_summary(profile_rows, "gat", k)
                solo_summary = family_summary(profile_rows, "solo", k)
                shuffled_rows = [
                    row for row in profile_rows
                    if row["family"].startswith("shuffled_") and row["k"] == k
                ]
                shuffled = {
                    "selected_over_pure": paired_summary(
                        shuffled_rows, "selected_utility"
                    ),
                    "oracle_over_pure": paired_summary(
                        shuffled_rows, "oracle_utility"
                    ),
                }
                stage_b_summary[profile][str(k)] = {
                    "gat": gat,
                    "solo": solo_summary,
                    "shuffled": shuffled,
                }
        attribution_profile_pass = {}
        for profile in ("heterogeneous", "saturated"):
            summary = stage_b_summary[profile]["8"]
            gat_ratio = summary["gat"]["selected_over_pure"]["mean_ratio"]
            solo_ratio = summary["solo"]["selected_over_pure"]["mean_ratio"]
            shuffled_ratio = summary["shuffled"]["selected_over_pure"]["mean_ratio"]
            gat_wins = summary["gat"]["selected_over_pure"]["strict_win_fraction"]
            attribution_profile_pass[profile] = bool(
                gat_ratio >= args.minimum_gat_ratio
                and gat_wins >= args.minimum_win_fraction
                and gat_ratio / max(solo_ratio, 1e-12)
                >= args.minimum_attribution_ratio
                and gat_ratio / max(shuffled_ratio, 1e-12)
                >= args.minimum_attribution_ratio
            )
        attribution_gate = {
            "profile_pass": attribution_profile_pass,
            "passed": all(attribution_profile_pass.values()),
        }

    if not stage_a_passed:
        decision = "STOP_CODEBOOK_CEILING_NOT_MATERIAL"
    elif not attribution_gate["passed"]:
        decision = "STOP_EXISTING_GAT_CODEBOOK_NOT_ATTRIBUTABLE"
    else:
        decision = "PROCEED_TO_MINIMAL_MULTIHEAD_SKELETON_CODEBOOK"

    payload = {
        "experiment": "channel_block_skeleton_codebook_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "definition": (
            "Generate K queue-independent binary skeletons per channel block; "
            "select one by its current Q-weighted skeleton SINR utility; then "
            "run the existing conditional physical-reuse completion once."
        ),
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "stage_a_summary": stage_a_summary,
        "stage_a_gate": {
            "required_profiles": ["heterogeneous", "saturated"],
            "minimum_ceiling_ratio": args.minimum_ceiling_ratio,
            "minimum_win_fraction": args.minimum_win_fraction,
            "profile_pass": ceiling_profile_pass,
            "passed": stage_a_passed,
            "gate_family": "calibration_teacher",
        },
        "stage_b_summary": stage_b_summary,
        "attribution_gate": attribution_gate,
        "message_accounting": {
            "channel_block": (
                "One frozen conference-GAT inference; K perturbation decodes "
                "do not add GAT message rounds."
            ),
            "queue_slot_selection": (
                "K local Q_i R_i(codeword) contributions plus one global "
                "K-vector aggregation/consistent-index decision.  This is "
                "not yet logically local and is charged separately."
            ),
            "after_selection": (
                "Exactly one existing conditional physical-reuse completion: "
                "exchange selected skeleton actions/physical quantities, then "
                "exchange candidate gains for one local join competition."
            ),
            "oracle_warning": (
                "oracle_utility completes all K skeletons only as a diagnostic "
                "coverage upper bound and is forbidden as deployment cost."
            ),
        },
        "graph_metadata": graph_metadata,
        "records": records,
        "decision": decision,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "stage_a_gate": payload["stage_a_gate"],
        "attribution_gate": attribution_gate,
        "decision": decision,
        "output": str(output),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
