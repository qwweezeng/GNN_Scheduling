#!/usr/bin/env python3
"""Paired queue evaluation of the minimal stateful Temporal-Residual GAT."""

import argparse
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.evaluate_mobile_block_fading_csi import (
    _aggregate,
    _number_key,
    _paired_comparison,
)
from models.local_physical_reuse import (
    GATExpectedRateLocalPhysicalReuseScheduler,
)
from models.temporal_residual_gat import TemporalResidualChannelGAT
from simulator.mobile_block_fading import (
    build_observed_network_state,
    generate_mobile_block_fading_trace,
    message_overhead_audit,
    run_mobile_queue_simulation,
)
from utils.fixed_csi_benchmark import (
    arrival_trace_seed,
    generate_hotspot_arrivals,
)
from utils.project_setup import (
    build_gat_scheduler,
    build_network_generator,
    load_config,
)


MODES = (
    ("latest", None),
    ("stale", None),
    ("large_scale", None),
    ("quantized", 4),
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--model",
        default="results/models/gat_temporal_residual_v1_numUAV=10_tx=10dBm.pth",
    )
    parser.add_argument(
        "--base_report",
        default=(
            "results/diagnostics/"
            "mobile_csi_frozen_gat_vs_pure_N10_1000slots_5seeds_20260715.json"
        ),
    )
    parser.add_argument(
        "--spatial_report",
        default=(
            "results/diagnostics/"
            "csi_augmented_spatial_teacher_eval_N10_20260715.json"
        ),
    )
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--arrival_rates", default="2.2,4")
    parser.add_argument("--mc_seeds", default="42,43,44,45,46")
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--diagnostic_stride", type=int, default=10)
    parser.add_argument("--output", default="")
    return parser.parse_args()


def _csv(text, cast):
    return [cast(item.strip()) for item in text.split(",") if item.strip()]


def _load_model(path, cfg):
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if checkpoint.get("model_version") != "channel_gat_temporal_residual_v1":
        raise ValueError(f"Unexpected temporal model metadata: {path}")
    spatial = build_gat_scheduler(cfg, raw_node_dim=1)
    model = TemporalResidualChannelGAT(
        spatial,
        embedding_dim=checkpoint.get("embedding_dim", cfg.get("GAT_OUT_DIM", 48)),
        temporal_hidden_dim=checkpoint.get("temporal_hidden_dim", 48),
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    return model.freeze_spatial().eval(), checkpoint


def _base_reference_runs(report, scenario, load, method, mode, seeds):
    return [
        report["run_details"][
            f"{scenario}|{load}|{method}|{mode}|seed={seed}"
        ]
        for seed in seeds
    ]


def _spatial_reference_runs(report, load, mode, seeds):
    return [
        report["run_details"][f"{load}|{mode}|seed={seed}"]
        for seed in seeds
    ]


def _sequence_diagnostic(model, net_gen, trace, mode, bits, stride):
    model.reset_temporal_state()
    probability_stds = []
    residuals = []
    history_contributions = []
    for block_index in range(len(trace.blocks)):
        state, _ = build_observed_network_state(
            net_gen, trace, block_index, mode, bits or 4
        )
        with torch.no_grad():
            base, _ = model.spatial_model.schedule_logits(
                state.vertex_features[:, :1], state.edge_index, state.edge_weights
            )
            stateful, _ = model.schedule_logits_with_state(state)
            memoryless, _, _ = model.temporal_step(
                state, {}, detach_update=True
            )
        if block_index % max(1, int(stride)) == 0:
            probability_stds.append(float(
                torch.sigmoid(stateful.reshape(-1)).std(unbiased=False).item()
            ))
            residuals.append(float(torch.mean(torch.abs(stateful - base)).item()))
            history_contributions.append(float(
                torch.mean(torch.abs(stateful - memoryless)).item()
            ))
    return {
        "mean_probability_std_across_links": float(np.mean(probability_stds)),
        "min_probability_std_across_links": float(np.min(probability_stds)),
        "mean_absolute_logit_residual_vs_spatial": float(np.mean(residuals)),
        "mean_absolute_logit_history_contribution": float(
            np.mean(history_contributions)
        ),
    }


def _gate(comparisons, diagnostics):
    passing = []
    for load, modes in comparisons.items():
        for mode, refs in modes.items():
            if mode == "latest":
                continue
            if all(item["directional_gate_passed"] for item in refs.values()):
                passing.append(f"{load}|{mode}")
    probability_stds = [
        item["mean_probability_std_across_links"]
        for item in diagnostics.values()
    ]
    history_values = [
        item["mean_absolute_logit_history_contribution"]
        for item in diagnostics.values()
    ]
    representation_valid = float(np.mean(probability_stds)) > 1e-6
    history_used = float(np.mean(history_values)) > 1e-6
    return {
        "criterion": (
            "In one imperfect condition Temporal must achieve >=4/5 joint "
            "delivered/backlog wins against Frozen-GAT, Pure, and the non-collapsed "
            "CSI-Augmented Spatial GAT. It must also retain CSI-sensitive outputs "
            "and measurably use previous-link state."
        ),
        "performance_passing_conditions": passing,
        "performance_gate_passed": bool(passing),
        "representation_is_csi_sensitive": representation_valid,
        "previous_link_state_changes_logits": history_used,
        "temporal_residual_gate_passed": bool(
            passing and representation_valid and history_used
        ),
        "next_step": (
            "Run the predefined reset-every-block queue ablation before attributing "
            "the gain specifically to temporal memory."
            if passing and representation_valid and history_used else
            "Record the minimal temporal result and apply the Phase-F stop rule; "
            "do not expand to deeper RNN, temporal attention, or Transformer search."
        ),
    }


def main():
    args = parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect"})
    net_gen = build_network_generator(cfg)
    model, checkpoint = _load_model(args.model, cfg)
    with open(args.base_report, "r", encoding="utf-8") as file:
        base_report = json.load(file)
    with open(args.spatial_report, "r", encoding="utf-8") as file:
        spatial_report = json.load(file)
    seeds = _csv(args.mc_seeds, int)
    arrival_rates = _csv(args.arrival_rates, float)
    scenario = f"v={args.speed_mps:g}mps_Tc={args.slots_per_block}slots"
    raw = {
        f"Lambda={_number_key(rate)}": {
            (f"{mode}_{bits}bit" if bits else mode): []
            for mode, bits in MODES
        }
        for rate in arrival_rates
    }
    run_details = {}
    diagnostics = {}

    for seed in seeds:
        trace = generate_mobile_block_fading_trace(
            net_gen,
            num_slots=args.num_slots,
            slots_per_block=args.slots_per_block,
            slot_duration=cfg.get("SLOT_DURATION", 0.001),
            speed_mps=args.speed_mps,
            seed=seed,
            quantization_bits=(4,),
        )
        for mode, bits in MODES:
            label = f"{mode}_{bits}bit" if bits else mode
            diagnostics[f"{label}|seed={seed}"] = _sequence_diagnostic(
                model, net_gen, trace, mode, bits,
                args.diagnostic_stride,
            )
        for rate in arrival_rates:
            load = f"Lambda={_number_key(rate)}"
            arrivals, _ = generate_hotspot_arrivals(
                args.num_slots,
                trace.num_links,
                rate,
                arrival_seed=arrival_trace_seed(seed, rate),
                hotspot_seed=seed,
            )
            for mode, bits in MODES:
                label = f"{mode}_{bits}bit" if bits else mode
                scheduler = GATExpectedRateLocalPhysicalReuseScheduler(model)
                metrics = run_mobile_queue_simulation(
                    net_gen, scheduler, trace, arrivals, mode, bits or 4,
                    packet_size=cfg.get("PACKET_SIZE", 12000),
                )
                metrics["mc_seed"] = seed
                metrics["scheduler"] = "Temporal-Residual-GAT"
                metrics["arrival_rate"] = rate
                metrics["overhead"] = message_overhead_audit(
                    metrics["average_available_links"],
                    metrics["average_available_transmitter_uavs"],
                    metrics["average_directed_conflict_edges"],
                    args.slots_per_block,
                    slot_duration=cfg.get("SLOT_DURATION", 0.001),
                    gat_rounds=cfg.get("NUM_GAT_LAYERS", 4),
                    hidden_dim=cfg.get("GAT_OUT_DIM", 48),
                    uses_channel_gat=True,
                )
                metrics["temporal_local_memory_kbit"] = (
                    metrics["average_available_links"]
                    * checkpoint.get("temporal_hidden_dim", 48) * 32.0 / 1000.0
                )
                raw[load][label].append(metrics)
                run_details[f"{load}|{label}|seed={seed}"] = metrics
                print(
                    f"{load} seed={seed} {label:<15} "
                    f"goodput={metrics['delivered_throughput_mbps']:.3f} "
                    f"Q={metrics['average_queue_backlog_mbit']:.4f}"
                )

    summaries = {
        load: {mode: _aggregate(runs) for mode, runs in modes.items()}
        for load, modes in raw.items()
    }
    comparisons = {}
    for load, modes in raw.items():
        comparisons[load] = {}
        for mode, candidate_runs in modes.items():
            comparisons[load][mode] = {
                "vs_Frozen-GAT": _paired_comparison(
                    candidate_runs,
                    _base_reference_runs(
                        base_report, scenario, load, "Frozen-GAT", mode, seeds
                    ),
                ),
                "vs_Pure": _paired_comparison(
                    candidate_runs,
                    _base_reference_runs(
                        base_report, scenario, load, "Pure", mode, seeds
                    ),
                ),
                "vs_CSI-Augmented-Spatial-GAT": _paired_comparison(
                    candidate_runs,
                    _spatial_reference_runs(spatial_report, load, mode, seeds),
                ),
            }
    gate = _gate(comparisons, diagnostics)
    report = {
        "experiment": "temporal_residual_gat_paired_evaluation_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "checkpoint_metadata": {
            key: checkpoint.get(key) for key in (
                "model_version", "spatial_checkpoint", "teacher_checkpoint",
                "best_epoch", "training_objective", "temporal_hidden_dim",
                "spatial_frozen", "persistent_link_identity",
            )
        },
        "summaries": summaries,
        "comparisons": comparisons,
        "sequence_output_diagnostics": diagnostics,
        "run_details": run_details,
        "overhead_interpretation": (
            "The link-local GRU adds no neighbor-message round. Reported local "
            "memory stores one float32 hidden vector per available persistent link."
        ),
        "gate": gate,
    }
    output = args.output or (
        "results/diagnostics/temporal_residual_eval_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    os.makedirs(os.path.dirname(output), exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "report": output,
        "gate": gate,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
