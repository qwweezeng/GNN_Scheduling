#!/usr/bin/env python3
"""Zero-training feasibility gate for conditional MWS negotiation.

This diagnostic deliberately grants each transition exact global sum(QR)
information.  It is an oracle study, not a deployable scheduler.  Its sole
purpose is to decide which conditional transition family, if any, has enough
headroom over PurePhysicalReuse to justify a learned distributed version.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from baseline.queue_schedulers import _link_gain_matrix  # noqa: E402
from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    conflict_neighbors,
    queue_snapshot,
)
from models.local_physical_reuse import PurePhysicalReuseScheduler  # noqa: E402
from utils.project_setup import build_network_generator, load_config  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


class _UnusedChannelModel:
    """PurePhysicalReuse needs an eval-compatible object but never queries it."""

    def eval(self):
        return self


class ExactToggleState:
    """Maintain exact physical rates and O(L) binary-toggle utilities."""

    def __init__(self, state, queues, action):
        self.state = state
        self.queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).cpu()
        # ``as_tensor`` can alias an existing CPU tensor.  Every diagnostic
        # branch must own its action state or one method contaminates another.
        self.action = (
            torch.as_tensor(action, dtype=torch.bool).reshape(-1).cpu().clone()
        )
        self.gain, self.direct = _link_gain_matrix(state)
        self.noise = float(state.noise_power)
        self.gap = float(getattr(state, "snr_gap", 1.0))
        self.interference = (
            self.gain[self.action].sum(dim=0)
            if self.action.any()
            else torch.zeros_like(self.direct)
        )

    def _rates(self, interference):
        return torch.log2(
            1.0 + self.direct / (interference + self.noise) / self.gap
        )

    def utility(self):
        rates = self._rates(self.interference)
        return float((self.queues * rates * self.action.float()).sum())

    def toggle_delta(self, link):
        """Return U(action with link toggled)-U(current action)."""
        link = int(link)
        old_rates = self._rates(self.interference)
        if self.action[link]:
            new_interference = (self.interference - self.gain[link]).clamp_min(0.0)
            new_action = self.action.clone()
            new_action[link] = False
        else:
            if self.queues[link] <= 0:
                return -float("inf")
            new_interference = self.interference + self.gain[link]
            new_action = self.action.clone()
            new_action[link] = True
        new_rates = self._rates(new_interference)
        new_utility = (self.queues * new_rates * new_action.float()).sum()
        old_utility = (self.queues * old_rates * self.action.float()).sum()
        return float(new_utility - old_utility)

    def toggle_delta_on_mask(self, link, mask):
        """Return the toggle utility change observed only on selected links."""
        link = int(link)
        mask = torch.as_tensor(mask, dtype=torch.bool).reshape(-1).cpu()
        old_rates = self._rates(self.interference)
        new_action = self.action.clone()
        if self.action[link]:
            new_interference = (self.interference - self.gain[link]).clamp_min(0.0)
            new_action[link] = False
        else:
            if self.queues[link] <= 0:
                return -float("inf")
            new_interference = self.interference + self.gain[link]
            new_action[link] = True
        new_rates = self._rates(new_interference)
        old_utility = (
            self.queues[mask] * old_rates[mask] * self.action[mask].float()
        ).sum()
        new_utility = (
            self.queues[mask] * new_rates[mask] * new_action[mask].float()
        ).sum()
        return float(new_utility - old_utility)

    def toggle_contributions(self, link):
        """Return each receiver-link's exact contribution to a binary toggle."""
        link = int(link)
        old_rates = self._rates(self.interference)
        new_action = self.action.clone()
        if self.action[link]:
            new_interference = (self.interference - self.gain[link]).clamp_min(0.0)
            new_action[link] = False
        else:
            if self.queues[link] <= 0:
                return torch.full_like(self.queues, -float("inf"))
            new_interference = self.interference + self.gain[link]
            new_action[link] = True
        new_rates = self._rates(new_interference)
        return self.queues * (
            new_rates * new_action.float() - old_rates * self.action.float()
        )

    def toggle(self, link):
        link = int(link)
        if self.action[link]:
            self.interference = (self.interference - self.gain[link]).clamp_min(0.0)
            self.action[link] = False
        else:
            self.interference += self.gain[link]
            self.action[link] = True

    def clone(self):
        return ExactToggleState(self.state, self.queues, self.action)


def positive_coordinate_sweeps(engine, sweeps, rng):
    """Sequentially accept every exact positive binary toggle."""
    engine = engine.clone()
    eligible = np.flatnonzero((engine.queues > 0).numpy())
    accepted = 0
    for _ in range(int(sweeps)):
        order = rng.permutation(eligible)
        changed = False
        for link in order:
            delta = engine.toggle_delta(link)
            if delta > 1e-6:
                before = engine.utility()
                engine.toggle(link)
                after = engine.utility()
                if after < before - 1e-5:
                    raise RuntimeError(
                        "Exact positive toggle violated monotonicity: "
                        f"delta={delta}, measured={after-before}"
                    )
                accepted += 1
                changed = True
        if not changed:
            break
    return engine.utility(), engine.action.clone(), accepted


def conditional_scale(engine):
    """A per-snapshot utility scale; it removes arbitrary queue units."""
    values = []
    for link in torch.nonzero(engine.queues > 0, as_tuple=True)[0].tolist():
        delta = abs(engine.toggle_delta(link))
        if np.isfinite(delta) and delta > 1e-8:
            values.append(delta)
    return float(np.median(values)) if values else 1.0


def exact_gibbs_sweeps(engine, sweeps, inverse_temperature, rng, scale):
    """Sample exact single-link conditionals in random sequential order."""
    engine = engine.clone()
    eligible = np.flatnonzero((engine.queues > 0).numpy())
    changed = 0
    for _ in range(int(sweeps)):
        for link in rng.permutation(eligible):
            toggle_delta = engine.toggle_delta(link)
            on_minus_off = -toggle_delta if engine.action[link] else toggle_delta
            logit = np.clip(inverse_temperature * on_minus_off / scale, -30.0, 30.0)
            next_on = bool(rng.random() < 1.0 / (1.0 + np.exp(-logit)))
            if next_on != bool(engine.action[link]):
                engine.toggle(link)
                changed += 1
    return engine.utility(), engine.action.clone(), changed


def best_composite_replacement(engine, neighbors, rounds):
    """Greedily apply exact challenger-for-active-neighborhood replacements."""
    engine = engine.clone()
    accepted = 0
    for _ in range(int(rounds)):
        current = engine.utility()
        best_utility = current
        best_action = None
        active = set(torch.nonzero(engine.action, as_tuple=True)[0].tolist())
        inactive = torch.nonzero(
            (engine.queues > 0) & ~engine.action, as_tuple=True
        )[0].tolist()
        for challenger in inactive:
            removed = active.intersection(neighbors[int(challenger)])
            candidate_action = engine.action.clone()
            if removed:
                candidate_action[torch.tensor(sorted(removed), dtype=torch.long)] = False
            candidate_action[int(challenger)] = True
            candidate = ExactToggleState(engine.state, engine.queues, candidate_action)
            utility = candidate.utility()
            if utility > best_utility + 1e-9:
                best_utility = utility
                best_action = candidate_action
        if best_action is None:
            break
        engine = ExactToggleState(engine.state, engine.queues, best_action)
        accepted += 1
    return engine.utility(), engine.action.clone(), accepted


def summarize(records, method):
    gains = np.asarray([
        row[method] / max(abs(row["pure_utility"]), 1e-12) - 1.0
        for row in records
    ], dtype=np.float64)
    return {
        "num_snapshots": len(records),
        "mean_gain_fraction_vs_pure": float(gains.mean()),
        "gain_ci95": float(1.96 * gains.std(ddof=1) / np.sqrt(len(gains)))
        if len(gains) > 1 else 0.0,
        "strict_win_fraction_vs_pure": float(np.mean(gains > 1e-9)),
        "strict_loss_fraction_vs_pure": float(np.mean(gains < -1e-9)),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--profiles", default="sparse,heterogeneous,saturated")
    parser.add_argument("--gibbs_chains", type=int, default=8)
    parser.add_argument(
        "--output",
        default="results/formal/conditional_negotiation_gate_N20_rician_20260717.json",
    )
    args = parser.parse_args()

    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    pure = PurePhysicalReuseScheduler(_UnusedChannelModel())
    profiles = [item.strip() for item in args.profiles.split(",") if item.strip()]
    methods = [
        "coordinate_1", "coordinate_2", "coordinate_4",
        "composite_1", "composite_2", "composite_4",
        "gibbs_b1_k2", "gibbs_b4_k2", "gibbs_b4_k4",
        "gibbs_bestof8_b4_k4",
    ]
    records = []
    for graph_index in range(args.num_graphs):
        graph_seed = args.seed + graph_index
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            pure_action = pure.schedule_with_state(state, queues)
            base = ExactToggleState(state, queues, pure_action)
            pure_utility = base.utility()
            reference = float(mws_objective(pure_action, queues, state))
            if not np.isclose(pure_utility, reference, rtol=2e-5, atol=2e-5):
                raise RuntimeError(
                    f"Incremental utility mismatch: {pure_utility} vs {reference}"
                )
            row = {
                "graph_seed": graph_seed,
                "queue_profile": profile,
                "num_links": int(state.num_vertices),
                "pure_utility": pure_utility,
            }
            for sweeps in (1, 2, 4):
                rng = np.random.default_rng(graph_seed + profile_index * 1000 + sweeps)
                row[f"coordinate_{sweeps}"] = positive_coordinate_sweeps(
                    base, sweeps, rng
                )[0]
                row[f"composite_{sweeps}"] = best_composite_replacement(
                    base, neighbors, sweeps
                )[0]
            scale = conditional_scale(base)
            gibbs_specs = ((1.0, 2), (4.0, 2), (4.0, 4))
            for beta, sweeps in gibbs_specs:
                utilities = []
                for chain in range(args.gibbs_chains):
                    rng = np.random.default_rng(
                        graph_seed + 1_000_000 * profile_index
                        + 10_000 * int(beta) + 100 * sweeps + chain
                    )
                    utilities.append(exact_gibbs_sweeps(
                        base, sweeps, beta, rng, scale
                    )[0])
                key = f"gibbs_b{int(beta)}_k{sweeps}"
                row[key] = float(np.mean(utilities))
                if beta == 4.0 and sweeps == 4:
                    row["gibbs_bestof8_b4_k4"] = float(np.max(utilities))
            records.append(row)
            print(
                f"seed={graph_seed} profile={profile:<13} L={state.num_vertices:>3} "
                f"coord4={100*(row['coordinate_4']/pure_utility-1):+.1f}% "
                f"comp2={100*(row['composite_2']/pure_utility-1):+.1f}% "
                f"gibbs={100*(row['gibbs_b4_k4']/pure_utility-1):+.1f}%"
            )

    by_profile = {
        profile: {
            method: summarize(
                [row for row in records if row["queue_profile"] == profile], method
            )
            for method in methods
        }
        for profile in profiles
    }
    overall = {method: summarize(records, method) for method in methods}
    expected_gibbs = overall["gibbs_b4_k4"]
    composite = overall["composite_2"]
    decision = {
        "conditional_gibbs": (
            "PROCEED_TO_LOCAL_CONDITIONAL_TEST"
            if expected_gibbs["mean_gain_fraction_vs_pure"] >= 0.02
            and expected_gibbs["strict_loss_fraction_vs_pure"] <= 0.20
            else "STOP_GIBBS_AS_PRIMARY_ROUTE"
        ),
        "composite_proposal": (
            "KEEP_AS_BACKUP_ROUTE"
            if composite["mean_gain_fraction_vs_pure"] >= 0.02
            and composite["strict_win_fraction_vs_pure"] >= 0.70
            else "STOP_COMPOSITE_ROUTE"
        ),
    }
    payload = {
        "experiment": "conditional_negotiation_zero_training_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definitions": {
            "coordinate": "Exact positive single-link toggles in random sequential sweeps.",
            "gibbs": "Exact global single-link conditional probabilities; reported value is one-sample expectation over chains.",
            "gibbs_bestof8": "Nondeployable library-existence diagnostic, not a method result.",
            "composite": "Exact best challenger replaces its active conflict neighborhood; centralized oracle.",
            "all_methods_are_non_deployable_oracles": True,
        },
        "predeclared_gate": {
            "minimum_mean_gain_fraction": 0.02,
            "maximum_gibbs_loss_fraction": 0.20,
            "minimum_composite_win_fraction": 0.70,
        },
        "decision": decision,
        "overall": overall,
        "by_profile": by_profile,
        "records": records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"decision": decision, "overall": overall, "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
