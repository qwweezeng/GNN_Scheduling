#!/usr/bin/env python3
"""Paired train-power by test-power audit for the conference channel GAT.

This experiment changes only the physical transmit-power distribution seen in
channel-only training.  Every trained model is evaluated on the same paired
test banks at every requested power.  Screening datasets are deterministic and
ephemeral by default; use --archive_datasets only for the final selected runs.
"""

from __future__ import annotations

import argparse
import json
import pickle
import random
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from train.train_channel_gat_rician import _output_audit
from train.trainer import Trainer
from utils.io import generate_dataset
from utils.project_setup import build_gat_scheduler, build_network_generator, load_config


def _csv(text: str, cast):
    return [cast(item.strip()) for item in text.split(",") if item.strip()]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--channels", default="rayleigh,rician")
    parser.add_argument("--train_powers_dbm", default="10,13,19,25,31")
    parser.add_argument("--test_powers_dbm", default="10,13,19,25,31")
    parser.add_argument("--train_size", type=int, default=200)
    parser.add_argument("--val_size", type=int, default=64)
    parser.add_argument("--test_size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--eval_interval", type=int, default=1)
    parser.add_argument("--seed", type=int, default=10086)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--archive_datasets", action="store_true")
    parser.add_argument(
        "--artifact_root",
        type=Path,
        default=ROOT / "results/diagnostics/channel_gat_power_transfer_screen_20260716",
    )
    parser.add_argument(
        "--dataset_root",
        type=Path,
        default=ROOT / "datasets/channel_gat_power_transfer",
    )
    return parser.parse_args()


def reset_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def dataset_summary(dataset) -> dict:
    links = np.asarray([state.num_vertices for state in dataset], dtype=float)
    edges = np.asarray([state.edge_index.shape[1] for state in dataset], dtype=float)
    return {
        "num_states": len(dataset),
        "mean_num_links": float(links.mean()),
        "median_num_links": float(np.median(links)),
        "mean_directed_conflict_edges": float(edges.mean()),
        "mean_in_degree": float(np.mean(edges / np.maximum(links, 1.0))),
    }


def make_config(base: dict, args, channel: str, power_dbm: float) -> dict:
    config = dict(base)
    config.update({
        "NUM_UAV": args.num_uav,
        "CHANNEL_MODEL": channel,
        "RICIAN_K_DB": args.rician_k_db,
        "TX_POWER": float(power_dbm),
        "CSI_MODE": "perfect",
        "USE_QUEUE": False,
        "NODE_RAW_DIM": 1,
        "SEED": args.seed,
    })
    return config


def generate_split(config: dict, size: int, seed: int):
    reset_seed(seed)
    generator = build_network_generator(config)
    return generate_dataset(
        size,
        generator,
        batch_size=config.get("GEN_BATCH_SIZE", 50),
        csi_mode="perfect",
        include_queue_feature=False,
    )


def archive_dataset(path: Path, metadata: dict, **splits) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as handle:
        pickle.dump({"metadata": metadata, **splits}, handle)


def train_one(args, base, channel: str, train_power: float, test_bank: dict) -> dict:
    config = make_config(base, args, channel, train_power)
    # Separate deterministic streams make every train-power dataset paired in
    # positions/fading while keeping train, validation, and test independent.
    train_set = generate_split(config, args.train_size, args.seed)
    val_set = generate_split(config, args.val_size, args.seed + 1)
    model = build_gat_scheduler(config, raw_node_dim=1)
    optimizer = torch.optim.Adam(model.parameters(), lr=float(config["LR"]))
    lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, **(config.get("LR_SCHEDULER_CONFIG", {}) or {})
    )
    case = f"N{args.num_uav}_{channel}_trainTx={train_power:g}dBm"
    case_dir = args.artifact_root / f"N{args.num_uav}" / channel / f"train_tx={train_power:g}dBm"
    case_dir.mkdir(parents=True, exist_ok=True)
    trainer = Trainer(
        model,
        optimizer,
        device="cpu",
        use_queue=False,
        log_dir=str(case_dir / "logs"),
        grad_clip_config=config.get("GRAD_CLIP_CONFIG"),
    )
    trained = trainer.train(
        num_epochs=args.epochs,
        train_dataset=train_set,
        val_dataset=val_set,
        eval_interval=args.eval_interval,
        lr_scheduler=lr_scheduler,
        use_queue=False,
    )
    transfer = {}
    for test_power, test_set in test_bank.items():
        transfer[format(test_power, "g")] = {
            "test_power_dbm": float(test_power),
            "dataset_summary": dataset_summary(test_set),
            "output_audit": _output_audit(model, test_set),
        }
    checkpoint_path = case_dir / "checkpoint.pth"
    torch.save({
        "model_version": "conference_gat_power_transfer_v1",
        "model_state_dict": model.state_dict(),
        "config": config,
        "train_power_dbm": float(train_power),
        "channel_model": channel,
        "best_epoch": trained["best_epoch"],
        "best_val_utility": trained["best_val_util"],
    }, checkpoint_path)
    metadata = {
        "purpose": "conference GAT train/test power transfer",
        "num_uav": args.num_uav,
        "channel_model": channel,
        "rician_k_db": args.rician_k_db if channel == "rician" else None,
        "tx_power_dbm": float(train_power),
        "csi_mode": "perfect",
        "normalized_small_scale_mean_power": 1.0,
        "seed_train": args.seed,
        "seed_val": args.seed + 1,
        "sizes": {"train": args.train_size, "val": args.val_size},
    }
    dataset_path = None
    if args.archive_datasets:
        dataset_path = (
            args.dataset_root / f"N{args.num_uav}" / channel /
            f"train_tx={train_power:g}dBm_seed={args.seed}_"
            f"n={args.train_size}-{args.val_size}.pkl"
        )
        archive_dataset(dataset_path, metadata, train_set=train_set, val_set=val_set)
    report = {
        "case": case,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": metadata,
        "epochs": args.epochs,
        "learning_rate": float(config["LR"]),
        "train_dataset_summary": dataset_summary(train_set),
        "val_dataset_summary": dataset_summary(val_set),
        "best_epoch": trained["best_epoch"],
        "best_val_utility": float(trained["best_val_util"]),
        "per_epoch": trained["per_epoch_logs"],
        "checkpoint_path": str(checkpoint_path),
        "archived_dataset_path": str(dataset_path) if dataset_path else None,
        "transfer": transfer,
    }
    (case_dir / "report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        f"[{case}] best-val={report['best_val_utility']:.4f}; "
        + ", ".join(
            f"test {power} dBm="
            f"{item['output_audit']['hard_test_utility']:.3f}/"
            f"{item['output_audit']['mean_binary_active_fraction']:.2%}"
            for power, item in transfer.items()
        ),
        flush=True,
    )
    return report


def main() -> None:
    args = parse_args()
    channels = _csv(args.channels, str)
    train_powers = _csv(args.train_powers_dbm, float)
    test_powers = _csv(args.test_powers_dbm, float)
    if any(channel not in {"rayleigh", "rician"} for channel in channels):
        raise ValueError("channels must be rayleigh and/or rician")
    base = load_config(ROOT / "configs/exp_example.yaml")
    args.artifact_root.mkdir(parents=True, exist_ok=True)
    reports = []
    test_manifests = {}
    for channel in channels:
        test_bank = {}
        channel_manifests = {}
        for power in test_powers:
            config = make_config(base, args, channel, power)
            test_set = generate_split(config, args.test_size, args.seed + 2)
            test_bank[power] = test_set
            channel_manifests[format(power, "g")] = dataset_summary(test_set)
            if args.archive_datasets:
                path = (
                    args.dataset_root / f"N{args.num_uav}" / channel /
                    f"test_tx={power:g}dBm_seed={args.seed + 2}_n={args.test_size}.pkl"
                )
                archive_dataset(path, {
                    "purpose": "paired power-transfer test bank",
                    "num_uav": args.num_uav,
                    "channel_model": channel,
                    "rician_k_db": args.rician_k_db if channel == "rician" else None,
                    "tx_power_dbm": float(power),
                    "csi_mode": "perfect",
                    "normalized_small_scale_mean_power": 1.0,
                    "seed_test": args.seed + 2,
                    "size": args.test_size,
                }, test_set=test_set)
        test_manifests[channel] = channel_manifests
        for train_power in train_powers:
            reports.append(train_one(args, base, channel, train_power, test_bank))
    summary = {
        "experiment": "conference_gat_power_transfer_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": {
            **vars(args),
            "artifact_root": str(args.artifact_root),
            "dataset_root": str(args.dataset_root),
            "train_powers_dbm": train_powers,
            "test_powers_dbm": test_powers,
            "channels": channels,
            "normalized_small_scale_mean_power": 1.0,
        },
        "test_bank_manifests": test_manifests,
        "cases": [{
            "case": report["case"],
            "settings": report["settings"],
            "best_epoch": report["best_epoch"],
            "best_val_utility": report["best_val_utility"],
            "checkpoint_path": report["checkpoint_path"],
            "archived_dataset_path": report["archived_dataset_path"],
            "transfer": report["transfer"],
        } for report in reports],
    }
    (args.artifact_root / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Saved {args.artifact_root / 'summary.json'}", flush=True)


if __name__ == "__main__":
    main()
