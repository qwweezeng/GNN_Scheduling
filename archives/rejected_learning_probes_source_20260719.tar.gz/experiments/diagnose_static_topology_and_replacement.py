#!/usr/bin/env python3
"""No-training diagnosis of topology scores and reversible skeleton decisions.

This experiment asks two deliberately separate questions.

1. Can a fixed, physically interpretable one-hop correction to ``Q*C_solo``
   already improve the LocalMax skeleton?
2. If not, is there nevertheless material gain when the completed Pure action
   is allowed to replace one active conflict neighborhood by one challenger?

The replacement search uses the true global ``sum(QR)`` objective and is
centralized.  It is therefore an upper-bound diagnostic, not a deployable
scheduler and not a proposed algorithm.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    conflict_neighbors,
    queue_snapshot,
)
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
    local_edge_gains,
    select_local_maxima,
)
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


STATIC_METHODS = (
    "degree_penalty",
    "neighbor_share",
    "physical_net_benefit",
    "physical_benefit_cost_ratio",
)


def topology_scores(state, queues):
    """Return Pure utility weights and four no-learning topology corrections."""
    queues = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).cpu()
    direct, source, target, edge_gain = local_edge_gains(state)
    noise = torch.as_tensor(state.noise_power, dtype=torch.float32).cpu()
    snr_gap = float(getattr(state, "snr_gap", 1.0))
    solo_rate = torch.log2(1.0 + direct / noise / snr_gap)
    pure_weight = queues * solo_rate

    num_links = int(state.num_vertices)
    neighbors = conflict_neighbors(state.edge_index, num_links)
    degree = torch.tensor(
        [len(items) for items in neighbors], dtype=torch.float32
    )
    neighbor_weight = torch.zeros_like(pure_weight)
    for link_index, items in enumerate(neighbors):
        if items:
            neighbor_weight[link_index] = pure_weight[
                torch.tensor(sorted(items), dtype=torch.long)
            ].sum()

    # ``harm[i]`` estimates the weighted rate lost by i's one-hop neighbors
    # if i is added while each affected neighbor is otherwise interference-free.
    harm = torch.zeros_like(pure_weight)
    if source.numel() > 0:
        interfered_rate = torch.log2(
            1.0
            + direct[target]
            / (noise + edge_gain)
            / snr_gap
        )
        loss = queues[target] * (solo_rate[target] - interfered_rate)
        harm.index_add_(0, source, torch.clamp(loss, min=0.0))

    epsilon = torch.tensor(1e-8, dtype=pure_weight.dtype)
    scores = {
        "pure": pure_weight,
        # Congested conflict neighborhoods are discounted equally, without
        # using any trainable parameter.
        "degree_penalty": pure_weight / (1.0 + degree),
        # A link is judged by its share of the total urgent utility in its
        # one-hop conflict neighborhood.
        "neighbor_share": pure_weight / (
            pure_weight + neighbor_weight + epsilon
        ),
        # Benefit minus the estimated externality imposed on one-hop peers.
        "physical_net_benefit": pure_weight - harm,
        # A scale-stable benefit-to-externality alternative.
        "physical_benefit_cost_ratio": pure_weight / (harm + epsilon),
    }
    diagnostics = {
        "mean_degree": float(degree.mean()),
        "mean_harm": float(harm.mean()),
        "mean_pure_weight": float(pure_weight.mean()),
    }
    return scores, diagnostics


def schedule_from_score(state, queues, score):
    """Run the unchanged LocalMax skeleton and physical-reuse completion."""
    valid = torch.as_tensor(queues).reshape(-1).cpu() > 0
    base = select_local_maxima(score, valid, state.edge_index).float()
    action, _, _ = complete_physical_reuse_from_base(state, queues, base)
    return action, base


def best_post_completion_replacement(state, queues, pure_action):
    """Find the best exact one-challenger replacement after Pure completion."""
    pure_action = torch.as_tensor(
        pure_action, dtype=torch.float32
    ).reshape(-1).round().cpu()
    best_action = pure_action.clone()
    best_utility = float(mws_objective(best_action, queues, state))
    best_challenger = None
    best_removed = []
    evaluated = 0

    active = set(torch.nonzero(pure_action > 0.5, as_tuple=True)[0].tolist())
    nonempty = torch.as_tensor(queues).reshape(-1).cpu() > 0
    neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
    for challenger in torch.nonzero(
        nonempty & (pure_action <= 0.5), as_tuple=True
    )[0].tolist():
        removed = sorted(active.intersection(neighbors[int(challenger)]))
        if not removed:
            continue
        candidate = pure_action.clone()
        candidate[torch.tensor(removed, dtype=torch.long)] = 0.0
        candidate[int(challenger)] = 1.0
        utility = float(mws_objective(candidate, queues, state))
        evaluated += 1
        if utility > best_utility + 1e-9:
            best_utility = utility
            best_action = candidate
            best_challenger = int(challenger)
            best_removed = removed
    return {
        "action": best_action,
        "utility": best_utility,
        "challenger": best_challenger,
        "removed_links": best_removed,
        "evaluated_replacements": evaluated,
    }


def summarize(records, method):
    ratios = np.asarray(
        [row["utilities"][method] / max(abs(row["utilities"]["pure"]), 1e-12)
         for row in records],
        dtype=np.float64,
    )
    gains = ratios - 1.0
    return {
        "num_snapshots": len(records),
        "mean_ratio_vs_pure": float(np.mean(ratios)),
        "mean_gain_fraction_vs_pure": float(np.mean(gains)),
        "gain_ci95": float(
            1.96 * np.std(gains, ddof=1) / np.sqrt(len(gains))
        ) if len(gains) > 1 else 0.0,
        "strict_win_fraction_vs_pure": float(np.mean(gains > 1e-9)),
        "strict_loss_fraction_vs_pure": float(np.mean(gains < -1e-9)),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--profiles", default="sparse,heterogeneous,saturated")
    parser.add_argument("--minimum_mean_gain_fraction", type=float, default=0.02)
    parser.add_argument("--minimum_win_fraction", type=float, default=0.70)
    parser.add_argument("--sparse_minimum_ratio", type=float, default=0.99)
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument(
        "--output",
        default=(
            "results/formal/static_topology_and_replacement_probe_"
            "N20_rician_20260716.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("The formal probe is frozen to N=20 and 10 dBm.")

    profiles = [item.strip() for item in args.profiles.split(",") if item.strip()]
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config,
        args.channel_gat_checkpoint,
        args.num_uav,
        device="cpu",
        allow_power_transfer=False,
    )
    pure_scheduler = PurePhysicalReuseScheduler(channel_model)

    records = []
    for graph_index in range(args.num_graphs):
        graph_seed = args.seed + graph_index
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            scores, score_diagnostics = topology_scores(state, queues)
            utilities = {}
            actions = {}
            skeleton_sizes = {}
            for method, score in scores.items():
                action, base = schedule_from_score(state, queues, score)
                utilities[method] = float(mws_objective(action, queues, state))
                actions[method] = action
                skeleton_sizes[method] = int(base.sum())

            # Assert that the reimplemented Pure path is exactly the production
            # scheduler before interpreting any paired comparison.
            production_pure = pure_scheduler.schedule_with_state(state, queues)
            if not torch.equal(
                actions["pure"].reshape(-1).round(),
                production_pure.reshape(-1).round(),
            ):
                raise RuntimeError("Diagnostic Pure path differs from production Pure.")

            replacement = best_post_completion_replacement(
                state, queues, actions["pure"]
            )
            utilities["post_completion_replacement_oracle"] = replacement["utility"]
            record = {
                "graph_seed": graph_seed,
                "queue_profile": profile,
                "num_links": int(state.num_vertices),
                "utilities": utilities,
                "skeleton_sizes": skeleton_sizes,
                "pure_final_active_links": int(actions["pure"].sum()),
                "replacement_challenger": replacement["challenger"],
                "replacement_removed_links": replacement["removed_links"],
                "evaluated_replacements": replacement["evaluated_replacements"],
                "score_diagnostics": score_diagnostics,
            }
            records.append(record)
            best_static = max(
                STATIC_METHODS,
                key=lambda name: utilities[name],
            )
            print(
                f"seed={graph_seed} profile={profile:<13} "
                f"best_static={best_static:<27} "
                f"static_gain={100 * (utilities[best_static] / utilities['pure'] - 1):+.2f}% "
                f"replace_gain={100 * (replacement['utility'] / utilities['pure'] - 1):+.2f}%"
            )

    methods = (*STATIC_METHODS, "post_completion_replacement_oracle")
    by_profile = {
        profile: {
            method: summarize(
                [row for row in records if row["queue_profile"] == profile],
                method,
            )
            for method in methods
        }
        for profile in profiles
    }
    overall = {method: summarize(records, method) for method in methods}

    competition_profiles = [
        profile for profile in profiles
        if profile in {"heterogeneous", "saturated"}
    ]
    static_pass = {}
    for method in STATIC_METHODS:
        competition_ok = all(
            by_profile[profile][method]["mean_gain_fraction_vs_pure"]
            >= args.minimum_mean_gain_fraction
            and by_profile[profile][method]["strict_win_fraction_vs_pure"]
            >= args.minimum_win_fraction
            for profile in competition_profiles
        )
        sparse_ok = (
            "sparse" not in by_profile
            or by_profile["sparse"][method]["mean_ratio_vs_pure"]
            >= args.sparse_minimum_ratio
        )
        static_pass[method] = bool(competition_ok and sparse_ok)

    oracle_method = "post_completion_replacement_oracle"
    replacement_pass = all(
        by_profile[profile][oracle_method]["mean_gain_fraction_vs_pure"]
        >= args.minimum_mean_gain_fraction
        and by_profile[profile][oracle_method]["strict_win_fraction_vs_pure"]
        >= args.minimum_win_fraction
        for profile in competition_profiles
    )
    if any(static_pass.values()):
        decision = "STATIC_TOPOLOGY_SCORE_HAS_MATERIAL_HEADROOM"
    elif replacement_pass:
        decision = "STATIC_SCORES_FAIL_BUT_REVERSIBLE_SET_DECISION_HAS_HEADROOM"
    else:
        decision = "NO_MATERIAL_HEADROOM_STOP_REDIRECTION"

    payload = {
        "experiment": "static_topology_and_replacement_probe_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "purpose": (
            "Separate the value of a fixed pre-skeleton topology score from "
            "the value of making the completed active set reversible."
        ),
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "definitions": {
            "degree_penalty": "Q*C_solo divided by one plus conflict degree.",
            "neighbor_share": (
                "Q*C_solo divided by its own plus neighboring Q*C_solo."
            ),
            "physical_net_benefit": (
                "Q*C_solo minus estimated one-hop weighted interference harm."
            ),
            "physical_benefit_cost_ratio": (
                "Q*C_solo divided by estimated one-hop interference harm."
            ),
            "post_completion_replacement_oracle": (
                "After Pure completion, try every inactive nonempty challenger, "
                "remove its active conflict neighbors, add it, and retain only "
                "the exact true-sum(QR) best action."
            ),
            "oracle_is_not_deployable": True,
        },
        "predeclared_gate": {
            "required_competition_profiles": competition_profiles,
            "minimum_mean_gain_fraction": args.minimum_mean_gain_fraction,
            "minimum_strict_win_fraction": args.minimum_win_fraction,
            "sparse_minimum_ratio_for_static_scores": args.sparse_minimum_ratio,
            "static_method_passed": static_pass,
            "replacement_oracle_passed": bool(replacement_pass),
        },
        "overall": overall,
        "by_profile": by_profile,
        "records": records,
        "decision": decision,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "static_method_passed": static_pass,
        "replacement_oracle_passed": replacement_pass,
        "decision": decision,
        "output": str(output),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
