#!/usr/bin/env python3
"""Minimal learnability gate for imperfect-CSI MarginalMP proposals.

The learner does not replace Direct-Link MarginalMP and does not predict the
final schedule.  It only filters an observed-positive toggle proposal when
that proposal is likely to have non-positive utility under the current true
channel.  A local MLP and a one-layer channel GAT receive the same local
features; the GAT adds one cached conflict-neighbor aggregation per channel
block.  Final schedules are always evaluated on current true CSI.
"""

import argparse
import json
import os
import random
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import queue_snapshot  # noqa: E402
from models.initial_schedule_construction import DirectLinkLocalMaxScheduler  # noqa: E402
from models.local_physical_reuse import select_local_positive_maxima  # noqa: E402
from models.marginal_mp import exact_link_toggle_marginals  # noqa: E402
from models.model import GATLayer  # noqa: E402
from simulator.mobile_block_fading import (  # noqa: E402
    build_observed_network_state,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import build_network_generator, load_config  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


MODES = ("stale", "large_scale", "quantized")
PROFILES = ("heterogeneous", "saturated")


def _parse_ints(text):
    return [int(item) for item in str(text).split(",") if item.strip()]


def _base_features(observed_state, mode):
    obs_snr = observed_state.vertex_features[:, 0].float().cpu()
    degree = torch.zeros(observed_state.num_vertices, dtype=torch.float32)
    if observed_state.edge_index.numel() > 0:
        degree.index_add_(
            0, observed_state.edge_index[1].cpu(),
            torch.ones(observed_state.edge_index.size(1)),
        )
    degree = degree / degree.max().clamp_min(1.0)
    onehot = torch.zeros((observed_state.num_vertices, len(MODES)))
    onehot[:, MODES.index(mode)] = 1.0
    return torch.cat([
        (obs_snr / 20.0).clamp(-3.0, 3.0).unsqueeze(1),
        degree.unsqueeze(1),
        onehot,
    ], dim=1)


def _dynamic_features(marginals, queues, action, valid):
    scale = marginals[valid].median().clamp_min(1e-6) if bool(valid.any()) else 1.0
    margin = torch.log1p(marginals.clamp_min(0.0) / scale).clamp_max(6.0)
    q = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).cpu()
    q = q / q.mean().clamp_min(1e-6)
    return torch.stack([margin, q.clamp_max(10.0), action.float().cpu()], dim=1)


def _graph_samples(observed_state, true_state, queues, mode, rounds):
    initializer = DirectLinkLocalMaxScheduler()
    action = initializer.schedule_with_state(
        observed_state, queues
    ).reshape(-1).round().bool().cpu()
    samples = []
    for _ in range(int(rounds)):
        observed = exact_link_toggle_marginals(observed_state, queues, action)
        truth = exact_link_toggle_marginals(true_state, queues, action)
        valid = torch.isfinite(observed) & (observed > 1e-6)
        samples.append({
            "dynamic": _dynamic_features(observed, queues, action, valid),
            "mask": valid,
            "label": (torch.isfinite(truth) & (truth > 1e-6)).float(),
        })
        selected = select_local_positive_maxima(
            observed, valid, observed_state.edge_index
        )
        if not bool(selected.any()):
            break
        action = torch.logical_xor(action, selected.cpu())
    return samples


def _make_graph(observed_state, true_state, queues, mode, profile, seed, block, rounds):
    return {
        "base": _base_features(observed_state, mode),
        "edge_index": observed_state.edge_index.long().cpu(),
        "edge_attr": observed_state.edge_weights.float().cpu(),
        "rounds": _graph_samples(observed_state, true_state, queues, mode, rounds),
        "mode": mode,
        "profile": profile,
        "seed": int(seed),
        "block": int(block),
    }


def _collect_graphs(net_gen, seeds, args):
    graphs = []
    for seed in seeds:
        trace = generate_mobile_block_fading_trace(
            net_gen, num_slots=args.num_slots,
            slots_per_block=args.slots_per_block, slot_duration=0.001,
            speed_mps=args.speed_mps, seed=seed,
            quantization_bits=(args.q_bits,), rician_k_db=args.rician_k_db,
        )
        for block in range(1, len(trace.blocks)):
            true_state, true_ids = build_true_network_state(net_gen, trace, block)
            for profile_index, profile in enumerate(PROFILES):
                queues = queue_snapshot(
                    true_state.num_vertices,
                    seed * 1_000_003 + block * 101 + profile_index * 10_000,
                    profile,
                )
                for mode in MODES:
                    observed_state, observed_ids = build_observed_network_state(
                        net_gen, trace, block, mode, args.q_bits
                    )
                    if not torch.equal(true_ids, observed_ids):
                        raise RuntimeError("Observed/true persistent IDs diverged")
                    graphs.append(_make_graph(
                        observed_state, true_state, queues, mode, profile,
                        seed, block, args.rounds,
                    ))
        print(f"collected seed={seed}")
    return graphs


class LocalMLP(nn.Module):
    def __init__(self, base_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(base_dim + 3, 24), nn.ReLU(),
            nn.Linear(24, 1),
        )

    def encode(self, base, edge_index, edge_attr):
        return base

    def logits(self, encoded, dynamic):
        return self.net(torch.cat([encoded, dynamic], dim=1)).squeeze(1)


class OneLayerChannelGAT(nn.Module):
    def __init__(self, base_dim):
        super().__init__()
        self.input = nn.Sequential(nn.Linear(base_dim, 16), nn.ReLU())
        self.gat = GATLayer(16, 1, 8, num_heads=2)
        self.head = nn.Sequential(
            nn.Linear(16 + 3, 24), nn.ReLU(), nn.Linear(24, 1),
        )

    def encode(self, base, edge_index, edge_attr):
        return self.gat(self.input(base), edge_index, edge_attr)

    def logits(self, encoded, dynamic):
        return self.head(torch.cat([encoded, dynamic], dim=1)).squeeze(1)


def _class_counts(graphs):
    positive = negative = 0
    for graph in graphs:
        for sample in graph["rounds"]:
            labels = sample["label"][sample["mask"]]
            positive += int(labels.sum())
            negative += int(labels.numel() - labels.sum())
    return positive, negative


def _train(model, train_graphs, val_graphs, args):
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    positive, negative = _class_counts(train_graphs)
    pos_weight = torch.tensor(float(negative) / max(positive, 1))
    best = None
    best_loss = float("inf")
    rng = random.Random(args.train_seed)
    for epoch in range(args.epochs):
        model.train()
        order = list(range(len(train_graphs)))
        rng.shuffle(order)
        total = count = 0
        for index in order:
            graph = train_graphs[index]
            encoded = model.encode(
                graph["base"], graph["edge_index"], graph["edge_attr"]
            )
            losses = []
            for sample in graph["rounds"]:
                mask = sample["mask"]
                if bool(mask.any()):
                    logits = model.logits(encoded, sample["dynamic"])[mask]
                    losses.append(F.binary_cross_entropy_with_logits(
                        logits, sample["label"][mask], pos_weight=pos_weight
                    ))
            if not losses:
                continue
            loss = torch.stack(losses).mean()
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            total += float(loss.detach())
            count += 1
        val_loss = _loss(model, val_graphs, pos_weight)
        print(f"epoch={epoch + 1} train_loss={total / max(count, 1):.5f} val_loss={val_loss:.5f}")
        if val_loss < best_loss:
            best_loss = val_loss
            best = {key: value.detach().clone() for key, value in model.state_dict().items()}
    model.load_state_dict(best)
    return {"train_positive": positive, "train_negative": negative, "best_val_loss": best_loss}


@torch.no_grad()
def _loss(model, graphs, pos_weight):
    model.eval()
    values = []
    for graph in graphs:
        encoded = model.encode(graph["base"], graph["edge_index"], graph["edge_attr"])
        for sample in graph["rounds"]:
            mask = sample["mask"]
            if bool(mask.any()):
                values.append(float(F.binary_cross_entropy_with_logits(
                    model.logits(encoded, sample["dynamic"])[mask],
                    sample["label"][mask], pos_weight=pos_weight,
                )))
    return float(np.mean(values)) if values else float("nan")


@torch.no_grad()
def _predictions(model, graphs):
    model.eval()
    probabilities, labels = [], []
    for graph in graphs:
        encoded = model.encode(graph["base"], graph["edge_index"], graph["edge_attr"])
        for sample in graph["rounds"]:
            mask = sample["mask"]
            if bool(mask.any()):
                probabilities.extend(torch.sigmoid(
                    model.logits(encoded, sample["dynamic"])[mask]
                ).tolist())
                labels.extend(sample["label"][mask].tolist())
    return np.asarray(probabilities), np.asarray(labels, dtype=np.int64)


def _classification(probability, label, threshold):
    keep = probability >= threshold
    true = label == 1
    recall = float(np.mean(keep[true])) if true.any() else 1.0
    false_removed = float(np.mean(~keep[~true])) if (~true).any() else 0.0
    accuracy = float(np.mean(keep == true))
    return {
        "threshold": float(threshold),
        "true_proposal_recall": recall,
        "false_proposal_removal": false_removed,
        "proposal_retention": float(np.mean(keep)),
        "balanced_accuracy": 0.5 * (recall + false_removed),
        "accuracy": accuracy,
    }


def _choose_threshold(model, val_graphs):
    probability, label = _predictions(model, val_graphs)
    candidates = [_classification(probability, label, value) for value in np.arange(0.1, 0.91, 0.05)]
    feasible = [row for row in candidates if row["true_proposal_recall"] >= 0.95]
    chosen = max(feasible or candidates, key=lambda row: row["false_proposal_removal"])
    return chosen


@torch.no_grad()
def _filtered_schedule(model, observed_state, true_state, queues, mode, rounds, threshold):
    model.eval()
    base = _base_features(observed_state, mode)
    encoded = model.encode(base, observed_state.edge_index, observed_state.edge_weights)
    action = DirectLinkLocalMaxScheduler().schedule_with_state(
        observed_state, queues
    ).reshape(-1).round().bool().cpu()
    out_degree = torch.bincount(
        observed_state.edge_index[0].cpu(), minlength=observed_state.num_vertices
    )
    announced = retained = announced_receptions = retained_receptions = selected_bad = 0
    for _ in range(int(rounds)):
        observed = exact_link_toggle_marginals(observed_state, queues, action)
        truth = exact_link_toggle_marginals(true_state, queues, action)
        valid = torch.isfinite(observed) & (observed > 1e-6)
        dynamic = _dynamic_features(observed, queues, action, valid)
        keep = torch.sigmoid(model.logits(encoded, dynamic)) >= float(threshold)
        announced += int(valid.sum())
        announced_receptions += int(out_degree[valid].sum())
        valid &= keep.cpu()
        retained += int(valid.sum())
        retained_receptions += int(out_degree[valid].sum())
        selected = select_local_positive_maxima(observed, valid, observed_state.edge_index)
        selected_bad += int((selected & (truth <= 1e-6)).sum())
        if not bool(selected.any()):
            break
        action = torch.logical_xor(action, selected.cpu())
    return (
        action.float().unsqueeze(1), announced, retained,
        announced_receptions, retained_receptions, selected_bad,
    )


@torch.no_grad()
def _baseline_schedule(observed_state, true_state, queues, rounds):
    action = DirectLinkLocalMaxScheduler().schedule_with_state(
        observed_state, queues
    ).reshape(-1).round().bool().cpu()
    out_degree = torch.bincount(
        observed_state.edge_index[0].cpu(), minlength=observed_state.num_vertices
    )
    announced = receptions = selected_bad = 0
    for _ in range(int(rounds)):
        observed = exact_link_toggle_marginals(observed_state, queues, action)
        truth = exact_link_toggle_marginals(true_state, queues, action)
        valid = torch.isfinite(observed) & (observed > 1e-6)
        announced += int(valid.sum())
        receptions += int(out_degree[valid].sum())
        selected = select_local_positive_maxima(observed, valid, observed_state.edge_index)
        selected_bad += int((selected & (truth <= 1e-6)).sum())
        if not bool(selected.any()):
            break
        action = torch.logical_xor(action, selected.cpu())
    return action.float().unsqueeze(1), announced, receptions, selected_bad


def _evaluate_online(model, net_gen, seeds, args, threshold, model_name):
    records = []
    for seed in seeds:
        trace = generate_mobile_block_fading_trace(
            net_gen, num_slots=args.num_slots,
            slots_per_block=args.slots_per_block, slot_duration=0.001,
            speed_mps=args.speed_mps, seed=seed,
            quantization_bits=(args.q_bits,), rician_k_db=args.rician_k_db,
        )
        for block in range(1, len(trace.blocks)):
            true_state, true_ids = build_true_network_state(net_gen, trace, block)
            for profile_index, profile in enumerate(PROFILES):
                queues = queue_snapshot(
                    true_state.num_vertices,
                    seed * 1_000_003 + block * 101 + profile_index * 10_000,
                    profile,
                )
                for mode in MODES:
                    observed_state, observed_ids = build_observed_network_state(
                        net_gen, trace, block, mode, args.q_bits
                    )
                    if not torch.equal(true_ids, observed_ids):
                        raise RuntimeError("Observed/true persistent IDs diverged")
                    baseline, proposed, proposal_receptions, bad_base = _baseline_schedule(
                        observed_state, true_state, queues, args.rounds
                    )
                    (
                        learned, announced, retained,
                        announced_receptions, retained_receptions, bad_learned,
                    ) = _filtered_schedule(
                        model, observed_state, true_state, queues, mode,
                        args.rounds, threshold,
                    )
                    records.append({
                        "model": model_name, "seed": seed, "block": block,
                        "mode": mode, "profile": profile,
                        "baseline_utility": float(mws_objective(baseline, queues, true_state)),
                        "learned_utility": float(mws_objective(learned, queues, true_state)),
                        "baseline_proposals": proposed,
                        "baseline_proposal_receptions": proposal_receptions,
                        "learned_proposals": announced,
                        "retained_proposals": retained,
                        "learned_proposal_receptions": announced_receptions,
                        "retained_proposal_receptions": retained_receptions,
                        "baseline_harmful_selected": bad_base,
                        "learned_harmful_selected": bad_learned,
                        "gat_node_broadcasts": int(observed_state.num_vertices)
                        if model_name == "one_layer_channel_gat" else 0,
                        "gat_neighbor_receptions": int(observed_state.edge_index.size(1))
                        if model_name == "one_layer_channel_gat" else 0,
                    })
        print(f"evaluated {model_name} seed={seed}")
    return records


def _mean_ci(values):
    values = np.asarray(values, dtype=np.float64)
    return {
        "mean": float(values.mean()),
        "ci95": float(1.96 * values.std(ddof=1) / np.sqrt(len(values))) if len(values) > 1 else 0.0,
    }


def _summarize_online(records):
    output = {}
    for model_name in sorted({row["model"] for row in records}):
        output[model_name] = {}
        model_rows = [row for row in records if row["model"] == model_name]
        for mode in MODES:
            output[model_name][mode] = {}
            for profile in PROFILES:
                rows = [row for row in model_rows if row["mode"] == mode and row["profile"] == profile]
                by_seed = defaultdict(list)
                for row in rows:
                    by_seed[row["seed"]].append(row)
                ratios = []
                for seed_rows in by_seed.values():
                    ratios.append(
                        np.mean([row["learned_utility"] for row in seed_rows])
                        / max(np.mean([row["baseline_utility"] for row in seed_rows]), 1e-12)
                    )
                baseline_proposals = sum(row["baseline_proposals"] for row in rows)
                retained = sum(row["retained_proposals"] for row in rows)
                baseline_receptions = sum(row["baseline_proposal_receptions"] for row in rows)
                retained_receptions = sum(row["retained_proposal_receptions"] for row in rows)
                gat_broadcasts = sum(row["gat_node_broadcasts"] for row in rows)
                gat_receptions = sum(row["gat_neighbor_receptions"] for row in rows)
                output[model_name][mode][profile] = {
                    "utility_ratio_to_direct_link_marginal_mp": _mean_ci(ratios),
                    "strict_seed_win_fraction": float(np.mean(np.asarray(ratios) > 1.0 + 1e-9)),
                    "proposal_retention": float(retained / max(baseline_proposals, 1)),
                    "proposal_message_reduction": float(1.0 - retained / max(baseline_proposals, 1)),
                    "proposal_neighbor_reception_reduction": float(
                        1.0 - retained_receptions / max(baseline_receptions, 1)
                    ),
                    "standalone_node_broadcast_change": float(
                        (retained + gat_broadcasts) / max(baseline_proposals, 1) - 1.0
                    ),
                    "standalone_neighbor_reception_change": float(
                        (retained_receptions + gat_receptions)
                        / max(baseline_receptions, 1) - 1.0
                    ),
                    "baseline_harmful_selected": int(sum(row["baseline_harmful_selected"] for row in rows)),
                    "learned_harmful_selected": int(sum(row["learned_harmful_selected"] for row in rows)),
                }
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--num_slots", type=int, default=60)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--q_bits", type=int, default=4)
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument("--train_seeds", default="100,101")
    parser.add_argument("--val_seeds", default="200")
    parser.add_argument("--test_seeds", default="42,43,44,45,46")
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--train_seed", type=int, default=7)
    parser.add_argument("--output", default="results/formal/marginal_mp_proposal_reliability_probe_N20_rician_20260718.json")
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("Formal probe is frozen to N=20 and 10 dBm")
    random.seed(args.train_seed)
    np.random.seed(args.train_seed)
    torch.manual_seed(args.train_seed)
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav, "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect", "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    net_gen = build_network_generator(config)
    train_graphs = _collect_graphs(net_gen, _parse_ints(args.train_seeds), args)
    val_graphs = _collect_graphs(net_gen, _parse_ints(args.val_seeds), args)
    base_dim = train_graphs[0]["base"].size(1)
    models = {
        "local_mlp": LocalMLP(base_dim),
        "one_layer_channel_gat": OneLayerChannelGAT(base_dim),
    }
    training = {}
    thresholds = {}
    classification = {}
    online_records = []
    for name, model in models.items():
        print(f"training {name}")
        training[name] = _train(model, train_graphs, val_graphs, args)
        thresholds[name] = _choose_threshold(model, val_graphs)
        probability, label = _predictions(model, val_graphs)
        classification[name] = {
            "validation": _classification(probability, label, thresholds[name]["threshold"]),
        }
        online_records.extend(_evaluate_online(
            model, net_gen, _parse_ints(args.test_seeds), args,
            thresholds[name]["threshold"], name,
        ))
    online = _summarize_online(online_records)
    performance_pass = []
    graph_specific_pass = []
    for mode in MODES:
        for profile in PROFILES:
            mlp = online["local_mlp"][mode][profile]
            gat = online["one_layer_channel_gat"][mode][profile]
            if (
                gat["utility_ratio_to_direct_link_marginal_mp"]["mean"] >= 1.05
                and gat["strict_seed_win_fraction"] >= 0.8
            ):
                performance_pass.append(f"{mode}/{profile}")
            if (
                gat["utility_ratio_to_direct_link_marginal_mp"]["mean"]
                >= mlp["utility_ratio_to_direct_link_marginal_mp"]["mean"] + 0.02
                and gat["utility_ratio_to_direct_link_marginal_mp"]["mean"] >= 1.05
            ):
                graph_specific_pass.append(f"{mode}/{profile}")
    payload = {
        "experiment": "marginal_mp_proposal_reliability_probe_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definition": (
            "A learner filters observed-positive MarginalMP toggle proposals; "
            "it never predicts the final schedule. The one-layer GAT channel "
            "embedding is computed once per channel block and reused in all rounds."
        ),
        "training": training,
        "threshold_selection": thresholds,
        "classification": classification,
        "online_summary": online,
        "gates": {
            "performance_pass_cells": performance_pass,
            "graph_specific_pass_cells": graph_specific_pass,
            "required": "GAT >=5% over baseline in >=4/5 seeds and >=2 percentage points over local MLP",
        },
        "message_accounting": {
            "proposal_broadcasts": "one node broadcast per retained positive proposal",
            "proposal_receptions": "one neighbor reception per outgoing conflict edge of each retained proposal",
            "gat_broadcasts": "one embedding broadcast per link-node per channel block",
            "gat_receptions": "one embedding reception per directed conflict edge per channel block",
            "rounds": "MarginalMP keeps K negotiation rounds; GAT adds one cached neighbor-aggregation round per channel block",
            "warning": "broadcast and neighbor-reception counts are reported separately; embedding payload size is larger than a scalar proposal and is not hidden",
        },
        "decision": (
            "PROCEED_TO_SHORT_DYNAMIC_GATE" if graph_specific_pass
            else "STOP_LEARNING_ASSISTED_MARGINAL_MP"
        ),
        "records": online_records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "performance_pass_cells": performance_pass,
        "graph_specific_pass_cells": graph_specific_pass,
        "decision": payload["decision"],
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
