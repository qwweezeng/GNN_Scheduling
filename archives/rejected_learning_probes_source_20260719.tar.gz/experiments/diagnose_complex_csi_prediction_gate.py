#!/usr/bin/env python3
"""Final no-training gate for trajectory-aided complex-CSI prediction.

The experiment separates physical channel-block duration from CSI feedback
age.  For a known Rician/Gauss--Markov trace it computes the conditional mean
power from an aged *complex* CSI sample and current geometry, then evaluates
the unchanged Direct-Link MarginalMP action on current true CSI.  No neural
network is trained.  Only a cell with material stale loss and material paired
scheduler recovery may unlock a minimal complex Link-GRU.
"""

import argparse
import json
import math
import os
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import queue_snapshot  # noqa: E402
from models.marginal_mp import DirectLinkMarginalMP  # noqa: E402
from simulator.mobile_block_fading import (  # noqa: E402
    build_network_state_from_power,
    build_observed_network_state,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import build_network_generator, load_config  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


PROFILES = ("heterogeneous", "saturated")
METHODS = ("latest", "large_scale", "stale", "complex_conditional")


def _parse_floats(text):
    return [float(item) for item in str(text).split(",") if item.strip()]


def _parse_ints(text):
    return [int(item) for item in str(text).split(",") if item.strip()]


def _distances(block, minimum_distance):
    return torch.cdist(block.positions, block.positions).clamp_min(
        float(minimum_distance)
    )


def conditional_expected_power(net_gen, trace, block_index, stale_blocks):
    """Bayes conditional mean power under the trace's Rician GM model.

    The predictor knows the aged complex channel, current/aged geometry, the
    Rician K-factor, and the per-block Gauss--Markov coefficient.  It does not
    access any innovation after the aged observation.
    """
    age = int(stale_blocks)
    if age < 1 or int(block_index) < age:
        raise ValueError("block_index must be at least stale_blocks >= 1")
    if trace.rician_k_db is None:
        raise ValueError("complex conditional predictor requires Rician fading")
    previous = trace.blocks[int(block_index) - age]
    current = trace.blocks[int(block_index)]
    tx_power = float(net_gen.tx_power)
    previous_amplitude = torch.sqrt(
        previous.large_scale_power / tx_power
    ).to(previous.true_channel.dtype)
    current_amplitude = torch.sqrt(
        current.large_scale_power / tx_power
    ).to(previous.true_channel.dtype)
    wavelength = 3.0e8 / float(net_gen.carrier_f)
    previous_phase = torch.exp(
        -1j * 2.0 * math.pi
        * _distances(previous, net_gen.min_distance).to(previous.true_channel.dtype)
        / wavelength
    )
    current_phase = torch.exp(
        -1j * 2.0 * math.pi
        * _distances(current, net_gen.min_distance).to(previous.true_channel.dtype)
        / wavelength
    )

    if np.isposinf(float(trace.rician_k_db)):
        expected = current.large_scale_power.clone()
        expected.fill_diagonal_(0.0)
        return expected

    k_linear = 10.0 ** (float(trace.rician_k_db) / 10.0)
    los_scale = math.sqrt(k_linear / (k_linear + 1.0))
    diffuse_scale = math.sqrt(1.0 / (k_linear + 1.0))
    normalized_previous = torch.zeros_like(previous.true_channel)
    valid = previous_amplitude.abs() > 0
    normalized_previous[valid] = (
        previous.true_channel[valid] / previous_amplitude[valid]
    )
    previous_diffuse = torch.zeros_like(previous.true_channel)
    previous_diffuse[valid] = (
        normalized_previous[valid] - los_scale * previous_phase[valid]
    ) / diffuse_scale

    rho_to_age = float(current.fading_rho) ** age
    conditional_small_mean = (
        los_scale * current_phase
        + diffuse_scale * rho_to_age * previous_diffuse
    )
    innovation_variance = diffuse_scale ** 2 * (1.0 - rho_to_age ** 2)
    expected = tx_power * current_amplitude.abs().square() * (
        conditional_small_mean.abs().square() + innovation_variance
    )
    expected = expected.float()
    expected.fill_diagonal_(0.0)
    if not torch.isfinite(expected).all() or bool((expected < 0).any()):
        raise RuntimeError("conditional expected power is invalid")
    return expected


def _mean_ci(values):
    values = np.asarray(values, dtype=np.float64)
    return {
        "mean": float(values.mean()),
        "ci95": float(1.96 * values.std(ddof=1) / np.sqrt(len(values)))
        if len(values) > 1 else 0.0,
    }


def _jaccard(left, right):
    left = left.reshape(-1).bool()
    right = right.reshape(-1).bool()
    union = left | right
    return float((left & right).sum() / union.sum()) if bool(union.any()) else 1.0


def _power_mae_db(predicted, truth):
    mask = (predicted > 0) & (truth > 0)
    if not bool(mask.any()):
        return 0.0
    error = torch.abs(
        10.0 * torch.log10(predicted[mask])
        - 10.0 * torch.log10(truth[mask])
    )
    return float(error.mean())


def _aggregate(records, k_db, speed, age, profile):
    rows = [
        row for row in records
        if row["rician_k_db"] == k_db
        and row["speed_mps"] == speed
        and row["stale_blocks"] == age
        and row["profile"] == profile
    ]
    by_seed = defaultdict(list)
    for row in rows:
        by_seed[row["seed"]].append(row)
    stale_latest = []
    conditional_latest = []
    conditional_stale = []
    large_latest = []
    conditional_mae_better = []
    for seed_rows in by_seed.values():
        means = {
            name: np.mean([row[f"{name}_utility"] for row in seed_rows])
            for name in METHODS
        }
        stale_latest.append(means["stale"] / max(means["latest"], 1e-12))
        conditional_latest.append(
            means["complex_conditional"] / max(means["latest"], 1e-12)
        )
        conditional_stale.append(
            means["complex_conditional"] / max(means["stale"], 1e-12)
        )
        large_latest.append(
            means["large_scale"] / max(means["latest"], 1e-12)
        )
        conditional_mae_better.append(
            np.mean([row["complex_conditional_mae_db"] for row in seed_rows])
            < np.mean([row["stale_mae_db"] for row in seed_rows])
        )
    return {
        "num_snapshots": len(rows),
        "num_seeds": len(by_seed),
        "stale_to_latest": _mean_ci(stale_latest),
        "complex_conditional_to_latest": _mean_ci(conditional_latest),
        "complex_conditional_to_stale": {
            **_mean_ci(conditional_stale),
            "strict_seed_win_fraction": float(
                np.mean(np.asarray(conditional_stale) > 1.0 + 1e-9)
            ),
        },
        "large_scale_to_latest": _mean_ci(large_latest),
        "mean_stale_mae_db": float(np.mean([row["stale_mae_db"] for row in rows])),
        "mean_complex_conditional_mae_db": float(np.mean([
            row["complex_conditional_mae_db"] for row in rows
        ])),
        "complex_mae_seed_win_fraction": float(np.mean(conditional_mae_better)),
        "mean_stale_action_jaccard_to_latest": float(np.mean([
            row["stale_jaccard_to_latest"] for row in rows
        ])),
        "mean_complex_action_jaccard_to_latest": float(np.mean([
            row["complex_conditional_jaccard_to_latest"] for row in rows
        ])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--num_slots", type=int, default=100)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--rician_k_db", default="5,10")
    parser.add_argument("--speed_mps", default="2,5")
    parser.add_argument("--stale_blocks", default="1,2,4")
    parser.add_argument("--seeds", default="42,43,44")
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument("--minimum_stale_loss", type=float, default=0.08)
    parser.add_argument("--minimum_predictor_gain", type=float, default=0.05)
    parser.add_argument("--minimum_seed_win_fraction", type=float, default=1.0)
    parser.add_argument(
        "--output",
        default=(
            "results/formal/complex_csi_prediction_gate_"
            "N20_rician_20260718.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("Formal gate is frozen to N=20 and 10 dBm")
    k_values = _parse_floats(args.rician_k_db)
    speeds = _parse_floats(args.speed_mps)
    ages = _parse_ints(args.stale_blocks)
    seeds = _parse_ints(args.seeds)
    if min(ages) < 1:
        raise ValueError("all stale_blocks values must be positive")
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
    })
    records = []
    for k_db in k_values:
        config["RICIAN_K_DB"] = k_db
        net_gen = build_network_generator(config)
        for speed in speeds:
            for seed in seeds:
                trace = generate_mobile_block_fading_trace(
                    net_gen,
                    num_slots=args.num_slots,
                    slots_per_block=args.slots_per_block,
                    slot_duration=0.001,
                    speed_mps=speed,
                    seed=seed,
                    quantization_bits=(4,),
                    rician_k_db=k_db,
                )
                for block_index in range(max(ages), len(trace.blocks)):
                    true_state, true_ids = build_true_network_state(
                        net_gen, trace, block_index
                    )
                    large_state, large_ids = build_observed_network_state(
                        net_gen, trace, block_index, "large_scale", 4
                    )
                    if not torch.equal(true_ids, large_ids):
                        raise RuntimeError("latest/large-scale IDs diverged")
                    for profile_index, profile in enumerate(PROFILES):
                        queues = queue_snapshot(
                            true_state.num_vertices,
                            seed * 1_000_003 + block_index * 101
                            + profile_index * 10_000,
                            profile,
                        )
                        scheduler = DirectLinkMarginalMP(rounds=args.rounds)
                        latest_action = scheduler.schedule_with_state(
                            true_state, queues
                        )
                        large_action = scheduler.schedule_with_state(
                            large_state, queues
                        )
                        latest_utility = float(mws_objective(
                            latest_action, queues, true_state
                        ))
                        large_utility = float(mws_objective(
                            large_action, queues, true_state
                        ))
                        for age in ages:
                            stale_state, stale_ids = build_observed_network_state(
                                net_gen, trace, block_index, "stale", 4,
                                stale_blocks=age,
                            )
                            conditional_power = conditional_expected_power(
                                net_gen, trace, block_index, age
                            )
                            conditional_state, conditional_ids = (
                                build_network_state_from_power(
                                    net_gen, trace, block_index,
                                    conditional_power,
                                    csi_label=f"complex_conditional_age{age}",
                                )
                            )
                            if not (
                                torch.equal(true_ids, stale_ids)
                                and torch.equal(true_ids, conditional_ids)
                            ):
                                raise RuntimeError("persistent IDs diverged")
                            stale_action = scheduler.schedule_with_state(
                                stale_state, queues
                            )
                            conditional_action = scheduler.schedule_with_state(
                                conditional_state, queues
                            )
                            records.append({
                                "rician_k_db": k_db,
                                "speed_mps": speed,
                                "seed": seed,
                                "block_index": block_index,
                                "stale_blocks": age,
                                "csi_age_ms": age * args.slots_per_block,
                                "profile": profile,
                                "num_links": int(true_state.num_vertices),
                                "latest_utility": latest_utility,
                                "large_scale_utility": large_utility,
                                "stale_utility": float(mws_objective(
                                    stale_action, queues, true_state
                                )),
                                "complex_conditional_utility": float(mws_objective(
                                    conditional_action, queues, true_state
                                )),
                                "stale_mae_db": _power_mae_db(
                                    trace.blocks[block_index - age].true_power,
                                    trace.blocks[block_index].true_power,
                                ),
                                "complex_conditional_mae_db": _power_mae_db(
                                    conditional_power,
                                    trace.blocks[block_index].true_power,
                                ),
                                "stale_jaccard_to_latest": _jaccard(
                                    stale_action, latest_action
                                ),
                                "complex_conditional_jaccard_to_latest": _jaccard(
                                    conditional_action, latest_action
                                ),
                            })
                print(f"completed K={k_db:g} speed={speed:g} seed={seed}")

    summary = {
        f"K={k_db:g}": {
            f"v={speed:g}": {
                f"age={age}": {
                    profile: _aggregate(
                        records, k_db, speed, age, profile
                    )
                    for profile in PROFILES
                }
                for age in ages
            }
            for speed in speeds
        }
        for k_db in k_values
    }
    gates = []
    for k_db in k_values:
        for speed in speeds:
            for age in ages:
                for profile in PROFILES:
                    cell = summary[f"K={k_db:g}"][f"v={speed:g}"][
                        f"age={age}"
                    ][profile]
                    stale_loss = 1.0 - cell["stale_to_latest"]["mean"]
                    gain = cell["complex_conditional_to_stale"]["mean"] - 1.0
                    passed = bool(
                        stale_loss >= args.minimum_stale_loss
                        and gain >= args.minimum_predictor_gain
                        and cell["complex_conditional_to_stale"][
                            "strict_seed_win_fraction"
                        ] >= args.minimum_seed_win_fraction
                        and cell["complex_mae_seed_win_fraction"]
                        >= args.minimum_seed_win_fraction
                    )
                    gates.append({
                        "cell": (
                            f"K={k_db:g}/v={speed:g}/age={age}/{profile}"
                        ),
                        "stale_loss": stale_loss,
                        "complex_gain_over_stale": gain,
                        "utility_seed_win_fraction": cell[
                            "complex_conditional_to_stale"
                        ]["strict_seed_win_fraction"],
                        "mae_seed_win_fraction": cell[
                            "complex_mae_seed_win_fraction"
                        ],
                        "passed": passed,
                    })
    passing = [item["cell"] for item in gates if item["passed"]]
    payload = {
        "experiment": "complex_csi_prediction_final_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definitions": {
            "motion": "constant velocity with boundary reflection",
            "physical_block_ms": args.slots_per_block,
            "csi_age_ms": "stale_blocks times physical_block_ms",
            "complex_conditional": (
                "conditional expected current power from aged complex CSI, "
                "current geometry, known Rician K, and known GM rho"
            ),
            "settlement": "all actions evaluated on current true CSI",
        },
        "summary": summary,
        "gates": gates,
        "passing_cells": passing,
        "decision": (
            "PROCEED_TO_MINIMAL_COMPLEX_LINK_GRU"
            if passing else "STOP_COMPLEX_CSI_PREDICTION_LINE"
        ),
        "records": records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "passing_cells": passing,
        "decision": payload["decision"],
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
