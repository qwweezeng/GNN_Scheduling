#!/usr/bin/env python3
"""No-training CSI headroom map for Direct-Link MarginalMP.

The diagnostic keeps persistent link identity and evaluates every final action
on current true CSI.  It separates imperfect-CSI damage in the initializer
from damage in the K-round marginal refinement, and measures a Zhao-style
oracle that only filters observed-positive toggle proposals whose true
marginal is negative.  No learned model is involved.
"""

import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import queue_snapshot  # noqa: E402
from models.initial_schedule_construction import DirectLinkLocalMaxScheduler  # noqa: E402
from models.local_physical_reuse import select_local_positive_maxima  # noqa: E402
from models.marginal_mp import exact_link_toggle_marginals  # noqa: E402
from simulator.mobile_block_fading import (  # noqa: E402
    build_observed_network_state,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import build_network_generator, load_config  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


MODES = ("stale", "large_scale", "quantized")
PROFILES = ("heterogeneous", "saturated")
VARIANTS = (
    "observed_observed",
    "true_init_observed_marginal",
    "observed_init_true_marginal",
    "true_sign_filter",
    "true_true",
)


def _parse_ints(text):
    return [int(item) for item in str(text).split(",") if item.strip()]


def _run_hybrid(
    init_state,
    marginal_state,
    queues,
    rounds,
    observed_state=None,
    true_state=None,
    true_sign_filter=False,
):
    initializer = DirectLinkLocalMaxScheduler()
    action = initializer.schedule_with_state(
        init_state, queues
    ).reshape(-1).round().bool().cpu()
    diagnostics = {
        "observed_positive": 0,
        "observed_false_positive": 0,
        "observed_false_negative": 0,
        "selected_toggles": 0,
        "selected_true_negative": 0,
        "selected_jaccard_to_true": [],
        "executed_rounds": 0,
    }
    for _ in range(int(rounds)):
        marginals = exact_link_toggle_marginals(
            marginal_state, queues, action
        )
        valid = torch.isfinite(marginals) & (marginals > 1e-6)

        observed_marginals = true_marginals = None
        if observed_state is not None and true_state is not None:
            observed_marginals = exact_link_toggle_marginals(
                observed_state, queues, action
            )
            true_marginals = exact_link_toggle_marginals(
                true_state, queues, action
            )
            finite = torch.isfinite(observed_marginals) & torch.isfinite(true_marginals)
            observed_positive = finite & (observed_marginals > 1e-6)
            true_positive = finite & (true_marginals > 1e-6)
            diagnostics["observed_positive"] += int(observed_positive.sum())
            diagnostics["observed_false_positive"] += int(
                (observed_positive & ~true_positive).sum()
            )
            diagnostics["observed_false_negative"] += int(
                (~observed_positive & true_positive).sum()
            )
            if true_sign_filter:
                valid &= true_positive

        selected = select_local_positive_maxima(
            marginals, valid, marginal_state.edge_index
        )
        diagnostics["executed_rounds"] += 1
        diagnostics["selected_toggles"] += int(selected.sum())
        if true_marginals is not None:
            diagnostics["selected_true_negative"] += int(
                (selected & (true_marginals <= 1e-6)).sum()
            )
            true_selected = select_local_positive_maxima(
                true_marginals,
                torch.isfinite(true_marginals) & (true_marginals > 1e-6),
                true_state.edge_index,
            )
            union = selected | true_selected
            jaccard = (
                float((selected & true_selected).sum() / union.sum())
                if bool(union.any()) else 1.0
            )
            diagnostics["selected_jaccard_to_true"].append(jaccard)
        if not bool(selected.any()):
            break
        action = torch.logical_xor(action, selected.cpu())
    diagnostics["selected_jaccard_to_true"] = (
        float(np.mean(diagnostics["selected_jaccard_to_true"]))
        if diagnostics["selected_jaccard_to_true"] else 1.0
    )
    return action.float().unsqueeze(1), diagnostics


def _mean_ci(values):
    values = np.asarray(values, dtype=np.float64)
    return {
        "mean": float(values.mean()),
        "ci95": float(1.96 * values.std(ddof=1) / np.sqrt(len(values)))
        if len(values) > 1 else 0.0,
    }


def _summarize(records, mode, profile, variant):
    rows = [
        row for row in records
        if row["mode"] == mode
        and row["profile"] == profile
        and row["variant"] == variant
    ]
    by_seed = defaultdict(list)
    for row in rows:
        by_seed[row["seed"]].append(row)
    seed_ratios_true = []
    seed_ratios_observed = []
    for seed_rows in by_seed.values():
        utility = np.mean([row["true_utility"] for row in seed_rows])
        true_ref = np.mean([row["true_true_utility"] for row in seed_rows])
        observed_ref = np.mean([
            row["observed_observed_utility"] for row in seed_rows
        ])
        seed_ratios_true.append(utility / max(true_ref, 1e-12))
        seed_ratios_observed.append(utility / max(observed_ref, 1e-12))
    ratio_true = _mean_ci(seed_ratios_true)
    ratio_observed = _mean_ci(seed_ratios_observed)
    ratio_observed["strict_win_fraction"] = float(np.mean(
        np.asarray(seed_ratios_observed) > 1.0 + 1e-9
    ))
    output = {
        "num_snapshots": len(rows),
        "num_seeds": len(by_seed),
        "ratio_to_true_true": ratio_true,
        "ratio_to_observed_observed": ratio_observed,
        "mean_active_links": float(np.mean([row["active_links"] for row in rows])),
    }
    if variant in {"observed_observed", "true_sign_filter"}:
        positive = sum(row["observed_positive"] for row in rows)
        selected = sum(row["selected_toggles"] for row in rows)
        output.update({
            "observed_false_positive_fraction": float(
                sum(row["observed_false_positive"] for row in rows)
                / max(positive, 1)
            ),
            "selected_true_negative_fraction": float(
                sum(row["selected_true_negative"] for row in rows)
                / max(selected, 1)
            ),
            "mean_selected_jaccard_to_true": float(np.mean([
                row["selected_jaccard_to_true"] for row in rows
            ])),
        })
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_slots", type=int, default=60)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument("--seeds", default="42,43,44,45,46")
    parser.add_argument("--q_bits", type=int, default=4)
    parser.add_argument("--minimum_loss", type=float, default=0.05)
    parser.add_argument("--minimum_gain", type=float, default=0.05)
    parser.add_argument("--minimum_seed_win_fraction", type=float, default=0.80)
    parser.add_argument(
        "--output",
        default=(
            "results/formal/marginal_mp_mobile_csi_headroom_"
            "N20_rician_20260718.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("Formal headroom gate is frozen to N=20 and 10 dBm")

    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    net_gen = build_network_generator(config)
    records = []
    for seed in _parse_ints(args.seeds):
        trace = generate_mobile_block_fading_trace(
            net_gen,
            num_slots=args.num_slots,
            slots_per_block=args.slots_per_block,
            slot_duration=0.001,
            speed_mps=args.speed_mps,
            seed=seed,
            quantization_bits=(args.q_bits,),
            rician_k_db=args.rician_k_db,
        )
        for block_index in range(1, len(trace.blocks)):
            true_state, true_ids = build_true_network_state(
                net_gen, trace, block_index
            )
            for profile_index, profile in enumerate(PROFILES):
                queues = queue_snapshot(
                    true_state.num_vertices,
                    seed * 1_000_003 + block_index * 101 + profile_index * 10_000,
                    profile,
                )
                for mode in MODES:
                    observed_state, observed_ids = build_observed_network_state(
                        net_gen, trace, block_index, mode, args.q_bits
                    )
                    if not torch.equal(true_ids, observed_ids):
                        raise RuntimeError("Observed/true persistent IDs diverged")
                    actions = {}
                    diagnostics = {}
                    actions["observed_observed"], diagnostics["observed_observed"] = _run_hybrid(
                        observed_state, observed_state, queues, args.rounds,
                        observed_state=observed_state, true_state=true_state,
                    )
                    actions["true_init_observed_marginal"], diagnostics[
                        "true_init_observed_marginal"
                    ] = _run_hybrid(
                        true_state, observed_state, queues, args.rounds,
                    )
                    actions["observed_init_true_marginal"], diagnostics[
                        "observed_init_true_marginal"
                    ] = _run_hybrid(
                        observed_state, true_state, queues, args.rounds,
                    )
                    actions["true_sign_filter"], diagnostics["true_sign_filter"] = _run_hybrid(
                        observed_state, observed_state, queues, args.rounds,
                        observed_state=observed_state, true_state=true_state,
                        true_sign_filter=True,
                    )
                    actions["true_true"], diagnostics["true_true"] = _run_hybrid(
                        true_state, true_state, queues, args.rounds,
                    )
                    utilities = {
                        variant: float(mws_objective(action, queues, true_state))
                        for variant, action in actions.items()
                    }
                    for variant in VARIANTS:
                        diag = diagnostics[variant]
                        records.append({
                            "seed": seed,
                            "block_index": block_index,
                            "mode": mode,
                            "profile": profile,
                            "variant": variant,
                            "num_links": int(true_state.num_vertices),
                            "true_utility": utilities[variant],
                            "true_true_utility": utilities["true_true"],
                            "observed_observed_utility": utilities[
                                "observed_observed"
                            ],
                            "active_links": int(actions[variant].sum()),
                            **diag,
                        })
        print(f"completed seed={seed}")

    summary = {
        mode: {
            profile: {
                variant: _summarize(records, mode, profile, variant)
                for variant in VARIANTS
            }
            for profile in PROFILES
        }
        for mode in MODES
    }
    gates = {}
    for mode in MODES:
        gates[mode] = {}
        for profile in PROFILES:
            cell = summary[mode][profile]
            observed_ratio = cell["observed_observed"][
                "ratio_to_true_true"
            ]["mean"]
            gates[mode][profile] = {
                "material_observed_loss": observed_ratio <= 1.0 - args.minimum_loss,
                "true_initializer_pass": bool(
                    cell["true_init_observed_marginal"][
                        "ratio_to_observed_observed"
                    ]["mean"] >= 1.0 + args.minimum_gain
                    and cell["true_init_observed_marginal"][
                        "ratio_to_observed_observed"
                    ]["strict_win_fraction"] >= args.minimum_seed_win_fraction
                ),
                "true_marginal_pass": bool(
                    cell["observed_init_true_marginal"][
                        "ratio_to_observed_observed"
                    ]["mean"] >= 1.0 + args.minimum_gain
                    and cell["observed_init_true_marginal"][
                        "ratio_to_observed_observed"
                    ]["strict_win_fraction"] >= args.minimum_seed_win_fraction
                ),
                "true_sign_filter_pass": bool(
                    cell["true_sign_filter"][
                        "ratio_to_observed_observed"
                    ]["mean"] >= 1.0 + args.minimum_gain
                    and cell["true_sign_filter"][
                        "ratio_to_observed_observed"
                    ]["strict_win_fraction"] >= args.minimum_seed_win_fraction
                ),
            }
    sign_filter_cells = [
        f"{mode}/{profile}"
        for mode in MODES for profile in PROFILES
        if gates[mode][profile]["material_observed_loss"]
        and gates[mode][profile]["true_sign_filter_pass"]
    ]
    marginal_cells = [
        f"{mode}/{profile}"
        for mode in MODES for profile in PROFILES
        if gates[mode][profile]["material_observed_loss"]
        and gates[mode][profile]["true_marginal_pass"]
    ]
    payload = {
        "experiment": "marginal_mp_mobile_csi_headroom_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "method_names": {
            "main": "Direct-Link MarginalMP",
            "rounds": args.rounds,
            "deprecated_names_forbidden": [
                "PurePhysicalReuse", "LocalPhysicalReuse-v2",
            ],
        },
        "definitions": {
            "observed_observed": "observed-CSI initializer and observed-CSI marginals",
            "true_init_observed_marginal": "true-CSI initializer, observed-CSI marginals",
            "observed_init_true_marginal": "observed-CSI initializer, true-CSI marginals",
            "true_sign_filter": (
                "observed marginals and ordering; oracle removes proposals "
                "whose true marginal is non-positive"
            ),
            "true_true": "true-CSI initializer and true-CSI marginals",
        },
        "summary": summary,
        "gates": gates,
        "eligible_true_sign_filter_cells": sign_filter_cells,
        "eligible_true_marginal_cells": marginal_cells,
        "decision": (
            "PROCEED_TO_MINIMAL_PROPOSAL_RELIABILITY_LEARNER"
            if sign_filter_cells
            else "STOP_PROPOSAL_RELIABILITY_LEARNER"
        ),
        "records": records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "eligible_true_sign_filter_cells": sign_filter_cells,
        "eligible_true_marginal_cells": marginal_cells,
        "decision": payload["decision"],
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
