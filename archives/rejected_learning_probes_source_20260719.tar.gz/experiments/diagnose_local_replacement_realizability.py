#!/usr/bin/env python3
"""Test whether one Pure-skeleton replacement can be selected locally.

The prior headroom oracle showed that replacing one Pure LocalMax winner set
can materially improve the final two-stage action.  This no-training probe asks
whether interpretable local quantities can identify the useful challenger.

Nothing in this file is a trained model.  The exact-best candidate and the
global base-delta score are centralized references.  The local scores restrict
their objective comparison to changed links and their one-hop conflict
neighborhoods.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    conflict_neighbors,
    queue_snapshot,
)
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
    local_edge_gains,
)
from models.model import calculate_achievable_rate  # noqa: E402
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


PROXY_METHODS = (
    "solo_exchange",
    "global_base_delta_reference",
    "local_base_delta",
    "local_final_delta",
    "two_hop_final_delta",
)
LOCAL_METHODS = (
    "solo_exchange",
    "local_base_delta",
    "local_final_delta",
    "two_hop_final_delta",
)


def weighted_rates(action, queues, state):
    rates = calculate_achievable_rate(
        torch.as_tensor(action, dtype=torch.float32).reshape(-1, 1),
        state,
        binary=True,
    ).detach().cpu().reshape(-1)
    return torch.as_tensor(queues, dtype=rates.dtype).reshape(-1).cpu() * rates


def changed_scope(reference, candidate, neighbors, hops=1):
    reference = torch.as_tensor(reference).reshape(-1).round().cpu()
    candidate = torch.as_tensor(candidate).reshape(-1).round().cpu()
    changed = torch.nonzero(reference != candidate, as_tuple=True)[0].tolist()
    scope = set(changed)
    frontier = set(changed)
    for _ in range(int(hops)):
        next_frontier = set()
        for link_index in frontier:
            next_frontier.update(neighbors[int(link_index)])
        next_frontier.difference_update(scope)
        scope.update(next_frontier)
        frontier = next_frontier
        if not frontier:
            break
    return sorted(scope)


def safe_correlation(left, right):
    left = np.asarray(left, dtype=np.float64)
    right = np.asarray(right, dtype=np.float64)
    if len(left) < 2 or np.std(left) <= 1e-12 or np.std(right) <= 1e-12:
        return None
    return float(np.corrcoef(left, right)[0, 1])


def enumerate_replacements(state, queues, pure_scheduler):
    pure_base = pure_scheduler.localmax.schedule_with_state(
        state, queues
    ).reshape(-1).detach().cpu().round()
    pure_final, _, _ = complete_physical_reuse_from_base(
        state, queues, pure_base
    )
    pure_final = pure_final.reshape(-1).detach().cpu().round()
    pure_utility = float(mws_objective(pure_final, queues, state))
    pure_base_weighted_rates = weighted_rates(pure_base, queues, state)
    pure_final_weighted_rates = weighted_rates(pure_final, queues, state)

    direct, _, _, _ = local_edge_gains(state)
    noise = torch.as_tensor(state.noise_power, dtype=torch.float32).cpu()
    snr_gap = float(getattr(state, "snr_gap", 1.0))
    queues_cpu = torch.as_tensor(queues, dtype=torch.float32).reshape(-1).cpu()
    solo_weight = queues_cpu * torch.log2(1.0 + direct / noise / snr_gap)

    neighbors = conflict_neighbors(state.edge_index, state.num_vertices)
    base_active = set(torch.nonzero(pure_base > 0.5, as_tuple=True)[0].tolist())
    nonempty = queues_cpu > 0
    candidates = []
    for challenger in torch.nonzero(
        nonempty & (pure_base <= 0.5), as_tuple=True
    )[0].tolist():
        removed = sorted(base_active.intersection(neighbors[int(challenger)]))
        if not removed:
            continue
        candidate_base = pure_base.clone()
        candidate_base[torch.tensor(removed, dtype=torch.long)] = 0.0
        candidate_base[int(challenger)] = 1.0
        candidate_final, _, _ = complete_physical_reuse_from_base(
            state, queues, candidate_base
        )
        candidate_final = candidate_final.reshape(-1).detach().cpu().round()
        final_utility = float(mws_objective(candidate_final, queues, state))

        candidate_base_rates = weighted_rates(candidate_base, queues, state)
        candidate_final_rates = weighted_rates(candidate_final, queues, state)
        base_scope = changed_scope(pure_base, candidate_base, neighbors)
        final_scope = changed_scope(pure_final, candidate_final, neighbors)
        two_hop_final_scope = changed_scope(
            pure_final, candidate_final, neighbors, hops=2
        )
        base_scope_tensor = torch.tensor(base_scope, dtype=torch.long)
        final_scope_tensor = torch.tensor(final_scope, dtype=torch.long)
        two_hop_final_scope_tensor = torch.tensor(
            two_hop_final_scope, dtype=torch.long
        )

        proxy_scores = {
            "solo_exchange": float(
                solo_weight[int(challenger)]
                - solo_weight[torch.tensor(removed, dtype=torch.long)].sum()
            ),
            "global_base_delta_reference": float(
                candidate_base_rates.sum() - pure_base_weighted_rates.sum()
            ),
            "local_base_delta": float(
                (
                    candidate_base_rates[base_scope_tensor]
                    - pure_base_weighted_rates[base_scope_tensor]
                ).sum()
            ),
            "local_final_delta": float(
                (
                    candidate_final_rates[final_scope_tensor]
                    - pure_final_weighted_rates[final_scope_tensor]
                ).sum()
            ),
            "two_hop_final_delta": float(
                (
                    candidate_final_rates[two_hop_final_scope_tensor]
                    - pure_final_weighted_rates[two_hop_final_scope_tensor]
                ).sum()
            ),
        }
        candidates.append({
            "challenger": int(challenger),
            "removed_winners": removed,
            "candidate_final_active_links": int(candidate_final.sum()),
            "final_utility": final_utility,
            "exact_final_delta": final_utility - pure_utility,
            "proxy_scores": proxy_scores,
            "base_scope_size": len(base_scope),
            "final_scope_size": len(final_scope),
            "two_hop_final_scope_size": len(two_hop_final_scope),
        })
    return pure_base, pure_final, pure_utility, candidates


def choose_candidate(candidates, method, pure_utility):
    if not candidates:
        return {
            "utility": pure_utility,
            "challenger": None,
            "predicted_delta": 0.0,
            "exact_delta": 0.0,
        }
    best = max(candidates, key=lambda row: row["proxy_scores"][method])
    predicted_delta = float(best["proxy_scores"][method])
    if predicted_delta <= 0.0:
        return {
            "utility": pure_utility,
            "challenger": None,
            "predicted_delta": predicted_delta,
            "exact_delta": 0.0,
        }
    return {
        "utility": float(best["final_utility"]),
        "challenger": int(best["challenger"]),
        "predicted_delta": predicted_delta,
        "exact_delta": float(best["exact_final_delta"]),
    }


def summarize(records, method):
    ratios = np.asarray([
        row["selected"][method]["utility"] / max(abs(row["pure_utility"]), 1e-12)
        for row in records
    ])
    gains = ratios - 1.0
    return {
        "num_snapshots": len(records),
        "mean_ratio_vs_pure": float(np.mean(ratios)),
        "mean_gain_fraction_vs_pure": float(np.mean(gains)),
        "gain_ci95": float(
            1.96 * np.std(gains, ddof=1) / np.sqrt(len(gains))
        ) if len(gains) > 1 else 0.0,
        "strict_win_fraction_vs_pure": float(np.mean(gains > 1e-9)),
        "strict_loss_fraction_vs_pure": float(np.mean(gains < -1e-9)),
        "mean_oracle_recovery_fraction": float(np.mean([
            max(row["selected"][method]["utility"] - row["pure_utility"], 0.0)
            / max(row["exact_oracle_utility"] - row["pure_utility"], 1e-12)
            if row["exact_oracle_utility"] > row["pure_utility"] + 1e-9 else 1.0
            for row in records
        ])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--profiles", default="sparse,heterogeneous,saturated")
    parser.add_argument("--minimum_mean_gain_fraction", type=float, default=0.02)
    parser.add_argument("--minimum_win_fraction", type=float, default=0.70)
    parser.add_argument("--sparse_minimum_ratio", type=float, default=0.99)
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument(
        "--output",
        default=(
            "results/formal/local_replacement_realizability_"
            "N20_rician_20260716.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("The formal probe is frozen to N=20 and 10 dBm.")

    profiles = [item.strip() for item in args.profiles.split(",") if item.strip()]
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config,
        args.channel_gat_checkpoint,
        args.num_uav,
        device="cpu",
        allow_power_transfer=False,
    )
    pure = PurePhysicalReuseScheduler(channel_model)

    records = []
    candidate_proxy_values = {method: [] for method in PROXY_METHODS}
    candidate_exact_values = {method: [] for method in PROXY_METHODS}
    one_hop_scope_fractions = []
    two_hop_scope_fractions = []
    for graph_index in range(args.num_graphs):
        graph_seed = args.seed + graph_index
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            pure_base, pure_final, pure_utility, candidates = enumerate_replacements(
                state, queues, pure
            )
            exact_best = max(
                candidates,
                key=lambda row: row["final_utility"],
                default=None,
            )
            if exact_best is None or exact_best["final_utility"] <= pure_utility:
                exact_oracle_utility = pure_utility
                exact_oracle_challenger = None
            else:
                exact_oracle_utility = float(exact_best["final_utility"])
                exact_oracle_challenger = int(exact_best["challenger"])
            selected = {
                method: choose_candidate(candidates, method, pure_utility)
                for method in PROXY_METHODS
            }
            selected["exact_final_oracle"] = {
                "utility": exact_oracle_utility,
                "challenger": exact_oracle_challenger,
                "predicted_delta": exact_oracle_utility - pure_utility,
                "exact_delta": exact_oracle_utility - pure_utility,
            }
            for candidate in candidates:
                one_hop_scope_fractions.append(
                    candidate["final_scope_size"] / float(state.num_vertices)
                )
                two_hop_scope_fractions.append(
                    candidate["two_hop_final_scope_size"]
                    / float(state.num_vertices)
                )
                for method in PROXY_METHODS:
                    candidate_proxy_values[method].append(
                        candidate["proxy_scores"][method]
                    )
                    candidate_exact_values[method].append(
                        candidate["exact_final_delta"]
                    )
            record = {
                "graph_seed": graph_seed,
                "queue_profile": profile,
                "num_links": int(state.num_vertices),
                "pure_skeleton_links": int(pure_base.sum()),
                "pure_final_active_links": int(pure_final.sum()),
                "pure_utility": pure_utility,
                "num_candidate_replacements": len(candidates),
                "mean_one_hop_final_scope_fraction": float(np.mean([
                    row["final_scope_size"] / float(state.num_vertices)
                    for row in candidates
                ])) if candidates else 0.0,
                "mean_two_hop_final_scope_fraction": float(np.mean([
                    row["two_hop_final_scope_size"] / float(state.num_vertices)
                    for row in candidates
                ])) if candidates else 0.0,
                "exact_oracle_utility": exact_oracle_utility,
                "exact_oracle_challenger": exact_oracle_challenger,
                "selected": selected,
            }
            records.append(record)
            print(
                f"seed={graph_seed} profile={profile:<13} "
                f"oracle={100 * (exact_oracle_utility / pure_utility - 1):+.2f}% "
                f"solo={100 * (selected['solo_exchange']['utility'] / pure_utility - 1):+.2f}% "
                f"local_base={100 * (selected['local_base_delta']['utility'] / pure_utility - 1):+.2f}% "
                f"local_final={100 * (selected['local_final_delta']['utility'] / pure_utility - 1):+.2f}%"
                f" two_hop={100 * (selected['two_hop_final_delta']['utility'] / pure_utility - 1):+.2f}%"
            )

    methods = (*PROXY_METHODS, "exact_final_oracle")
    by_profile = {
        profile: {
            method: summarize(
                [row for row in records if row["queue_profile"] == profile],
                method,
            )
            for method in methods
        }
        for profile in profiles
    }
    overall = {method: summarize(records, method) for method in methods}
    proxy_quality = {
        method: {
            "candidate_count": len(candidate_proxy_values[method]),
            "pearson_with_exact_final_delta": safe_correlation(
                candidate_proxy_values[method], candidate_exact_values[method]
            ),
            "sign_accuracy_vs_exact_final_delta": float(np.mean(
                np.sign(candidate_proxy_values[method])
                == np.sign(candidate_exact_values[method])
            )),
        }
        for method in PROXY_METHODS
    }

    competition_profiles = [
        profile for profile in profiles
        if profile in {"heterogeneous", "saturated"}
    ]
    local_pass = {}
    for method in LOCAL_METHODS:
        competition_ok = all(
            by_profile[profile][method]["mean_gain_fraction_vs_pure"]
            >= args.minimum_mean_gain_fraction
            and by_profile[profile][method]["strict_win_fraction_vs_pure"]
            >= args.minimum_win_fraction
            and by_profile[profile][method]["strict_loss_fraction_vs_pure"] == 0.0
            for profile in competition_profiles
        )
        sparse_ok = (
            "sparse" not in by_profile
            or by_profile["sparse"][method]["mean_ratio_vs_pure"]
            >= args.sparse_minimum_ratio
        )
        local_pass[method] = bool(competition_ok and sparse_ok)
    decision = (
        "NUMERICAL_LOCAL_GATE_PASS_REQUIRES_MESSAGE_SCOPE_AUDIT"
        if any(local_pass.values())
        else "LOCAL_REPLACEMENT_PROXY_FAILS_STOP_BEFORE_TRAINING"
    )
    payload = {
        "experiment": "local_replacement_realizability_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "purpose": (
            "Test whether local, set-conditioned replacement scores recover "
            "the previously observed exact one-substitution headroom."
        ),
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "definitions": {
            "solo_exchange": (
                "Challenger Q*C_solo minus the sum for conflicting Pure winners."
            ),
            "global_base_delta_reference": (
                "Exact global sum(QR) change on the two skeletons before completion; "
                "centralized reference, not deployable."
            ),
            "local_base_delta": (
                "Skeleton sum(QR) change restricted to changed links and their "
                "one-hop conflict neighbors."
            ),
            "local_final_delta": (
                "After common reuse completion, sum(QR) change restricted to changed "
                "links and their one-hop conflict neighbors."
            ),
            "two_hop_final_delta": (
                "After common reuse completion, sum(QR) change restricted to "
                "changed links and their two-hop conflict neighborhoods."
            ),
            "exact_final_oracle": (
                "Exact best final action among all one-challenger skeleton replacements."
            ),
            "no_trained_model": True,
        },
        "predeclared_gate": {
            "required_competition_profiles": competition_profiles,
            "minimum_mean_gain_fraction": args.minimum_mean_gain_fraction,
            "minimum_strict_win_fraction": args.minimum_win_fraction,
            "no_strict_losses_allowed": True,
            "sparse_minimum_ratio": args.sparse_minimum_ratio,
            "local_method_passed": local_pass,
        },
        "proxy_quality": proxy_quality,
        "message_scope_audit": {
            "candidate_count": len(one_hop_scope_fractions),
            "one_hop_mean_fraction_of_all_links": float(
                np.mean(one_hop_scope_fractions)
            ),
            "one_hop_median_fraction_of_all_links": float(
                np.median(one_hop_scope_fractions)
            ),
            "two_hop_mean_fraction_of_all_links": float(
                np.mean(two_hop_scope_fractions)
            ),
            "two_hop_median_fraction_of_all_links": float(
                np.median(two_hop_scope_fractions)
            ),
            "two_hop_full_network_fraction": float(np.mean(
                np.asarray(two_hop_scope_fractions) >= 1.0 - 1e-12
            )),
            "interpretation_rule": (
                "A numerical local-score pass is not a deployability pass; "
                "the covered fraction and actual payload must be audited."
            ),
        },
        "overall": overall,
        "by_profile": by_profile,
        "records": records,
        "decision": decision,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "local_method_passed": local_pass,
        "decision": decision,
        "output": str(output),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
