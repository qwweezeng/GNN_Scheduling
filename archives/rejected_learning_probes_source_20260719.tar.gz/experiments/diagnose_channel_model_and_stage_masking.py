#!/usr/bin/env python3
"""Channel-only diagnosis of fading realism, GAT collapse, and stage masking."""

import argparse
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from baseline.queue_schedulers import centralized_mws_greedy
from models.local_physical_reuse import (
    GATExpectedRateLocalPhysicalReuseScheduler,
    PurePhysicalReuseScheduler,
    complete_physical_reuse_from_base,
)
from models.model import calculate_achievable_rate
from simulator.mobile_block_fading import (
    build_observed_network_state,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import (
    build_network_generator,
    load_channel_gat,
    load_config,
)


CHANNEL_SPECS = (
    ("rayleigh", None),
    ("rician_K5dB", 5.0),
    ("pure_los", float("inf")),
)
CSI_SPECS = (
    ("latest", None),
    ("stale", None),
    ("large_scale", None),
    ("quantized_4bit", 4),
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--mc_seeds", default="42,43,44,45,46")
    parser.add_argument(
        "--block_stride", type=int, default=10,
        help="Evaluate every nth block; block zero is skipped because stale equals latest.",
    )
    parser.add_argument("--output", default="")
    return parser.parse_args()


def _csv(text, cast):
    return [cast(item.strip()) for item in text.split(",") if item.strip()]


def _sum_spectral_efficiency(action, state):
    action = torch.as_tensor(action, dtype=torch.float32).reshape(-1, 1)
    return float(calculate_achievable_rate(
        action, state, binary=True
    ).sum().item())


def _interference_free_ceiling(state):
    links = state.links.detach().cpu()
    direct = state.signal_power.detach().cpu()[links[:, 0], links[:, 1]]
    return float(torch.log2(
        1.0 + direct / float(state.noise_power) / float(state.snr_gap)
    ).sum().item())


def _jaccard(left, right):
    left = torch.as_tensor(left).reshape(-1) > 0
    right = torch.as_tensor(right).reshape(-1) > 0
    union = left | right
    if not bool(union.any()):
        return 1.0
    return float(((left & right).sum() / union.sum()).item())


def _safe_ratio(numerator, denominator):
    return float(numerator / denominator) if denominator > 1e-12 else None


def _mean_ci(values):
    values = np.asarray([v for v in values if v is not None], dtype=float)
    if values.size == 0:
        return {"mean": None, "ci95": None, "count": 0}
    ci = (
        1.96 * float(values.std(ddof=1)) / np.sqrt(values.size)
        if values.size > 1 else 0.0
    )
    return {
        "mean": float(values.mean()),
        "ci95": float(ci),
        "count": int(values.size),
    }


def _aggregate(rows):
    keys = sorted({key for row in rows for key in row if key not in {
        "seed", "block_index", "channel_model", "csi_mode"
    }})
    return {key: _mean_ci([row.get(key) for row in rows]) for key in keys}


def _correlation(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.size < 2 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return None
    return float(np.corrcoef(x, y)[0, 1])


def _db(power):
    return 10.0 * torch.log10(torch.as_tensor(power).clamp_min(1e-30))


def _predictability_summary(samples):
    current = np.concatenate([item["current_db"] for item in samples])
    stale = np.concatenate([item["stale_db"] for item in samples])
    large = np.concatenate([item["large_db"] for item in samples])
    return {
        "num_link_block_samples": int(current.size),
        "current_vs_stale_pearson_db": _correlation(current, stale),
        "current_vs_large_scale_pearson_db": _correlation(current, large),
        "stale_mean_absolute_error_db": float(np.mean(np.abs(current - stale))),
        "large_scale_mean_absolute_error_db": float(
            np.mean(np.abs(current - large))
        ),
        "current_power_db_std": float(np.std(current)),
        "innovation_db_std_current_minus_stale": float(np.std(current - stale)),
    }


def _prior(model, state):
    with torch.no_grad():
        logits, _ = model.schedule_logits(
            state.vertex_features[:, :1], state.edge_index, state.edge_weights
        )
        probabilities = torch.sigmoid(logits.reshape(-1))
    action = probabilities >= float(getattr(model, "decision_threshold", 0.5))
    return probabilities.cpu(), action.float().cpu()


def _channel_snapshot_rows(
    net_gen, model, trace, seed, block_index, channel_label
):
    true_state, true_indices = build_true_network_state(
        net_gen, trace, block_index
    )
    queues = torch.ones(true_state.num_vertices)
    true_greedy_action = centralized_mws_greedy(true_state, queues)
    true_greedy_se = _sum_spectral_efficiency(true_greedy_action, true_state)
    ceiling = _interference_free_ceiling(true_state)
    all_active_se = _sum_spectral_efficiency(
        torch.ones(true_state.num_vertices), true_state
    )

    modes = {}
    for mode_label, bits in CSI_SPECS:
        mode = "quantized" if bits else mode_label
        observed_state, observed_indices = build_observed_network_state(
            net_gen, trace, block_index, mode, bits or 4
        )
        if not torch.equal(observed_indices, true_indices):
            raise RuntimeError("Channel-only diagnosis lost persistent-link alignment")
        probabilities, gat_binary = _prior(model, observed_state)
        observed_greedy = centralized_mws_greedy(observed_state, queues)

        gat_scheduler = GATExpectedRateLocalPhysicalReuseScheduler(model)
        gat_skeleton = gat_scheduler.localmax.schedule_with_state(
            observed_state, queues
        ).reshape(-1)
        gat_final, _, gat_joiners = complete_physical_reuse_from_base(
            observed_state, queues, gat_skeleton
        )
        gat_final = gat_final.reshape(-1)

        pure_scheduler = PurePhysicalReuseScheduler(model)
        pure_skeleton = pure_scheduler.localmax.schedule_with_state(
            observed_state, queues
        ).reshape(-1)
        pure_final, _, pure_joiners = complete_physical_reuse_from_base(
            observed_state, queues, pure_skeleton
        )
        pure_final = pure_final.reshape(-1)

        modes[mode_label] = {
            "state": observed_state,
            "observed_greedy": observed_greedy.reshape(-1),
            "probabilities": probabilities,
            "gat_binary": gat_binary,
            "gat_skeleton": gat_skeleton,
            "gat_final": gat_final,
            "gat_joiners": gat_joiners,
            "pure_skeleton": pure_skeleton,
            "pure_final": pure_final,
            "pure_joiners": pure_joiners,
        }

    latest = modes["latest"]
    reference_final_se = _sum_spectral_efficiency(
        latest["gat_final"], true_state
    )
    rows = []
    for mode_label, _ in CSI_SPECS:
        item = modes[mode_label]
        state = item["state"]
        observed_skeleton_true_join, _, _ = complete_physical_reuse_from_base(
            true_state, queues, item["gat_skeleton"]
        )
        latest_skeleton_observed_join, _, _ = complete_physical_reuse_from_base(
            state, queues, latest["gat_skeleton"]
        )

        gat_skeleton_se = _sum_spectral_efficiency(
            item["gat_skeleton"], true_state
        )
        gat_final_se = _sum_spectral_efficiency(item["gat_final"], true_state)
        pure_skeleton_se = _sum_spectral_efficiency(
            item["pure_skeleton"], true_state
        )
        pure_final_se = _sum_spectral_efficiency(item["pure_final"], true_state)
        probabilities = item["probabilities"]
        rows.append({
            "seed": int(seed),
            "block_index": int(block_index),
            "channel_model": channel_label,
            "csi_mode": mode_label,
            "num_links": int(true_state.num_vertices),
            "interference_free_shannon_ceiling_se": ceiling,
            "true_csi_centralized_greedy_se": true_greedy_se,
            "true_csi_greedy_ratio_to_ceiling": _safe_ratio(
                true_greedy_se, ceiling
            ),
            "observed_csi_centralized_greedy_true_settled_se": (
                _sum_spectral_efficiency(item["observed_greedy"], true_state)
            ),
            "conference_gat_binary_true_settled_se": _sum_spectral_efficiency(
                item["gat_binary"], true_state
            ),
            "all_active_true_se": all_active_se,
            "gat_prior_mean": float(probabilities.mean().item()),
            "gat_prior_std_across_links": float(
                probabilities.std(unbiased=False).item()
            ),
            "gat_prior_min": float(probabilities.min().item()),
            "gat_prior_max": float(probabilities.max().item()),
            "gat_binary_active_fraction": float(
                item["gat_binary"].float().mean().item()
            ),
            "gat_binary_is_all_active": float(
                bool((item["gat_binary"] > 0).all())
            ),
            "gat_skeleton_active_links": float(item["gat_skeleton"].sum().item()),
            "gat_final_active_links": float(item["gat_final"].sum().item()),
            "gat_joined_links": float(item["gat_joiners"].sum().item()),
            "gat_skeleton_true_se": gat_skeleton_se,
            "gat_final_true_se": gat_final_se,
            "gat_final_gain_over_skeleton_se": gat_final_se - gat_skeleton_se,
            "gat_skeleton_share_of_final_se": _safe_ratio(
                gat_skeleton_se, gat_final_se
            ),
            "pure_skeleton_true_se": pure_skeleton_se,
            "pure_final_true_se": pure_final_se,
            "pure_final_gain_over_skeleton_se": pure_final_se - pure_skeleton_se,
            "gat_skeleton_jaccard_to_latest": _jaccard(
                item["gat_skeleton"], latest["gat_skeleton"]
            ),
            "gat_final_jaccard_to_latest": _jaccard(
                item["gat_final"], latest["gat_final"]
            ),
            "actual_final_ratio_to_latest_final": _safe_ratio(
                gat_final_se, reference_final_se
            ),
            "observed_skeleton_true_join_ratio_to_latest_final": _safe_ratio(
                _sum_spectral_efficiency(
                    observed_skeleton_true_join, true_state
                ),
                reference_final_se,
            ),
            "latest_skeleton_observed_join_ratio_to_latest_final": _safe_ratio(
                _sum_spectral_efficiency(
                    latest_skeleton_observed_join, true_state
                ),
                reference_final_se,
            ),
        })
    return rows


def main():
    args = parse_args()
    if args.block_stride < 1:
        raise ValueError("block_stride must be >= 1")
    seeds = _csv(args.mc_seeds, int)
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({"NUM_UAV": args.num_uav, "TX_POWER": 10.0, "CSI_MODE": "perfect"})
    net_gen = build_network_generator(cfg)
    model, checkpoint = load_channel_gat(cfg, args.num_uav, device="cpu")
    model.eval()

    rows = []
    predictability = {label: [] for label, _ in CHANNEL_SPECS}
    for channel_label, k_db in CHANNEL_SPECS:
        for seed in seeds:
            trace = generate_mobile_block_fading_trace(
                net_gen,
                num_slots=args.num_slots,
                slots_per_block=args.slots_per_block,
                slot_duration=cfg.get("SLOT_DURATION", 0.001),
                speed_mps=args.speed_mps,
                seed=seed,
                quantization_bits=(4,),
                rician_k_db=k_db,
            )
            block_indices = range(1, len(trace.blocks), args.block_stride)
            for block_index in block_indices:
                block = trace.blocks[block_index]
                previous = trace.blocks[block_index - 1]
                available = torch.where(block.available)[0]
                links = trace.links[available]
                tx, rx = links[:, 0], links[:, 1]
                predictability[channel_label].append({
                    "current_db": _db(block.true_power[tx, rx]).numpy(),
                    "stale_db": _db(previous.true_power[tx, rx]).numpy(),
                    "large_db": _db(block.large_scale_power[tx, rx]).numpy(),
                })
                rows.extend(_channel_snapshot_rows(
                    net_gen, model, trace, seed, block_index, channel_label
                ))
                print(
                    f"channel={channel_label:<14} seed={seed} "
                    f"block={block_index} rows={len(rows)}"
                )

    summaries = {}
    for channel_label, _ in CHANNEL_SPECS:
        summaries[channel_label] = {}
        for mode_label, _ in CSI_SPECS:
            selected = [
                row for row in rows
                if row["channel_model"] == channel_label
                and row["csi_mode"] == mode_label
            ]
            summaries[channel_label][mode_label] = _aggregate(selected)

    report = {
        "experiment": "channel_model_and_stage_masking_diagnosis_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "purpose": (
            "Separate channel predictability, conference-GAT prior behavior, "
            "LocalMax skeleton sensitivity, and conditional-reuse sensitivity "
            "before interpreting queue-level robustness."
        ),
        "settings": vars(args),
        "channel_models": {
            "rayleigh": "Historical h=a*g, g~CN(0,1), no deterministic LoS.",
            "rician_K5dB": (
                "Normalized LoS plus correlated diffuse component, K=5 dB."
            ),
            "pure_los": (
                "Deterministic unit-magnitude LoS phasor; received power equals "
                "large-scale path-loss power. Sensitivity boundary, not a full "
                "wideband UAV channel model."
            ),
        },
        "reference_boundaries": {
            "interference_free_shannon_ceiling": (
                "Strict but loose mathematical ceiling: sum of every link's solo "
                "Shannon spectral efficiency with all mutual interference removed."
            ),
            "true_csi_centralized_greedy": (
                "Achievable full-information add/delete greedy reference; not an "
                "exact optimum or mathematical upper bound."
            ),
        },
        "base_checkpoint": checkpoint,
        "predictability": {
            label: _predictability_summary(items)
            for label, items in predictability.items()
        },
        "summaries": summaries,
        "raw_rows": rows,
    }
    output = args.output or (
        "results/diagnostics/channel_model_and_stage_masking_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    os.makedirs(os.path.dirname(output), exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "output": output,
        "predictability": report["predictability"],
        "num_rows": len(rows),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
