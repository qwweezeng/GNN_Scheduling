#!/usr/bin/env python3
"""Evaluate CSI-augmented Spatial GAT against saved Frozen-GAT/Pure pairs."""

import argparse
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.evaluate_mobile_block_fading_csi import (
    _aggregate,
    _number_key,
    _paired_comparison,
)
from models.local_physical_reuse import (
    GATExpectedRateLocalPhysicalReuseScheduler,
)
from simulator.mobile_block_fading import (
    build_observed_network_state,
    generate_mobile_block_fading_trace,
    message_overhead_audit,
    run_mobile_queue_simulation,
)
from utils.fixed_csi_benchmark import (
    arrival_trace_seed,
    generate_hotspot_arrivals,
)
from utils.project_setup import (
    build_gat_scheduler,
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)


MODES = (
    ("latest", None),
    ("stale", None),
    ("large_scale", None),
    ("quantized", 4),
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--model",
        default=(
            "results/formal/csi_augmented_spatial_gate_N20_rician_20260716/"
            "model.pth"
        ),
    )
    parser.add_argument(
        "--base_report",
        default=(
            "results/formal/"
            "mobile_csi_high_load_valid_gat_vs_pure_N20_rician_20260716.json"
        ),
    )
    parser.add_argument(
        "--base_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--arrival_rates", default="2.2,4")
    parser.add_argument("--mc_seeds", default="42,43,44,45,46")
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--output", default="")
    return parser.parse_args()


def _csv(text, cast):
    return [cast(item.strip()) for item in text.split(",") if item.strip()]


def _load_model(path, cfg):
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if checkpoint.get("model_version") not in {
        "channel_gat_csi_augmented_spatial_v1",
        "channel_gat_csi_augmented_spatial_teacher_v2",
    }:
        raise ValueError(f"Unexpected augmented model metadata: {path}")
    model = build_gat_scheduler(cfg, raw_node_dim=1)
    model.load_state_dict(checkpoint["model_state_dict"])
    return model.eval(), checkpoint


def _output_diagnostic(model, state):
    with torch.no_grad():
        logits, _ = model.schedule_logits(
            state.vertex_features[:, :1], state.edge_index, state.edge_weights
        )
        probabilities = torch.sigmoid(logits.reshape(-1))
    return {
        "num_links": int(probabilities.numel()),
        "probability_mean": float(probabilities.mean().item()),
        "probability_std": float(probabilities.std(unbiased=False).item()),
        "probability_min": float(probabilities.min().item()),
        "probability_max": float(probabilities.max().item()),
        "logit_mean": float(logits.mean().item()),
    }


def _reference_runs(base_report, scenario_key, load_key, method, mode_label, seeds):
    return [
        base_report["run_details"][
            f"{scenario_key}|{load_key}|{method}|{mode_label}|seed={seed}"
        ]
        for seed in seeds
    ]


def _candidate_gate(comparisons, output_is_input_insensitive=False):
    passing = []
    for load_key, modes in comparisons.items():
        for mode, references in modes.items():
            if mode == "latest":
                continue
            if (
                references["vs_Frozen-GAT"]["directional_gate_passed"]
                and references["vs_Pure"]["directional_gate_passed"]
            ):
                passing.append(f"{load_key}|{mode}")
    performance_passed = bool(passing)
    representation_valid = not bool(output_is_input_insensitive)
    return {
        "criterion": (
            "CSI-Augmented-GAT must achieve >=4/5 joint delivered/backlog "
            "wins against both Frozen-GAT and Pure in the same imperfect condition"
        ),
        "performance_passing_conditions": passing,
        "performance_gate_passed": performance_passed,
        "representation_is_csi_sensitive": representation_valid,
        "csi_augmented_spatial_gate_passed": bool(
            performance_passed and representation_valid
        ),
        "next_step": (
            "Use CSI-Augmented-GAT as the spatial baseline for the predefined "
            "Temporal-Residual GAT."
            if performance_passed and representation_valid else
            (
                "Record the input-insensitive representation collapse; do not "
                "treat its queue metric as learned CSI resilience."
                if not representation_valid else
                "Record that CSI-sensitive single-frame retraining did not pass "
                "the paired queue gate, then test whether the minimal temporal "
                "state supplies the missing information."
            )
        ),
    }


def main():
    args = parse_args()
    cfg = load_config("configs/exp_example.yaml")
    cfg.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    net_gen = build_network_generator(cfg)
    model, checkpoint = _load_model(args.model, cfg)
    frozen_model, _ = load_channel_gat_checkpoint(
        cfg, args.base_checkpoint, args.num_uav, device="cpu"
    )
    with open(args.base_report, "r", encoding="utf-8") as file:
        base_report = json.load(file)
    seeds = _csv(args.mc_seeds, int)
    arrival_rates = _csv(args.arrival_rates, float)
    scenario_key = f"v={args.speed_mps:g}mps_Tc={args.slots_per_block}slots"

    raw = {
        f"Lambda={_number_key(rate)}": {
            (f"{mode}_{bits}bit" if bits else mode): []
            for mode, bits in MODES
        }
        for rate in arrival_rates
    }
    diagnostics = {}
    run_details = {}
    for seed in seeds:
        trace = generate_mobile_block_fading_trace(
            net_gen,
            num_slots=args.num_slots,
            slots_per_block=args.slots_per_block,
            slot_duration=cfg.get("SLOT_DURATION", 0.001),
            speed_mps=args.speed_mps,
            seed=seed,
            quantization_bits=(4,),
            rician_k_db=args.rician_k_db,
        )
        for mode, bits in MODES:
            label = f"{mode}_{bits}bit" if bits else mode
            state, _ = build_observed_network_state(
                net_gen, trace, 1, mode, bits or 4
            )
            diagnostics[f"{label}|seed={seed}"] = {
                "CSI-Augmented-GAT": _output_diagnostic(model, state),
                "Frozen-GAT": _output_diagnostic(frozen_model, state),
            }
        for rate in arrival_rates:
            load_key = f"Lambda={_number_key(rate)}"
            arrivals, _ = generate_hotspot_arrivals(
                args.num_slots,
                trace.num_links,
                rate,
                arrival_seed=arrival_trace_seed(seed, rate),
                hotspot_seed=seed,
            )
            for mode, bits in MODES:
                label = f"{mode}_{bits}bit" if bits else mode
                scheduler = GATExpectedRateLocalPhysicalReuseScheduler(model)
                metrics = run_mobile_queue_simulation(
                    net_gen, scheduler, trace, arrivals, mode, bits or 4,
                    packet_size=cfg.get("PACKET_SIZE", 12000),
                )
                metrics["mc_seed"] = seed
                metrics["scheduler"] = "CSI-Augmented-GAT"
                metrics["arrival_rate"] = rate
                metrics["overhead"] = message_overhead_audit(
                    metrics["average_available_links"],
                    metrics["average_available_transmitter_uavs"],
                    metrics["average_directed_conflict_edges"],
                    args.slots_per_block,
                    slot_duration=cfg.get("SLOT_DURATION", 0.001),
                    gat_rounds=cfg.get("NUM_GAT_LAYERS", 4),
                    hidden_dim=cfg.get("GAT_OUT_DIM", 48),
                    uses_channel_gat=True,
                )
                raw[load_key][label].append(metrics)
                run_details[f"{load_key}|{label}|seed={seed}"] = metrics
                print(
                    f"{load_key} seed={seed} {label:<15} "
                    f"goodput={metrics['delivered_throughput_mbps']:.3f} "
                    f"Q={metrics['average_queue_backlog_mbit']:.4f}"
                )

    summaries = {
        load: {mode: _aggregate(runs) for mode, runs in modes.items()}
        for load, modes in raw.items()
    }
    comparisons = {}
    for load_key, modes in raw.items():
        comparisons[load_key] = {}
        for mode_label, candidate_runs in modes.items():
            comparisons[load_key][mode_label] = {
                "vs_Frozen-GAT": _paired_comparison(
                    candidate_runs,
                    _reference_runs(
                        base_report, scenario_key, load_key,
                        "Frozen-GAT", mode_label, seeds,
                    ),
                ),
                "vs_Pure": _paired_comparison(
                    candidate_runs,
                    _reference_runs(
                        base_report, scenario_key, load_key,
                        "Pure", mode_label, seeds,
                    ),
                ),
            }
    candidate_stds = [
        item["CSI-Augmented-GAT"]["probability_std"]
        for item in diagnostics.values()
    ]
    frozen_stds = [
        item["Frozen-GAT"]["probability_std"]
        for item in diagnostics.values()
    ]
    candidate_means = [
        item["CSI-Augmented-GAT"]["probability_mean"]
        for item in diagnostics.values()
    ]
    frozen_means = [
        item["Frozen-GAT"]["probability_mean"]
        for item in diagnostics.values()
    ]
    output_diagnosis = {
        "augmented_mean_probability_std": float(np.mean(candidate_stds)),
        "augmented_min_probability_std": float(np.min(candidate_stds)),
        "augmented_mean_probability": float(np.mean(candidate_means)),
        "frozen_mean_probability_std": float(np.mean(frozen_stds)),
        "frozen_min_probability_std": float(np.min(frozen_stds)),
        "frozen_mean_probability": float(np.mean(frozen_means)),
        "augmented_is_input_insensitive": bool(
            np.mean(candidate_stds) < 1e-6
        ),
        "interpretation": (
            "The augmented prior is input-insensitive and all-active; its queue "
            "metric cannot be credited to learned CSI robustness."
            if np.mean(candidate_stds) < 1e-6 else
            "The augmented prior remains CSI-sensitive. Its paired queue gate, "
            "rather than output variance alone, determines whether retraining helped."
        ),
    }
    gate = _candidate_gate(
        comparisons,
        output_is_input_insensitive=output_diagnosis[
            "augmented_is_input_insensitive"
        ],
    )
    report = {
        "experiment": "csi_augmented_spatial_gat_paired_evaluation_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "checkpoint_metadata": {
            key: checkpoint.get(key) for key in (
                "model_version", "base_checkpoint", "best_epoch",
                "training_objective", "training_csi_modes",
            )
        },
        "summaries": summaries,
        "comparisons": comparisons,
        "output_diagnosis": output_diagnosis,
        "per_state_output_diagnostics": diagnostics,
        "run_details": run_details,
        "gate": gate,
    }
    output = args.output or (
        "results/diagnostics/csi_augmented_spatial_eval_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
    )
    os.makedirs(os.path.dirname(output), exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "report": output,
        "output_diagnosis": output_diagnosis,
        "gate": gate,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
