#!/usr/bin/env python3
"""One-day gate for physically meaningful temporal CSI prediction.

The experiment never trains on scheduling actions or conference logits.  It
predicts the current physical dB power matrix under LoS-dominant Rician fading,
then compares a link-local GRU and a one-round spatial-temporal GAT against
current large-scale CSI, stale CSI, and a fitted affine AR baseline.
"""

import argparse
import copy
import json
import os
import random
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.physical_state_stgnn import PhysicalStateTemporalPredictor
from simulator.mobile_block_fading import generate_mobile_block_fading_trace
from utils.project_setup import build_network_generator, load_config


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_slots", type=int, default=600)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--train_seeds", default="100,101,102,103,104,105,106,107")
    parser.add_argument("--val_seeds", default="200,201")
    parser.add_argument("--test_seeds", default="42,43,44,45,46")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--bptt_blocks", type=int, default=12)
    parser.add_argument("--learning_rate", type=float, default=1e-3)
    parser.add_argument("--embedding_dim", type=int, default=24)
    parser.add_argument("--hidden_dim", type=int, default=24)
    parser.add_argument("--seed", type=int, default=20260716)
    parser.add_argument(
        "--output",
        default=(
            "results/diagnostics/physical_state_stgnn_gate_"
            "N10_ricianK5_20260716.json"
        ),
    )
    parser.add_argument(
        "--checkpoint",
        default=(
            "results/models/physical_state_temporal_gate_"
            "N10_ricianK5_20260716.pth"
        ),
    )
    return parser.parse_args()


def _seeds(text):
    return [int(item) for item in str(text).split(",") if item.strip()]


def _db(power):
    return 10.0 * torch.log10(torch.as_tensor(power).clamp_min(1e-30))


def _pair_catalog(num_uav):
    pairs = [(u, v) for u in range(num_uav) for v in range(num_uav) if u != v]
    return torch.tensor(pairs, dtype=torch.long)


def _pair_graph(pairs):
    """Connect physical channels that share an endpoint, with role features."""
    source, target, attrs = [], [], []
    pair_list = pairs.tolist()
    for src_idx, (a, b) in enumerate(pair_list):
        for dst_idx, (c, d) in enumerate(pair_list):
            if src_idx == dst_idx:
                continue
            role = [a == c, b == d, a == d, b == c]
            if any(role):
                source.append(src_idx)
                target.append(dst_idx)
                attrs.append([float(value) for value in role])
    return (
        torch.tensor([source, target], dtype=torch.long),
        torch.tensor(attrs, dtype=torch.float32),
    )


def _trace(net_gen, args, seed):
    return generate_mobile_block_fading_trace(
        net_gen,
        num_slots=args.num_slots,
        slots_per_block=args.slots_per_block,
        slot_duration=0.001,
        speed_mps=args.speed_mps,
        seed=seed,
        quantization_bits=(4,),
        rician_k_db=args.rician_k_db,
    )


def _sequence(trace, pairs):
    tx, rx = pairs[:, 0], pairs[:, 1]
    rows = []
    for block_idx in range(1, len(trace.blocks)):
        previous = trace.blocks[block_idx - 1]
        current = trace.blocks[block_idx]
        stale_db = _db(previous.true_power[tx, rx])
        previous_ls_db = _db(previous.large_scale_power[tx, rx])
        current_ls_db = _db(current.large_scale_power[tx, rx])
        target_db = _db(current.true_power[tx, rx])
        previous_distance = torch.linalg.vector_norm(
            previous.positions[tx] - previous.positions[rx], dim=1
        )
        current_distance = torch.linalg.vector_norm(
            current.positions[tx] - current.positions[rx], dim=1
        )
        features = torch.stack([
            stale_db - previous_ls_db,
            current_ls_db,
            current_distance,
            current_distance - previous_distance,
        ], dim=1).float()
        rows.append({
            "features": features,
            "target_residual": (target_db - current_ls_db).float(),
            "target_db": target_db.float(),
            "stale_db": stale_db.float(),
            "current_ls_db": current_ls_db.float(),
        })
    return rows


def _feature_stats(sequences):
    features = torch.cat([
        row["features"] for sequence in sequences for row in sequence
    ], dim=0)
    mean = features.mean(dim=0)
    std = features.std(dim=0, unbiased=False).clamp_min(1e-6)
    targets = torch.cat([
        row["target_residual"] for sequence in sequences for row in sequence
    ])
    target_mean = targets.mean()
    target_std = targets.std(unbiased=False).clamp_min(1e-6)
    return mean, std, target_mean, target_std


def _fit_affine_ar(sequences):
    stale_residual = torch.cat([
        row["features"][:, 0] for sequence in sequences for row in sequence
    ]).double()
    target = torch.cat([
        row["target_residual"] for sequence in sequences for row in sequence
    ]).double()
    design = torch.stack([torch.ones_like(stale_residual), stale_residual], dim=1)
    solution = torch.linalg.lstsq(design, target.unsqueeze(1)).solution.squeeze(1)
    return float(solution[0]), float(solution[1])


def _normalized(row, feature_mean, feature_std, target_mean, target_std, device):
    features = ((row["features"] - feature_mean) / feature_std).to(device)
    target = ((row["target_residual"] - target_mean) / target_std).to(device)
    return features, target


def _train_model(
    name, use_spatial, train_sequences, val_sequences, graph, stats, args, device
):
    feature_mean, feature_std, target_mean, target_std = stats
    edge_index, edge_attr = (item.to(device) for item in graph)
    model = PhysicalStateTemporalPredictor(
        input_dim=4,
        embedding_dim=args.embedding_dim,
        hidden_dim=args.hidden_dim,
        edge_dim=4,
        use_spatial=use_spatial,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    best_state, best_mae, best_epoch, logs = None, float("inf"), -1, []
    for epoch in range(args.epochs):
        model.train()
        order = list(range(len(train_sequences)))
        random.Random(args.seed + epoch).shuffle(order)
        losses = []
        for sequence_index in order:
            sequence = train_sequences[sequence_index]
            hidden = model.initial_hidden(sequence[0]["features"].size(0), device)
            window = []
            for row_index, row in enumerate(sequence):
                features, target = _normalized(
                    row, feature_mean, feature_std, target_mean, target_std, device
                )
                prediction, hidden = model.forward_step(
                    features, edge_index, edge_attr, hidden
                )
                window.append(torch.mean((prediction - target) ** 2))
                last = row_index + 1 == len(sequence)
                if len(window) >= args.bptt_blocks or last:
                    loss = torch.stack(window).mean()
                    optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                    optimizer.step()
                    losses.append(float(loss.detach()))
                    hidden = hidden.detach()
                    window = []
        validation = _evaluate_model(
            model, val_sequences, graph, stats, device
        )
        log = {
            "epoch": epoch,
            "train_normalized_mse": float(np.mean(losses)),
            "val_mae_db": validation["aggregate"]["mae_db"],
        }
        logs.append(log)
        print(
            f"[{name}] epoch={epoch} train_mse={log['train_normalized_mse']:.5f} "
            f"val_mae={log['val_mae_db']:.4f} dB",
            flush=True,
        )
        if log["val_mae_db"] < best_mae - 1e-8:
            best_mae = log["val_mae_db"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
    model.load_state_dict(best_state)
    return model, {
        "name": name,
        "best_epoch": best_epoch,
        "best_val_mae_db": best_mae,
        "logs": logs,
        "parameter_count": sum(p.numel() for p in model.parameters()),
    }


def _evaluate_model(model, sequences, graph, stats, device):
    feature_mean, feature_std, target_mean, target_std = stats
    edge_index, edge_attr = (item.to(device) for item in graph)
    per_seed = []
    model.eval()
    with torch.no_grad():
        for sequence in sequences:
            hidden = model.initial_hidden(sequence[0]["features"].size(0), device)
            errors = []
            for row in sequence:
                features, _ = _normalized(
                    row, feature_mean, feature_std, target_mean, target_std, device
                )
                normalized_prediction, hidden = model.forward_step(
                    features, edge_index, edge_attr, hidden
                )
                prediction = (
                    normalized_prediction.cpu() * target_std + target_mean
                    + row["current_ls_db"]
                )
                errors.append(torch.abs(prediction - row["target_db"]))
            error = torch.cat(errors)
            per_seed.append({
                "mae_db": float(error.mean()),
                "p90_abs_error_db": float(torch.quantile(error, 0.9)),
            })
    return {
        "per_seed": per_seed,
        "aggregate": {
            "mae_db": float(np.mean([item["mae_db"] for item in per_seed])),
            "p90_abs_error_db": float(np.mean([
                item["p90_abs_error_db"] for item in per_seed
            ])),
        },
    }


def _evaluate_baselines(sequences, ar_intercept, ar_beta):
    names = ("current_large_scale", "one_block_stale", "affine_ar")
    output = {name: [] for name in names}
    for sequence in sequences:
        errors = {name: [] for name in names}
        for row in sequence:
            predictions = {
                "current_large_scale": row["current_ls_db"],
                "one_block_stale": row["stale_db"],
                "affine_ar": row["current_ls_db"] + ar_intercept
                + ar_beta * row["features"][:, 0],
            }
            for name, prediction in predictions.items():
                errors[name].append(torch.abs(prediction - row["target_db"]))
        for name in names:
            error = torch.cat(errors[name])
            output[name].append({
                "mae_db": float(error.mean()),
                "p90_abs_error_db": float(torch.quantile(error, 0.9)),
            })
    return {
        name: {
            "per_seed": rows,
            "aggregate": {
                "mae_db": float(np.mean([item["mae_db"] for item in rows])),
                "p90_abs_error_db": float(np.mean([
                    item["p90_abs_error_db"] for item in rows
                ])),
            },
        }
        for name, rows in output.items()
    }


def _win_count(candidate, reference):
    return sum(
        left["mae_db"] < right["mae_db"]
        for left, right in zip(candidate["per_seed"], reference["per_seed"])
    )


def main():
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cpu")
    config = load_config("configs/exp_example.yaml")
    config.update({
        "NUM_UAV": args.num_uav,
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    net_gen = build_network_generator(config)
    pairs = _pair_catalog(args.num_uav)
    graph = _pair_graph(pairs)
    train_seeds, val_seeds, test_seeds = (
        _seeds(args.train_seeds), _seeds(args.val_seeds), _seeds(args.test_seeds)
    )
    print("Generating paired Rician trajectories...", flush=True)
    train_sequences = [_sequence(_trace(net_gen, args, seed), pairs) for seed in train_seeds]
    val_sequences = [_sequence(_trace(net_gen, args, seed), pairs) for seed in val_seeds]
    test_sequences = [_sequence(_trace(net_gen, args, seed), pairs) for seed in test_seeds]
    stats = _feature_stats(train_sequences)
    ar_intercept, ar_beta = _fit_affine_ar(train_sequences)
    baselines = _evaluate_baselines(test_sequences, ar_intercept, ar_beta)

    link_gru, link_training = _train_model(
        "link_gru", False, train_sequences, val_sequences, graph, stats, args, device
    )
    stgnn, stgnn_training = _train_model(
        "physical_state_stgnn", True, train_sequences, val_sequences, graph,
        stats, args, device
    )
    link_result = _evaluate_model(link_gru, test_sequences, graph, stats, device)
    stgnn_result = _evaluate_model(stgnn, test_sequences, graph, stats, device)
    best_analytic_name = min(
        baselines, key=lambda name: baselines[name]["aggregate"]["mae_db"]
    )
    best_analytic = baselines[best_analytic_name]
    learned_vs_analytic = _win_count(stgnn_result, best_analytic)
    local_vs_analytic = _win_count(link_result, best_analytic)
    spatial_vs_local = _win_count(stgnn_result, link_result)
    gate = {
        "best_analytic_baseline": best_analytic_name,
        "link_gru_win_seeds_vs_best_analytic": local_vs_analytic,
        "stgnn_win_seeds_vs_best_analytic": learned_vs_analytic,
        "stgnn_win_seeds_vs_link_gru": spatial_vs_local,
        "temporal_physical_prediction_gate_passed": local_vs_analytic >= 4,
        "spatial_predictor_gate_passed": (
            learned_vs_analytic >= 4 and spatial_vs_local >= 4
        ),
        "spatial_gat_value_gate_passed": spatial_vs_local >= 4,
        "proceed_to_scheduler_gate_with_link_gru": local_vs_analytic >= 4,
        "decision": (
            "Keep link-local temporal physical estimator for the scheduler gate; "
            "stop spatial message passing inside the predictor."
            if local_vs_analytic >= 4 and spatial_vs_local < 4 else
            "Follow the boolean gates without expanding model complexity."
        ),
    }
    payload = {
        "experiment": "physical_state_stgnn_one_day_gate",
        "timestamp": datetime.now().isoformat(),
        "purpose": (
            "Test whether temporal history and spatial graph messages predict "
            "current physical channel power beyond stale, large-scale, and AR."
        ),
        "settings": vars(args),
        "channel_definition": {
            "model": "normalized Rician",
            "rician_k_db": args.rician_k_db,
            "target": "current dB power residual around current large-scale power",
            "pair_identity": "all ordered UAV pairs (u,v), u!=v",
        },
        "graph": {
            "num_pair_nodes": int(pairs.size(0)),
            "num_directed_shared_endpoint_edges": int(graph[0].size(1)),
            "spatial_message_rounds_per_channel_block": 1,
            "temporal_memory_message_rounds": 0,
            "link_gru_new_message_rounds_per_channel_block": 0,
            "network_wide_link_gru_state_floats": int(
                pairs.size(0) * args.hidden_dim
            ),
            "link_gru_state_floats_per_receiver_uav": int(
                (args.num_uav - 1) * args.hidden_dim
            ),
            "spatial_predictor_unicast_payload_bits_per_block": int(
                graph[0].size(1) * args.embedding_dim * 32
            ),
            "spatial_predictor_unicast_payload_mbps_at_block_period": float(
                graph[0].size(1) * args.embedding_dim * 32
                / (args.slots_per_block * 0.001) / 1e6
            ),
            "payload_scope": (
                "Conservative directed-edge unicast for the rejected spatial "
                "predictor; excludes headers and CSI acquisition. Link-GRU "
                "state is local memory, not an air-interface payload."
            ),
        },
        "normalization": {
            "feature_mean": stats[0].tolist(),
            "feature_std": stats[1].tolist(),
            "target_mean": float(stats[2]),
            "target_std": float(stats[3]),
        },
        "affine_ar": {"intercept": ar_intercept, "beta": ar_beta},
        "training": {"link_gru": link_training, "stgnn": stgnn_training},
        "results": {
            **baselines,
            "link_gru": link_result,
            "physical_state_stgnn": stgnn_result,
        },
        "gate": gate,
        "conclusion_boundary": (
            "Passing the physical gate only permits a downstream scheduler "
            "test; it does not by itself prove throughput or backlog gains."
        ),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    checkpoint = Path(args.checkpoint)
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_version": "physical_state_temporal_gate_v1",
        "channel_model": "rician",
        "rician_k_db": float(args.rician_k_db),
        "num_uav": int(args.num_uav),
        "pair_catalog": pairs,
        "pair_edge_index": graph[0],
        "pair_edge_attr": graph[1],
        "feature_mean": stats[0],
        "feature_std": stats[1],
        "target_mean": stats[2],
        "target_std": stats[3],
        "link_gru_state_dict": link_gru.state_dict(),
        "stgnn_state_dict": stgnn.state_dict(),
        "embedding_dim": int(args.embedding_dim),
        "hidden_dim": int(args.hidden_dim),
        "gate": gate,
    }, checkpoint)
    print(json.dumps({
        "output": str(output),
        "checkpoint": str(checkpoint),
        "aggregate_mae_db": {
            name: result["aggregate"]["mae_db"]
            for name, result in payload["results"].items()
        },
        "gate": gate,
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
