#!/usr/bin/env python3
"""Zero-training translation gate from the accepted Link-GRU to MarginalMP.

The existing N=10 physical-state predictor is frozen.  Its coherent predicted
power matrix, stale CSI, current large-scale CSI, and affine AR prediction are
each passed to the same Direct-Link MarginalMP backend.  Final utility is
always settled on current true CSI.  This is a feasibility gate, not a formal
N=20 result.
"""

import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import queue_snapshot  # noqa: E402
from experiments.evaluate_physical_state_scheduler_gate import (  # noqa: E402
    _db,
    _features,
    _matrix_from_pair_db,
    _seeds,
)
from models.marginal_mp import DirectLinkMarginalMP  # noqa: E402
from models.physical_state_stgnn import PhysicalStateTemporalPredictor  # noqa: E402
from simulator.mobile_block_fading import (  # noqa: E402
    build_network_state_from_power,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import build_network_generator, load_config  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


MODES = ("latest", "stale", "current_large_scale", "affine_ar", "link_gru")
PROFILES = ("heterogeneous", "saturated")


def _mean_ci(values):
    values = np.asarray(values, dtype=np.float64)
    return {
        "mean": float(values.mean()),
        "ci95": float(1.96 * values.std(ddof=1) / np.sqrt(len(values)))
        if len(values) > 1 else 0.0,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uav", type=int, default=10)
    parser.add_argument("--num_slots", type=int, default=600)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--test_seeds", default="42,43,44,45,46")
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument(
        "--predictor_checkpoint",
        default=(
            "results/models/physical_state_temporal_gate_"
            "N10_ricianK5_20260716.pth"
        ),
    )
    parser.add_argument(
        "--prediction_report",
        default=(
            "results/diagnostics/physical_state_stgnn_gate_"
            "N10_ricianK5_20260716.json"
        ),
    )
    parser.add_argument("--minimum_gain", type=float, default=0.05)
    parser.add_argument("--minimum_win_fraction", type=float, default=0.80)
    parser.add_argument(
        "--output",
        default=(
            "results/formal/link_gru_direct_link_marginal_mp_gate_"
            "N10_rician_20260718.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 10:
        raise ValueError("The reused predictor checkpoint is fixed to N=10")

    predictor_payload = torch.load(
        args.predictor_checkpoint, map_location="cpu", weights_only=False
    )
    prediction_report = json.loads(Path(args.prediction_report).read_text())
    if not predictor_payload["gate"]["proceed_to_scheduler_gate_with_link_gru"]:
        raise RuntimeError("Stored prediction gate did not accept Link-GRU")
    pairs = predictor_payload["pair_catalog"].long()
    predictor = PhysicalStateTemporalPredictor(
        input_dim=4,
        embedding_dim=int(predictor_payload["embedding_dim"]),
        hidden_dim=int(predictor_payload["hidden_dim"]),
        edge_dim=4,
        use_spatial=False,
    )
    predictor.load_state_dict(predictor_payload["link_gru_state_dict"])
    predictor.eval()
    feature_mean = predictor_payload["feature_mean"]
    feature_std = predictor_payload["feature_std"]
    target_mean = predictor_payload["target_mean"]
    target_std = predictor_payload["target_std"]
    edge_index = predictor_payload["pair_edge_index"]
    edge_attr = predictor_payload["pair_edge_attr"]
    ar_intercept = float(prediction_report["affine_ar"]["intercept"])
    ar_beta = float(prediction_report["affine_ar"]["beta"])

    config = load_config("configs/exp_example.yaml")
    config.update({
        "NUM_UAV": 10,
        "TX_POWER": 10.0,
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
        "CSI_MODE": "perfect",
    })
    net_gen = build_network_generator(config)
    rows = []
    for seed in _seeds(args.test_seeds):
        trace = generate_mobile_block_fading_trace(
            net_gen,
            num_slots=args.num_slots,
            slots_per_block=args.slots_per_block,
            slot_duration=0.001,
            speed_mps=args.speed_mps,
            seed=seed,
            quantization_bits=(4,),
            rician_k_db=args.rician_k_db,
        )
        hidden = predictor.initial_hidden(pairs.size(0))
        for block_index in range(1, len(trace.blocks)):
            previous, current = trace.blocks[block_index - 1:block_index + 1]
            raw_features = _features(previous, current, pairs)
            normalized = (raw_features - feature_mean) / feature_std
            with torch.no_grad():
                normalized_residual, hidden = predictor.forward_step(
                    normalized, edge_index, edge_attr, hidden
                )
            current_ls_pair_db = _db(
                current.large_scale_power[pairs[:, 0], pairs[:, 1]]
            )
            predicted_pair_db = (
                current_ls_pair_db
                + normalized_residual * target_std + target_mean
            )
            ar_pair_db = (
                current_ls_pair_db
                + ar_intercept + ar_beta * raw_features[:, 0]
            )
            powers = {
                "latest": current.true_power,
                "stale": previous.true_power,
                "current_large_scale": current.large_scale_power,
                "affine_ar": _matrix_from_pair_db(
                    ar_pair_db, pairs, args.num_uav
                ),
                "link_gru": _matrix_from_pair_db(
                    predicted_pair_db, pairs, args.num_uav
                ),
            }
            true_state, true_indices = build_true_network_state(
                net_gen, trace, block_index
            )
            for profile_index, profile in enumerate(PROFILES):
                queues = queue_snapshot(
                    true_state.num_vertices,
                    seed * 1_000_003 + block_index * 101 + profile_index * 10_000,
                    profile,
                )
                for mode in MODES:
                    state, observed_indices = build_network_state_from_power(
                        net_gen, trace, block_index, powers[mode], csi_label=mode
                    )
                    if not torch.equal(observed_indices, true_indices):
                        raise RuntimeError("Predicted/true persistent IDs diverged")
                    scheduler = DirectLinkMarginalMP(rounds=args.rounds)
                    action = scheduler.schedule_with_state(state, queues)
                    rows.append({
                        "seed": seed,
                        "block": block_index,
                        "profile": profile,
                        "mode": mode,
                        "true_utility": float(
                            mws_objective(action, queues, true_state)
                        ),
                        "active_links": int(action.sum()),
                    })
        print(f"completed seed={seed}")

    per_seed = defaultdict(dict)
    aggregate = {}
    for profile in PROFILES:
        for mode in MODES:
            seed_values = []
            for seed in _seeds(args.test_seeds):
                values = [
                    row["true_utility"] for row in rows
                    if row["seed"] == seed
                    and row["profile"] == profile
                    and row["mode"] == mode
                ]
                value = float(np.mean(values))
                per_seed[(profile, seed)][mode] = value
                seed_values.append(value)
            aggregate[f"{profile}/{mode}"] = {
                "true_utility": _mean_ci(seed_values),
                "mean_active_links": float(np.mean([
                    row["active_links"] for row in rows
                    if row["profile"] == profile and row["mode"] == mode
                ])),
            }

    gates = {}
    for profile in PROFILES:
        nonlearned = ("stale", "current_large_scale", "affine_ar")
        best_baseline = max(
            nonlearned,
            key=lambda mode: aggregate[f"{profile}/{mode}"][
                "true_utility"
            ]["mean"],
        )
        ratios = np.asarray([
            per_seed[(profile, seed)]["link_gru"]
            / max(per_seed[(profile, seed)][best_baseline], 1e-12)
            for seed in _seeds(args.test_seeds)
        ])
        latest = np.asarray([
            per_seed[(profile, seed)]["latest"]
            for seed in _seeds(args.test_seeds)
        ])
        baseline = np.asarray([
            per_seed[(profile, seed)][best_baseline]
            for seed in _seeds(args.test_seeds)
        ])
        candidate = np.asarray([
            per_seed[(profile, seed)]["link_gru"]
            for seed in _seeds(args.test_seeds)
        ])
        recoverable_gap = np.maximum(latest - baseline, 1e-12)
        gates[profile] = {
            "best_nonlearned_baseline": best_baseline,
            "link_gru_over_best_nonlearned": _mean_ci(ratios),
            "strict_win_fraction": float(np.mean(ratios > 1.0 + 1e-9)),
            "mean_fraction_latest_gap_recovered": float(np.mean(
                (candidate - baseline) / recoverable_gap
            )),
            "passed": bool(
                ratios.mean() >= 1.0 + args.minimum_gain
                and np.mean(ratios > 1.0 + 1e-9) >= args.minimum_win_fraction
            ),
        }
    payload = {
        "experiment": "link_gru_to_direct_link_marginal_mp_translation_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "purpose": (
            "Reuse the accepted N=10 Link-GRU without retraining and test "
            "whether its lower physical prediction MAE becomes useful when "
            "translated through Direct-Link MarginalMP."
        ),
        "settings": vars(args),
        "method": "Direct-Link MarginalMP",
        "predictor_checkpoint": args.predictor_checkpoint,
        "aggregate": aggregate,
        "gates": gates,
        "decision": (
            "PROCEED_TO_N20_LINK_GRU_MARGINAL_MP"
            if any(value["passed"] for value in gates.values())
            else "STOP_LINK_GRU_MARGINAL_MP_TRANSLATION"
        ),
        "rows": rows,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "gates": gates,
        "decision": payload["decision"],
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
