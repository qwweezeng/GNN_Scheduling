#!/usr/bin/env python3
"""Cheap learnability gate for the missing global MWS toggle externality.

The task is intentionally narrower than scheduling: among links whose one-hop
physical toggle margin is positive, predict the exact global toggle margin.
An MLP and one-/two-layer GATs receive the same node features.  If graph
message passing cannot reject unsafe false-positive toggles better than the
MLP, no end-to-end scheduler is trained.
"""

import argparse
import copy
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_conditional_negotiation_gate import (  # noqa: E402
    ExactToggleState,
    _UnusedChannelModel,
)
from experiments.diagnose_local_conditional_information_gate import (  # noqa: E402
    hop_scopes,
)
from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    queue_snapshot,
)
from models.local_physical_reuse import (  # noqa: E402
    PurePhysicalReuseScheduler,
    local_edge_gains,
)
from models.model import GATLayer  # noqa: E402
from utils.project_setup import build_network_generator, load_config  # noqa: E402


def make_sample(state, queues, pure):
    action = pure.schedule_with_state(state, queues)
    engine = ExactToggleState(state, queues, action)
    num_links = int(state.num_vertices)
    scopes, coverage = hop_scopes(state.edge_index, num_links, 1)
    local_delta = torch.tensor([
        engine.toggle_delta_on_mask(link, scopes[link])
        for link in range(num_links)
    ], dtype=torch.float32)
    global_delta = torch.tensor([
        engine.toggle_delta(link) for link in range(num_links)
    ], dtype=torch.float32)
    nonempty = engine.queues > 0
    finite = torch.isfinite(global_delta) & torch.isfinite(local_delta)
    values = global_delta[nonempty & finite].abs()
    values = values[values > 1e-8]
    scale = float(values.median()) if values.numel() else 1.0

    rates = engine._rates(engine.interference)
    solo_rates = engine._rates(torch.zeros_like(engine.interference))
    positive_q = engine.queues[nonempty]
    q_scale = float(positive_q.mean()) if positive_q.numel() else 1.0
    rate_scale = float(solo_rates.mean().clamp_min(1e-6))

    source, target = state.edge_index.detach().cpu()
    degree = torch.zeros(num_links, dtype=torch.float32)
    active_neighbors = torch.zeros(num_links, dtype=torch.float32)
    if source.numel():
        degree.index_add_(0, source, torch.ones_like(source, dtype=torch.float32))
        active_neighbors.index_add_(
            0, source, engine.action[target].float()
        )
    degree_scale = float(degree.max().clamp_min(1.0))
    local_scaled = torch.where(
        finite, local_delta / scale, torch.zeros_like(local_delta)
    )
    target_global = torch.where(
        finite, global_delta / scale, torch.zeros_like(global_delta)
    )
    x = torch.stack([
        engine.queues / max(q_scale, 1e-6),
        engine.action.float(),
        rates / rate_scale,
        solo_rates / rate_scale,
        local_scaled,
        active_neighbors / degree.clamp_min(1.0),
        degree / degree_scale,
    ], dim=1)

    _, edge_source, edge_target, edge_gain = local_edge_gains(state)
    noise = float(state.noise_power)
    edge_attr = (
        torch.log10((edge_gain / noise).clamp_min(1e-12)).clamp(-6.0, 6.0) / 6.0
    ).unsqueeze(1)
    # A transmitter needs messages from the receivers it would affect, hence
    # reverse each physical source->affected-receiver edge for aggregation.
    message_edge_index = torch.stack([edge_target, edge_source], dim=0)
    candidate = nonempty & finite & (local_delta > 1e-9)
    return {
        "x": x,
        "edge_index": message_edge_index,
        "edge_attr": edge_attr,
        "candidate": candidate,
        "target": target_global,
        "local_scaled": local_scaled,
        "coverage": coverage,
    }


def build_split(generator, pure, seeds, profiles):
    samples = []
    for graph_seed in seeds:
        torch.manual_seed(int(graph_seed))
        np.random.seed(int(graph_seed))
        state = generator.generate_network(csi_mode="perfect", include_queue_feature=False)
        for profile_index, profile in enumerate(profiles):
            queues = queue_snapshot(
                state.num_vertices,
                int(graph_seed) + 100_003 + 10_000 * profile_index,
                profile,
            )
            sample = make_sample(state, queues, pure)
            sample["graph_seed"] = int(graph_seed)
            sample["profile"] = profile
            samples.append(sample)
    return samples


class NodeMLP(nn.Module):
    def __init__(self, input_dim, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden), nn.ReLU(), nn.Linear(hidden, 1)
        )

    def forward(self, sample):
        residual = self.net(sample["x"]).reshape(-1)
        return sample["local_scaled"] + residual


class ResidualGAT(nn.Module):
    def __init__(self, input_dim, layers, hidden=16):
        super().__init__()
        self.encoder = nn.Linear(input_dim, hidden)
        self.layers = nn.ModuleList([
            GATLayer(hidden, 1, hidden, num_heads=1) for _ in range(int(layers))
        ])
        self.head = nn.Sequential(
            nn.Linear(hidden + input_dim, hidden), nn.ReLU(), nn.Linear(hidden, 1)
        )

    def forward(self, sample):
        h = F.elu(self.encoder(sample["x"]))
        for layer in self.layers:
            h = h + F.elu(layer(h, sample["edge_index"], sample["edge_attr"]))
        residual = self.head(torch.cat([h, sample["x"]], dim=1)).reshape(-1)
        return sample["local_scaled"] + residual


def train_model(model, train_samples, val_samples, epochs, learning_rate):
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    best_state = copy.deepcopy(model.state_dict())
    best_val = float("inf")
    history = []
    for epoch in range(int(epochs)):
        model.train()
        order = np.random.default_rng(10_000 + epoch).permutation(len(train_samples))
        train_losses = []
        for index in order:
            sample = train_samples[int(index)]
            mask = sample["candidate"]
            if not mask.any():
                continue
            prediction = model(sample)
            loss = F.mse_loss(prediction[mask], sample["target"][mask])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            train_losses.append(float(loss.detach()))
        model.eval()
        val_numerator = 0.0
        val_count = 0
        with torch.no_grad():
            for sample in val_samples:
                mask = sample["candidate"]
                if not mask.any():
                    continue
                error = (model(sample)[mask] - sample["target"][mask]).square()
                val_numerator += float(error.sum())
                val_count += int(error.numel())
        val_loss = val_numerator / max(val_count, 1)
        history.append({
            "epoch": epoch + 1,
            "train_mse": float(np.mean(train_losses)) if train_losses else 0.0,
            "val_mse": val_loss,
        })
        if val_loss < best_val:
            best_val = val_loss
            best_state = copy.deepcopy(model.state_dict())
    model.load_state_dict(best_state)
    return history, best_val


def evaluate(model, samples):
    predictions, targets = [], []
    model.eval()
    with torch.no_grad():
        for sample in samples:
            mask = sample["candidate"]
            if mask.any():
                predictions.append(model(sample)[mask])
                targets.append(sample["target"][mask])
    prediction = torch.cat(predictions).cpu().numpy()
    target = torch.cat(targets).cpu().numpy()
    safe = target > 0.0
    accepted = prediction > 0.0
    unsafe = ~safe
    correlation = float(np.corrcoef(prediction, target)[0, 1])
    return {
        "num_candidates": int(target.size),
        "num_safe": int(safe.sum()),
        "num_unsafe_false_positives_from_one_hop": int(unsafe.sum()),
        "mse": float(np.mean((prediction - target) ** 2)),
        "correlation": correlation,
        "sign_accuracy": float(np.mean(accepted == safe)),
        "safe_acceptance_rate": float(np.mean(accepted[safe])) if safe.any() else 1.0,
        "unsafe_rejection_rate": float(np.mean(~accepted[unsafe])) if unsafe.any() else 1.0,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--train_graphs", type=int, default=12)
    parser.add_argument("--val_graphs", type=int, default=4)
    parser.add_argument("--test_graphs", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--learning_rate", type=float, default=0.001)
    parser.add_argument("--seed", type=int, default=31415)
    parser.add_argument(
        "--output",
        default="results/formal/residual_gat_learnability_N20_rician_20260717.json",
    )
    args = parser.parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": 5.0,
    })
    generator = build_network_generator(config)
    pure = PurePhysicalReuseScheduler(_UnusedChannelModel())
    profiles = ("sparse", "heterogeneous", "saturated")
    train = build_split(generator, pure, range(31000, 31000 + args.train_graphs), profiles)
    val = build_split(generator, pure, range(41000, 41000 + args.val_graphs), profiles)
    test = build_split(generator, pure, range(24680, 24680 + args.test_graphs), profiles)
    input_dim = int(train[0]["x"].shape[1])
    constructors = {
        "mlp": lambda: NodeMLP(input_dim),
        "gat_1layer": lambda: ResidualGAT(input_dim, layers=1),
        "gat_2layer": lambda: ResidualGAT(input_dim, layers=2),
    }
    results = {}
    histories = {}
    for model_index, (name, constructor) in enumerate(constructors.items()):
        torch.manual_seed(args.seed + model_index)
        model = constructor()
        history, best_val = train_model(
            model, train, val, args.epochs, args.learning_rate
        )
        results[name] = evaluate(model, test)
        results[name]["best_val_mse"] = best_val
        histories[name] = history
        print(name, json.dumps(results[name], indent=2))

    best_gat_name = max(
        ("gat_1layer", "gat_2layer"),
        key=lambda name: results[name]["unsafe_rejection_rate"],
    )
    best_gat = results[best_gat_name]
    mlp = results["mlp"]
    passed = (
        best_gat["unsafe_rejection_rate"] >= 0.50
        and best_gat["safe_acceptance_rate"] >= 0.90
        and best_gat["unsafe_rejection_rate"] >= mlp["unsafe_rejection_rate"] + 0.10
    )
    payload = {
        "experiment": "residual_gat_learnability_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "task": (
            "Predict exact global toggle margins only among candidates whose "
            "one-hop physical margin is positive. Regression uses no class weights."
        ),
        "features": [
            "relative_queue", "current_action", "current_rate", "solo_rate",
            "one_hop_margin", "active_neighbor_fraction", "relative_degree",
        ],
        "predeclared_gate": {
            "minimum_unsafe_rejection_rate": 0.50,
            "minimum_safe_acceptance_rate": 0.90,
            "minimum_unsafe_rejection_advantage_over_mlp": 0.10,
        },
        "mean_one_hop_node_coverage": float(np.mean([s["coverage"] for s in test])),
        "results": results,
        "best_gat": best_gat_name,
        "gate_passed": passed,
        "decision": (
            "PROCEED_TO_STATE_CONDITIONED_GAT_UPDATER"
            if passed else "STOP_RESIDUAL_GAT_ROUTE"
        ),
        "history": histories,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "decision": payload["decision"], "best_gat": best_gat_name,
        "mean_one_hop_node_coverage": payload["mean_one_hop_node_coverage"],
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
