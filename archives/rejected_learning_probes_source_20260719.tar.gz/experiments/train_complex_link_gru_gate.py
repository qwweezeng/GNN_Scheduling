#!/usr/bin/env python3
"""Single-shot complex-input Link-GRU gate for aged Rician CSI.

The model is trained centrally on complete simulated traces but executes one
directed UAV pair at a time.  It receives an aged complex channel sample and
known geometry/age features, predicts the current dB power residual, and then
hands one coherent power matrix to unchanged Direct-Link MarginalMP.  A
same-input stateless MLP is mandatory; no spatial GAT is trained.
"""

import argparse
import copy
import json
import math
import os
import random
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
from torch import nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_complex_csi_prediction_gate import (  # noqa: E402
    conditional_expected_power,
)
from experiments.diagnose_mws_topology_scaling_headroom import queue_snapshot  # noqa: E402
from models.complex_geometry_csi import ComplexGeometryCSIPredictor  # noqa: E402
from models.marginal_mp import DirectLinkMarginalMP  # noqa: E402
from simulator.mobile_block_fading import (  # noqa: E402
    build_network_state_from_power,
    build_observed_network_state,
    build_true_network_state,
    generate_mobile_block_fading_trace,
)
from utils.project_setup import build_network_generator, load_config  # noqa: E402
from utils.scheduling_objective import mws_objective  # noqa: E402


PROFILES = ("heterogeneous", "saturated")
LEARNED = ("complex_mlp", "complex_link_gru")


def _parse_ints(text):
    return [int(item) for item in str(text).split(",") if item.strip()]


def _parse_floats(text):
    return [float(item) for item in str(text).split(",") if item.strip()]


def _pair_catalog(num_uav):
    return torch.tensor(
        [(u, v) for u in range(num_uav) for v in range(num_uav) if u != v],
        dtype=torch.long,
    )


def _db(power):
    return 10.0 * torch.log10(torch.as_tensor(power).clamp_min(1e-30))


def _sequence(
    trace, pairs, age, speed, maximum_age, minimum_distance, carrier_f,
    tx_power,
):
    tx, rx = pairs[:, 0], pairs[:, 1]
    wavelength = 3.0e8 / float(carrier_f)
    rows = []
    for block_index in range(int(maximum_age), len(trace.blocks)):
        previous = trace.blocks[block_index - int(age)]
        current = trace.blocks[block_index]
        previous_amplitude = torch.sqrt(
            previous.large_scale_power[tx, rx] / float(tx_power)
        ).clamp_min(1e-30)
        normalized_previous = (
            previous.true_channel[tx, rx] / previous_amplitude
        )
        previous_distance = torch.linalg.vector_norm(
            previous.positions[tx] - previous.positions[rx], dim=1
        ).clamp_min(float(minimum_distance))
        current_distance = torch.linalg.vector_norm(
            current.positions[tx] - current.positions[rx], dim=1
        ).clamp_min(float(minimum_distance))
        previous_angle = 2.0 * math.pi * previous_distance / wavelength
        current_angle = 2.0 * math.pi * current_distance / wavelength
        rho_age = float(current.fading_rho) ** int(age)
        features = torch.stack([
            normalized_previous.real.float(),
            normalized_previous.imag.float(),
            torch.cos(previous_angle),
            torch.sin(previous_angle),
            torch.cos(current_angle),
            torch.sin(current_angle),
            torch.full_like(current_distance, rho_age),
            ((current_distance - previous_distance) / wavelength).float(),
            torch.full_like(current_distance, float(age) / float(maximum_age)),
            torch.full_like(current_distance, float(speed) / 5.0),
        ], dim=1)
        target = _db(
            current.true_power[tx, rx] / current.large_scale_power[tx, rx]
        ).float()
        rows.append({
            "block_index": block_index,
            "features": features,
            "target_residual_db": target,
        })
    return rows


def _make_trace(net_gen, args, seed, speed):
    return generate_mobile_block_fading_trace(
        net_gen,
        num_slots=args.num_slots,
        slots_per_block=args.slots_per_block,
        slot_duration=0.001,
        speed_mps=speed,
        seed=seed,
        quantization_bits=(4,),
        rician_k_db=args.rician_k_db,
    )


def _all_sequences(net_gen, args, seeds, pairs):
    ages = _parse_ints(args.stale_blocks)
    maximum_age = max(ages)
    sequences = []
    for seed in seeds:
        for speed in _parse_floats(args.speed_mps):
            trace = _make_trace(net_gen, args, seed, speed)
            for age in ages:
                sequences.append({
                    "seed": seed,
                    "speed": speed,
                    "age": age,
                    "trace": trace,
                    "rows": _sequence(
                        trace, pairs, age, speed, maximum_age,
                        net_gen.min_distance, net_gen.carrier_f,
                        net_gen.tx_power,
                    ),
                })
        print(f"generated training/evaluation sequences seed={seed}")
    return sequences


def _stats(sequences):
    features = torch.cat([
        row["features"] for sequence in sequences for row in sequence["rows"]
    ])
    targets = torch.cat([
        row["target_residual_db"]
        for sequence in sequences for row in sequence["rows"]
    ])
    return (
        features.mean(0), features.std(0, unbiased=False).clamp_min(1e-6),
        targets.mean(), targets.std(unbiased=False).clamp_min(1e-6),
    )


class ComplexLinkGRU(nn.Module):
    def __init__(self, input_dim=10, hidden_dim=16):
        super().__init__()
        self.embed = nn.Sequential(nn.Linear(input_dim, 24), nn.ReLU())
        self.gru = nn.GRUCell(24, hidden_dim)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, 16), nn.ReLU(), nn.Linear(16, 1),
        )
        nn.init.zeros_(self.head[-1].weight)
        nn.init.zeros_(self.head[-1].bias)

    def initial_hidden(self, num_pairs, device):
        return torch.zeros(int(num_pairs), self.gru.hidden_size, device=device)

    def forward_step(self, features, hidden):
        hidden = self.gru(self.embed(features), hidden)
        return self.head(hidden).squeeze(1), hidden


def _normalized(row, stats, device):
    fm, fs, tm, ts = stats
    return (
        ((row["features"] - fm) / fs).to(device),
        ((row["target_residual_db"] - tm) / ts).to(device),
    )


@torch.no_grad()
def _evaluate_prediction(model, sequences, stats, device):
    model.eval()
    per_sequence = []
    _, _, target_mean, target_std = stats
    for sequence in sequences:
        hidden = model.initial_hidden(
            sequence["rows"][0]["features"].size(0), device
        )
        errors = []
        predictions = {}
        for row in sequence["rows"]:
            features, _ = _normalized(row, stats, device)
            output, hidden = model.forward_step(features, hidden)
            residual_db = output.cpu() * target_std + target_mean
            errors.append(torch.abs(residual_db - row["target_residual_db"]))
            predictions[row["block_index"]] = residual_db
        error = torch.cat(errors)
        per_sequence.append({
            "seed": sequence["seed"],
            "speed": sequence["speed"],
            "age": sequence["age"],
            "mae_db": float(error.mean()),
            "p90_abs_error_db": float(torch.quantile(error, 0.9)),
            "predictions": predictions,
        })
    return per_sequence


def _validation_mae(model, sequences, stats, device):
    return float(np.mean([
        row["mae_db"] for row in _evaluate_prediction(
            model, sequences, stats, device
        )
    ]))


def _train(name, model, train_sequences, val_sequences, stats, args, device):
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    best_state, best_mae, best_epoch, logs = None, float("inf"), -1, []
    for epoch in range(args.epochs):
        model.train()
        order = list(range(len(train_sequences)))
        random.Random(args.seed + epoch).shuffle(order)
        losses = []
        for index in order:
            sequence = train_sequences[index]
            hidden = model.initial_hidden(
                sequence["rows"][0]["features"].size(0), device
            )
            window = []
            for row_index, row in enumerate(sequence["rows"]):
                features, target = _normalized(row, stats, device)
                output, hidden = model.forward_step(features, hidden)
                window.append(torch.nn.functional.smooth_l1_loss(output, target))
                last = row_index + 1 == len(sequence["rows"])
                if len(window) >= args.bptt_blocks or last:
                    loss = torch.stack(window).mean()
                    optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                    optimizer.step()
                    losses.append(float(loss.detach()))
                    if hidden is not None:
                        hidden = hidden.detach()
                    window = []
        val_mae = _validation_mae(model, val_sequences, stats, device)
        logs.append({
            "epoch": epoch + 1,
            "train_loss": float(np.mean(losses)),
            "val_mae_db": val_mae,
        })
        print(
            f"[{name}] epoch={epoch + 1} "
            f"train_loss={np.mean(losses):.5f} val_mae={val_mae:.4f} dB"
        )
        if val_mae < best_mae:
            best_mae = val_mae
            best_epoch = epoch + 1
            best_state = copy.deepcopy(model.state_dict())
    model.load_state_dict(best_state)
    return {
        "best_epoch": best_epoch,
        "best_val_mae_db": best_mae,
        "parameter_count": sum(p.numel() for p in model.parameters()),
        "logs": logs,
    }


def _matrix_from_residual(block, pairs, residual_db):
    matrix = torch.zeros_like(block.large_scale_power)
    tx, rx = pairs[:, 0], pairs[:, 1]
    matrix[tx, rx] = block.large_scale_power[tx, rx] * torch.pow(
        10.0, residual_db / 10.0
    )
    return matrix


def _mean_ci(values):
    values = np.asarray(values, dtype=np.float64)
    return {
        "mean": float(values.mean()),
        "ci95": float(1.96 * values.std(ddof=1) / np.sqrt(len(values)))
        if len(values) > 1 else 0.0,
    }


def _scheduler_records(
    models, predictions, sequences, net_gen, pairs, args
):
    records = []
    by_key = {
        (row["seed"], row["speed"], row["age"]): row
        for model_rows in predictions.values() for row in model_rows
    }
    # The traces are shared between MLP and GRU evaluation rows.
    unique_sequences = {
        (row["seed"], row["speed"], row["age"]): row
        for row in sequences
    }
    for key, sequence in unique_sequences.items():
        seed, speed, age = key
        trace = sequence["trace"]
        prediction_by_model = {}
        for name in LEARNED:
            match = next(
                row for row in predictions[name]
                if (row["seed"], row["speed"], row["age"]) == key
            )
            prediction_by_model[name] = match["predictions"]
        for row in sequence["rows"]:
            block_index = row["block_index"]
            true_state, true_ids = build_true_network_state(
                net_gen, trace, block_index
            )
            stale_state, stale_ids = build_observed_network_state(
                net_gen, trace, block_index, "stale", 4, stale_blocks=age
            )
            large_state, large_ids = build_observed_network_state(
                net_gen, trace, block_index, "large_scale", 4
            )
            analytic_power = conditional_expected_power(
                net_gen, trace, block_index, age
            )
            analytic_state, analytic_ids = build_network_state_from_power(
                net_gen, trace, block_index, analytic_power,
                csi_label="complex_conditional",
            )
            learned_states = {}
            for name in LEARNED:
                power = _matrix_from_residual(
                    trace.blocks[block_index], pairs,
                    prediction_by_model[name][block_index],
                )
                learned_states[name], learned_ids = build_network_state_from_power(
                    net_gen, trace, block_index, power, csi_label=name
                )
                if not torch.equal(true_ids, learned_ids):
                    raise RuntimeError("learned/true persistent IDs diverged")
            if not (
                torch.equal(true_ids, stale_ids)
                and torch.equal(true_ids, large_ids)
                and torch.equal(true_ids, analytic_ids)
            ):
                raise RuntimeError("baseline/true persistent IDs diverged")
            states = {
                "latest": true_state,
                "large_scale": large_state,
                "stale": stale_state,
                "complex_conditional": analytic_state,
                **learned_states,
            }
            for profile_index, profile in enumerate(PROFILES):
                queues = queue_snapshot(
                    true_state.num_vertices,
                    seed * 1_000_003 + block_index * 101
                    + profile_index * 10_000,
                    profile,
                )
                utilities = {}
                for name, state in states.items():
                    action = DirectLinkMarginalMP(
                        rounds=args.rounds
                    ).schedule_with_state(state, queues)
                    utilities[name] = float(mws_objective(
                        action, queues, true_state
                    ))
                records.append({
                    "seed": seed, "speed_mps": speed,
                    "stale_blocks": age,
                    "csi_age_ms": age * args.slots_per_block,
                    "block_index": block_index, "profile": profile,
                    **{f"{name}_utility": value for name, value in utilities.items()},
                })
        print(f"scheduler gate seed={seed} speed={speed:g} age={age}")
    return records


def _scheduler_summary(records, speed, age, profile):
    rows = [
        row for row in records
        if row["speed_mps"] == speed
        and row["stale_blocks"] == age
        and row["profile"] == profile
    ]
    by_seed = defaultdict(list)
    for row in rows:
        by_seed[row["seed"]].append(row)
    ratios = defaultdict(list)
    recovery = defaultdict(list)
    for seed_rows in by_seed.values():
        mean = {
            name: np.mean([row[f"{name}_utility"] for row in seed_rows])
            for name in (
                "latest", "large_scale", "stale", "complex_conditional",
                "complex_mlp", "complex_link_gru",
            )
        }
        for name in (
            "large_scale", "stale", "complex_conditional",
            "complex_mlp", "complex_link_gru",
        ):
            ratios[f"{name}_to_latest"].append(
                mean[name] / max(mean["latest"], 1e-12)
            )
            ratios[f"{name}_to_stale"].append(
                mean[name] / max(mean["stale"], 1e-12)
            )
        gap = mean["complex_conditional"] - mean["stale"]
        for name in LEARNED:
            recovery[name].append(
                (mean[name] - mean["stale"]) / max(gap, 1e-12)
            )
        ratios["gru_to_mlp"].append(
            mean["complex_link_gru"] / max(mean["complex_mlp"], 1e-12)
        )
    output = {key: _mean_ci(value) for key, value in ratios.items()}
    for key in (
        "complex_mlp_to_stale", "complex_link_gru_to_stale", "gru_to_mlp"
    ):
        output[key]["strict_seed_win_fraction"] = float(
            np.mean(np.asarray(ratios[key]) > 1.0 + 1e-9)
        )
    output["complex_mlp_fraction_analytic_gain_recovered"] = _mean_ci(
        recovery["complex_mlp"]
    )
    output["complex_link_gru_fraction_analytic_gain_recovered"] = _mean_ci(
        recovery["complex_link_gru"]
    )
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--speed_mps", default="2,5")
    parser.add_argument("--stale_blocks", default="1,2,4")
    parser.add_argument("--num_slots", type=int, default=100)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument("--train_seeds", default="100,101,102,103")
    parser.add_argument("--val_seeds", default="200")
    parser.add_argument("--test_seeds", default="42,43,44,45,46")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--bptt_blocks", type=int, default=8)
    parser.add_argument("--hidden_dim", type=int, default=16)
    parser.add_argument("--learning_rate", type=float, default=0.001)
    parser.add_argument("--seed", type=int, default=20260718)
    parser.add_argument(
        "--output",
        default="results/formal/complex_link_gru_gate_N20_ricianK5_20260718.json",
    )
    parser.add_argument(
        "--checkpoint",
        default="results/models/complex_link_gru_gate_N20_ricianK5_20260718.pth",
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0 or args.rician_k_db != 5.0:
        raise ValueError("Formal learned gate is frozen to N=20, 10 dBm, K=5 dB")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cpu")
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav, "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect", "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    net_gen = build_network_generator(config)
    pairs = _pair_catalog(args.num_uav)
    train_sequences = _all_sequences(
        net_gen, args, _parse_ints(args.train_seeds), pairs
    )
    val_sequences = _all_sequences(
        net_gen, args, _parse_ints(args.val_seeds), pairs
    )
    test_sequences = _all_sequences(
        net_gen, args, _parse_ints(args.test_seeds), pairs
    )
    stats = _stats(train_sequences)
    models = {
        "complex_mlp": ComplexGeometryCSIPredictor(10, args.hidden_dim).to(device),
        "complex_link_gru": ComplexLinkGRU(10, args.hidden_dim).to(device),
    }
    training = {}
    predictions = {}
    prediction_summary = {}
    for name, model in models.items():
        training[name] = _train(
            name, model, train_sequences, val_sequences, stats, args, device
        )
        predictions[name] = _evaluate_prediction(
            model, test_sequences, stats, device
        )
        prediction_summary[name] = {
            "mae_db": float(np.mean([row["mae_db"] for row in predictions[name]])),
            "p90_abs_error_db": float(np.mean([
                row["p90_abs_error_db"] for row in predictions[name]
            ])),
        }
    scheduler_records = _scheduler_records(
        models, predictions, test_sequences, net_gen, pairs, args
    )
    scheduler_summary = {
        f"v={speed:g}": {
            f"age={age}": {
                profile: _scheduler_summary(
                    scheduler_records, speed, age, profile
                )
                for profile in PROFILES
            }
            for age in _parse_ints(args.stale_blocks)
        }
        for speed in _parse_floats(args.speed_mps)
    }
    performance_cells = []
    temporal_specific_cells = []
    for speed in _parse_floats(args.speed_mps):
        for age in _parse_ints(args.stale_blocks):
            for profile in PROFILES:
                cell_name = f"v={speed:g}/age={age}/{profile}"
                cell = scheduler_summary[f"v={speed:g}"][f"age={age}"][profile]
                stale_loss = 1.0 - cell["stale_to_latest"]["mean"]
                gru_gain = cell["complex_link_gru_to_stale"]["mean"] - 1.0
                performance = bool(
                    stale_loss >= 0.08 and gru_gain >= 0.05
                    and cell["complex_link_gru_to_stale"][
                        "strict_seed_win_fraction"
                    ] >= 0.8
                )
                temporal = bool(
                    performance
                    and cell["gru_to_mlp"]["mean"] >= 1.02
                    and cell["gru_to_mlp"]["strict_seed_win_fraction"] >= 0.8
                    and cell[
                        "complex_link_gru_fraction_analytic_gain_recovered"
                    ]["mean"] >= 0.5
                )
                if performance:
                    performance_cells.append(cell_name)
                if temporal:
                    temporal_specific_cells.append(cell_name)
    decision = (
        "ACCEPT_MINIMAL_COMPLEX_LINK_GRU"
        if temporal_specific_cells
        else "STOP_COMPLEX_LINK_GRU_NO_SCHEDULING_VALUE"
    )
    checkpoint = Path(args.checkpoint)
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_version": "complex_link_gru_gate_v1",
        "settings": vars(args), "pair_catalog": pairs,
        "feature_mean": stats[0], "feature_std": stats[1],
        "target_mean": stats[2], "target_std": stats[3],
        "complex_mlp_state_dict": models["complex_mlp"].state_dict(),
        "complex_link_gru_state_dict": models["complex_link_gru"].state_dict(),
        "decision": decision,
    }, checkpoint)
    payload = {
        "experiment": "complex_link_gru_single_shot_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definition": (
            "Central training on complex aged CSI and geometry; link-local "
            "execution; predicted power matrix feeds unchanged Direct-Link MarginalMP."
        ),
        "training": training,
        "prediction_summary": prediction_summary,
        "scheduler_summary": scheduler_summary,
        "gates": {
            "performance_cells": performance_cells,
            "temporal_specific_cells": temporal_specific_cells,
            "requirements": (
                "stale loss >=8%, GRU gain >=5% with >=4/5 wins; GRU >=2pp "
                "over same-input MLP with >=4/5 wins; recover >=50% analytic gain"
            ),
        },
        "decision": decision,
        "checkpoint": str(checkpoint),
        "records": scheduler_records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "prediction_summary": prediction_summary,
        "performance_cells": performance_cells,
        "temporal_specific_cells": temporal_specific_cells,
        "decision": decision,
        "output": str(output),
        "checkpoint": str(checkpoint),
    }, indent=2))


if __name__ == "__main__":
    main()
