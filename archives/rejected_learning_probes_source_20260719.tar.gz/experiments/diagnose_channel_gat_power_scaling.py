#!/usr/bin/env python3
"""Power-scaling diagnostics for the conference channel-only GAT.

Stage 1 is intentionally training-free: it measures how transmit power changes
the candidate-link density before selecting a small, physically interpretable
set of train/test powers.  Later stages add the paired power-transfer matrix in
the same file so this task has one reproducible experiment entry point.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.project_setup import build_network_generator, load_config


def _csv(text: str, cast):
    return [cast(item.strip()) for item in text.split(",") if item.strip()]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num_uavs", default="10,20,30")
    parser.add_argument("--channels", default="rayleigh,rician")
    parser.add_argument("--powers_dbm", default="7,10,13,16,19,22,25,28,31")
    parser.add_argument("--num_samples", type=int, default=128)
    parser.add_argument("--seed", type=int, default=10086)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results/diagnostics/channel_gat_power_connectivity_20260716.json",
    )
    return parser.parse_args()


def reset_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def connectivity_probe(
    base_config: dict,
    *,
    num_uav: int,
    channel_model: str,
    power_dbm: float,
    rician_k_db: float,
    num_samples: int,
    seed: int,
) -> dict:
    config = dict(base_config)
    config.update({
        "NUM_UAV": int(num_uav),
        "CHANNEL_MODEL": channel_model,
        "RICIAN_K_DB": float(rician_k_db),
        "TX_POWER": float(power_dbm),
        "CSI_MODE": "perfect",
        "USE_QUEUE": False,
    })
    reset_seed(seed)
    generator = build_network_generator(config)
    threshold = 10.0 ** (float(config["SNR_THRES"]) / 10.0)
    max_links = num_uav * (num_uav - 1)
    link_counts = []
    for _ in range(num_samples):
        positions = generator._init_positions()
        _, _, snr, _ = generator._channel_gain(positions)
        link_counts.append(int((snr >= threshold).sum().item()))
    counts = np.asarray(link_counts, dtype=float)
    fractions = counts / float(max_links)
    return {
        "num_uav": int(num_uav),
        "channel_model": channel_model,
        "rician_k_db": float(rician_k_db) if channel_model == "rician" else None,
        "power_dbm": float(power_dbm),
        "num_samples": int(num_samples),
        "max_directed_links": int(max_links),
        "mean_candidate_links": float(counts.mean()),
        "median_candidate_links": float(np.median(counts)),
        "p10_candidate_links": float(np.quantile(counts, 0.10)),
        "p90_candidate_links": float(np.quantile(counts, 0.90)),
        "mean_connectivity_fraction": float(fractions.mean()),
        "fully_connected_state_fraction": float(np.mean(counts == max_links)),
    }


def main() -> None:
    args = parse_args()
    num_uavs = _csv(args.num_uavs, int)
    channels = _csv(args.channels, str)
    powers = _csv(args.powers_dbm, float)
    if any(channel not in {"rayleigh", "rician"} for channel in channels):
        raise ValueError("channels must be rayleigh and/or rician")
    base_config = load_config(ROOT / "configs/exp_example.yaml")
    rows = []
    for num_uav in num_uavs:
        for channel in channels:
            for power_dbm in powers:
                row = connectivity_probe(
                    base_config,
                    num_uav=num_uav,
                    channel_model=channel,
                    power_dbm=power_dbm,
                    rician_k_db=args.rician_k_db,
                    num_samples=args.num_samples,
                    seed=args.seed,
                )
                rows.append(row)
                print(
                    f"N={num_uav:2d} {channel:8s} P={power_dbm:5.1f} dBm: "
                    f"links={row['mean_candidate_links']:.1f}/"
                    f"{row['max_directed_links']} "
                    f"({row['mean_connectivity_fraction']:.1%}), "
                    f"full={row['fully_connected_state_fraction']:.1%}",
                    flush=True,
                )
    report = {
        "experiment": "channel_gat_power_connectivity_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "purpose": (
            "Choose train/test power points from candidate-link density before "
            "running the expensive GAT power-transfer matrix"
        ),
        "settings": {
            "num_uavs": num_uavs,
            "channels": channels,
            "powers_dbm": powers,
            "num_samples": args.num_samples,
            "seed": args.seed,
            "snr_threshold_db": float(base_config["SNR_THRES"]),
            "rician_k_db": args.rician_k_db,
            "normalized_small_scale_mean_power": 1.0,
        },
        "rows": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Saved {args.output}", flush=True)


if __name__ == "__main__":
    main()
