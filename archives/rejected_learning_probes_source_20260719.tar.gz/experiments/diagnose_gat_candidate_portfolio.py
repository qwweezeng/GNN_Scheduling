#!/usr/bin/env python3
"""No-training upper bound for a Pure/GAT two-candidate portfolio.

Pure and the conference GAT may be better viewed as complementary candidate
generators: Pure preserves queue urgency, while GAT proposes a channel-efficient
spatial-reuse pattern.  This centralized diagnostic selects the candidate with
the largest true instantaneous sum(QR).  It only tests whether a fixed K<=3
portfolio has enough graph-specific headroom to justify a distributed selector.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_mws_topology_scaling_headroom import (  # noqa: E402
    ConstantPriorModel,
    queue_snapshot,
)
from models.local_physical_reuse import (  # noqa: E402
    GATExpectedRateLocalPhysicalReuseScheduler,
    GATHardSeedPhysicalReuseScheduler,
    PurePhysicalReuseScheduler,
)
from utils.project_setup import (  # noqa: E402
    build_network_generator,
    load_channel_gat_checkpoint,
    load_config,
)
from utils.scheduling_objective import mws_objective  # noqa: E402


PROFILES = ("sparse", "heterogeneous", "saturated")


def paired_summary(records, candidate, reference):
    ratios = np.asarray([
        row[candidate] / max(abs(row[reference]), 1e-12)
        for row in records
    ])
    return {
        "mean_ratio": float(np.mean(ratios)),
        "ci95": float(
            1.96 * np.std(ratios, ddof=1) / np.sqrt(len(ratios))
        ) if len(ratios) > 1 else 0.0,
        "strict_win_fraction": float(np.mean(ratios > 1.0 + 1e-9)),
        "strict_loss_fraction": float(np.mean(ratios < 1.0 - 1e-9)),
    }


def summarize(records):
    selection_counts = {}
    for row in records:
        selection_counts[row["gat_portfolio_selected"]] = (
            selection_counts.get(row["gat_portfolio_selected"], 0) + 1
        )
    return {
        "gat_portfolio_over_pure": paired_summary(
            records, "gat_portfolio_utility", "pure_utility"
        ),
        "gat_portfolio_over_constant_portfolio": paired_summary(
            records, "gat_portfolio_utility", "constant_portfolio_utility"
        ),
        "constant_portfolio_over_pure": paired_summary(
            records, "constant_portfolio_utility", "pure_utility"
        ),
        "expected_gat_over_pure": paired_summary(
            records, "gat_expected_utility", "pure_utility"
        ),
        "hard_gat_over_pure": paired_summary(
            records, "gat_hard_utility", "pure_utility"
        ),
        "gat_portfolio_selection_counts": selection_counts,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--num_graphs", type=int, default=12)
    parser.add_argument("--seed", type=int, default=24680)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument(
        "--constant_probability", type=float,
        default=0.050029350853525105,
    )
    parser.add_argument(
        "--channel_gat_checkpoint",
        default=(
            "results/formal/channel_gat_power_transfer_N20_20260716/"
            "N20/rician/train_tx=10dBm/checkpoint.pth"
        ),
    )
    parser.add_argument("--minimum_gain_over_pure", type=float, default=1.02)
    parser.add_argument(
        "--minimum_gain_over_constant_portfolio", type=float, default=1.01
    )
    parser.add_argument("--minimum_win_fraction", type=float, default=0.60)
    parser.add_argument(
        "--output",
        default=(
            "results/formal/gat_candidate_portfolio_probe_"
            "N20_rician_20260717.json"
        ),
    )
    args = parser.parse_args()
    if args.num_uav != 20 or args.tx_power_dbm != 10.0:
        raise ValueError("This probe is frozen to N=20 and 10 dBm.")

    config = load_config(args.config)
    config.update({
        "NUM_UAV": 20,
        "TX_POWER": 10.0,
        "CSI_MODE": "perfect",
        "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    generator = build_network_generator(config)
    channel_model, checkpoint_path = load_channel_gat_checkpoint(
        config, args.channel_gat_checkpoint, 20,
        device="cpu", allow_power_transfer=False,
    )
    schedulers = {
        "pure": PurePhysicalReuseScheduler(channel_model),
        "gat_expected": GATExpectedRateLocalPhysicalReuseScheduler(channel_model),
        "gat_hard": GATHardSeedPhysicalReuseScheduler(channel_model),
        "constant_expected": GATExpectedRateLocalPhysicalReuseScheduler(
            ConstantPriorModel(args.constant_probability)
        ),
    }

    records = []
    for graph_offset in range(args.num_graphs):
        graph_seed = args.seed + graph_offset
        torch.manual_seed(graph_seed)
        np.random.seed(graph_seed)
        state = generator.generate_network(
            csi_mode="perfect", include_queue_feature=False
        )
        for profile_index, profile in enumerate(PROFILES):
            queues = queue_snapshot(
                state.num_vertices,
                graph_seed + 100_003 + 10_000 * profile_index,
                profile,
            )
            utilities = {}
            active_links = {}
            for name, scheduler in schedulers.items():
                action = scheduler.schedule_with_state(state, queues)
                utilities[name] = float(mws_objective(action, queues, state))
                active_links[name] = int(action.sum())
            gat_candidates = ("pure", "gat_expected", "gat_hard")
            gat_selected = max(gat_candidates, key=lambda name: utilities[name])
            constant_candidates = ("pure", "constant_expected")
            constant_selected = max(
                constant_candidates, key=lambda name: utilities[name]
            )
            record = {
                "graph_seed": graph_seed,
                "profile": profile,
                "num_links": int(state.num_vertices),
                "pure_utility": utilities["pure"],
                "gat_expected_utility": utilities["gat_expected"],
                "gat_hard_utility": utilities["gat_hard"],
                "constant_expected_utility": utilities["constant_expected"],
                "gat_portfolio_utility": utilities[gat_selected],
                "gat_portfolio_selected": gat_selected,
                "constant_portfolio_utility": utilities[constant_selected],
                "constant_portfolio_selected": constant_selected,
                "active_links": active_links,
            }
            records.append(record)
            print(
                f"seed={graph_seed} profile={profile:<13} "
                f"selected={gat_selected:<12} "
                f"portfolio/Pure={record['gat_portfolio_utility']/record['pure_utility']:.3f} "
                f"portfolio/ConstBank={record['gat_portfolio_utility']/record['constant_portfolio_utility']:.3f}"
            )

    by_profile = {
        profile: summarize([
            row for row in records if row["profile"] == profile
        ])
        for profile in PROFILES
    }
    profile_passed = {}
    for profile in ("heterogeneous", "saturated"):
        vs_pure = by_profile[profile]["gat_portfolio_over_pure"]
        vs_constant = by_profile[profile][
            "gat_portfolio_over_constant_portfolio"
        ]
        profile_passed[profile] = bool(
            vs_pure["mean_ratio"] >= args.minimum_gain_over_pure
            and vs_pure["strict_win_fraction"] >= args.minimum_win_fraction
            and vs_constant["mean_ratio"]
            >= args.minimum_gain_over_constant_portfolio
        )
    gate_passed = all(profile_passed.values())
    payload = {
        "experiment": "gat_pure_candidate_portfolio_upper_bound_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "motivation": (
            "Treat Pure as a queue-urgency candidate generator and the "
            "conference GAT as a channel-efficient candidate generator, then "
            "test whether choosing by true current sum(QR) creates material "
            "graph-specific headroom."
        ),
        "definitions": {
            "gat_portfolio": (
                "Centralized exact best of Pure, continuous-pi expected-rate "
                "GAT, and conference hard-seed GAT after common completion."
            ),
            "constant_portfolio": (
                "Centralized exact best of Pure and same-mean constant-pi "
                "expected-rate completion."
            ),
            "not_deployable": True,
        },
        "settings": vars(args),
        "channel_checkpoint": checkpoint_path,
        "by_profile": by_profile,
        "records": records,
        "predeclared_gate": {
            "required_profiles": ["heterogeneous", "saturated"],
            "minimum_gain_over_pure": args.minimum_gain_over_pure,
            "minimum_gain_over_constant_portfolio": (
                args.minimum_gain_over_constant_portfolio
            ),
            "minimum_win_fraction_vs_pure": args.minimum_win_fraction,
            "profile_passed": profile_passed,
            "gate_passed": gate_passed,
        },
        "decision": (
            "PROCEED_TO_DISTRIBUTED_TWO_CANDIDATE_SELECTOR"
            if gate_passed
            else "STOP_GAT_CANDIDATE_PORTFOLIO"
        ),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    print(json.dumps({
        "by_profile": by_profile,
        "predeclared_gate": payload["predeclared_gate"],
        "decision": payload["decision"],
        "output": str(output),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
