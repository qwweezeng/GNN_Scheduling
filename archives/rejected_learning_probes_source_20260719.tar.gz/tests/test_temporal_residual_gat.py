import unittest
from types import SimpleNamespace

import torch
import torch.nn as nn

from models.local_physical_reuse import (
    GATExpectedRateLocalPhysicalReuseScheduler,
)
from models.temporal_residual_gat import TemporalResidualChannelGAT


class TinySpatialGAT(nn.Module):
    def __init__(self):
        super().__init__()
        self.projection = nn.Linear(1, 3, bias=False)
        with torch.no_grad():
            self.projection.weight.copy_(torch.tensor([[1.0], [2.0], [-1.0]]))

    def schedule_logits(self, x, edge_index, edge_attr):
        del edge_index, edge_attr
        embedding = self.projection(x)
        return embedding[:, :1] / 2.0, embedding


def state(links, features):
    return SimpleNamespace(
        links=torch.tensor(links, dtype=torch.long),
        vertex_features=torch.tensor(features, dtype=torch.float32).reshape(-1, 1),
        edge_index=torch.empty(2, 0, dtype=torch.long),
        edge_weights=torch.empty(0, 1),
    )


class TemporalResidualGATTest(unittest.TestCase):
    def test_zero_residual_initialization_exactly_matches_spatial_model(self):
        model = TemporalResidualChannelGAT(
            TinySpatialGAT(), embedding_dim=3, temporal_hidden_dim=3
        ).freeze_spatial()
        current = state([[0, 1], [2, 3]], [2.0, 4.0])
        base, _ = model.spatial_model.schedule_logits(
            current.vertex_features, current.edge_index, current.edge_weights
        )
        temporal, _, _ = model.temporal_step(current, {})
        self.assertTrue(torch.equal(base, temporal))

    def test_hidden_state_is_keyed_by_directed_link_not_row_position(self):
        torch.manual_seed(3)
        model = TemporalResidualChannelGAT(
            TinySpatialGAT(), embedding_dim=3, temporal_hidden_dim=3
        ).freeze_spatial()
        first = state([[0, 1], [2, 3]], [2.0, 4.0])
        _, _, hidden = model.temporal_step(first, {})
        old_a = hidden[(0, 1)]
        old_b = hidden[(2, 3)]
        second = state([[2, 3], [0, 1]], [4.0, 2.0])
        _, embedding = model.spatial_model.schedule_logits(
            second.vertex_features, second.edge_index, second.edge_weights
        )
        expected_b = model.temporal_cell(embedding[0:1], old_b.unsqueeze(0))[0]
        expected_a = model.temporal_cell(embedding[1:2], old_a.unsqueeze(0))[0]
        _, _, updated = model.temporal_step(second, hidden)
        self.assertTrue(torch.allclose(updated[(2, 3)], expected_b))
        self.assertTrue(torch.allclose(updated[(0, 1)], expected_a))

    def test_new_scheduler_resets_runtime_history_between_simulations(self):
        model = TemporalResidualChannelGAT(
            TinySpatialGAT(), embedding_dim=3, temporal_hidden_dim=3
        ).freeze_spatial()
        model._runtime_hidden[(0, 1)] = torch.ones(3)
        GATExpectedRateLocalPhysicalReuseScheduler(model)
        self.assertEqual(model._runtime_hidden, {})


if __name__ == "__main__":
    unittest.main()
