"""Minimal physical-channel temporal predictors for the CSI feasibility gate.

Each graph node is one directed UAV-to-UAV physical channel ``(u, v)``.  This
catalog contains every ordered pair, so a single coherent predicted power
matrix supplies both desired-link and cross-interference gains to the existing
two-stage scheduler.
"""

import torch
from torch import nn

from models.model import GATLayer, NodeEmbedding


class PhysicalStateTemporalPredictor(nn.Module):
    """Predict the current dB residual around current large-scale power.

    ``use_spatial=False`` is the link-local GRU ablation.  ``use_spatial=True``
    inserts one conference-style GAT message round before the same GRU and
    regression head.  The recurrent state is indexed by the permanent directed
    UAV pair and therefore remains aligned across channel blocks.
    """

    def __init__(
        self,
        input_dim=4,
        embedding_dim=24,
        hidden_dim=24,
        edge_dim=4,
        use_spatial=True,
    ):
        super().__init__()
        self.input_dim = int(input_dim)
        self.embedding_dim = int(embedding_dim)
        self.hidden_dim = int(hidden_dim)
        self.edge_dim = int(edge_dim)
        self.use_spatial = bool(use_spatial)
        self.node_embed = NodeEmbedding(
            input_dim=self.input_dim,
            hidden_dims=[32],
            output_dim=self.embedding_dim,
        )
        self.spatial_layer = (
            GATLayer(
                node_dim=self.embedding_dim,
                edge_dim=self.edge_dim,
                out_dim=self.embedding_dim,
                num_heads=1,
            )
            if self.use_spatial else None
        )
        self.temporal_cell = nn.GRUCell(self.embedding_dim, self.hidden_dim)
        self.residual_head = nn.Sequential(
            nn.Linear(self.hidden_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
        )
        # At initialization both learned variants equal current large-scale CSI.
        nn.init.zeros_(self.residual_head[-1].weight)
        nn.init.zeros_(self.residual_head[-1].bias)

    def initial_hidden(self, num_pairs, device=None):
        device = device or next(self.parameters()).device
        return torch.zeros(int(num_pairs), self.hidden_dim, device=device)

    def forward_step(self, features, edge_index, edge_attr, hidden):
        embedding = self.node_embed(features)
        if self.spatial_layer is not None:
            embedding = self.spatial_layer(embedding, edge_index, edge_attr)
        updated = self.temporal_cell(embedding, hidden)
        residual = self.residual_head(updated).squeeze(-1)
        return residual, updated

