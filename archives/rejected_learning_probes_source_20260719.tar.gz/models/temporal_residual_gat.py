"""Minimal link-local temporal extension of the conference spatial GAT."""

import torch
from torch import nn


class TemporalResidualChannelGAT(nn.Module):
    """Add one persistent-link GRU residual to a frozen spatial channel GAT.

    The spatial GAT still performs every inter-link message exchange.  The GRU
    state is private to one directed physical link, identified by ``(tx, rx)``.
    Consequently this module adds local memory and computation, but no new
    neighbor-message round.
    """

    model_version = "channel_gat_temporal_residual_v1"

    def __init__(self, spatial_model, embedding_dim=48, temporal_hidden_dim=48):
        super().__init__()
        self.spatial_model = spatial_model
        self.embedding_dim = int(embedding_dim)
        self.temporal_hidden_dim = int(temporal_hidden_dim)
        self.temporal_cell = nn.GRUCell(
            self.embedding_dim, self.temporal_hidden_dim
        )
        self.residual_head = nn.Linear(self.temporal_hidden_dim, 1)
        # At initialization the deployed model is exactly the spatial baseline.
        nn.init.zeros_(self.residual_head.weight)
        nn.init.zeros_(self.residual_head.bias)
        self._runtime_hidden = {}

    def freeze_spatial(self):
        for parameter in self.spatial_model.parameters():
            parameter.requires_grad_(False)
        self.spatial_model.eval()
        return self

    def train(self, mode=True):
        super().train(mode)
        # The planned first temporal experiment always keeps space frozen.
        self.spatial_model.eval()
        return self

    def reset_temporal_state(self):
        self._runtime_hidden = {}

    @staticmethod
    def _link_keys(state):
        return [tuple(map(int, pair)) for pair in state.links.detach().cpu().tolist()]

    def temporal_step_from_embedding(
        self, link_keys, spatial_embedding, base_logits,
        hidden_by_link=None, detach_update=False,
    ):
        """Update temporal state from cached frozen-spatial outputs."""
        if hidden_by_link is None:
            hidden_by_link = {}
        device = next(self.temporal_cell.parameters()).device
        spatial_embedding = spatial_embedding.to(device).detach()
        base_logits = base_logits.to(device).detach()
        previous = torch.stack([
            hidden_by_link.get(
                key,
                torch.zeros(self.temporal_hidden_dim, device=device),
            ).to(device)
            for key in link_keys
        ])
        updated = self.temporal_cell(spatial_embedding, previous)
        logits = base_logits + self.residual_head(updated)
        for row, key in enumerate(link_keys):
            value = updated[row]
            hidden_by_link[key] = value.detach() if detach_update else value
        return logits, hidden_by_link

    def temporal_step(self, state, hidden_by_link=None, detach_update=False):
        """Process one block and update states aligned by permanent link ID."""
        if hidden_by_link is None:
            hidden_by_link = {}
        device = next(self.temporal_cell.parameters()).device
        with torch.no_grad():
            base_logits, spatial_embedding = self.spatial_model.schedule_logits(
                state.vertex_features[:, :1].to(device),
                state.edge_index.to(device),
                state.edge_weights.to(device),
            )
        keys = self._link_keys(state)
        logits, hidden_by_link = self.temporal_step_from_embedding(
            keys, spatial_embedding, base_logits, hidden_by_link, detach_update
        )
        return logits, spatial_embedding, hidden_by_link

    def detach_hidden(self, hidden_by_link):
        return {key: value.detach() for key, value in hidden_by_link.items()}

    def schedule_logits_with_state(self, state):
        logits, embedding, self._runtime_hidden = self.temporal_step(
            state, self._runtime_hidden, detach_update=True
        )
        return logits, embedding

    def schedule_logits(self, x, edge_index, edge_attr):
        """Stateless compatibility path used only by generic diagnostics."""
        with torch.no_grad():
            base_logits, embedding = self.spatial_model.schedule_logits(
                x, edge_index, edge_attr
            )
        zero = torch.zeros(
            embedding.size(0), self.temporal_hidden_dim,
            dtype=embedding.dtype, device=embedding.device,
        )
        hidden = self.temporal_cell(embedding.detach(), zero)
        return base_logits.detach() + self.residual_head(hidden), embedding

    def forward(self, x, edge_index, edge_attr, use_ste=False):
        logits, embedding = self.schedule_logits(x, edge_index, edge_attr)
        return torch.sigmoid(logits), embedding
