#!/usr/bin/env python3
"""Short dynamic-queue gate for the accepted complex-input local predictor.

The checkpoint is frozen.  Latest, aged CSI, current large-scale CSI, the
known-model complex conditional predictor, and the learned stateless MLP share
the same Rician trace and hotspot arrivals.  Every final service rate is
settled on current true CSI by Direct-Link MarginalMP.
"""

import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments.diagnose_complex_csi_prediction_gate import conditional_expected_power  # noqa: E402
from experiments.train_complex_link_gru_gate import (  # noqa: E402
    _matrix_from_residual,
    _pair_catalog,
    _sequence,
)
from models.complex_geometry_csi import ComplexGeometryCSIPredictor  # noqa: E402
from models.marginal_mp import DirectLinkMarginalMP  # noqa: E402
from simulator.mobile_block_fading import (  # noqa: E402
    generate_mobile_block_fading_trace,
    run_mobile_queue_simulation,
)
from utils.fixed_csi_benchmark import (  # noqa: E402
    arrival_trace_seed,
    generate_hotspot_arrivals,
)
from utils.project_setup import build_network_generator, load_config  # noqa: E402


METHODS = ("latest", "stale", "large_scale", "complex_conditional", "complex_mlp")


def _parse_ints(text):
    return [int(item) for item in str(text).split(",") if item.strip()]


def _parse_floats(text):
    return [float(item) for item in str(text).split(",") if item.strip()]


def _mean_ci(values):
    values = np.asarray(values, dtype=np.float64)
    return {
        "mean": float(values.mean()),
        "ci95": float(1.96 * values.std(ddof=1) / np.sqrt(len(values)))
        if len(values) > 1 else 0.0,
    }


@torch.no_grad()
def _predicted_powers(model, checkpoint, trace, pairs, net_gen, args):
    maximum_age = max(_parse_ints(checkpoint["settings"]["stale_blocks"]))
    rows = _sequence(
        trace, pairs, args.stale_blocks, args.speed_mps, maximum_age,
        net_gen.min_distance, net_gen.carrier_f, net_gen.tx_power,
    )
    feature_mean = checkpoint["feature_mean"]
    feature_std = checkpoint["feature_std"]
    target_mean = checkpoint["target_mean"]
    target_std = checkpoint["target_std"]
    powers = [block.large_scale_power.clone() for block in trace.blocks]
    for row in rows:
        normalized = (row["features"] - feature_mean) / feature_std
        output, _ = model.forward_step(normalized, None)
        residual_db = output.cpu() * target_std + target_mean
        powers[row["block_index"]] = _matrix_from_residual(
            trace.blocks[row["block_index"]], pairs, residual_db
        )
    return powers


def _conditional_powers(trace, net_gen, args):
    maximum_age = max(_parse_ints(args.training_stale_blocks))
    powers = [block.large_scale_power.clone() for block in trace.blocks]
    for block_index in range(maximum_age, len(trace.blocks)):
        powers[block_index] = conditional_expected_power(
            net_gen, trace, block_index, args.stale_blocks
        )
    return powers


def _summarize(records, arrival_rate, method):
    rows = [
        row for row in records
        if row["arrival_rate"] == arrival_rate and row["method"] == method
    ]
    return {
        "delivered_throughput_mbps": _mean_ci([
            row["delivered_throughput_mbps"] for row in rows
        ]),
        "physical_service_mbps": _mean_ci([
            row["physical_service_mbps"] for row in rows
        ]),
        "average_total_queue_backlog_mbit": _mean_ci([
            row["average_total_queue_backlog_mbit"] for row in rows
        ]),
        "successful_delivery_ratio": _mean_ci([
            row["successful_delivery_ratio"] for row in rows
        ]),
        "average_packet_delay_ms": _mean_ci([
            row["average_packet_delay_ms"]
            for row in rows if row["average_packet_delay_ms"] is not None
        ]),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/exp_example.yaml")
    parser.add_argument("--num_uav", type=int, default=20)
    parser.add_argument("--tx_power_dbm", type=float, default=10.0)
    parser.add_argument("--rician_k_db", type=float, default=5.0)
    parser.add_argument("--speed_mps", type=float, default=5.0)
    parser.add_argument("--slots_per_block", type=int, default=5)
    parser.add_argument("--stale_blocks", type=int, default=1)
    parser.add_argument("--training_stale_blocks", default="1,2,4")
    parser.add_argument("--num_slots", type=int, default=1000)
    parser.add_argument("--arrival_rates", default="2.2,4")
    parser.add_argument("--seeds", default="42,43,44,45,46")
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument(
        "--checkpoint",
        default="results/models/complex_link_gru_gate_N20_ricianK5_20260718.pth",
    )
    parser.add_argument(
        "--output",
        default="results/formal/complex_mlp_dynamic_gate_N20_ricianK5_20260718.json",
    )
    args = parser.parse_args()
    if (
        args.num_uav != 20 or args.tx_power_dbm != 10.0
        or args.rician_k_db != 5.0 or args.speed_mps != 5.0
        or args.stale_blocks != 1
    ):
        raise ValueError("Formal dynamic gate is frozen to N20/K5/v5/age1")
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if checkpoint["decision"] != "STOP_COMPLEX_LINK_GRU_NO_SCHEDULING_VALUE":
        raise RuntimeError("Unexpected upstream checkpoint decision")
    hidden_dim = int(checkpoint["settings"]["hidden_dim"])
    model = ComplexGeometryCSIPredictor(10, hidden_dim)
    model.load_state_dict(checkpoint["complex_mlp_state_dict"])
    model.eval()
    pairs = checkpoint["pair_catalog"].long()
    config = load_config(args.config)
    config.update({
        "NUM_UAV": args.num_uav, "TX_POWER": args.tx_power_dbm,
        "CSI_MODE": "perfect", "CHANNEL_MODEL": "rician",
        "RICIAN_K_DB": args.rician_k_db,
    })
    net_gen = build_network_generator(config)
    progress = Path(args.output).with_suffix(".progress.json")
    records = (
        json.loads(progress.read_text(encoding="utf-8"))["records"]
        if progress.exists() else []
    )
    completed = {
        (row["seed"], row["arrival_rate"], row["method"])
        for row in records
    }
    for seed in _parse_ints(args.seeds):
        trace = generate_mobile_block_fading_trace(
            net_gen, num_slots=args.num_slots,
            slots_per_block=args.slots_per_block, slot_duration=0.001,
            speed_mps=args.speed_mps, seed=seed,
            quantization_bits=(4,), rician_k_db=args.rician_k_db,
        )
        mlp_powers = _predicted_powers(
            model, checkpoint, trace, pairs, net_gen, args
        )
        conditional_powers = _conditional_powers(trace, net_gen, args)
        for arrival_rate in _parse_floats(args.arrival_rates):
            arrivals, profile = generate_hotspot_arrivals(
                args.num_slots, trace.num_links, arrival_rate,
                arrival_seed=arrival_trace_seed(seed, arrival_rate),
                hotspot_seed=seed,
            )
            for method in METHODS:
                if (seed, arrival_rate, method) in completed:
                    print(
                        f"resume-skip seed={seed} Lambda={arrival_rate:g} "
                        f"method={method}"
                    )
                    continue
                kwargs = {}
                csi_mode = method
                if method == "stale":
                    kwargs["stale_blocks"] = args.stale_blocks
                elif method == "complex_conditional":
                    kwargs.update({
                        "observed_power_by_block": conditional_powers,
                        "observed_csi_label": method,
                    })
                    csi_mode = "predicted"
                elif method == "complex_mlp":
                    kwargs.update({
                        "observed_power_by_block": mlp_powers,
                        "observed_csi_label": method,
                    })
                    csi_mode = "predicted"
                metrics = run_mobile_queue_simulation(
                    net_gen, DirectLinkMarginalMP(rounds=args.rounds),
                    trace, arrivals, csi_mode=csi_mode, q_bits=4,
                    packet_size=config.get("PACKET_SIZE", 12000), **kwargs,
                )
                records.append({
                    "seed": seed, "arrival_rate": arrival_rate,
                    "method": method,
                    "arrival_profile": profile["arrival_profile"],
                    **metrics,
                })
                progress.parent.mkdir(parents=True, exist_ok=True)
                progress.write_text(json.dumps({
                    "settings": vars(args), "records": records,
                }, indent=2), encoding="utf-8")
                print(
                    f"seed={seed} Lambda={arrival_rate:g} method={method} "
                    f"delivered={metrics['delivered_throughput_mbps']:.3f} "
                    f"backlog={metrics['average_total_queue_backlog_mbit']:.3f}"
                )
    summary = {
        f"Lambda={rate:g}": {
            method: _summarize(records, rate, method) for method in METHODS
        }
        for rate in _parse_floats(args.arrival_rates)
    }
    gates = {}
    passing = []
    for rate in _parse_floats(args.arrival_rates):
        load_rows = [row for row in records if row["arrival_rate"] == rate]
        baseline_names = ("stale", "large_scale")
        best_baseline = min(
            baseline_names,
            key=lambda name: summary[f"Lambda={rate:g}"][name][
                "average_total_queue_backlog_mbit"
            ]["mean"],
        )
        paired = []
        for seed in _parse_ints(args.seeds):
            baseline = next(
                row for row in load_rows
                if row["seed"] == seed and row["method"] == best_baseline
            )
            learned = next(
                row for row in load_rows
                if row["seed"] == seed and row["method"] == "complex_mlp"
            )
            paired.append({
                "seed": seed,
                "delivered_ratio": learned["delivered_throughput_mbps"]
                / max(baseline["delivered_throughput_mbps"], 1e-12),
                "physical_ratio": learned["physical_service_mbps"]
                / max(baseline["physical_service_mbps"], 1e-12),
                "backlog_ratio": learned["average_total_queue_backlog_mbit"]
                / max(baseline["average_total_queue_backlog_mbit"], 1e-12),
            })
        delivered = np.asarray([row["delivered_ratio"] for row in paired])
        physical = np.asarray([row["physical_ratio"] for row in paired])
        backlog = np.asarray([row["backlog_ratio"] for row in paired])
        joint_wins = int(np.sum(
            (delivered >= 1.0 - 1e-9)
            & (physical >= 1.0 - 1e-9)
            & (backlog <= 0.95)
        ))
        passed = bool(
            delivered.mean() >= 1.0
            and physical.mean() >= 1.0
            and backlog.mean() <= 0.95
            and joint_wins >= 4
        )
        gates[f"Lambda={rate:g}"] = {
            "best_nonpredictive_baseline": best_baseline,
            "complex_mlp_delivered_ratio": _mean_ci(delivered),
            "complex_mlp_physical_ratio": _mean_ci(physical),
            "complex_mlp_backlog_ratio": _mean_ci(backlog),
            "joint_seed_wins": joint_wins,
            "passed": passed,
        }
        if passed:
            passing.append(f"Lambda={rate:g}")
    decision = (
        "ACCEPT_COMPLEX_GEOMETRY_MLP_CSI_MODULE"
        if passing else "STOP_ALL_LEARNED_CSI_MODULES"
    )
    payload = {
        "experiment": "complex_mlp_short_dynamic_gate_v1",
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "settings": vars(args),
        "definition": (
            "Frozen stateless complex/geometry MLP predicts one coherent power "
            "matrix; unchanged Direct-Link MarginalMP serves current true channel."
        ),
        "summary": summary,
        "gates": gates,
        "passing_loads": passing,
        "decision": decision,
        "records": records,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "gates": gates, "passing_loads": passing,
        "decision": decision, "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
